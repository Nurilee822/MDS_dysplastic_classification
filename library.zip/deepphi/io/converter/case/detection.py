#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import time
import glob
import logging
import numpy as np
import xml.etree.cElementTree as ET
import multiprocessing

from deepphi.io.converter import TemplateConvereter
import deepphi.io.sitk
from deepphi.io.converter.statistics import StatDataset
from deepphi.io.converter.utils import *


class ConverterDetectionCase4(TemplateConvereter):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterDetectionCase4, self).__init__(dimension, *args, **kwargs)
        self.classes = multiprocessing.Manager().dict()

    def _check_structure(self, input_path):
        pass


    def _check_structure_this(self, path):
        list_val = ListCheckVal()

        path_dir = os.path.dirname(glob.glob(path + '/*')[0])
        dataset_name = get_dataset_name(path)
        label_name = get_label_name(path)

        path_dataset = '{}/{}'.format(path_dir, dataset_name)
        path_label = '{}/{}'.format(path_dir, label_name)

        list_img = [os.path.basename(c) for c in glob.glob(path_dataset + '/*')]
        list_label = [os.path.basename(c) for c in glob.glob(path_label + '/*')]

        # 이미지 마다 대응되는 라벨이 있는지 확인
        list_img_wo_exe = [os.path.splitext(img)[0] for img in list_img]
        list_label_wo_exe = [os.path.splitext(label)[0] for label in list_label]

        list_not_in_dataset = list()
        list_not_in_label = list()

        for filename in list_img_wo_exe:
            if filename not in list_label_wo_exe:
                list_not_in_label.append(filename)

        for filename in list_label_wo_exe:
            if filename not in list_img_wo_exe:
                list_not_in_dataset.append(filename)

        if list_not_in_label + list_not_in_dataset:
            msg = 'There are some mismatched files in your Dataset. Please check your Dataset or Label.csv.'
            cv = CheckVal('Missing File Error', "fail", msg, list_files=list_not_in_label + list_not_in_dataset)
            list_val.append(cv)
        list_val.Raise()

    def _get_work(self, input_path, output_path):
        self._check_structure_this(input_path)

        list_work = list()
        dataset_name = get_dataset_name(input_path)
        label_name = get_label_name(input_path)

        filename_image = np.array(sorted(glob.glob(input_path + '/{}/*'.format(dataset_name))))
        filename_label = np.array(sorted(glob.glob(input_path + '/{}/*'.format(label_name))))
        list_filename = zip(filename_image, filename_label)

        # logging.info(filename_image)
        for dataset_file, label_file in list_filename:
            filename_base = os.path.basename(dataset_file)
            output_file = output_path + '/' + '/{}.hdf5'.format(os.path.splitext(filename_base)[0])
            input_file = [dataset_file, label_file]
            list_work.append([input_file, output_file])

        return list_work

    def _update_stat(self, label_class):
        if len(label_class) == 0:
            return
        num_classes = np.sum(label_class, axis=0).astype('int')
        list_class = list(self.classes.keys())
        for i in range(len(num_classes)):
            name = list_class[i]
            count = int(self.statistics[name]['count'])
            count += num_classes[i]
            self.statistics[name]['count'] = int(count)

    def _add_class_info(self, filename):
        dataset = deepphi.io.sitk.DeepPhiDataSet()
        dataset.load(filename, decryption_key=self.encryption_key)

        # add class info
        num_class = len(dict(self.classes).keys())
        dataset['label']['object_detection']['header']['classes'] = dict(self.classes)
        dataset['label']['object_detection']['header']['class_name'] = list(dict(self.classes).keys())
        dataset['label']['object_detection']['header']['num_class'] = num_class

        logging.info(filename)
        logging.info(dict(self.classes))

        label_class = self.idx_class_to_sorted[dataset['label']['object_detection']['bbox_class'].astype('int')]
        label_one_hat = np.zeros([len(label_class), num_class])
        for i in range(len(label_class)):
            label_one_hat[i, label_class[i]] = 1

        dataset['label']['object_detection']['bbox_class'] = label_one_hat

        self.save(filename, dataset)
        logging.debug("Add Class Info : " + filename)
        self._update_stat(label_one_hat)

    def convert(self, input_path, output_path, num_worker=1, kafka_brokers=None):
        self._check_structure(input_path)

        list_work = self._get_work(input_path, output_path)

        num_work = len(list_work)
        # create batch
        batch_size = 20
        num_work = len(list_work)
        num_batch = num_work // batch_size + 1
        list_batch = [list_work[i*batch_size: (i+1)*batch_size] for i in range(num_batch+1) if len(list_work[i*batch_size: (i+1)*batch_size]) > 0]

        num_completed = 0
        start_time = time.time()
        num_batch = len(list_batch)
        for i in range(num_batch):
            batch = list_batch[i]
            logging.debug('Batch {} is Started, num_batch={}'.format(i, len(batch)))

            # convert batch
            with multiprocessing.Pool(num_worker) as p:
                result = p.map(self._work, batch)

            num_completed += len(batch)
            logging.info("[Converting] {} / {} Files".format(num_completed, num_work))
            time_info = self.cal_time_info(start_time, num_completed, num_work)
            self._send_msg_files(kafka_brokers, result, batch, time_info)

        # add class info
        class_sorted = np.sort(list(self.classes.keys()))
        idx_class_to_sorted = np.argsort(np.argsort(list(self.classes.keys())))

        dict_class = dict()
        for idx, name in enumerate(class_sorted):
            # sort dictionary key by alphabetical order
            dict_class[name] = idx
            self.statistics[name] = StatDataset(name, idx)
            self.statistics[name]['count'] = 0

        self.classes = dict_class
        self.idx_class_to_sorted = idx_class_to_sorted

        output_path = [work[1] for work in list_work]
        for i, path in enumerate(output_path):
            self._add_class_info(path)
            num_completed = i + 1
            if num_completed % 20 == 0:
                logging.info("[Add Info] {} / {} Files".format(num_completed, num_work))
            i += 1

        return self.statistics

    def _work(self, work):
        input_file, output_file = work
        dataset_file, label_file = input_file
        logging.debug('Convert {}'.format(dataset_file))

        if os.path.isdir(label_file):
            label_file = glob.glob(label_file + "/*")[0]

        data_input = self._load_dataset(dataset_file)
        label_input = self._load_label(label_file)

        data_output = data_input
        data_input['label']['object_detection']['bbox_coordinate'] = label_input['bboxes']
        data_input['label']['object_detection']['bbox_class'] = label_input['labels']

        logging.info(output_file)
        self.save(output_file, data_output)

        # create msg
        shape = list(data_output['image']['array'].shape)
        if not data_output['image']['header']['IsVector']:
            shape.append(1)

        color_mode = data_output['image']['header']['color_mode']
        result = {'shape': shape, 'color_mode': color_mode}
        return result

    def _load_dataset(self, filename):
        dataset = deepphi.io.sitk.DeepPhiDataSet()
        dataset.read_image(filename)
        return dataset

    def _load_label(self, filename):
        xml_root = ET.parse(filename).getroot()
        label = self.__parse_annotations(xml_root)
        return label

    def _findNode(self, parent, name, debug_name=None, parse=None):
        if debug_name is None:
            debug_name = name

        result = parent.find(name)
        if result is None:
            raise ValueError('missing element \'{}\''.format(debug_name))
        if parse is not None:
            try:
                return parse(result.text)
            except ValueError as e:
                raise ValueError('illegal value for \'{}\': {}'.format(debug_name, e))
        return result

    def __parse_annotation(self, element):
        class_name = self._findNode(element, 'name').text
        if class_name not in self.classes.keys():
            self.classes[class_name] = len(self.classes.keys())

        label = self.classes[class_name]

        if self._dimension == "2D":
            box = np.zeros((4,))
            bndbox = self._findNode(element, 'bndbox')
            box[0] = self._findNode(bndbox, 'ymin', 'bndbox.ymin', parse=float) - 1
            box[1] = self._findNode(bndbox, 'xmin', 'bndbox.xmin', parse=float) - 1
            box[2] = self._findNode(bndbox, 'ymax', 'bndbox.ymax', parse=float) - 1
            box[3] = self._findNode(bndbox, 'xmax', 'bndbox.xmax', parse=float) - 1

        elif self._dimension == "3D":
            box = np.zeros((6,))
            bndbox = self._findNode(element, 'bndbox')
            box[0] = self._findNode(bndbox, 'zmin', 'bndbox.zmin', parse=float) - 1
            box[1] = self._findNode(bndbox, 'ymin', 'bndbox.ymin', parse=float) - 1
            box[2] = self._findNode(bndbox, 'xmin', 'bndbox.xmin', parse=float) - 1

            box[3] = self._findNode(bndbox, 'zmax', 'bndbox.zmax', parse=float) - 1
            box[4] = self._findNode(bndbox, 'ymax', 'bndbox.ymax', parse=float) - 1
            box[5] = self._findNode(bndbox, 'xmax', 'bndbox.xmin', parse=float) - 1

        else:
            raise Exception()

        return box, label

    def __parse_annotations(self, xml_root):
        if self._dimension == "2D":
            annotations = {'labels': np.empty((len(xml_root.findall('object')),)),
                           'bboxes': np.empty((len(xml_root.findall('object')), 4))}
        elif self._dimension == "3D":
            annotations = {'labels': np.empty((len(xml_root.findall('object')),)),
                           'bboxes': np.empty((len(xml_root.findall('object')), 6))}

        for i, element in enumerate(xml_root.iter('object')):
            try:
                box, label = self.__parse_annotation(element)
            except ValueError as e:
                raise ValueError('could not parse object #{}: {}'.format(i, e))

            annotations['bboxes'][i, :] = box
            annotations['labels'][i] = label

        return annotations


if __name__ == '__main__':
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    input_path = '/home/swseo-ubuntu/mnt/sda2/datasets/converter_test/test_zip/case4_2D'
    output_path = '/home/swseo-ubuntu/mnt/sda2/datasets/deepphi_beta_result/Pascal_VOC/'

    dimension = '2D'

    converter = ConverterDetectionCase4(dimension)
    converter.convert(input_path, output_path)
