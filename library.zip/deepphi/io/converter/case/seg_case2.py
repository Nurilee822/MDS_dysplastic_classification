#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import glob
import numpy as np
import SimpleITK as sitk
import pandas as pd
import parse

import deepphi.io.sitk
import logging

from deepphi.io.converter.case.segmentation import ConverterSeg
from deepphi.io.converter.utils import *
from deepphi.io.converter.statistics import StatDataset


class ConverterSegCase2(ConverterSeg):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterSegCase2, self).__init__(dimension, *args, **kwargs)
        self.class_name = list()
        self.class_value = list()

    def _check_structure(self, input_path):
        pass

    def initialization(self, input_path):
        filename = get_name_xlsx(input_path)
        self.class_name, self.class_value_idx, self.series_independent = read_class_xlsx(filename)
        self.class_value = np.arange(len(self.class_name)).astype('int')
        self._add_class_name_in_stat()

    def _create_empty_label(self, img_shape):
        img_shape = list(img_shape)
        max_value = len(self.class_name)
        label_shape = img_shape + [max_value]
        empty_label = np.zeros(label_shape).astype('bool')
        empty_label[..., 0] = True
        return empty_label

    def get_segmentation_label(self, data_input, label_input, is_empty='empty dir'):
        label_input = self.validation_label(data_input, label_input)

        label_shape = label_input['array'].shape
        label_shape = label_shape[:-1]
        label_array = self._create_empty_label(label_shape)

        list_filename = label_input['header']['file_name']
        for i in range(len(list_filename)):
            filename = list_filename[i]
            mask = label_input['array'][..., i]
            #
            cls_name = self.get_class_from_name(filename)
            idx = self.class_name.index(cls_name)
            value = self.class_value_idx[idx]
            if isinstance(value, list):
                logging.info(value)
                mask = (mask >= value[0]) & (mask <= value[1])
            else:
                mask = (mask == value)

            label_array[..., idx] = (mask | label_array[..., idx])
            #background
            label_array[..., 0] = label_array[..., 0] & ~mask

        label_input['file_array'] = label_input['array'][:]
        label_input['array'] = label_array.astype('uint8')

        # set num_class
        label_input['header']['num_class'] = label_input['array'].shape[-1]
        label_input['header']['class_name'] = self.class_name
        label_input['header']['class_number'] = self.class_value

        label_input['header']['dim'] = len(label_input['array'].shape) - 1

        return label_input

    def get_class_from_name(self, filename):
        basename = os.path.basename(filename)
        filename_wo_exe = get_filename_wo_exe(basename)
        class_name_this = filename_wo_exe.split('-')[0]
        return class_name_this


if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = './hb_text/ex1/'

    dimension = '2D'
    converter = ConverterSegCase2(dimension)
    converter.convert(path, './')
