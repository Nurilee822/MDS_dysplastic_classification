#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import glob
import numpy as np
import SimpleITK as sitk
import pandas as pd
import parse

import deepphi.io.sitk
import logging

from deepphi.io.converter.case.classification import ConverterClassification
from deepphi.io.converter.utils import *


class ConverterCase1(ConverterClassification):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterCase1, self).__init__(dimension, *args, **kwargs)

    def _check_structure(self, input_path):
        pass

    def _get_class(self, path):
        path_basename = os.path.basename(path)
        parsing = parse.parse("{class}{number:d}.{exe}", path_basename)

        if parsing['class'] not in self.cls:
            msg = 'The class "{}" for "{}" is not included in "Label.csv"'.format(parsing['class'], path_basename)
            raise Exception(msg)

        logging.debug((path, parsing['class']))

        return parsing['class']

    def _get_work(self, input_path, output_path):
        path_csv = glob.glob(input_path + '/*.csv')[0]
        label_csv = pd.read_csv(path_csv, header=None, encoding='cp949')
        self.cls = list(label_csv[0])

        list_work = list()
        dataset_name = get_dataset_name(input_path)
        list_filename = glob.glob(input_path + '/{}/*'.format(dataset_name))

        for filename in list_filename:
            class_name = self._get_class(filename)
            id_cls = self.cls.index(class_name)

            # make one-hat
            label_class = np.zeros(len(self.cls))
            label_class[id_cls] = 1

            output_file = ('.').join(filename.split('.')[:-1])
            output_file = output_path + '/{}.hdf5'.format(os.path.basename(output_file))
            list_work.append([filename, output_file, label_class])

        self._add_class_name_in_stat()
        return list_work

    def load(self, filename):
        dataset = deepphi.io.sitk.DeepPhiDataSet()
        dataset.read_image(filename)
        return dataset


if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = '/home/swseo-ubuntu/mnt/sda2/datasets/converter_test/case1_2D'

    dimension = '2D'
    converter = ConverterCase1(dimension)
    converter.convert(path, './')
