#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import glob
import numpy as np
import SimpleITK as sitk
import pandas as pd
import parse

import deepphi.io.sitk
import logging

from deepphi.io.converter.case.segmentation import ConverterSeg
from deepphi.io.converter.utils import *
from deepphi.io.converter.statistics import StatDataset


class ConverterSegCase1(ConverterSeg):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterSegCase1, self).__init__(dimension, *args, **kwargs)
        self.class_name = list()
        self.class_value = list()

    def _check_structure(self, input_path):
        pass

    def initialization(self, input_path):
        print(glob.glob(input_path + "/*"))
        filename = get_name_xlsx(input_path)
        print(filename)
        self.class_name, self.class_value, self.series_independent = read_class_xlsx(filename)
        self._add_class_name_in_stat()

    def get_segmentation_label(self, data_input, label_input):
        label_input = self.validation_label(data_input, label_input)
        # make boolean mask
        list_mask = list()
        if len(self.class_name) == 2:
            label_input['array'] = label_input['array'][..., 0]

        for value in self.class_value:
            if isinstance(value, list):
                mask = (label_input['array'] >= value[0]) & (label_input['array'] <= value[1])
                mask = mask.squeeze()
            else:
                mask = (label_input['array'] == value).squeeze()
            list_mask.append(mask)

        label_input['array'] = np.stack(list_mask, axis=-1).astype("uint8")
        # set num_class
        label_input['header']['num_class'] = label_input['array'].shape[-1]
        label_input['header']['class_name'] = self.class_name
        label_input['header']['class_number'] = self.class_value

        return label_input

    def _get_seg_label_multi_channel(self):
        pass

    def _get_seg_label_multi_value(self):
        pass


if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = '/home/hslisalee/Desktop/dataset/trans_example'
    # path = '/home/swseo-ubuntu/mnt/sda2/datasets/converter_test/test_zip/TEST/'

    dimension = '3D'
    converter = ConverterSegCase1(dimension)
    converter.convert(path, './')
