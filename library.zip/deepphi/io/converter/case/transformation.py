#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import glob
import SimpleITK as sitk
import numpy as np

import deepphi.io.sitk
import logging
import parse
from deepphi.io.converter import TemplateConvereter
from deepphi.io.converter.statistics import StatDataset
from deepphi.io.converter.utils import *


class ConverterTrans(TemplateConvereter):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterTrans, self).__init__(dimension, *args, **kwargs)
        self.series_independent = 'no'
        self._batch_count = 0

    def _check_structure(self, input_path):
        pass

    def initialization(self, input_path):
        pass

    def _check_structure_this(self, input_path):
        dataset_name = get_dataset_name(input_path)
        label_name = get_label_name(input_path)

        list_img = glob.glob(input_path + '/{}/*'.format(dataset_name))
        list_label = glob.glob(input_path + '/{}/*'.format(label_name))

        # 이미지 마다 대응되는 라벨이 있는지 확인
        list_img_wo_exe = list()
        list_label_wo_exe = list()

        for img in list_img:
            basename = os.path.basename(img)
            if not os.path.isdir(img):
                list_img_wo_exe.append(parse.parse("{filename}.{exe}", basename)['filename'])
            else:
                list_img_wo_exe.append(basename)

        for label in list_label:
            basename = os.path.basename(label)
            if not os.path.isdir(label):
                list_label_wo_exe.append(parse.parse("{filename}.{exe}", basename)['filename'])
            else:
                list_label_wo_exe.append(basename)

        list_not_in_dataset = list()
        list_not_in_label = list()

        for filename in list_img_wo_exe:
            if filename not in list_label_wo_exe:
                list_not_in_label.append(filename)

        for filename in list_label_wo_exe:
            if filename not in list_img_wo_exe:
                list_not_in_dataset.append(filename)

        for filename in list_not_in_dataset:
            logging.error(
                'The Filename "{}" in Label Folder is not Included in Dataset Folder. Please Check your Dataset.'.format(
                    filename))

        for filename in list_not_in_label:
            logging.error(
                'The Filename "{}" in Dataset Folder is not Included in Label Folder. Please Check your Dataset.'.format(
                    filename))

        if list_not_in_dataset + list_not_in_label:
            raise Exception('There are some mismatched files in your Dataset. Please check your Dataset or Label.')

    def _get_work(self, input_path, output_path):
        dataset_name = get_dataset_name(input_path)
        label_name = get_label_name(input_path)

        self.initialization(input_path)
        list_work = list()
        filename_image = np.array(sorted(glob.glob(input_path + '/{}/*'.format(dataset_name))))
        filename_label = np.array(sorted(glob.glob(input_path + '/{}/*'.format(label_name))))
        list_filename = zip(filename_image, filename_label)

        for filename in list_filename:
            dataset_file = filename[0]
            label_file = filename[1]
            filename_base = os.path.basename(dataset_file)

            output_file = output_path + '/' + '/{}.hdf5'.format(os.path.splitext(filename_base)[0])
            list_work.append([[dataset_file, label_file], output_file])

        return list_work

    def _work(self, work):
        try:
            input_file, output_file = work
            dataset_file, label_file = input_file
            logging.debug('Convert {}'.format(dataset_file))

            logging.debug("Start Convert : " + dataset_file)

            data_input = self.load(dataset_file)
            logging.debug("image loaded : " + dataset_file)

            label_input = deepphi.io.sitk.DeepPhiImage()
            ret = label_input.read_image(label_file, mask=False)
            if ret == 'empty_dir':
                return 'pass'
            label_input = self.get_transformation_label(data_input, label_input)

            data_input['label']['transformation'] = label_input
            logging.info(data_input['label']['transformation'].keys())

            data_output = data_input
            self.save(output_file, data_output)
            logging.debug("End Convert : " + output_file)
            # create msg
            shape = list(data_output['image']['array'].shape)
            if not data_output['image']['header']['IsVector']:
                shape.append(1)

            color_mode = data_output['image']['header']['color_mode']

            result = {'shape': shape, 'color_mode': color_mode, 'stat_info': None}
            return result
        except Exception:
            logging.error('error occurred in filename: {}'.format(os.path.basename(dataset_file)))
            logging.error('error occurred in filename: {}'.format(os.path.basename(dataset_file)))
            logging.error('error occurred in filename: {}'.format(os.path.basename(dataset_file)))
            logging.error('error occurred in filename: {}'.format(os.path.basename(dataset_file)))

            import traceback
            traceback = traceback.format_exc()
            raise Exception(traceback)

    def load(self, filename):
        logging.debug("image load start: " + filename)
        dataset = deepphi.io.sitk.DeepPhiDataSet()
        dataset.read_image(filename)
        logging.debug("image load end: " + filename)
        return dataset

    def get_transformation_label(self, data_input, label_input):
        return label_input

    def validation_label(self, data_input, label_input):
        image_shape = data_input['image']['array'].shape
        if data_input['image']['header']['IsVector']:
            image_shape = image_shape[:-1]

        label_shape = label_input['array'].shape

        ######## check label channel axis ####
        if len(label_shape) == len(image_shape):
            label_input['header']['IsVector'] = False
        elif len(image_shape) == len(label_shape) - 1:
            label_input['header']['IsVector'] = True
        else:
            dim_image = len(image_shape)
            dim_label = len(label_shape) - label_input['header']['IsVector']
            raise Exception('The Dimension of the Label ({}D) is Different with the Dimension of Data ({}D). Please Check the Dimension of the Label.'.format(dim_image, dim_label))

        if label_input['header']['IsVector']:
            ########### check channel first   ###############
            if image_shape == label_shape[:-1]:
                # channel last
                channel = 'last'
            elif image_shape == label_shape[1:]:
                # channel first
                logging.info("-------------------------------------")
                logging.info(image_shape)
                logging.info(label_input['array'].shape)
                logging.info("-------------------------------------")

                if len(label_input['array'].shape) == 3:
                    label_input['array'] = np.transpose(label_input['array'], [1, 2, 0])
                elif len(label_input['array'].shape) == 4:
                    label_input['array'] = np.transpose(label_input['array'], [1, 2, 3, 0])
            else:
                pass
                #############################################

        return label_input



if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = ['/home/swseo-ubuntu/mnt/sda2/datasets/deepphi_beta/Lee']

    fraction = [80, 10, 10]
    dimension = '2D'
    converter = ConverterTrans(fraction, dimension)
    converter.convert(path, './')

