#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import glob
import numpy as np
import pandas as pd
import SimpleITK as sitk

import deepphi.io.sitk
import logging

from deepphi.io.converter.case.classification import ConverterClassification
from deepphi.io.converter.utils import *

class ConverterCase3(ConverterClassification):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterCase3, self).__init__(dimension, *args, **kwargs)

    def _check_structure(self, input_path):
        pass

    def _check_structure_this(self, input_path):
        list_val = ListCheckVal()

        dataset_name = get_dataset_name(input_path)
        path_total = np.array(glob.glob(input_path + '/{}/*'.format(dataset_name)))
        path_total_base = list()
        for filename in path_total:
            path_total_base.append(os.path.basename(filename))

        path_csv = glob.glob(input_path + '/*.csv')[0]

        label_csv = pd.read_csv(path_csv, dtype=str)

        list_filename_csv = list(label_csv[label_csv.columns[0]])

        not_in_list = list()
        for filename in list_filename_csv:
            if filename not in path_total_base:
                not_in_list.append(input_path + '/{}/{}'.format(dataset_name, filename))

        not_in_list2 = list()
        for filename in path_total_base:
            if filename not in list_filename_csv:
                not_in_list2.append(input_path + '/{}/{}'.format(dataset_name, filename))

        if not_in_list + not_in_list2:
            msg = 'There are some mismatched files in your Dataset. Please check your Dataset or Label.csv.'
            cv = CheckVal('Missing File Error', "fail", msg, list_files=not_in_list + not_in_list2)
            list_val.append(cv)
        list_val.Raise()

        # if not_in_list:
        #     for filename in not_in_list:
        #         logging.error('The filename "{}", included in the "Label.csv", is not in the "Dataset" folder. '.format(filename, filename))
        #
        #     logging.debug(input_path)
        #     raise Exception('There are some mismatched files in your Dataset. Please check your Dataset or Label.csv.')
        #
        # if not_in_list2:
        #     for filename in not_in_list2:
        #         logging.error('The filename "{}", included in the "Dataset", is not in the "Label.csv".'.format(filename, filename))
        #     logging.debug(input_path)
        #     raise Exception('There are some mismatched files in your Dataset. Please check your Dataset or Label.csv.')

    def _check_cls(self, input_path):
        list_dir = glob.glob(input_path + '/*')
        list_dir_basename = list()

        for dir_path in list_dir:
            list_dir_basename.append(os.path.basename(dir_path))

        self.cls = list(np.sort(list_dir_basename))
        logging.info("Class Info: {}".format(self.cls))

    def _get_work(self, input_path, output_path):
        self._check_structure_this(input_path)
        path_csv = glob.glob(input_path + '/*.csv')[0]
        label_csv = pd.read_csv(path_csv, dtype=str)
        label_csv = label_csv.set_index(label_csv.columns[0])

        dataset_name = get_dataset_name(input_path)
        list_filename = glob.glob(input_path + '/{}/*'.format(dataset_name))

        self.cls = label_csv.columns
        if len(self.cls) == 1:  # binary case
            list_label = list(label_csv[label_csv.columns[0]])
            self.cls = list(np.sort(np.unique(list_label)))
            case = '3-1'
        else:
            case = '3-2'

        list_work = list()

        for filename in list_filename:
            filename_base = os.path.basename(filename)

            if case == '3-1':
                label_class = np.zeros(len(self.cls))
                class_name = label_csv.loc[filename_base][0]
                label = self.cls.index(class_name)
                label_class[label] = 1
            else:
                label_class = np.array(label_csv.loc[filename_base])

            if os.path.isdir(filename):
                output_file = filename
            else:
                output_file = ('.').join(filename.split('.')[:-1])

            output_file = output_path + '/' + '/{}.hdf5'.format(os.path.basename(output_file))
            list_work.append([filename, output_file, label_class])

        self._add_class_name_in_stat()
        return list_work

    def load(self, filename):
        dataset = deepphi.io.sitk.DeepPhiDataSet()
        dataset.read_image(filename)
        return dataset


if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = '/home/swseo-ubuntu/mnt/sda2/datasets/converter_test/test_zip/case3-1_2D'

    dimension = '2D'
    converter = ConverterCase3(dimension)
    converter.convert(path, './')

    # path = ['/home/swseo-ubuntu/mnt/sda2/datasets/converter_test/case2_3D']
    #
    # fraction = [80, 10, 10]
    # dimension = '3D'
    # converter = ConverterCase2(fraction, dimension)
    # converter.convert(path, './')

