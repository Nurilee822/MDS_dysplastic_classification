#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import glob
import numpy as np
import SimpleITK as sitk
import pandas as pd
import parse

import deepphi.io.sitk
import logging

from deepphi.io.converter.case.transformation import ConverterTrans
from deepphi.io.converter.utils import *
from deepphi.io.converter.statistics import StatDataset


class ConverterTransCase1(ConverterTrans):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterTransCase1, self).__init__(dimension, *args, **kwargs)

    def _check_structure(self, input_path):
        pass

    def get_transformation_label(self, data_input, label_input):
        label_input = self.validation_label(data_input, label_input)
        return label_input


if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = '/home/hslisalee/Desktop/dataset/trans_example/2D_jpg'

    dimension = '2D'
    converter = ConverterTransCase1(dimension)
    converter.convert(path, './')