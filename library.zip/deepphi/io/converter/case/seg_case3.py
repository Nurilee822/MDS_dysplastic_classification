#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import glob
import numpy as np
import SimpleITK as sitk
import pandas as pd
import parse

import deepphi.io.sitk
import logging

from deepphi.io.converter.case.seg_case2 import ConverterSegCase2
from deepphi.io.converter.utils import *
from deepphi.io.converter.statistics import StatDataset


class ConverterSegCase3(ConverterSegCase2):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterSegCase3, self).__init__(dimension, *args, **kwargs)
        self.class_name = list()
        self.class_value = list()

    def _check_structure(self, input_path):
        pass

    def initialization(self, input_path):
        self.class_name, self.class_value = ['background', 'target'], [0, 1]
        self._add_class_name_in_stat()

    def get_segmentation_label(self, data_input, label_input):
        label_input = self.validation_label(data_input, label_input)
        self._validataion(label_input)

        # make boolean mask
        list_mask = list()

        pixel_values = np.unique(label_input['array'])

        value = label_input['array']
        if (min(pixel_values) == 0) and (max(pixel_values) == 255):
            label_input['array'][value < 125] = 0
            label_input['array'][value >= 125] = 255

        #background
        mask = (label_input['array'] == 0).squeeze()
        list_mask.append(mask)
        #target
        mask = (label_input['array'] != 0).squeeze()
        list_mask.append(mask)

        label_input['array'] = np.stack(list_mask, axis=-1)
        # set num_class
        label_input['header']['num_class'] = label_input['array'].shape[-1]
        label_input['header']['class_name'] = self.class_name
        label_input['header']['class_number'] = self.class_value

        return label_input

    def _validataion(self, label_input):
        # check multi-channel
        num_channel = label_input['array'].shape[-1]
        if num_channel > 1:
            msg = "The number of channels in your label file is {}. ".format(num_channel)
            msg += "If there are multiple classes in the label file, an Excel file with class information is required. See the manual for details."
            raise Exception(msg)

        # check binary
        pixel_values = np.unique(label_input['array'])
        if (min(pixel_values) == 0) and (max(pixel_values) == 255):
            return

        num_value = len(pixel_values)
        if num_value > 2:
            msg = "There are too many pixel values in your label file."
            msg += "\n- pixel values - "
            msg += "\n{}".format(pixel_values)
            raise Exception(msg)



if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = '/home/swseo-ubuntu/mnt/sda2/datasets/converter_test/test_zip/lung_seg'
    path = '/home/swseo-ubuntu/mnt/sda2/datasets/converter_test(old)/case7_2D'

    dimension = '2D'
    converter = ConverterSegCase3(dimension)
    converter.convert(path, './')
