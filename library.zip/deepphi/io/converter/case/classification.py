#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import glob
import numpy as np
import SimpleITK as sitk
import pandas as pd
import parse

import deepphi.io.sitk
import logging

from deepphi.io.converter import TemplateConvereter
from deepphi.io.converter.statistics import StatDataset



class ConverterClassification(TemplateConvereter):
    def __init__(self, dimension, *args, **kwargs):
        super(ConverterClassification, self).__init__(dimension, *args, **kwargs)
        self.cls = list()
        self.statistics = dict()

    def _update_stat(self, stat):
        if len(stat) == 0:
            return
        num_classes = np.sum(stat, axis=0).astype('int')
        for i in range(len(num_classes)):
            name = self.cls[i]
            count = int(self.statistics[name]['count'])
            count += num_classes[i]
            self.statistics[name]['count'] = int(count)

        logging.debug(self.statistics)

    def _add_class_name_in_stat(self):
        for idx in range(len(self.cls)):
            name = self.cls[idx]
            self.statistics[name] = StatDataset(name, idx)
            self.statistics[name]['count'] = 0

    def _work(self, work):
        input_file, output_file, label = work
        logging.debug('Convert {}'.format(input_file))

        data_input = self.load(input_file)
        # one-hot encoding
        data_input['label']['classification']['array'] = np.array(label).astype('int')
        # print(data_input['label']['classification']['array'])
        data_input['label']['classification']['header'] = {'num_class': len(label), 'class_name': list(self.cls)}
        data_output = data_input

        self.save(output_file, data_output)
        # create msg
        shape = list(data_output['image']['array'].shape)
        if not data_output['image']['header']['IsVector']:
            shape.append(1)
        color_mode = data_output['image']['header']['color_mode']

        result = {'shape': shape, 'color_mode': color_mode, 'stat_info': label}
        return result


if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = '/home/swseo-ubuntu/mnt/sda2/datasets/converter_test/case1_2D'

    dimension = '2D'
    converter = ConverterCase1(dimension)
    converter.convert(path, './')
