#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
import os
import time
import glob
import logging
import json
import numpy as np
import copy
import multiprocessing
import deepphi.io.sitk
from deepphi.io.converter.utils import *
from deepphi.image_processing.__init__ import Converter

MSG_RESULT = {"execution_type": "CONVERT", "status": "in_progress", "msg_err": list(), "list_files_err": [],
              "result_unpack": {"path_structure": ""},
              "result_convert": {
                        "file_info": {
                                     "hdf5_info": [],
                                     "time": {
                                         "elapsed_time": 0,
                                         "remaining_time": 0,
                                         "progress": 0
                                     }
                                 }
              },
              "result_class_info": {
                  "class_info": list(),
              }
              }


class TemplateConvereter(Converter):
    def __init__(self, dimension, modality=None, *args, **kwargs):
        super(TemplateConvereter, self).__init__(*args, **kwargs)

        self._dimension = dimension
        self.statistics = dict()
        self.list_type = ['train', 'test', 'val']
        self.modality = modality

    def _update_stat(self, stat):
        pass

    def _do_work(self, work):
        try:
            result = self._work(work)
            return result
        except Exception as e:
            input_files = work[0]
            output_files = work[1]

            if isinstance(input_files, list):
                list_files = input_files
            else:
                list_files = [input_files]
            msg = 'Fail to Create hdf5 file named "{}"'.format(os.path.basename(output_files))
            msg += '\n\n' + str(e)
            raise ConvertException(msg, list_msg_err=list_files)

    def import_meta_data(self, input_filename, output_data):
        return output_data

    def convert(self, input_path, output_path, num_worker=1, kafka_brokers=None, batch_unit_size=20):
        num_worker = 4
        batch_unit_size = num_worker
        spending_time_per_batch = 2

        logging.info('-' * 80)

        for path in input_path:
            self._check_structure(path)

        list_work = self._get_work(input_path, output_path)

        # create batch
        # batch_size = batch_size
        num_work = len(list_work)
        num_batch = num_work // batch_unit_size + 1
        list_batch_unit = [list_work[i * batch_unit_size: (i + 1) * batch_unit_size] for i in range(num_batch + 1) if len(list_work[i * batch_unit_size: (i + 1) * batch_unit_size]) > 0]

        num_completed = 0
        start_time = time.time()

        num_batch_unit = 1
        while list_batch_unit:
            batch, list_batch_unit = self.get_batch(num_batch_unit, list_batch_unit)

            result = self.convert_batch(batch, num_worker=num_worker)

            num_completed += len(batch)
            logging.info("[Converting] {} / {} Files".format(num_completed, num_work))

            time_info = self.cal_time_info(start_time, num_completed, num_work)
            self._send_msg_files(kafka_brokers, result, batch, time_info)

            # propose next num_batch_unit
            avg_time_per_img = time_info['avgTime']
            avg_time_per_batch_unit = avg_time_per_img * batch_unit_size

            num_batch_unit = int(spending_time_per_batch / avg_time_per_batch_unit + 1)
            self._send_msg_progress(kafka_brokers, num_work, len(batch), avg_time_per_batch_unit)

        return self.statistics

    def get_batch(self, num_unit, list_batch_unit):
        list_batch = list()
        for i in range(num_unit):
            list_batch = list_batch + list_batch_unit.pop()
            if len(list_batch_unit) == 0:
                break
        return list_batch, list_batch_unit

    def convert_batch(self, batch, num_worker=4):
        # convert batch
        with multiprocessing.Pool(num_worker) as p:
            result = p.map(self._work, batch)

        stat = list()
        for r in result:
            if r == 'pass':
                continue
            stat.append(r['stat_info'])
        self._update_stat(stat)
        return result

    def cal_time_info(self, start_time, num_complete, num_total):
        current_time = time.time()
        elapsed_time = current_time - start_time
        avg_time = elapsed_time / num_complete
        remaining_time = max((num_total - num_complete) * avg_time, 0)
        progress = min(num_complete / num_total, 1) * 100
        time_info = {"elapsed_time": elapsed_time, "remaining_time": remaining_time,
                     "progress": progress, "avgTime": avg_time}

        return time_info

    def _send_msg_progress(self, kafka_brokers, totalSize, processedSize, avgTime):
        msg_json = {"execution_type": "CONVERT", "totalSize": totalSize, "avgTime": avgTime, "processedSize": processedSize, "status": "CONVERTING"}

        result_topic = 'deepphi-dataset-progress'
        kafka_brokers.send_massage_test(result_topic, msg_json)

    def _send_msg_files(self, kafka_brokers, result, batch, time_info):
        list_hdf5_info = list()
        for i in range(len(batch)):
            if result[i] == 'pass':
                continue
            work = batch[i]
            input_path = work[0]
            output_path = remove_duplicated_slash(work[1])
            if isinstance(input_path, str):
                input_path = [input_path]

            # def get_all_files(path):
            #     list_all = glob.glob(path + "/*")
            #     list_files = list()
            #     for filename in list_all:
            #         if os.path.isdir(filename):
            #             list_files = list_files + get_all_files(filename)
            #         else:
            #             list_files.append(filename)
            #     return list_files

            # related_files = list()
            # for filename in input_path:
            #     if os.path.isdir(filename):
            #         related_files = related_files + get_all_files(filename)
            #     else:
            #         related_files.append(filename)

            size = os.path.getsize(output_path)
            shape = str(result[i]['shape'])
            color_mode = result[i]['color_mode']

            # hdf5_info = {"filename": output_path, "related_files": related_files, "size": size, "shape": shape,
            #              "color_mode": color_mode}
            hdf5_info = {"filename": output_path, "size": size, "shape": shape,
                         "color_mode": color_mode}

            list_hdf5_info.append(hdf5_info)

        msg = {"hdf5_info": list_hdf5_info, "time": time_info}
        result_topic = "deepphi-dataset-file-result"
        msg_json = copy.copy(MSG_RESULT)
        msg_json["result_convert"]["file_info"] = msg
        # logging.info(kafka_brokers)
        kafka_brokers.send_massage_test(result_topic, msg_json)

    def _add_modality(self, data):
        data['image']['header']['modality'] = self.modality

    def _add_metadata(self, data):
        self._add_modality(data)

    def save(self, output_file, data_output):
        self._add_modality(data_output)
        super().save(output_file, data_output)


def remove_duplicated_slash(filename):
    while '//' in filename:
        filename = filename.replace('//', '/')

    return filename
