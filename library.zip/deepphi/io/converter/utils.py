#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import zipfile
import numpy as np
import os
import glob
import pandas as pd


class ZipStructure(dict):
    def __init__(self, abs_path, *args, **kwargs):
        super(ZipStructure, self).__init__(*args, **kwargs)
        self["files"] = list()
        self["folders"] = dict()
        self.abs_path = abs_path

    def add_file(self, filename):
        self["files"].append(filename)

    def add_folder(self, dirname):
        base_name = os.path.basename((dirname))
        self['folders'][base_name] = get_unzip_structure(dirname)

    def get_files(self, mode='this', basename=False):
        if mode == 'this':
            list_files = list(self['files'])
            if basename:
                for i in range(len(list_files)):
                    list_files[i] = os.path.basename(list_files[i])
            return list_files
        elif mode == 'all':
            list_in_files = self.get_files(mode='this')
            for dir_name in self.get_folders(basename=True):
                list_in_this_dir = self['folders'][dir_name].get_files(mode='all')
                # for i in range(len(list_in_this_dir)):
                #     list_in_this_dir[i] = "{}/{}".format(dir_name, list_in_this_dir[i])

                list_in_files = list_in_files + list_in_this_dir

            return list_in_files

    def get_folders(self, mode='this', basename=False):
        if mode == 'this':
            list_dirname = list()
            for key in self['folders'].keys():
                abs_path = self['folders'][key].abs_path
                list_dirname.append(abs_path)

            if basename:
                for i in range(len(list_dirname)):
                    list_dirname[i] = os.path.basename(list_dirname[i])

            return list_dirname
        elif mode == 'all':
            list_in_dirs = self.get_folders(mode='this', basename=basename)
            for dir_name in self.get_folders(basename=True):
                list_in_this_dir = self['folders'][dir_name].get_folders(mode='all')

                # for i in range(len(list_in_this_dir)):
                #     list_in_this_dir[i] = "{}/{}".format(dir_name, list_in_this_dir[i])

                list_in_dirs = list_in_dirs + list_in_this_dir

            return list_in_dirs

def get_dataset_name(file_structure):
    if isinstance(file_structure, str):
        if os.path.exists(file_structure):
            dir_list = glob.glob(file_structure + '/*')
    else:
        dir_list = file_structure.get_folders(basename=True)
    for dir_name in dir_list:
        basename = os.path.basename(dir_name)
        if basename.lower() == 'dataset':
            return basename
    return False


def get_label_name(file_structure):
    if isinstance(file_structure, str):
        if os.path.exists(file_structure):
            dir_list = glob.glob(file_structure + '/*')
            import logging

        for name in dir_list:
            basename = os.path.basename(name)
            if (basename.lower() == 'label') or (basename.lower() == 'label.csv') or (basename.lower() == 'label.xlsx'):
                return basename
    else:
        list_folders = file_structure.get_folders(basename=True)
        list_files = file_structure.get_files(basename=True)

        for name in list_folders:
            if name.lower() == 'label':
                return name

        for name in list_files:
            if (os.path.splitext(name)[-1]) == '.csv' or (os.path.splitext(name)[-1] == '.xlsx'):
                return name
        return False

def get_name_xlsx(input_path):
    files = glob.glob(input_path + '/*')
    filename_class = None
    for filename in files:
        import logging
        logging.info(filename)
        basename = os.path.basename(filename)
        if (basename.lower() == 'class.xlsx') or (basename.lower() == 'data_option.xlsx')\
                or (basename.lower() == 'transformation.xlsx'):
            filename_class = filename
            return filename_class

    return None

def get_list_in_dir(name_list, dirname):
    list_in_dataset = [name for name in name_list
                       if (dirname in name) and (dirname != name)]

    return list_in_dataset


def get_extension(filename):
    filename_piece = filename.split('.')
    if len(filename_piece) == 1:
        exe = ''
    else:
        exe = filename_piece[-1]
    if exe == 'gz' and filename_piece[-2] == 'nii':
        exe = "{}.{}".format(filename_piece[-2], exe)
    return exe


def get_filename_wo_exe(filename):
    exe = get_extension(filename)
    if exe == '':
        return filename
    else:
        return filename[:-len(exe) - 1]


def get_zip_structure(zipfile):
    info_list = [info for info in zipfile.infolist()]
    file_structure = ZipStructure()

    for name in info_list:
        dir_hierachy = name.filename.split('/')

        if len(dir_hierachy) == 1:
            file_structure.add_file(name.filename)
        else:
            if dir_hierachy[-1] == '':
                dir_hierachy.pop(-1)  # remove ''
            last_name = dir_hierachy.pop(-1)
            dict_now = file_structure
            for dir_name in dir_hierachy:  # deep into the hierachy
                dict_now = dict_now["folders"][dir_name]

            if name.is_dir():
                dict_now.add_folder(last_name)
            else:
                dict_now.add_file(last_name)

    return file_structure


def get_unzip_structure(input_path):
    structure = ZipStructure(input_path)
    list_path = glob.glob(input_path + "/*")
    for path in list_path:
        if os.path.isdir(path):
            structure.add_folder(path)
            # sub_structure = get_unzip_structure(path)
            # structure['folders'][path] = sub_structure
        else:
            structure.add_file(path)
    return structure


def read_class_xlsx(filename):
    class_info = pd.read_excel(filename)
    if len(class_info) == 1:
        series_independent = str(class_info.iloc[0, 0]).lower()
        return series_independent
    else:
        series_independent = str(class_info.iloc[0, 0]).lower()
        class_name = list(class_info.iloc[:, 1])
        class_value = list(class_info.iloc[:, 2])
        for i in range(len(class_value)):
            if isinstance(class_value[i], str):
                class_value[i] = [int(v) for v in class_value[i].split('-')]

        return class_name, class_value, series_independent


def check_multi_label(input_path):
    label_name = get_label_name(input_path)
    filename_label = glob.glob(input_path + '/{}/*'.format(label_name))

    list_slice_exe = ['dcm', 'png', 'jpg', 'jpeg']

    is_slice = False
    num_labels = 0
    for filename in filename_label:
        if not os.path.isdir(filename):
            return False

        labels = glob.glob(filename + '/*')

        # check is slice
        list_exe = list()
        for filename in labels:
            exe = get_extension(filename)
            list_exe.append(exe)

        if len(list_exe) > 0:
            exe = np.unique(list_exe)[0]
        else:
            exe = ""

        if exe in list_slice_exe:
            is_slice = True
        else:
            is_slice = False
        ####

        num_labels = max(num_labels, len(labels))

    if is_slice:
        return False

    return num_labels > 1


class ConvertException(Exception):
    def __init__(self, *arg, case_expected="Unexpected", list_msg_err=[], **kwargs):
        super(ConvertException, self).__init__(*arg, **kwargs)
        self.case_expected = case_expected
        self.list_msg_err = list_msg_err


class CheckVal(dict):
    def __init__(self, type, val, msg="", list_files=[]):
        self.MSG_JSON = {
        "err_type": "None",
        "err_message": "None",
        "err_data": []}

        self['val'] = val

        self.MSG_JSON["err_type"] = type
        self.MSG_JSON["err_message"] = msg
        self.MSG_JSON["err_data"] = list_files


class ListCheckVal(object):
    LIST_VAL = list()

    def append(self, x):
        self.LIST_VAL.append(x)

    def Raise(self, prefix="", case_expected="Unexpected"):
        list_msg_error = list()
        suc = True
        msg_err = prefix + "\n\n"
        for cv in self.LIST_VAL:
            if cv['val'] == 'fail':
                suc = False

                cv.MSG_JSON["err_data"] = cv.MSG_JSON["err_data"][:20]
                list_msg_error.append(cv.MSG_JSON)
        if not suc:
            raise ConvertException(msg_err, case_expected=case_expected, list_msg_err=list_msg_error)
