#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import zipfile
import numpy as np
import os
import logging
from deepphi.io.converter.utils import *
import shutil


def remove_exception(file_structure):
    list_exception = ["db"]
    file_list = file_structure.get_files(mode="all")
    for filename in file_list:
        exe = get_extension(filename)
        if exe in list_exception:
            os.remove(filename)
            logging.info("{} is removed".format(filename))

def classify_template_compressed(unzip_path, dimension='2D'):
    file_structure = get_unzip_structure(unzip_path)
    remove_exception(file_structure)

    file_structure = get_unzip_structure(unzip_path)
    dataset_name = get_dataset_name(file_structure)
    if not dataset_name:
        # dataset 폴더가 존재하지 않고, file이 없음
        if len(file_structure['files']) == 0:
            validation_case2(file_structure, dimension)
            return 'case2'
        else:
            msg = 'Unexpected Data Structure'
            msg = '\n The data structure must include a folder named "Dataset" or the structure must be template case2.'
            raise Exception(msg)

    # check validataion
    dataset_structure = file_structure['folders'][dataset_name]

    ### 1차 validation
    prefix = "There are some problems in your dataset."
    check_val = ListCheckVal()
    check_val.append(_check_directory_list(file_structure))  # dataset과 label 이외에 폴더가 존재하는지
    # check_val.append(_check_dimension(dataset_structure, dimension))
    check_val.append(_check_extension(file_structure.get_files(mode='all')))
    # Dataset 하위 파일은 이미지만
    check_val.append(_check_existence_label(file_structure))
    check_val.Raise(prefix=prefix)

    ### 2차 validation
    check_val = ListCheckVal()
    list_available_exe = ['nii', 'nii.gz', 'png', 'jpg', 'jpeg', 'dcm', 'tif', '',
                          'NII', 'NII.GZ', 'PNG', 'JPG', 'JPEG', 'DCM', 'TIF']
    check_val.append(_check_extension(dataset_structure.get_files(mode='all'),
                                      list_available_exe=list_available_exe))
    check_val.Raise(prefix=prefix)


    # check validataion
    label_name = get_label_name(file_structure)
    if (label_name.lower() == 'label.csv'):
        validation_case1_3(file_structure, dataset_name)
        return 'case1 or case3'

    label_structure = file_structure['folders'][label_name]
    list_in_label = label_structure.get_files(mode='all')

    list_exe = list(np.unique([get_extension(name) for name in list_in_label]))

    if 'xml' in list_exe:
        if len(list_exe) == 1:
            validataion_case4_5(dataset_structure, label_structure, dimension)
            return 'case4 or case5'
        else:
            msg = "There are too many extension types({}) for label files.".format(list_exe)
            msg = msg + 'The extension type "xml" cannot coexist with other extension type.'
            raise Exception(msg)

    if 'csv' in list_exe:
        if len(list_exe) == 1:
            return 'cls_case4'
        else:
            msg = "There are too many extension types({}) for label files.".format(list_exe)
            msg = msg + 'The extension type "xml" cannot coexist with other extension type.'
            raise Exception(msg)

    validation_segmentation(dataset_structure, label_structure, dimension)

    filename_class = get_name_xlsx(unzip_path)
    if filename_class is not None:
        tmp_filename_class = os.path.basename(filename_class).lower()
        if tmp_filename_class == 'transformation.xlsx':
            if len(pd.read_excel(filename_class)) == 0:
                return 'trans_case1'
            series_independent = read_class_xlsx(filename_class)
        else:
            class_name, class_value, series_independent = read_class_xlsx(filename_class)
        if series_independent == 'yes':
            dataset_patient = glob.glob(unzip_path + "/" + dataset_name + "/*")
            label_patient = glob.glob(unzip_path + "/" + label_name + "/*")

            for patient_dir in list(dataset_patient):
                patient_name = os.path.basename(patient_dir)
                each = glob.glob(patient_dir + "/*")
                for filename in each:
                    basename = os.path.basename(filename)
                    name_new = "{}/{}/{}_{}".format(unzip_path, dataset_name, patient_name, basename)
                    shutil.move(filename, name_new)
                if os.path.isdir(patient_dir):
                    shutil.rmtree(patient_dir)
                else:
                    os.remove(patient_dir)

            for patient_dir in list(label_patient):
                patient_name = os.path.basename(patient_dir)
                each = glob.glob(patient_dir + "/*")
                for filename in each:
                    basename = os.path.basename(filename)
                    name_new = "{}/{}/{}_{}".format(unzip_path, label_name, patient_name, basename)
                    shutil.move(filename, name_new)
                if os.path.isdir(patient_dir):
                    shutil.rmtree(patient_dir)
                else:
                    os.remove(patient_dir)

    if check_multi_label(unzip_path):
        validation_case2_seg(unzip_path)
        return "seg_case2"
    else:
        if filename_class is not None:
            if tmp_filename_class == 'transformation.xlsx':
                return 'trans_case1'
            else:
                return 'seg_case1'
        else:
            return 'seg_case3'


def validation_case2_seg(input_path):
    list_val = ListCheckVal()

    ########### validation ##################
    filename_class = get_name_xlsx(input_path)
    label_name = get_label_name(input_path)
    filename_label = np.array(sorted(glob.glob(input_path + '/{}/*/*'.format(label_name))))

    if filename_class is None:
        msg = 'Multiple label files exist within each patient folder. \n'
        msg += 'You need a "class.xlsx" file that contains the class information for each label file. \n'
        msg += 'See the manual for more information.'
        raise Exception(msg)

    class_name, class_value, _ = read_class_xlsx(filename_class)

    def get_class_from_name(filename):
        basename = os.path.basename(filename)
        filename_wo_exe = get_filename_wo_exe(basename)
        class_name_this = filename_wo_exe.split('-')[0]
        return class_name_this

    # check name format
    list_name_unavailable = list()
    for filename in filename_label:
        class_name_this = get_class_from_name(filename)
        if class_name_this not in class_name:
            filename_sub = filename[len(input_path):]
            list_name_unavailable.append(filename_sub)

    if list_name_unavailable:
        msg = "There exist some files for which the class cannot be identified because the file name format is not appropriate."
        # for filename in list_name_unavailable:
        #     msg += "\n - {}".format(filename)
        # raise Exception(msg)

        val_type = "Name Error"
        list_val.append(CheckVal(val_type, "fail", msg, list_files=list_name_unavailable))
        list_val.Raise()
    ########### validation ##################


def validation_case2(file_structure, dimension):
    list_val = ListCheckVal()
    # dimension validation
    list_dir_class = file_structure.get_folders(basename=True)
    for dir_class in list_dir_class:
        class_structure = file_structure['folders'][dir_class]
        ret = _check_dimension(class_structure, dimension)
        if ret['val'] == 'fail':
            list_val.append(ret)
            break
    # extension validation
    list_available_exe = ['nii', 'nii.gz', 'png', 'jpg', 'jpeg', 'dcm', 'tif', 'bmp', '',
                          'NII', 'NII.GZ', 'PNG', 'JPG', 'JPEG', 'DCM', 'TIF', 'BMP']
    ret = _check_extension(file_structure.get_files(mode='all'), list_available_exe=list_available_exe)
    list_val.append(ret)

    prefix = "The uploaded dataset is estimated to be a template case2. But there are some problems."
    list_val.Raise(prefix=prefix, case_expected='case2')


def validation_case1_3(file_structure, dataset_name):
    list_val = ListCheckVal()


#     # extension validation
#     list_available_exe = ['nii', 'nii.gz', 'png', 'jpg', 'jpeg', 'dcm', 'tif']
#     dataset = file_structure['folders'][dataset_name]
#     ret = _check_extension(dataset.get_files(mode='all'), list_available_exe=list_available_exe)
#     list_val.append(ret)

#     prefix = "The uploaded dataset is estimated to be a template case1 or case3. But there are some problems."
#     list_val.Raise(prefix=prefix)

def validataion_case4_5(dataset_structure, label_structure, dimension):
    list_val = ListCheckVal()

    # check match
    if dimension == '2D':
        list_label = label_structure.get_files()
        list_dataset = dataset_structure.get_files()

    elif dimension == '3D':
        list_label = label_structure.get_folders()
        list_dataset = dataset_structure.get_folders()

    ret = _check_mismatch(list_dataset, list_label)
    list_val.append(ret)

    # extension label validation
    list_available_exe = ['xml']
    ret = _check_extension(label_structure.get_files(mode='all'), list_available_exe=list_available_exe)
    list_val.append(ret)

    prefix = "The uploaded dataset is estimated to be a template case4 or case5. But there are some problems."

    # raise Exception
    list_val.Raise(prefix=prefix, case_expected='case4 or 5')

# def get_depth(list_filenames, folder_name):

def validation_segmentation(dataset_structure, label_structure, dimension):
    list_val = ListCheckVal()

    # check match
    list_label_folders = label_structure.get_files(mode='all')
    list_dataset_folders = dataset_structure.get_files(mode='all')

    if dimension == '2D':
        list_label = label_structure.get_files()
        list_dataset = dataset_structure.get_files()

        for i in range(len(list_dataset)):
            list_dataset[i] = get_filename_wo_exe(list_dataset[i])

        for i in range(len(list_label)):
            list_label[i] = get_filename_wo_exe(list_label[i])

    elif dimension == '3D':
        list_label = label_structure.get_folders()
        list_dataset = dataset_structure.get_folders()

    ret = _check_mismatch(list_dataset, list_label)
    list_val.append(ret)

    # extension label validation
    list_available_exe = ['nii', 'nii.gz', 'png', 'jpg', 'jpeg', 'dcm', 'tif', 'bmp', '',
                          'NII', 'NII.GZ', 'PNG', 'JPG', 'JPEG', 'DCM', 'TIF', 'BMP']
    ret = _check_extension(label_structure.get_files(mode='all'), list_available_exe=list_available_exe)
    list_val.append(ret)

    prefix = "The uploaded dataset is estimated to be the segmentation case. But there are some problems."

    # raise Exception
    list_val.Raise(prefix=prefix, case_expected='segmentation')


def _check_directory_list(file_structure):
    val_type = "DIR ERROR"
    list_available_dir = ['dataset', 'label']
    list_dir = file_structure.get_folders(basename=True)

    if len(list_dir) == 0:
        msg = "The Dataset is Empty.\n"
        return CheckVal(val_type, "fail", msg)

    list_dir_not_available = list()
    for dir_name in list_dir:
        if dir_name.lower() not in list_available_dir:
            list_dir_not_available.append(dir_name)

    if list_dir_not_available:
        msg = "There are unexpected directories in your Dataset.\n"
        # msg = msg + "Unexpected Directories: \n"
        # for dir_name in list_dir_not_available:
        #     msg = msg + " - {}\n".format(dir_name)
        return CheckVal(val_type, "fail", msg)
    else:
        return CheckVal(val_type, "success")


def _check_dimension(file_structure, dimension):
    val_type = "DIMENSION ERROR"
    list_files = file_structure.get_files(basename=True)
    list_folders = file_structure.get_folders(basename=True)

    if (dimension == '3D') and list_files:
        msg = "The 3D images must be in each patient folders in the dataset directory."
        msg = msg + "\nPlease check the dimensions of your dataset."
        msg = msg + "\nIf your dataset is 3D, put all images in each patient folder."
        return CheckVal(val_type, "fail", msg)

    if (dimension == '2D') and list_folders:
        msg = "The 2D image dataset cannot contain folders inside the dataset folder."
        msg = msg + "\nPlease check the dimensions of your dataset."
        msg = msg + "\nIf your dataset is 2D, please remove unexpected directories in the dataset folder."
        return CheckVal(val_type, "fail", msg)

    return CheckVal(val_type, "success")


def _check_extension(file_list, list_available_exe=None):
    val_type = 'EXTENSION ERROR'
    if list_available_exe is None:
        list_available_exe = ['nii', 'nii.gz', 'png', 'jpg', 'jpeg', 'dcm', 'tif', 'bmp', 'xml', 'csv', 'xlsx', '',
                              'NII', 'NII.GZ', 'PNG', 'JPG', 'JPEG', 'DCM', 'TIF', 'BMP', 'XML', 'CSV', 'XLSX']
    list_unavailable_file = list()

    for filename in file_list:
        exe = get_extension(filename)
        if exe not in list_available_exe:
            list_unavailable_file.append(filename)

        if len(list_unavailable_file) > 20:
            break

    if list_unavailable_file:
        msg = "There are files with unavailable extensions in your dataset."
        # for filename in list_unavailable_file:
        #     msg = msg + "\n - {}".format(filename)
        return CheckVal(val_type, "fail", msg, list_files=list_unavailable_file)

    return CheckVal(val_type, "success")


def _check_existence_label(file_structure):
    val_type = "LABEL ERROR"

    list_label = list()
    list_folders = file_structure.get_folders(basename=True)
    list_files = file_structure.get_files(basename=True)

    for name in list_folders:
        if name.lower() == 'label':
            list_label.append(name)

    for name in list_files:
        if name.lower() == 'label.csv':
            list_label.append(name)

    if not list_label:
        msg = 'The file named "Label.csv" or folder named "Label" must exist in the uploaded zip file.'
        return CheckVal(val_type, "fail", msg)
    elif len(list_label) > 1:
        msg = "There are too many label files or folders in the uploaded zip file."
        return CheckVal(val_type, "fail", msg)

    return CheckVal(val_type, "success")


def _check_mismatch(list_dataset, list_label):
    val_type = "MISMATCH ERROR"
    list_not_in_dataset = list()

    for i in range(len(list_dataset)):
        basename = os.path.basename(list_dataset[i])
        list_dataset[i] = get_filename_wo_exe(basename)

    for filename in list_label:
        basename = os.path.basename(filename)
        filename_wo_exe = get_filename_wo_exe(basename)
        if filename_wo_exe not in list_dataset:
            list_not_in_dataset.append(filename)

        if len(list_not_in_dataset) > 20:
            break

    if list_not_in_dataset:
        msg = 'There are some mismatched files in your Dataset. Please check your Dataset or Label.\n'
        msg = msg + 'Mis-matched Files\n'
        # for filename in list_not_in_dataset:
        #     msg = msg + " - {} \n".format(filename)
        return CheckVal(val_type, "fail", msg, list_files=list_not_in_dataset)

    return CheckVal(val_type, "success")

def check_csv_structure(path_csv):
    label_csv = pd.read_csv(path_csv, encoding='cp949')
    if len(label_csv.columns) == 1:
        case = 'case1'
    else:
        case = 'case3'

    return case


def classify_template_case(path, case):
    dir_list = glob.glob(path + '/*')
    if case == "case2":
        return "case2"
    elif case == "case1 or case3":
        label_name = get_label_name(path)
        path_csv = os.path.dirname(dir_list[0]) + "/" + label_name
        case = check_csv_structure(path_csv)
        return case
    elif case == 'cls_case4':
        return 'cls_case4'
    elif case == "case4 or case5":
        return "case4"
    elif case in ['seg_case1', 'seg_case2', 'seg_case3']:
        return case
    elif case == 'trans_case1':
        return case
    else:
        raise Exception('The Data Structure is not available. Please Check your Dataset.')


if __name__ == "__main__":
    path = '/home/swseo-ubuntu/mnt/sda2/datasets/converter_test/test_zip/TEST/'
    path = '/home/hslisalee/Desktop/dataset/trans_example/2D_jpg'
    print(classify_template_compressed(path, dimension='2D'))