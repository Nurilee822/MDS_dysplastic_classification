from deepphi.io.sitk import *
import xml.etree.cElementTree as ET
import glob
from deepphi.io.converter_v2.validation.exception import *
from deepphi.logger.error import DeepPhiError, ErrorAnalyzer
import deepphi
import pandas as pd
import numpy as np


def get_list_img(path, each=False):
    if not each:
        list_img = glob.glob(path + "/*")
    else:
        list_img = glob.glob(path + "/*/*")

    return list_img


def load_image(path_img):
    data = deepphi.io.sitk.DeepPhiDataSet()
    data.read_image(path_img)
    return data


def load_cls_label(path_label):
    return


def load_seg_label(path_label, shape, class_dict=None):
    if path_label.split(".")[-1] == "xml":
        label_input = DeepPhiImage()
        try:
            label_input.read_xml_mask(path_label, shape, class_dict)
        except:
            code = 'worker.dataset-converter.error.invalid-xml'
            raise DeepPhiError(code=code, parameter={})
    else:
        label_input = DeepPhiImage()
        label_input.read_image(path_label, mask=True)
    return label_input


def load_det_class(path_label):
    if os.path.isdir(path_label):
        path_label = glob.glob(path_label + "/*.xml")[0]
    try:
        xml_root = ET.parse(path_label).getroot()
        list_class = list()
        for i, element in enumerate(xml_root.iter('object')):
            try:
                class_name = _find_node(element, 'name').text
                list_class.append(class_name)
            except ValueError as e:
                raise ValueError('could not parse object #{}: {}'.format(i, e))
    except:
        code = 'worker.dataset-converter.error.invalid-xml'
        raise DeepPhiError(code=code, parameter={})
    return list_class


def load_det_label(path_label, dimension):
    if os.path.isdir(path_label):
        path_label = glob.glob(path_label + "/*.xml")[0]
    try:
        xml_root = ET.parse(path_label).getroot()
        list_box, list_class = _parse_annotations(xml_root, dimension)
    except:
        # msg = 'The xml form is not correct. Please read the manual and check it again.'
        code = 'worker.dataset-converter.error.invalid-xml'
        raise DeepPhiError(code=code, parameter={})
    return list_box, list_class


def load_tran_label(path_label):
    label_input = DeepPhiImage()
    label_input.read_image(path_label)
    return label_input


def cls_total_class_name(excel_file):
    excel_file = excel_file.replace("//", "/")
    label_excel = pd.read_csv(excel_file, encoding='cp949')
    label_cls_list = list(label_excel[label_excel.columns[1]])
    class_name_list = np.unique(np.array(label_cls_list))
    class_name_list = [class_name for class_name in class_name_list if class_name != 'nan']
    return class_name_list


def det_total_class_name(path_label):
    label_list = glob.glob(path_label + '*.xml')
    list_class = list()
    for file in label_list:
        try:
            xml_root = ET.parse(file).getroot()
            for i, element in enumerate(xml_root.iter('object')):
                class_name = (element.find('name')).text
                if class_name not in list_class:
                    list_class.append(class_name)
        except:
            continue
    return list(map(str, list_class))



def _find_node(parent, name, debug_name=None, parse=None):
    if debug_name is None:
        debug_name = name

    result = parent.find(name)
    if result is None:
        raise ValueError('missing element \'{}\''.format(debug_name))
    if parse is not None:
        try:
            return parse(result.text)
        except ValueError as e:
            raise ValueError('illegal value for \'{}\': {}'.format(debug_name, e))
    return result


def _parse_annotation(element, dimension):
    class_name = _find_node(element, 'name').text

    if dimension == "2D":
        box = np.zeros((4,))
        bndbox = _find_node(element, 'bndbox')
        box[0] = _find_node(bndbox, 'ymin', 'bndbox.ymin', parse=float) - 1
        box[1] = _find_node(bndbox, 'xmin', 'bndbox.xmin', parse=float) - 1
        box[2] = _find_node(bndbox, 'ymax', 'bndbox.ymax', parse=float) - 1
        box[3] = _find_node(bndbox, 'xmax', 'bndbox.xmax', parse=float) - 1

    elif dimension == "3D":
        box = np.zeros((6,))
        bndbox = _find_node(element, 'bndbox')
        box[0] = _find_node(bndbox, 'zmin', 'bndbox.zmin', parse=float) - 1
        box[1] = _find_node(bndbox, 'ymin', 'bndbox.ymin', parse=float) - 1
        box[2] = _find_node(bndbox, 'xmin', 'bndbox.xmin', parse=float) - 1

        box[3] = _find_node(bndbox, 'zmax', 'bndbox.zmax', parse=float) - 1
        box[4] = _find_node(bndbox, 'ymax', 'bndbox.ymax', parse=float) - 1
        box[5] = _find_node(bndbox, 'xmax', 'bndbox.xmin', parse=float) - 1

    else:
        raise Exception()

    return box, class_name


def _parse_annotations(xml_root, dimension):
    list_box = list()
    list_class = list()
    for i, element in enumerate(xml_root.iter('object')):
        try:
            box, class_name = _parse_annotation(element, dimension)
            list_box.append(box)
            list_class.append(class_name)
        except ValueError as e:
            raise ValueError('could not parse object #{}: {}'.format(i, e))

    return list_box, list_class


if __name__ == '__main__':
    path_det_label = '/home/swseo/Dropbox/deepnoid/development/DEEP-PHI-deeplearning-beta/deepphi/io/converter_v2/unit_test/case1/origin/detection/raccoon-1.xml'
    print(load_det_label(path_det_label, dimension='2D'))

