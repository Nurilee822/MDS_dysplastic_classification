from deepphi.io.converter_v2.validation.validation_folder import *
import os, shutil, glob
import pandas as pd
from deepphi.logger.error import DeepPhiError, ErrorAnalyzer



def cla_validation_folder(path):
    if type(path) == str:
        dataset_structure = get_unzip_structure(path)
    else:
        dataset_structure, _ = get_unzip_structure_from_list(path)
        path = os.path.dirname(path[0])
    if len(dataset_structure['files']) > 0:  # 폴더가 아닌 파일이 존재하는지 체크
        code = 'worker.dataset-converter.error.invalid-structure.file-exist-in-root-directory'
        raise DeepPhiError(code=code, parameter={})


def cls_case1_rename(path):
    csv_name = os.path.basename(path) + '.csv'
    if csv_name.split('.')[0] not in ['train', 'test', 'validation']:
        csv_name = 'Label.csv'
    if type(path) == str:
        dataset_structure = get_unzip_structure(path)
    else:
        dataset_structure, _ = get_unzip_structure_from_list(path)
        path = os.path.dirname(path[0])
    if path[-1] != '/':
        path = path + '/'

    target_dir = path
    label_path = path + '../classification/'

    if not os.path.exists(target_dir):
        os.mkdir(target_dir)
    if not os.path.exists(label_path):
        os.mkdir(label_path)

    csv_file = open(label_path + csv_name, 'w', encoding='cp949')
    csv_file.write('Filename,Class Name\n')

    for class_name in dataset_structure['folders']:
        for target in ['files', 'folders']:
            for file in dataset_structure['folders'][class_name][target]:
                filename = os.path.basename(file)
                if os.path.exists(target_dir + filename):
                    csv_file.close()
                    code = 'worker.dataset-converter.error.invalid-structure.duplicate-file-exist'
                    raise DeepPhiError(code=code, parameter={'filename': filename})
                else:
                    shutil.move(path + class_name + '/' + filename, target_dir + filename)
                csv_file.write(filename + ',' + class_name + '\n')
        os.rmdir(path + class_name)
    csv_file.close()


def custom_csv_merge(cls_path):
    csv_list = glob.glob(cls_path + '*.csv')
    allData = []  # 읽어 들인 csv파일 내용을 저장할 빈 리스트를 하나 만든다
    for file in csv_list:
        df = pd.read_csv(file, encoding='cp949')   # for구문으로 csv파일들을 읽어 들인다
        allData.append(df)
        os.remove(file)
    dataCombine = pd.concat(allData, axis=0, ignore_index=True)
    dataCombine.to_csv(cls_path + 'Label.csv', index=False, encoding ='cp949')

if __name__ == "__main__":
    path = 'C:/Users/장한별/Desktop/딥파이/dataset/케이스체크/연습_cla_case1/dataset'
    path = ['C:/Users/장한별/Desktop/딥파이/dataset/케이스체크/연습_cla_case1/dataset/AD',
            'C:/Users/장한별/Desktop/딥파이/dataset/케이스체크/연습_cla_case1/dataset/CN',
            'C:/Users/장한별/Desktop/딥파이/dataset/케이스체크/연습_cla_case1/dataset/MCI']
    cla_validation_folder(path)
    cls_case1_rename(path)

