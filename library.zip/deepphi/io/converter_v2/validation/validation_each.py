import logging, shutil
import numpy as np
from deepphi.io.converter_v2.io import get_list_img, load_image, load_seg_label, load_det_class, \
    load_det_label, load_tran_label
from deepphi.io.converter_v2.unpacking import make_total_class_name
from deepphi.io.converter_v2.validation.exception import *
from deepphi.io.converter_v2.validation.make_sample import *
from deepphi.io.converter_v2.utils import *
from deepphi.logger.error import DeepPhiError, ErrorAnalyzer
import traceback
import sys, os, glob, psutil, copy
import pandas as pd
import xml.etree.cElementTree as ET
import time, cv2, multiprocessing
from functools import partial


class DeepphiValidation(object):
    def __init__(self, path_origin, dataset_case, msg_creator, kafka_producer=None,
                 encryption_key=None, requestType=None, image_path=None):
        self.path_origin = path_origin
        self.msg_creator = msg_creator
        self.kafka_producer = kafka_producer
        self.dataset_case = dataset_case[0]
        self.encryption_key = encryption_key
        self.requestType = requestType
        self.process_count = 0
        self.send_count = 0
        self.process_time = 0
        self.image_path = image_path
        self.max_fraction = list()

    def validate(self, list_img=None, num_worker=4):
        logging.info('밸리데이션 시작')
        start_time = time.time()
        self.msg_creator.set_total_count(len(list_img))
        logging.info("받은 전체 데이터셋 수: %d" % self.msg_creator.count)
        sample_path = self.msg_creator.get_sample_path()
        if (self.requestType == 'ALL') and (os.path.exists(sample_path)):
            shutil.rmtree(sample_path)

        list_label, list_class_label = self.get_list_label(self.dataset_case)
        label_extension = [tmp_label_name.split('.')[-1] for tmp_label_name in list_label]
        if self.msg_creator.labelNames in ["", "[]", None, "None"]:
            self.msg_creator.labelNames = str(make_total_class_name(self.path_origin))
        previous_seg_class = self.check_label_names(self.dataset_case)

        if self.dataset_case.split('_')[1] == '2D':
            if self.msg_creator.count > 500:
                batch_size = 200
            else:
                batch_size = 50
            if 'xml' in label_extension:
                batch_size = 30
        else:
            batch_size = 8
        list_batch = get_list_batch(list_img, batch_size=batch_size)

        val_checker = DataValidationFile(self.msg_creator.class_info)

        val_function = partial(val_multi, checker=copy.deepcopy(val_checker), image_path=self.image_path,
                               list_label=list_label, list_class_label=list_class_label,
                               case=self.dataset_case, previous_seg_class=previous_seg_class)
        with multiprocessing.Pool(num_worker) as pool:
            self.val_work(list_batch, val_function, pool)


        logging.info(time.time() - start_time)
        logging.info('밸리데이션 끝')

    def val_work(self, list_batch, val_function, pool):
        self.process_time = time.time()
        for i in range(len(list_batch)):
            batch = list_batch[i]
            val_result = pool.map(val_function, batch)
            self.val_result_update(val_result)

    def val_result_update(self, val_result):
        for result_checker, val_output in val_result:
            if result_checker.status == 'SUCCESS':
                result_checker.class_info = self.msg_creator.class_info
                if 'SEGMENTATION' in self.dataset_case:
                    class_value, fraction_info = val_output
                    if type(class_value) == dict:
                        result_checker.update_class_xml(class_value)
                    else:
                        result_checker.update_class_info(class_value, self.dataset_case.split('_')[0].upper())
                    self.get_max_fraction(fraction_info, result_checker.class_info[1]['classInfos'])
                elif 'TRANSFORMATION' not in self.dataset_case:
                    result_checker.update_class_info(val_output, self.dataset_case.split('_')[0].upper())
                self.msg_creator.class_info = result_checker.class_info
            self.msg_creator.add_result(result_checker.get_validation_result())
            self.process_count += 1
            self.send_result(send_type='validation')

    def convert(self, path_save, list_img=None, num_worker=4):
        logging.info('컨버터 시작')
        start_time = time.time()
        self.msg_creator.set_total_count(len(list_img))
        self.msg_creator.set_start_time()
        logging.info("받은 전체 데이터셋 수: %d" % self.msg_creator.count)

        list_label, list_class_label = self.get_list_label(self.dataset_case)

        if self.dataset_case.split('_')[1] == '2D':
            if self.msg_creator.count > 500:
                batch_size = 100
            else:
                batch_size = 50
        else:
            batch_size = 8

        list_batch = get_list_batch(list_img, batch_size=batch_size)

        convert_checker = DataValidationFile(self.msg_creator.class_info, encryption_key=self.encryption_key)

        convert_function = partial(convert_multi, checker=copy.deepcopy(convert_checker),
                                   image_path=self.image_path, path_save=path_save,
                                   list_label=list_label, list_class_label=list_class_label,
                                   case=self.dataset_case)

        with multiprocessing.Pool(num_worker) as pool:
            self.convert_work(list_batch, convert_function, pool)

        logging.info(time.time() - start_time)
        logging.info('컨버터 끝')

    def convert_work(self, list_batch, convert_function, pool):
        self.process_time = time.time()
        for i in range(len(list_batch)):
            batch = list_batch[i]
            convert_result = pool.map(convert_function, batch)
            self.convert_result_update(convert_result)

    def convert_result_update(self, convert_result):
        for msg in convert_result:
            self.process_count += 1
            self.msg_creator.add_result(msg)
            self.send_result(send_type='convert')

    def send_result(self, send_type='validation'):
        if self.process_count == self.msg_creator.count:
            if send_type == 'validation' and self.msg_creator.class_info[1]['classInfos']:
                self.msg_creator.add_label_name(len(self.msg_creator.class_info[1]['classInfos']))
                if 'SEGMENTATION' in self.dataset_case:
                    sample_path = self.msg_creator.get_sample_path()
                    self.save_sample_image(sample_path)
                    logging.info('샘플 이미지 생성 완료')
            logging.info("카프카 보낸 count: %d" % (self.process_count - self.send_count))
            logging.info("전체 count : %d, 현재 count: %d" % (self.msg_creator.count, self.process_count))
            logging.info('라스트')
            self.send_kafka(class_info=True)
        else:
            if (self.process_count - self.send_count == 30) or (time.time() - self.process_time > 1):
                logging.info("카프카 보낸 count: %d" % (self.process_count - self.send_count))
                logging.info("전체 count : %d, 현재 count: %d" % (self.msg_creator.count, self.process_count))
                self.send_kafka()
                self.send_count = self.process_count
                self.process_time = time.time()

    def send_kafka(self, class_info=False):
        result_topic = 'deepphi-dataset-file-result'
        if sys.argv[3] == 'test':
            result_topic = 'deepphi-module-finish-test'
        if (not class_info) and (len(self.msg_creator.result) == 0):
            pass
        else:
            self.kafka_producer.send_massage_test(result_topic, self.msg_creator.get_kafka_msg(class_info=False))
            if class_info:
                self.kafka_producer.send_class_info_massage(self.msg_creator.get_class_kafka_msg())

            self.msg_creator.result = list()
            self.msg_creator.processed_count = 0

    def get_path_label(self, case):
        if 'SEGMENTATION' in case:
            path_label = self.path_origin + '/segmentation/'
        elif 'TRANSFORMATION' in case:
            path_label = self.path_origin + '/transformation/'
        elif 'DETECTION' in case:
            path_label = self.path_origin + '/detection/'
        elif 'CLASSIFICATION' in case:
            path_label = self.path_origin + '/classification/'
        else:
            raise Exception()
        return path_label

    def get_list_label(self, case):
        if 'CLASSIFICATION' in case:
            path_label = self.get_path_label(case)
            label_file_name = get_list_img(path_label)[0]
            label_extension = get_extension(label_file_name).lower()
            if label_extension == 'csv':
                label_excel = pd.read_csv(label_file_name, encoding='cp949')
            else:
                label_excel = pd.read_excel(label_file_name)
            list_name_label = label_excel[label_excel.columns[0]]
            list_label = [get_filename_wo_exe_csv(str(label_name)) for label_name in list_name_label]
            list_class_label = label_excel[label_excel.columns[1]]
        else:
            path_label = self.get_path_label(case)
            list_label = get_list_img(path_label)
            list_class_label = None
        return list_label, list_class_label

    def check_label_names(self, case):
        previous_seg_class = self.msg_creator.labelNames
        if 'SEGMENTATION' in case:
            if self.requestType == 'ALL':
                self.msg_creator.labelNames = 0
            try:
                previous_seg_class = int(self.msg_creator.labelNames)
            except:
                previous_seg_class = 0
        return previous_seg_class

    def get_max_fraction(self, fraction_info, class_info):
        tmp_img_name = fraction_info[0]
        tmp_label_name = fraction_info[1]
        fraction_list = fraction_info[2:]
        list_fraction = self.initial_max_fraction(class_info)

        for i in range(1, len(fraction_list)):
            class_name, idx_slice, fraction = fraction_list[i]
            idx = list_fraction.index(class_name)
            if fraction > self.max_fraction[idx]['fraction']:
                self.max_fraction[idx]['fraction'] = fraction
                self.max_fraction[idx]['idx_slice'] = idx_slice
                self.max_fraction[idx]['img_name'] = tmp_img_name
                self.max_fraction[idx]['label_name'] = tmp_label_name

    def initial_max_fraction(self, class_info):
        list_fraction = [self.max_fraction[j]['class_name']
                         for j in range(len(self.max_fraction))]
        for info in class_info:
            if info['name']:
                name = info['name']
            else:
                name = str(info['value'])
            if name not in list_fraction:
                self.max_fraction.append({'img_name': str(), 'label_name': str(), 'class_name': name,
                                          'idx_slice': int(), 'fraction': float()})
                list_fraction.append(name)
        return list_fraction

    def save_sample_image(self, sample_path):
        is_check_folder(sample_path)
        self.max_fraction_sort()
        for i in range(1, len(self.max_fraction)):
            try:
                data = load_image(self.max_fraction[i]['img_name'])
                img_shape = data['image']['array'].shape
                if data['image']['header']['IsVector']:
                    img_shape = img_shape[:-1]

                if get_extension(self.max_fraction[i]['label_name']).lower() == 'xml':
                    class_dict = {self.msg_creator.class_info[1]["classInfos"][j]['name']:
                                      self.msg_creator.class_info[1]["classInfos"][j]['value']
                                  for j in range(len(self.msg_creator.class_info[1]["classInfos"]))}
                    label = load_seg_label(self.max_fraction[i]['label_name'], shape=img_shape, class_dict=class_dict)
                else:
                    label = load_seg_label(self.max_fraction[i]['label_name'], shape=img_shape)

                if data['image']['header']['dim'] == 2:
                    data['image']['array'] = np.expand_dims(data['image']['array'], axis=0)
                    label['array'] = np.expand_dims(label['array'], axis=0)
                label['array'] = np.expand_dims(label['array'], axis=-1)
                idx_slice = self.max_fraction[i]['idx_slice']
                save_np_to_jpg(f"{sample_path}/{int(self.max_fraction[i]['class_name'])}.jpg", data['image']['array'][idx_slice],
                               label['array'][idx_slice], int(self.max_fraction[i]['class_name']))
            except:
                pass

    def max_fraction_sort(self):
        try:
            class_name = [int(name['class_name']) for name in self.max_fraction]
            sorted_class_name = sorted(class_name)
            if class_name != sorted_class_name:
                self.max_fraction = [self.max_fraction[class_name.index(sorted_class_name[i])]
                                     for i in range(len(sorted_class_name))]
        except:
            for i in range(len(self.max_fraction)):
                self.max_fraction[i]['class_name'] = str(i)


class DataValidationFile(object):
    def __init__(self, class_info, encryption_key=None):
        self.status = None
        self.message = ""
        self.detail = ""
        self.messageParameter = dict()
        self.originals = list()
        self.class_info = class_info
        self.encryption_key = encryption_key
        self.file_info = self.initialize_file_into()
        self.det_name_to_index = None
        self.seg_name_to_index = None
        self.class_name = []

    def initialize_file_into(self):
        file_info = {
            "filePath": None,
            "size": None,
            "shape": None,
            "colorMode": None,
            "fileNm": None,
            "labelDetails": []
        }

        for i in range(len(self.class_info)):
            label_type = self.class_info[i]['labelType']
            if label_type == "SEGMENTATION":
                info = {"labelType": "SEGMENTATION", "avgFraction": []}
                for each in self.class_info[i]["classInfos"]:
                    c = {
                        "className": each["name"],
                        "index": each["index"],
                        "avgFraction": 0.0
                    }
                    info["avgFraction"].append(c)
            elif label_type == "CLASSIFICATION":
                info = {"labelType": "CLASSIFICATION", "className": "", "index": 0,
                        "prediction": None, "probability": None}
            elif label_type == "DETECTION":
                info = {"labelType": "DETECTION", "boxCount": [], "objectCount": None}
                for each in self.class_info[i]["classInfos"]:
                    c = {
                        "className": each["name"],
                        "index": each["index"],
                        "count": 0
                    }
                    info["boxCount"].append(c)
            else:
                continue

            file_info["labelDetails"].append(info)
        return file_info

    def save(self, filename, data):
        data.save(filename, encryption_key=self.encryption_key)
        # create msg
        shape = list(data['image']['array'].shape)

        if not data['image']['header']['IsVector']:
            shape.append(1)
        color_mode = data['image']['header']['color_mode']
        size = os.path.getsize(filename)

        self.file_info["colorMode"] = color_mode
        self.file_info["shape"] = str(shape)
        self.file_info["size"] = size
        while "//" in filename:
            filename = filename.replace("//", "/")
        self.file_info["filePath"] = filename
        self.file_info["fileNm"] = os.path.basename(filename)

    def add_cls_label(self, data, class_name):
        list_name = [info['name'] for info in self.class_info[0]["classInfos"]]
        index = list_name.index(class_name)
        data["label"]["classification"]["array"] = np.zeros(len(list_name))
        data["label"]["classification"]["array"][index] = 1
        data['label']['classification']['header'] = {'num_class': len(list_name),
                                                     'class_name': list_name}
        self.file_info["labelDetails"][0]["className"] = class_name
        self.file_info["labelDetails"][0]["index"] = index
        return data

    def add_seg_label(self, data, filename_label, class_dict=None):
        if self.seg_name_to_index is None:
            self.seg_name_to_index = {'background': 0}
            self.seg_name_to_index.update({self.class_info[1]["classInfos"][j]["name"]:
                                               self.class_info[1]["classInfos"][j]["value"]
                                           for j in range(1, len(self.class_info[1]["classInfos"]))})
        img_shape = data['image']['array'].shape
        if data['image']['header']['IsVector']:
            img_shape = img_shape[:-1]

        label = load_seg_label(filename_label, shape=img_shape, class_dict=class_dict)
        if len(class_dict) == 2 and len(np.unique(label['array'])) == 2:
            label['array'] = np.uint8((label['array'] - np.min(label['array'])) / (np.max(label['array']) - np.min(label['array'])))
        if (label['header']['IsVector']) and (label['array'].shape[-1] == 3):
            new_array = color_to_gray(label['array'], label['header']['dim'])
            label['array'] = new_array
            label['header']['IsVector'] = False

        label = self.make_mask_label(data, label)
        label['array'] = label['array'].astype("uint8")
        data['label']['segmentation'] = label
        data['label']['segmentation']['header']['dtype'] = 'uint8'
        data['label']['segmentation']['header']['class_name'] = list(self.seg_name_to_index.keys())
        data['label']['segmentation']['header']['class_value'] = list(self.seg_name_to_index.values())
        data['label']['segmentation']['header']['num_class'] = len(self.seg_name_to_index)
        data['label']['segmentation']['header']['Direction'] = data['image']['header']['Direction']
        data['label']['segmentation']['header']['Origin'] = data['image']['header']['Origin']
        data['label']['segmentation']['header']['Spacing'] = data['image']['header']['Spacing']

        for i in range(len(self.file_info["labelDetails"][1]["avgFraction"])):
            total_size = label['array'][..., 0].size
            fraction = np.sum(label['array'][..., i] == 1) / total_size
            self.file_info["labelDetails"][1]["avgFraction"][i]["avgFraction"] = fraction
        return data

    def add_det_label(self, data, filename_label, dimension):
        if self.det_name_to_index is None:
            self.det_name_to_index = {info['name']: info['index']
                                      for info in self.class_info[2]["classInfos"]}
        list_box, list_class = load_det_label(filename_label, dimension=dimension)
        list_cls_arr = list()
        self.file_info["labelDetails"][2]["objectCount"] = len(list_class)
        for name in list_class:
            idx = self.det_name_to_index[name]
            label_cls = np.zeros(len(self.det_name_to_index))
            label_cls[idx] = 1
            list_cls_arr.append(label_cls)
            self.file_info["labelDetails"][2]["boxCount"][idx]['count'] += 1

        data['label']['object_detection']['bbox_coordinate'] = np.array(list_box)
        data['label']['object_detection']['bbox_class'] = np.array(list_cls_arr)

        data['label']['object_detection']['header']['classes'] = self.det_name_to_index
        data['label']['object_detection']['header']['class_name'] = list(self.det_name_to_index.keys())
        data['label']['object_detection']['header']['num_class'] = len(self.det_name_to_index)
        return data

    def make_mask_label(self, data_input, label_input):
        image_shape = data_input['image']['array'].shape
        if data_input['image']['header']['IsVector']:
            image_shape = image_shape[:-1]

        label_shape = label_input['array'].shape
        ######## check label channel axis ####
        if len(label_shape) == len(image_shape):
            label_input['header']['IsVector'] = False
        elif len(image_shape) == len(label_shape) - 1:
            label_input['header']['IsVector'] = True
        else:
            dim_image = len(image_shape)
            dim_label = len(label_shape) - label_input['header']['IsVector']
            raise Exception(
                'The Dimension of the Label ({}D) is Different with the Dimension of Data ({}D). Please Check the Dimension of the Label.'.format(
                    dim_image, dim_label))

        if label_input['header']['IsVector']:
            ########### check channel first   ###############
            if image_shape == label_shape[:-1]:
                # channel last
                channel = 'last'
            elif image_shape == label_shape[1:]:
                # channel first
                logging.info("-------------------------------------")
                logging.info(image_shape)
                logging.info(label_input['array'].shape)
                logging.info("-------------------------------------")

                if len(label_input['array'].shape) == 3:
                    label_input['array'] = np.transpose(label_input['array'], [1, 2, 0])
                elif len(label_input['array'].shape) == 4:
                    label_input['array'] = np.transpose(label_input['array'], [1, 2, 3, 0])
            else:
                raise Exception(
                    'The Shape of the Label {} is Different with the Shape of Data {}. Please Check the Shape of the Label.'.format(
                        label_shape, image_shape))
            #############################################

        if not label_input['header']['IsVector']:
            label_input['array'] = np.expand_dims(label_input['array'], axis=-1)
            label_input['header']['IsVector'] = True

        list_msk = [label_input['array'] == list(self.seg_name_to_index.values())[i]
                    for i in range(len(self.seg_name_to_index))]
        mask = np.concatenate(list_msk, axis=-1).astype('uint8')
        label_input['array'] = mask

        return label_input

    def mask_value_dict(self):
        for i in range(len(self.class_info)):
            if self.class_info[i]['labelType'] != "SEGMENTATION":
                continue
            class_dict = {self.class_info[i]["classInfos"][j]['name']: self.class_info[i]["classInfos"][j]['value']
                          for j in range(len(self.class_info[i]["classInfos"]))}
        return class_dict

    def get_validation_result(self):
        msg = {
            "status": self.status,
            "message": self.message,
            "detail": self.detail,
            "messageParameter": self.messageParameter,
            "hdf": self.file_info,
            "original": self.originals
        }
        return msg

    def update_class_info(self, class_name, label_type):
        for i in range(len(self.class_info)):
            if self.class_info[i]['labelType'] != label_type:
                continue
            target = 'name'
            seg_color = False
            if label_type == 'SEGMENTATION':
                target = 'value'
                seg_color = True
            list_class = [self.class_info[i]["classInfos"][j][target]
                          for j in range(len(self.class_info[i]["classInfos"]))]

            for name in class_name:
                if name not in list_class:
                    add_info = add_class_info(len(list_class), name, label_type)
                    self.class_info[i]["classInfos"].append(add_info)
                    list_class.append(name)
                    list_class.sort()
                    self.class_info[i]["classInfos"] = class_name_sort(self.class_info[i]["classInfos"], target)
                    try:
                        for k in range(len(self.class_info[i]["classInfos"])):
                            self.class_info[i]["classInfos"][k]['color'] = assign_color(k, seg=seg_color)
                    except:
                        pass
                else:
                    if label_type == 'CLASSIFICATION':
                        idx = list_class.index(name)
                        self.class_info[i]["classInfos"][idx]["count"] += 1
                if label_type == 'CLASSIFICATION':
                    self.file_info["labelDetails"][i]["className"] = name
                    self.file_info["labelDetails"][i]["index"] = list_class.index(name)

    def update_class_xml(self, class_dict):
        list_class = [self.class_info[1]["classInfos"][j]['name']
                      for j in range(len(self.class_info[1]["classInfos"]))]
        class_name = list(class_dict.keys())

        for name in class_name:
            if name not in list_class:
                add_index = len(self.class_info[1]["classInfos"])
                add_info = {"value": add_index, "index": add_index, "count": 0, "name": name,
                            "editable": False, "interest": False, "color": "", "weight": 0.0}
                self.class_info[1]["classInfos"].append(add_info)
                try:
                    self.class_info[1]["classInfos"][add_index]['color'] = assign_color(add_index, seg=True)
                except:
                    pass


def add_class_info(len_class, name, label_type):
    add_info = {"value": 0, "index": len_class, "count": 0, "name": name,
                "editable": False, "interest": False, "color": "", "weight": 0.0}
    if label_type == 'CLASSIFICATION':
        add_info['count'] = 1
    elif label_type == 'SEGMENTATION':
        add_info['value'] = name
        add_info['name'] = ""
    return add_info


def get_list_batch(file_list, batch_size):
    num_batch = len(file_list) // batch_size + 1
    list_batch = [file_list[i * batch_size: (i + 1) * batch_size] for i in range(num_batch + 1) if
                  len(file_list[i * batch_size: (i + 1) * batch_size]) > 0]
    return list_batch


def val_multi(img_info, checker, image_path, list_label, list_class_label, case, previous_seg_class):
    filename_img = image_path + img_info['name']
    val_output = None
    label_type = case.split('_')[0]
    dimension_type = int(case.split('_')[1][0])
    _checker = copy.deepcopy(checker)
    _checker.originals.append(filename_img.replace("//", "/"))
    try:
        if label_type == 'CLASSIFICATION':
            check_extension(filename_img, [], case)
            val_output = [check_excel_matching(filename_img, list_label, list_class_label)]
            data = load_image(filename_img)
            if data['image']['header']['dim'] != dimension_type:
                code = 'worker.dataset-converter.error.invalid-dimension'
                raise DeepPhiError(code=code, parameter={})
        else:
            filename_label = check_matching(filename_img, list_label)
            _checker.originals.append(filename_label.replace("//", "/"))
            check_extension(filename_img, filename_label, case)
            if label_type == 'SEGMENTATION':
                if get_extension(filename_label).lower() == 'xml':
                    try:
                        class_dict = get_class_name_xml(filename_label)
                    except:
                        code = 'worker.dataset-converter.error.invalid-xml'
                        raise DeepPhiError(code=code, parameter={})
                    val_output = validate_seg(filename_img, filename_label, dimension_type, previous_seg_class, class_dict)
                else:
                    val_output = validate_seg(filename_img, filename_label, dimension_type, previous_seg_class)
            elif label_type == 'DETECTION':
                val_output = validate_det(filename_img, filename_label, dimension_type)
            elif label_type == 'TRANSFORMATION':
                validate_tran(filename_img, filename_label, dimension_type)
        _checker.status = 'SUCCESS'
        filename_save = '/' + '/{}.hdf5'.format(os.path.splitext(os.path.basename(filename_img))[0])
        _checker.file_info["fileNm"] = os.path.basename(filename_save)
    except Exception as exception:
        analyzer = ErrorAnalyzer(exception)
        msg = analyzer.get_error_msg()
        _checker.status = 'FAILED'
        _checker.message = msg['message']
        _checker.detail = msg['detail']
        _checker.messageParameter = msg['messageParameter']
    return [_checker, val_output]


def convert_multi(img_info, checker, image_path, path_save, list_label, list_class_label, case):
    filename_img = image_path + img_info['name']
    filename_save = path_save + \
                    '/' + '/{}.hdf5'.format(os.path.splitext(os.path.basename(filename_img))[0])
    label_type, dimension = case.split('_')[0:2]
    _checker = copy.deepcopy(checker)
    _checker.originals.append(filename_img.replace("//", "/"))
    try:
        data = load_image(filename_img)
        if label_type == 'CLASSIFICATION':
            cls_name = check_excel_matching(filename_img, list_label, list_class_label)
            data = _checker.add_cls_label(data, cls_name)
        else:
            filename_label = check_matching(filename_img, list_label)
            _checker.originals.append(filename_label.replace("//", "/"))
            if label_type == 'SEGMENTATION':
                class_dict = _checker.mask_value_dict()
                data = _checker.add_seg_label(data, filename_label, class_dict=class_dict)
            elif label_type == 'DETECTION':
                data = _checker.add_det_label(data, filename_label, dimension)
            elif label_type == 'TRANSFORMATION':
                data = add_tran_label(data, filename_label)

        _checker.save(filename_save, data)
        _checker.status = 'SUCCESS'

    except Exception as exception:
        analyzer = ErrorAnalyzer(exception)
        msg = analyzer.get_error_msg()
        _checker.status = 'FAILED'
        _checker.message = msg['message']
        _checker.detail = msg['detail']
        _checker.messageParameter = msg['messageParameter']

    msg = _checker.get_validation_result()
    for key in list(img_info.keys()):
        if key != 'name':
            msg['hdf'][key] = img_info[key]
    return msg


def add_tran_label(data, filename_label):
    label = load_tran_label(filename_label)
    data['label']['transformation'] = label
    return data


def color_to_gray(array, dim):
    if array.dtype in ['int16', 'int32', 'float64']:
        array = np.float32(array)
    if dim == 2:
        new_array = cv2.cvtColor(array, cv2.COLOR_RGB2GRAY)
    else:
        new_array = np.zeros_like(array[:, :, :, 0])
        for i in range(array.shape[0]):
            new_array[i,] = cv2.cvtColor(array[i,], cv2.COLOR_RGB2GRAY)
    return new_array


def get_class_name_xml(filename_label):
    xml_root = ET.parse(filename_label).getroot()
    annotations = xml_root.find('Annotations').findall('Annotation')
    class_dict = {'background': 0}
    class_name = list(class_dict.keys())
    count = 1
    for i in range(len(annotations)):
        tmp_class_name = str(annotations[i].attrib['class'])
        if (tmp_class_name == '') or (',' in tmp_class_name):
            tmp_class_name = 'no class'
        if tmp_class_name not in class_name:
            class_name.append(tmp_class_name)
            class_dict[tmp_class_name] = count
            count += 1
    return class_dict


def validate_seg(filename_img, filename_label, dimension_type, previous_seg_class, class_dict=None):
    data = load_image(filename_img)
    if data['image']['header']['dim'] != dimension_type:
        code = 'worker.dataset-converter.error.invalid-dimension'
        raise DeepPhiError(code=code, parameter={})
    img_shape = data['image']['array'].shape
    if data['image']['header']['IsVector']:
        img_shape = img_shape[:-1]
    label = load_seg_label(filename_label, shape=img_shape, class_dict=class_dict)
    check_dimension_image(data, label)
    label = check_seg_shape(data, label)
    if class_dict:
        label_info = class_dict
    else:
        label_info = get_seg_label_info(label)
        class_dict = {str(index): index for index in label_info}

    if previous_seg_class != 0:
        if int(previous_seg_class) < len(label_info):
            code = 'worker.dataset-converter.error.add-dataset.class-mismatch'
            raise DeepPhiError(code=code, parameter={})

    fraction_info = get_fraction_info(data, label, class_dict)
    fraction_info.insert(0, filename_label)
    fraction_info.insert(0, filename_img)
    return [label_info, fraction_info]


def validate_tran(filename_img, filename_label, dimension_type):
    data = load_image(filename_img)
    if data['image']['header']['dim'] != dimension_type:
        code = 'worker.dataset-converter.error.invalid-dimension'
        raise DeepPhiError(code=code, parameter={})
    label = load_tran_label(filename_label)
    check_dimension_image(data, label)


def validate_det(filename_img, filename_label, dimension_type):
    data = load_image(filename_img)
    if data['image']['header']['dim'] != dimension_type:
        code = 'worker.dataset-converter.error.invalid-dimension'
        raise DeepPhiError(code=code, parameter={})
    list_class = load_det_class(filename_label)
    return list_class


def get_seg_label_info(label):
    list_index = list(np.unique(label['array']).astype('int'))
    return list_index


def check_dimension_image(data_input, label_input):
    dim_image = data_input['image']['header']['dim']
    dim_label = label_input['header']['dim']
    if dim_image != dim_label:
        code = 'worker.dataset-converter.error.dimension-mismatch'
        raise DeepPhiError(code=code, parameter={'dim_label': dim_label, 'dim_image': dim_image})


def check_seg_shape(data_input, label_input):
    image_shape = data_input['image']['array'].shape
    if data_input['image']['header']['IsVector']:
        image_shape = image_shape[:-1]

    label_shape = label_input['array'].shape
    code = 'worker.dataset-converter.error.shape-mismatch'
    if label_input['header']['IsVector']:
        ########### check channel first   ###############
        if image_shape == label_shape[:-1]:
            # channel last
            channel = 'last'
        elif image_shape == label_shape[1:]:
            # channel first
            logging.info("-------------------------------------")
            logging.info(image_shape)
            logging.info(label_input['array'].shape)
            logging.info("-------------------------------------")


            if len(label_input['array'].shape) == 3:
                label_input['array'] = np.transpose(label_input['array'], [1, 2, 0])
            elif len(label_input['array'].shape) == 4:
                label_input['array'] = np.transpose(label_input['array'], [1, 2, 3, 0])
        else:
            raise DeepPhiError(code=code, parameter={'shape_label': label_shape, 'shape_image': image_shape})

        #############################################
    if not label_input['header']['IsVector']:
        if image_shape != label_shape:
            raise DeepPhiError(code=code, parameter={'shape_label': label_shape, 'shape_image': image_shape})
        label_input['array'] = np.expand_dims(label_input['array'], axis=-1)
        label_input['header']['IsVector'] = True

    return label_input


def class_name_sort(class_info, target):
    total_class_name = [cls_name[target] for cls_name in class_info]
    sorted_class_name = sorted(total_class_name)
    if total_class_name != sorted_class_name:
        new_class_info = [class_info[total_class_name.index(sorted_class_name[i])] for i in range(len(sorted_class_name))]
        for i in range(len(new_class_info)):
            new_class_info[i]['index'] = i
    else:
        new_class_info = class_info

    return new_class_info


def get_fraction_info(data, label, class_dict):
    if data['image']['header']['dim'] == 2:
        data['image']['array'] = np.expand_dims(data['image']['array'], axis=0)
        label['array'] = np.expand_dims(label['array'], axis=0)

    fraction_info = [get_max_fraction_slice(label['array'], class_dict, list(class_dict.values())[idx])
                     for idx in range(len(class_dict))]
    return fraction_info


def get_filename_wo_exe_csv(filename):
    extension_case = ['jpg', 'jpeg', 'png', 'tif', 'tiff', 'dcm', 'bmp', 'nii', 'nii.gz']
    exe = [extension for extension in extension_case if extension in filename]
    if exe:
        filename = filename.replace('.' + exe[0], '')
    return filename



if __name__ == '__main__':
    path_origin = "../unit_test/case1/origin/"
    case = "DETECTION_2D_CASE1"
    class_info = [
        {
            "labelType": "CLASSIFICATION",
            "hasLabel": False,
            "labelShape": "",
            "classInfos": []
        },
        {
            "labelType": "SEGMENTATION",
            "hasLabel": False,
            "labelShape": "",
            "classInfos": []
        },
        {
            "labelType": "DETECTION",
            "hasLabel": False,
            "labelShape": "",
            "classInfos": []
        },
        {
            "labelType": "TRANSFORMATION",
            "hasLabel": False,
            "labelShape": "",
            "classInfos": []
        }
    ]
    checker = DeepphiValidation(path_origin, case, class_info)
    result = checker.validate()
    class_info = checker.class_info
    checker = DeepphiValidation(path_origin, case, msg_creator, requestType="ALL")
    result = checker.validate(list_img=list_dataset)

    print(class_info)
    print(result)
