#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import zipfile
import numpy as np
import os
import logging
from deepphi.io.converter_v2.utils import *
import shutil
from deepphi.logger.error import DeepPhiError, ErrorAnalyzer
from deepphi.io.converter_v2.validation.exception import *


def case_validation(unzip_path, datasetCases):
    if type(unzip_path) == str:
        top_path = unzip_path
        dataset_path = top_path + '/dataset/'
        dataset_structure = get_unzip_structure(dataset_path)
    else:
        dataset_structure, top_path = get_unzip_structure_from_list(unzip_path)
    label_type, case = split_case(datasetCases)
    # msg = 'Selected case and uploaded folder structure are different.'
    for i in range(len(label_type)): # 멀티 라벨
        # Classification case 1
        if not (('CLASSIFICATION' == label_type[i]) and (case[i] == 1)):
            label_path = top_path + '/%s/' % (label_type[i].lower())
            label_structure = get_unzip_structure(label_path)
            # Classification case 2
            # if ('CLASSIFICATION' == label_type[i]) and (case[i] == 2):
                # 엑셀 파일1개 이외의 것이 존재하는지 체크
                # if (len(label_structure['folders']) > 0) or (len(label_structure['files']) > 1):
                #     msg = msg + '\nFor Classification Case 2, there should be only one Excel file. Please delete the others.'
                #     raise FolderStructureError(msg)
                # # 엑셀 파일인지 체크
                # if os.path.splitext(label_structure['files'][0])[-1] not in ('.csv', '.xlsx'):
                #     msg = msg + '\nFor Classification Case 2, the label file must be in Excel format.'
                #     raise FolderStructureError(msg)
            # else:  # segmentation, detection, transformation
                # detection 경우 시리즈 데이터인지 체크
            if 'DETECTION' == label_type[i]:
                if series_check(dataset_structure) or series_check(label_structure):
                    # msg = msg + '\nFor Detection, There should be no series data in the Dataset or Label.'
                    code = 'worker.dataset-converter.error.detection-series-check'
                    raise DeepPhiError(code=code, parameter={})

def split_case(datasetCases):
    label_type = [data.split('_')[0] for data in datasetCases]
    case = [int(data[-1]) for data in datasetCases]
    return label_type, case


if __name__ == "__main__":
    # path = ['/home/hslisalee/Desktop/dataset/케이스체크/연습2/Output/dataset/1.png',
    #         '/home/hslisalee/Desktop/dataset/케이스체크/연습2/Output/dataset/2.png',
    #         '/home/hslisalee/Desktop/dataset/케이스체크/연습2/Output/dataset/3.png']
    path = ['/home/swseo/Dropbox/deepnoid/development/DEEP-PHI-deeplearning-beta/deepphi/io/converter_v2/unit_test/case2/origin/']
    datasetCases = [
      "CLASSIFICATION_2D_CASE2",
      "SEGMENTATION_2D_CASE2"
    ]
    unzip_path = path
    case_validation(path, datasetCases)