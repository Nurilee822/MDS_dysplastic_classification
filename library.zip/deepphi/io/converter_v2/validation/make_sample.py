#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import numpy as np
import cv2, logging
import matplotlib.pyplot as plt
from PIL import ImageFont, ImageDraw, Image

def save_np_to_jpg(path, img_array, label_array, idx):
    img_array = rescale(img_array)
    img_array = make_rgb_image(img_array)
    img_array = zero_padding(img_array)
    label_array = zero_padding(label_array)
    tmp_label = np.uint8(np.zeros((label_array.shape[0], label_array.shape[0], 3)))
    tmp_label[label_array[:, :, 0] == idx] = 255
    overlay_img = np.copy(img_array)
    overlay_img[label_array[:, :, 0] == idx] = (255, 0, 0)
    output_img = np.concatenate((img_array, tmp_label, overlay_img), axis=1)
    title_img = make_title_image()
    output_img = cv2.resize(output_img, (768, 256))
    output_img = np.concatenate((output_img, title_img), axis=0)
    output_img = cv2.resize(output_img, (700, 230))
    image = Image.fromarray(output_img)
    image.save(path)


def write_text(text, location):
    img_array = np.uint8(np.zeros((30,256,3)))
    font_path = './deepphi/io/font/NanumGothicBold.ttf'
    font = ImageFont.truetype(font_path, 20)
    image = Image.fromarray(img_array)
    draw = ImageDraw.Draw(image)
    draw.text(location, text, font=font, fill=(255,255,255))
    return np.uint8(np.array(image))


def make_title_image():
    img1 = write_text('Original', [90, 0])
    img2 = write_text('Label', [100, 0])
    img3 = write_text('Overlay', [95, 0])
    output_img = np.concatenate((img1, img2, img3), axis=1)
    return output_img


def get_max_fraction_slice(array, class_dict, index_class):
    num_count_slice = np.sum(np.sum(np.sum(array == index_class, axis=-1), axis=-1), axis=-1)
    idx_slice = np.argmax(num_count_slice)
    num_count = num_count_slice[idx_slice]
    fraction = num_count/(array.shape[1] * array.shape[2])
    class_name = [name for name, value in class_dict.items() if value == index_class][0]
    return [class_name, idx_slice, fraction]


def zero_padding(img_array):
    height, width = img_array.shape[0:2]
    margin = [np.abs(height - width) // 2, np.abs(height - width) // 2]
    if np.abs(height - width) % 2 != 0:
        margin[0] += 1
    if height < width:
        margin_list = [margin, [0, 0], [0, 0]]
    else:
        margin_list = [[0, 0], margin, [0, 0]]
    new_array = np.pad(img_array, margin_list, mode='constant')  # add zero-padding to image
    return new_array


def rescale(array):
    min_value = np.min(array)
    max_value = np.max(array)
    diviser = max_value - min_value
    if diviser == 0:
        if max_value != 0:
            array = np.uint8((array / max_value) * 255)
        else:
            array = np.uint8(array)
    else:
        array = np.uint8((array - min_value) / (diviser) * 255)
    return array

def make_rgb_image(ori_img):
    if ori_img.ndim == 2:
        output_img = cv2.cvtColor(ori_img, cv2.COLOR_GRAY2RGB)
    else:
        ori_img_ch = ori_img.shape[-1]
        if ori_img_ch == 3:
            output_img = ori_img
        else:
            output_img = np.uint8(ori_img.sum(axis=2))
            output_img = cv2.cvtColor(output_img, cv2.COLOR_GRAY2RGB)
    return output_img