#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
import time
import os, logging, glob
from deepphi.io.converter_v2.io import *

class KafakaUpload(object):
    def __init__(self, cfg):
        self.cfg = cfg

        self.moduleId = cfg['parameterInformation']['moduleId']
        self.imageDatasetId = cfg['datasetInformation']['imageDatasetId']
        self.historyId = cfg['datasetInformation']['historyId']
        self.executeRequester = cfg['parameterInformation']['executeRequester']
        self.executionType = cfg['datasetInformation']['executionType']
        self.autoValidation = cfg['datasetInformation']['autoValidation']
        self.replace = cfg['datasetInformation']['replace']
        self.labelNames = str(cfg['datasetInformation']['labelNames'])

        self.output_path = cfg['datasetPath']['outputPath']
        while "//" in self.output_path:
            self.output_path = self.output_path.replace("//", "/")

        # self.has_label = {'CLASSIFICATION': False, 'SEGMENTATION': False, 'DETECTION': False, 'TRANSFORMATION': False}
        self.path_unpacking_result = None
        self.class_info = [
                {
                    "labelType": "CLASSIFICATION",
                    "hasLabel": False,
                    "labelShape": "",
                    "classInfos": []
                },
                {
                    "labelType": "SEGMENTATION",
                    "hasLabel": False,
                    "labelShape": "",
                    "classInfos": []
                },
                {
                    "labelType": "DETECTION",
                    "hasLabel": False,
                    "labelShape": "",
                    "classInfos": []
                },
                {
                    "labelType": "TRANSFORMATION",
                    "hasLabel": False,
                    "labelShape": "",
                    "classInfos": []
                }
            ]
        self.result = list()
        self.executionStatus = "IN_PROGRESS"
        # self.errorMsg = ""
        self.message = ""
        self.detail = ""
        self.messageParameter = dict()

        self.count = 0
        self.processed_count = 0
        self.start_time = time.time()

    def set_start_time(self):
        self.start_time = time.time()

    def set_total_count(self, count):
        self.count = count

    def add_label_name(self, class_name):
        self.labelNames = str(class_name)

    def add_result(self, result):
        self.result.append(result)
        self.processed_count += 1

    def get_kafka_msg(self, class_info=True):
        if class_info:
            label_information = self.class_info
        else:
            label_information = []
        sample_path = self.get_sample_path()
        execution_result = self.get_execution_result()
        msg = {
            "moduleId": self.moduleId,
            "imageDatasetId": self.imageDatasetId,
            "historyId": self.historyId,
            "executeRequester": self.executeRequester,
            "executionType": self.executionType,
            "executionStatus": self.executionStatus,
            "autoValidation": self.autoValidation,
            # "errorMsg": self.errorMsg,
            "message": self.message,
            "detail": self.detail,
            "messageParameter": self.messageParameter,
            "labelInformations": label_information,
            "samplePath": sample_path,
            "executionResult": execution_result,
            "replace": self.replace,
            "labelNames": self.labelNames
        }
        return msg

    def get_class_kafka_msg(self):
        msg = {'moduleId': self.moduleId,
               'status': 'SUCCESS',
               'executionType': self.executionType,
               'moduleExecuteId': 0,
               'requester': self.executeRequester,
               'historyId': self.historyId,
               'autoValidation': self.autoValidation,
               'labelInformations': self.class_info,
               'labelNames': self.labelNames}
        return msg

    def set_has_label(self, labelType):
        for i in range(len(self.class_info)):
            if labelType.upper() == self.class_info[i]['labelType']:
                self.class_info[i]["hasLabel"] = True


    def get_sample_path(self):
        path = os.path.dirname(os.path.dirname(self.output_path)) + "/" + "sample/"
        if not os.path.exists(path):
            # print(path)
            os.mkdir(path)
        return path

    def set_unpacking_result(self, path):
        self.path_unpacking_result = path

    def get_unpacking_result(self):
        if self.path_unpacking_result is None:
            return ""
        else:
            return self.path_unpacking_result

    def get_progress_info(self):
        info = {
                    "totalCnt": self.count,
                    "processedCnt": self.processed_count
                }

        return info

    def get_upload_file_result(self):
        return self.result

    def get_execution_result(self):
        result = {
                "unpackResultPath": self.get_unpacking_result(),
                "progressInformation": self.get_progress_info(),
                "uploadFileResults": self.get_upload_file_result()
            }
        return result


