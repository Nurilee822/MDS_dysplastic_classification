#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import os
import shutil
import zipfile
import deepphi.io.converter_v2.utils as utils
from deepphi.io.converter_v2.io import *
import glob, time
from pathlib import Path
from deepphi.io.converter_v2.utils import is_check_folder
from deepphi.io.converter_v2.validation.cls_case1_make_excel import *
from deepphi.io.converter_v2.validation.exception import *
from deepphi.logger.error import DeepPhiError, ErrorAnalyzer
import traceback


def unpack_zip(zip_filename, unzip_path, cls_case1=False, dimension=None):
    try:
        # add handling for ko charset
        with zipfile.ZipFile(zip_filename, 'r') as zf:
            zipInfo = zf.infolist()
            list_dir = list()
            for fileEntry in zipInfo:
                element = fileEntry.filename.split("/")
                if len(element) == 1:
                    continue
                if fileEntry.filename.split("/")[1] == '':
                    list_dir.append(fileEntry.filename.encode('cp437').decode('euc-kr', 'ignore'))

            if '__MACOSX/' in list_dir:
                list_dir.remove('__MACOSX/')

            is_folder = len(list_dir) == 1
            if cls_case1:
                is_folder = False
            if is_folder:
                folder_name = os.path.basename(unzip_path)
                unzip_path = os.path.dirname(unzip_path)

            for fileEntry in zipInfo:
                try:
                    try:
                        fileEntry.filename = fileEntry.filename.encode('cp437').decode('euc-kr', 'ignore')
                    except:
                        pass
                    if not ('.DS_Store' in fileEntry.filename) or ('thumb.db' in fileEntry.filename):
                        zf.extract(fileEntry, unzip_path)
                except:
                    raise Exception()

        os.remove(zip_filename)
        delete_macosx(unzip_path)
        if (dimension == '3D') and (len(list_dir) == 1):

            for _, dirs, _ in os.walk(glob.glob(unzip_path + '/*/')[0]):
                if len(dirs) == 0:
                    is_check_folder(unzip_path + '/' + folder_name)
                    for i in range(20):
                        try:
                            shutil.move(unzip_path + '/' + list_dir[0], unzip_path + '/' + folder_name)
                            return
                        except Exception as e:
                            tb = traceback.format_exc()
                            logging.info(tb)
                            time.sleep(5)
                    raise Exception()
                else:
                    break

        if is_folder:
            for i in range(20):
                try:
                    os.rename(unzip_path + '/' + list_dir[0], unzip_path + '/' + folder_name)
                    return
                except Exception as e:
                    tb = traceback.format_exc()
                    logging.info(tb)
                    time.sleep(5)
            raise Exception()
    except Exception as e:
        code = 'worker.dataset-converter.error.broken-zip'
        raise DeepPhiError(code=code, parameter={})


def get_unzip_path(zip_path, input_path):
    list_zip = glob.glob(zip_path + '/*/*.zip')
    is_custom = custom_check(list_zip)
    list_zip = sorting_zip_list(list_zip)
    is_append = False

    list_work = list()
    for zip_name in list_zip:
        dir_name = os.path.basename(os.path.dirname(zip_name))
        unzip_path = input_path + '/' + dir_name
        is_append = os.path.exists(unzip_path)
        if is_append:
            unzip_path = input_path + "/append/" + dir_name
            is_check_folder(input_path + "/append/")

        unzip_path = unzip_path.replace("//", "/")
        list_work.append([zip_name, unzip_path])

    return list_work, is_append, is_custom


def custom_check(list_zip):
    for zip_name in list_zip:
        if Path(zip_name).stem.lower() in ['train', 'validation', 'test']:
            return True
    return False


def sorting_zip_list(list_zip):
    for i in range(len(list_zip)):
        if 'Test.zip' in list_zip[i]:
            tmp_list = list_zip[i]
            del list_zip[i]
            list_zip.append(tmp_list)
    return list_zip


def get_csv_path(csv_path, input_path):
    list_zip = glob.glob(csv_path + '/*/*.csv')
    is_append = False
    list_work = list()
    for zip_name in list_zip:
        dir_name = os.path.basename(os.path.dirname(zip_name))
        unzip_path = input_path + '/' + dir_name
        is_append = os.path.exists(unzip_path)
        if is_append:
            unzip_path = input_path + "/append/" + dir_name
            is_check_folder(input_path + "/append/")
            is_check_folder(unzip_path)

        list_work.append([zip_name, unzip_path])

    return list_work, is_append


def make_total_class_name(unzip_path):
    total_class = list()
    if os.path.exists(unzip_path + 'classification'):
        excel_file = glob.glob(unzip_path + 'classification' + '/*csv')[0]
        excel_file = excel_file.replace("//", "/")
        class_name_list = cls_total_class_name(excel_file)
        total_class.append({'CLASSIFICATION': class_name_list})

    if os.path.exists(unzip_path + 'detection'):
        path_label = unzip_path + 'detection/'
        class_name_list = det_total_class_name(path_label)
        total_class.append({'DETECTION': class_name_list})

    return total_class


def confirm_class_name(dataset_class_name, append_class_name, unzip_path):
    if dataset_class_name:
        for each in append_class_name:
            label_type = list(each.keys())[0]
            class_name = list(each.values())[0]
            for name in class_name:
                for i in range(len(dataset_class_name)):
                    if list(dataset_class_name[i].keys())[0] == label_type:
                        if name not in list(dataset_class_name[i].values())[0]:
                            # msg = 'It is different from the existing class information.\n'
                            # msg = msg + 'The class name (%s) you want to add does not exist in the existing class.' % name
                            # msg = msg + '\nPlease create a new dataset.'
                            delete_append(unzip_path)
                            code = 'worker.dataset-converter.error.add-dataset.another-class'
                            raise DeepPhiError(code=code, parameter={'class_name': name})
                            # raise ClassMisMatchError(msg)


def delete_macosx(path):
    mac_folder = path + '/__MACOSX'
    mac_folder = mac_folder.replace("//", "/")
    if os.path.exists(mac_folder):
        shutil.rmtree(mac_folder)



if __name__ == '__main__':
    zip_path = './unit_test/dataset/zip/'
    input_path = './unit_test/dataset/origin/'
    output_path = './unit_test/dataset/output/'

    list_work = get_unzip_path(zip_path, input_path)
    for work in list_work:
        unpack_zip(*work)

    structure = utils._get_structure(input_path + 'unpack')


# def run_unpack(cfg):
#     mode = 'result_unpack'
#     msg_json = Hdf5Converter.MSG_RESULT
#     msg_json['execution_type'] = 'UNPACK'
#
#     # check zip valid
#     zip_filename = cfg['dataset']['zip_path']
#     upzip_path = cfg['dataset']['input_path']
#     dimension = cfg['dataset_information']['dimension_type']
#
#     if os.path.exists(upzip_path):
#         shutil.rmtree(upzip_path)
#
#     # add handling for ko charset
#     with zipfile.ZipFile(zip_filename, 'r') as zf:
#         zipInfo = zf.infolist()
#         for fileEntry in zipInfo:
#             try:
#                 fileEntry.filename = fileEntry.filename.encode('cp437').decode('euc-kr', 'ignore')
#                 zf.extract(fileEntry, upzip_path)
#             except:
#                 raise Exception('handle exception required.')
#
#     # structure
#     structure = Hdf5Converter._get_structure(upzip_path)
#     path_structure = str(Path(upzip_path).parent) + "/structure.json"
#
#     json_data = json.dumps(structure)
#     with open(path_structure, 'w') as f:
#         f.write(json_data)
#
#     # get case converter
#     # case = Hdf5Converter._get_template_case(upzip_path, dimension)
#     # case_converter = CONVERTER[case](dimension)
#     # num_hdf5 = len(case_converter._get_work(upzip_path, './'))
#
#     # make msg
#     msg_json['status'] = 'success'
#     # msg_json['totalSize'] = num_hdf5
#     msg_json[mode]['path_structure'] = path_structure
#
#     return msg_json
