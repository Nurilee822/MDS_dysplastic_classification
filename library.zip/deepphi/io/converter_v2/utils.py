#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import os
import glob, logging
import numpy as np
import pandas as pd
from deepphi.io.converter_v2.validation.exception import *
from deepphi.logger.error import DeepPhiError, ErrorAnalyzer
import shutil
import time


def append_dataset(structure, unzip_path, cls_case1, replace=False):
    append_type = os.listdir(unzip_path + 'append/')
    for append_target in append_type:
        if append_target != 'classification':
            append_path = unzip_path + 'append/' + append_target
            origin_path = unzip_path + append_target

            append_file_list = os.listdir(append_path)
            origin_file_list = os.listdir(origin_path)

            intersection_list = list(set(append_file_list) & set(origin_file_list))
            unique_append_list = [file for file in append_file_list if file not in intersection_list]
            list_structure = list()

            for file in unique_append_list:
                list_structure = find_target_list(file, structure, list_structure)
                shutil.move(append_path + '/' + file, origin_path)

            if replace:
                for file in intersection_list:
                    list_structure = find_target_list(file, structure, list_structure)
                    if get_extension(file).lower():
                        os.remove(origin_path + '/' + file)
                    else:
                        shutil.rmtree(origin_path + '/' + file)
                    shutil.move(append_path + '/' + file, origin_path)
            structure = list_structure

        else:
            target_path = unzip_path + 'classification'
            source_path = unzip_path + 'append/classification'
            if os.path.exists(target_path) and os.path.exists(source_path):
                structure_csv = csv_append(source_path, target_path, replace)
                if not cls_case1:
                    structure += structure_csv

    time.sleep(1)
    delete_append(unzip_path)

    return structure


def find_target_list(file, structure, list_structure):
    target_structure = [_file_structure for _file_structure in structure
                        if file in _file_structure['filePath']]
    for _target_structure in target_structure:
        _target_structure['filePath'] = _target_structure['filePath'].replace("/append", "").replace("//", "/")
        _target_structure['folderPath'] = _target_structure['folderPath'].replace("/append", "").replace("//", "/")
        list_structure.append(_target_structure)
    return list_structure



def csv_append(source_path, target_path, replace=False):
    list_append = list()
    structure, _ = get_unpack_structure(os.path.dirname(target_path) + '/dataset', labelType='DATASET')
    dataset_name_list = [get_filename_wo_exe(filename['fileNm']) for filename in structure]

    target_csv, target_name_list, target_class_list = find_class_to_csv(target_path)
    _, source_name_list, source_class_list = find_class_to_csv(source_path)

    csv_file = open(target_csv, 'w', encoding='cp949')
    csv_file.write('Filename,Class Name\n')

    for i in range(len(source_name_list)):
        source_file_name = source_name_list[i]
        source_file_class = source_class_list[i]
        if (source_file_name in target_name_list) and replace:
            target_file_index = target_name_list.index(source_file_name)
            target_class_list[target_file_index] = source_file_class
            if source_file_name in dataset_name_list:
                list_append.append(structure[dataset_name_list.index(source_file_name)])
        elif (source_file_name in target_name_list) and (not replace):
            pass
        else:
            target_name_list.append(source_file_name)
            target_class_list.append(source_file_class)

    for i in range(len(target_name_list)):
        csv_file.write(target_name_list[i] + ',' + target_class_list[i] + '\n')
    csv_file.close()
    return list_append


def find_class_to_csv(input_path):
    input_csv = glob.glob(input_path + '/*csv')[0]
    input_csv = input_csv.replace("//", "/")
    input_csv_file = pd.read_csv(input_csv, encoding='cp949')
    input_name_list = [get_filename_wo_exe(filename) for filename in input_csv_file[input_csv_file.columns[0]]]
    input_class_list = [str(classname) for classname in input_csv_file[input_csv_file.columns[1]]]
    return input_csv, input_name_list, input_class_list


def is_check_folder(path):
    if not os.path.exists(path):
        os.mkdir(path)
        time.sleep(0.01)


def folder_duplicate_check(input_path, target_path, cls_case1=False):
    folder_list = os.listdir(input_path)
    for folder_name in folder_list:
        path = input_path + '/' + folder_name

        path = custom_duplicate_name_change(path, target_path)
        path = name_plus_count(path, target_path)
        if cls_case1 and (os.path.basename(path) != folder_name):
            csv_filename_change(path, folder_name)


def get_unpack_structure(input_path, labelType=None, zipfile_name=None, cls_case1=False):
    if zipfile_name in ['TRAIN', 'VALIDATION', 'TEST']:
        target_path = os.path.dirname(input_path) + '/' + 'dataset_by_deepnoid_tmp'
        is_check_folder(target_path)
        folder_duplicate_check(input_path, target_path, cls_case1)

    file_structure = get_unzip_structure(input_path)
    list_filename = file_structure.get_files(mode='all')
    list_folders = file_structure.get_folders(mode='all')

    list_st = list()
    total_size = 0
    tmp_path = []
    tmp_target_path = []
    for path in list_filename + list_folders:
        path = path.replace("//", "/")

        if os.path.isdir(path):
            size = None
        else:
            size = os.path.getsize(path)
            total_size += size

        folder_path = os.path.relpath(os.path.dirname(path), os.path.dirname(input_path)) + "/"

        if zipfile_name in ['TRAIN', 'VALIDATION', 'TEST']:
            folder_path = folder_path.replace(zipfile_name.lower(), 'dataset')

            ori_file_name = os.path.basename(path)
            if os.path.dirname(path).split('/')[-1].upper() in ['TRAIN', 'VALIDATION', 'TEST']:
                path = custom_duplicate_name_change(path, target_path)
                path = name_plus_count(path, target_path)

                if cls_case1 and (os.path.basename(path) != ori_file_name):
                    csv_filename_change(path, ori_file_name)
                tmp_path.append(path)
                tmp_target_path.append(target_path)
            path = path.replace("/" + zipfile_name.lower(), "/dataset")
            label_name = 'DATASET'
            usage_type = zipfile_name.lower()
        elif zipfile_name == 'DATASET':
            label_name = 'DATASET'
            usage_type = ""
        else:
            label_name = labelType
            usage_type = ""
        fileNm = os.path.basename(path)
        if '.' in fileNm:
            file_type = "FILE"
        else:
            file_type = "FOLDER"

        list_st.append(
            {'filePath': path, 'size': size, 'fileNm': fileNm, 'folderPath': folder_path, 'fileType': file_type,
             'labelType': label_name, 'usage': usage_type})

    if zipfile_name in ['TRAIN', 'VALIDATION', 'TEST']:
        for i in range(len(tmp_path)):
            try:
                shutil.move(tmp_path[i], tmp_target_path[i])
            except:
                pass
        shutil.rmtree(input_path)
    else:
        list_st.append({'filePath': input_path, 'size': total_size, 'fileNm': os.path.basename(input_path),
                        'folderPath': "", 'fileType': "FOLDER", 'labelType': labelType, 'usage': ""})
    return list_st, total_size


def csv_filename_change(path, ori_file_name):
    after_file_name = os.path.basename(path)
    zip_name = os.path.basename(os.path.dirname(path))
    csv_path = path.split(zip_name,1)[0] + 'classification/' + zip_name + '.csv'
    test = pd.read_csv(csv_path, encoding='cp949')
    test.loc[test.Filename==ori_file_name, 'Filename'] = after_file_name
    test.to_csv(csv_path, index=False, encoding ='cp949')


def custom_duplicate_name_change(path, target_path):
    file_list = os.listdir(target_path)
    file_name = os.path.basename(path)

    if file_name in file_list:
        usage_name = os.path.basename(os.path.dirname(path)).upper()
        try:
            _file_name, extension_name = file_name.split('.')
            new_name = os.path.dirname(path) + '/' + _file_name + '_' + usage_name + '.'+extension_name
        except:
            new_name = os.path.dirname(path) + '/' + file_name + '_' + usage_name

        os.rename(path, new_name)
        return new_name
    else:
        return path


def name_plus_count(path, target_path):
    file_name = os.path.basename(path)
    count = 0
    ori_name = file_name
    while True:
        if os.path.exists(target_path + file_name):
            try:
                _file_name, extension_name = ori_name.split('.')
                file_name = _file_name + '_' + str(count) + '.' + extension_name
            except:
                file_name = ori_name + '_' + str(count)
            count += 1
        else:
            os.rename(path, os.path.dirname(path) + '/' + file_name)
            return os.path.dirname(path) + '/' + file_name



class ZipStructure(dict):
    def __init__(self, abs_path, *args, **kwargs):
        super(ZipStructure, self).__init__(*args, **kwargs)
        self["files"] = list()
        self["folders"] = dict()
        self.abs_path = abs_path

    def add_file(self, filename):
        self["files"].append(filename)

    def add_folder(self, dirname):
        base_name = os.path.basename((dirname))
        self['folders'][base_name] = get_unzip_structure(dirname)

    def get_files(self, mode='this', basename=False):
        if mode == 'this':
            list_files = list(self['files'])
            if basename:
                for i in range(len(list_files)):
                    list_files[i] = os.path.basename(list_files[i])
            return list_files
        elif mode == 'all':
            list_in_files = self.get_files(mode='this')
            for dir_name in self.get_folders(basename=True):
                list_in_this_dir = self['folders'][dir_name].get_files(mode='all')
                # for i in range(len(list_in_this_dir)):
                #     list_in_this_dir[i] = "{}/{}".format(dir_name, list_in_this_dir[i])

                list_in_files = list_in_files + list_in_this_dir

            return list_in_files

    def get_folders(self, mode='this', basename=False):
        if mode == 'this':
            list_dirname = list()
            for key in self['folders'].keys():
                abs_path = self['folders'][key].abs_path
                list_dirname.append(abs_path)

            if basename:
                for i in range(len(list_dirname)):
                    list_dirname[i] = os.path.basename(list_dirname[i])

            return list_dirname
        elif mode == 'all':
            list_in_dirs = self.get_folders(mode='this', basename=basename)
            for dir_name in self.get_folders(basename=True):
                list_in_this_dir = self['folders'][dir_name].get_folders(mode='all')

                # for i in range(len(list_in_this_dir)):
                #     list_in_this_dir[i] = "{}/{}".format(dir_name, list_in_this_dir[i])

                list_in_dirs = list_in_dirs + list_in_this_dir

            return list_in_dirs


def get_dataset_name(file_structure):
    if isinstance(file_structure, str):
        if os.path.exists(file_structure):
            dir_list = glob.glob(file_structure + '/*')
    else:
        dir_list = file_structure.get_folders(basename=True)
    for dir_name in dir_list:
        basename = os.path.basename(dir_name)
        if basename.lower() == 'dataset':
            return basename
    return False


def get_label_name(file_structure):
    if isinstance(file_structure, str):
        if os.path.exists(file_structure):
            dir_list = glob.glob(file_structure + '/*')
            import logging

        for name in dir_list:
            basename = os.path.basename(name)
            if (basename.lower() == 'label') or (basename.lower() == 'label.csv'):
                return basename
    else:
        list_folders = file_structure.get_folders(basename=True)
        list_files = file_structure.get_files(basename=True)

        for name in list_folders:
            if name.lower() == 'label':
                return name

        for name in list_files:
            if name.lower() == 'label.csv':
                return name


def get_name_xlsx(input_path):
    files = glob.glob(input_path + '/*')
    filename_class = None
    for filename in files:
        import logging
        # logging.info(filename)
        basename = os.path.basename(filename)
        if (basename.lower() == 'class.xlsx') or (basename.lower() == 'data_option.xlsx') \
                or (basename.lower() == 'transformation.xlsx'):
            filename_class = filename
            return filename_class

    return None


def get_list_in_dir(name_list, dirname):
    list_in_dataset = [name for name in name_list
                       if (dirname in name) and (dirname != name)]

    return list_in_dataset


def get_extension(filename):
    filename_piece = filename.split('.')
    if len(filename_piece) == 1:
        exe = ''
    else:
        exe = filename_piece[-1]
    if exe == 'gz' and filename_piece[-2] == 'nii':
        exe = "{}.{}".format(filename_piece[-2], exe)
    return exe


def get_filename_wo_exe(filename):
    exe = get_extension(filename)
    if exe == '':
        return filename
    else:
        return filename[:-len(exe) - 1]


def get_zip_structure(zipfile):
    info_list = [info for info in zipfile.infolist()]
    file_structure = ZipStructure()

    for name in info_list:
        dir_hierachy = name.filename.split('/')

        if len(dir_hierachy) == 1:
            file_structure.add_file(name.filename)
        else:
            if dir_hierachy[-1] == '':
                dir_hierachy.pop(-1)  # remove ''
            last_name = dir_hierachy.pop(-1)
            dict_now = file_structure
            for dir_name in dir_hierachy:  # deep into the hierachy
                dict_now = dict_now["folders"][dir_name]

            if name.is_dir():
                dict_now.add_folder(last_name)
            else:
                dict_now.add_file(last_name)

    return file_structure


def get_unzip_structure(input_path):
    structure = ZipStructure(input_path)
    list_path = glob.glob(input_path + "/*")
    for path in list_path:
        if os.path.isdir(path):
            structure.add_folder(path)
        else:
            structure.add_file(path)
    return structure


def read_class_xlsx(filename):
    class_info = pd.read_excel(filename)
    if len(class_info) == 1:
        series_independent = str(class_info.iloc[0, 0]).lower()
        return series_independent
    else:
        series_independent = str(class_info.iloc[0, 0]).lower()
        class_name = list(class_info.iloc[:, 1])
        class_value = list(class_info.iloc[:, 2])
        for i in range(len(class_value)):
            if isinstance(class_value[i], str):
                class_value[i] = [int(v) for v in class_value[i].split('-')]

        return class_name, class_value, series_independent


def check_multi_label(input_path):
    label_name = get_label_name(input_path)
    filename_label = glob.glob(input_path + '/{}/*'.format(label_name))

    list_slice_exe = ['dcm', 'png', 'jpg', 'jpeg']

    is_slice = False
    num_labels = 0
    for filename in filename_label:
        if not os.path.isdir(filename):
            return False

        labels = glob.glob(filename + '/*')

        # check is slice
        list_exe = list()
        for filename in labels:
            exe = get_extension(filename)
            list_exe.append(exe)

        if len(list_exe) > 0:
            exe = np.unique(list_exe)[0]
        else:
            exe = ""

        if exe in list_slice_exe:
            is_slice = True
        else:
            is_slice = False
        ####

        num_labels = max(num_labels, len(labels))

    if is_slice:
        return False

    return num_labels > 1


def get_unzip_structure_from_list(path_list):
    top_path = os.path.dirname(path_list[0])
    structure = ZipStructure(top_path)
    for path in path_list:
        if os.path.isdir(path):
            structure.add_folder(path)
        else:
            structure.add_file(path)
    return structure, os.path.dirname(top_path)


def series_check(structure):
    patient_name = structure.get_folders(basename=True)
    for name in patient_name:
        patient_folder = structure['folders'][name]
        if len(patient_folder['folders']) != 0:
            return True
    return False


def split_case(dataset_case):
    label_type = [data.split('_')[0] for data in dataset_case]
    case = [int(data[-1]) for data in dataset_case]
    return label_type, case


def check_extension(dataset_name, label_name, label_type):
    label_type, case = split_case([label_type])
    extension_case = ['jpg', 'jpeg', 'png', 'tif', 'tiff', 'dcm', 'bmp', 'nii', 'nii.gz']

    dataset_series = confirm_extension(dataset_name, extension_case, 'Image')

    if label_type[0] == 'DETECTION':
        if dataset_series:
            code = 'worker.dataset-converter.error.detection-series-check'
            raise DeepPhiError(code=code, parameter={})
        label_series = confirm_extension(label_name, ['xml'], label_type[0].capitalize() + ' Label')
    elif label_type[0] in ['SEGMENTATION', 'TRANSFORMATION']:
        extension_case.append('xml')
        label_series = confirm_extension(label_name, extension_case, label_type[0].capitalize() + ' Label')
        if case[0] == 1:
            if dataset_series or label_series:
                code = 'worker.dataset-converter.error.folder-structure-case1-series'
                raise DeepPhiError(code=code, parameter={})
        if case[0] == 2:
            if not (dataset_series or label_series):
                # msg = 'For case 2, either the dataset or label must be a series type data.'
                code = 'worker.dataset-converter.error.folder-structure-no-series'
                raise DeepPhiError(code=code, parameter={})


def check_empty_folder(filename, msg_type):
    if len(os.listdir(filename)) == 0:
        # msg = 'The "%s" folder in the %s tab is empty.' % (filename.split('/')[-1], msg_type)
        code = 'worker.dataset-converter.error.image-directory-empty'
        raise DeepPhiError(code=code, parameter={'folder': filename.split('/')[-1]})


def confirm_extension(filename, extension_case, msg_type):
    series = False
    if os.path.isdir(filename):
        check_empty_folder(filename, msg_type)
        if len(os.listdir(filename)[0].split('.')) > 1:
            confirm_folder_extension(filename, extension_case, msg_type)
        else:  # series folder
            for name in os.listdir(filename):
                check_empty_folder(filename + '//' + name, msg_type)
                confirm_folder_extension(filename + '/' + name, extension_case, msg_type)
                series = True
    else:
        if not confirm_file_extension(filename, extension_case):
            # msg = 'The %s file is an unsupported extension.' % msg_type
            # msg = msg + '\nAvailable extension list: %s' % str(extension_case)
            code = 'worker.dataset-converter.error.unsupported-extension'
            raise DeepPhiError(code=code, parameter={'target': msg_type, 'list_extension': str(extension_case)})
    return series


def confirm_folder_extension(foldername, extension_case, msg_type):
    for tmp_filename in os.listdir(foldername):
        if not confirm_file_extension(tmp_filename, extension_case):
            # msg = 'The "%s" file in this folder name on the %s is an unsupported extension.' % (
            # tmp_filename.split('/')[-1], msg_type)
            # msg = msg + '\nAvailable extension list: %s' % str(extension_case)
            code = 'worker.dataset-converter.error.unsupported-extension-in-series'
            raise DeepPhiError(code=code, parameter={'filename':tmp_filename.split('/')[-1], 'target':msg_type, 'list_extension':str(extension_case)})


def confirm_file_extension(filename, extension_case):
    file_extension = get_extension(filename).lower()
    return file_extension in extension_case


def check_matching(filename_img, list_label):
    basename = get_filename_wo_exe(os.path.basename(filename_img))
    list_label_basename = [get_filename_wo_exe(os.path.basename(list_label[i]))
                           for i in range(len(list_label))]
    if basename in list_label_basename:
        label_index = list_label_basename.index(basename)
        return list_label[label_index]
    else:
        code = 'worker.dataset-converter.error.no-label-file'
        raise DeepPhiError(code=code, parameter={})


def check_excel_matching(filename_img, list_label, list_class_label):
    basename = get_filename_wo_exe(os.path.basename(filename_img))
    code = 'worker.dataset-converter.error.no-label-file'
    if basename not in list_label:
        raise DeepPhiError(code=code, parameter={})
    else:
        class_name = str(list_class_label[list_label.index(basename)])
        if class_name == 'nan':
            raise DeepPhiError(code=code, parameter={})
        else:
            return class_name


def assign_color(index, seg=False):
    COLOR_CODE = ["#0070c0", "#ff0000", "#00b050", "#ffd800", "#7030a0",
                  "#00b0f0", "#ff678a", "#ff9500", "#92d050", "#002060",
                  "#00e0d9", "#ff00ff", "#e0edce", "#d1b8c0", "#63602a",
                  "#ffd6e9", "#c187f5", "#475c63", "#476352", "#595c57",
                  "#e64805", "#c93c8c", "#bab8b6", "#802b2b", "#ffbf7a"]

    if seg:
        COLOR_CODE = ['#000000', '#ffffff'] + COLOR_CODE


    return COLOR_CODE[index]


def delete_append(unzip_path):
    for i in range(10):
        try:
            if os.path.exists(unzip_path + "/append"):
                shutil.rmtree(unzip_path + "/append")
            break
        except:
            time.sleep(5)
            continue