#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import pydicom
import glob
import os
import parse
import pandas as pd
import numpy as np
from deepphi.logger.error import DeepPhiError, ErrorAnalyzer


def check_csv_structure(path_dataset, path_csv):
    label_csv = pd.read_csv(path_csv)
    if len(label_csv.columns) == 1:
        case = 'case1'
    elif len(label_csv.columns) == 2:
        case = 'case3'
    else:
        case = 'case6'

    return case


def check_label(path_dataset, path_label, dimension='2D'):
    if dimension == '2D':
        case = check_label_2d(path_dataset, path_label)
    elif dimension == '3D':
        case = check_label_3d(path_dataset, path_label)
    else:
        raise Exception(
            'The Dimension Type {} is not Available. Please Select 2D or 3D as your Dimension Type.'.format(dimension))

    return case


def check_label_2d(path_dataset, path_label):
    EXE_LIST = ('xml', 'jpg', 'jpeg', 'png', 'nii.gz', 'tif')

    list_exe = check_exe(path_label, dimension='2D')
    if len(list_exe) > 1:
        msg = "There are {} types of labels {} in your 'Label' Folder. Please Check your Label Type.".format(
            len(list_exe), list_exe)
        raise Exception(msg)
    else:
        exe = list_exe[0]

    if exe == 'xml':
        case = 'case4'
    elif exe in ['jpg', 'jpeg', 'png', 'tif', 'bmp']:
        case = 'case7'
    elif exe == 'nii.gz':
        case = 'case8'
    else:
        msg = 'The Data Structure is not available. Please Check your Dataset.'
        raise Exception(msg)

    return case


def check_label_3d(path_dataset, path_label):
    list_exe_dataset = check_exe(path_dataset, dimension='3D')
    list_exe_label = check_exe(path_label, dimension='3D')

    if len(list_exe_dataset) > 1:
        msg = "There are {} types of Images {} in your 'Dataset' Folder. Please Check your Dataset Type.".format(
            len(list_exe_dataset), list_exe_dataset)
        raise Exception(msg)
    else:
        exe_dataset = list_exe_dataset[0]

    if len(list_exe_label) > 1:
        msg = "There are {} types of Labels {} in your 'Label' Folder. Please Check your Label Type.".format(
            len(list_exe_label), list_exe_label)
        raise Exception(msg)
    else:
        exe_label = list_exe_label[0]

    if (exe_dataset, exe_label) == ('nii.gz', 'nii.gz'):
        case = 'case10'
    elif (exe_dataset, exe_label) == ('dcm', 'nii.gz'):
        case = 'case9'
    else:
        msg = 'The Pair of Types for Dataset and Label {} is not Availbale. Please Check your Dataset.'.format(
            (exe_dataset, exe_label))
        raise Exception(msg)

    return case


def check_exe(path, dimension=None):
    if dimension == '2D':
        list_filename = glob.glob(path + '/*')
    elif dimension == '3D':
        list_filename = glob.glob(path + '/*/*')
    else:
        raise Exception('Please Check your Dataset.')

    if len(list_filename) == 0:
        path_split = path.split('/')
        code = 'worker.dataset-converter.error.image-directory-empty'
        raise DeepPhiError(code=code, parameter={'folder': path_split[-2] + '/' + path_split[-1]})

    list_exe = list()

    for filename in list_filename:
        if os.path.isdir(filename):
            list_exe.append("")
        else:
            try:
                test_dcm = pydicom.dcmread(filename)
                exe = "dcm"
            except:
                path_basename = os.path.basename(filename)
                piece_filename = path_basename.split(".")
                exe = piece_filename[-1]
                if len(exe) > 2:
                    nii = piece_filename[-2]

                    if nii == "nii":
                        exe = "{}.{}".format(nii, exe)
            # parsing = parse.parse("{filename}.{exe}", path_basename)
            list_exe.append(exe)

    list_exe = list(np.unique(list_exe))

    return list_exe




