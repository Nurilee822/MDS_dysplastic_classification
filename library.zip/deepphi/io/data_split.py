#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

from deepphi.image_processing.__init__ import Converter
import logging
import multiprocessing
import numpy as np
import os


class DataSplit(Converter):
    def __init__(self, *args, **kwargs):
        super(DataSplit, self).__init__(*args, **kwargs)

    def convert(self, input_path, output_path, num_worker=1, split=None):
        list_work = self._get_work(input_path, output_path, split=split)

        # create batch
        batch_size = 20
        num_work = len(list_work)
        num_batch = num_work // batch_size + 1
        list_batch = [list_work[i*batch_size: (i+1)*batch_size] for i in range(num_batch+1) if len(list_work[i*batch_size: (i+1)*batch_size]) > 0]

        num_completed = 0
        num_batch = len(list_batch)
        for i in range(num_batch):
            batch = list_batch[i]
            logging.debug('Batch {} is Started, num_batch={}'.format(i, len(batch)))

            # convert batch
            with multiprocessing.Pool(num_worker) as p:
                result = p.map(self._work, batch)

            num_completed += len(batch)
            logging.info("[Converting] {} / {} Files".format(num_completed, num_work))

    def _work(self, work):
        input_file, output_file = work

        data_input = list()
        for filename in input_file:
            data_input.append(self.load(filename))

        self.save(output_file, data_input[0])

    def _get_work(self, input_path, output_path, split=None):
        list_input_pairs = self._get_input_path(input_path, split=split)
        list_work = list()

        num_input = len(list_input_pairs)
        idx_shuffle = np.random.choice(num_input, num_input, replace=False)
        if not os.path.exists(output_path + '/train'):
            os.mkdir(output_path + '/train')
        if not os.path.exists(output_path + '/val'):
            os.mkdir(output_path + '/val')
        if not os.path.exists(output_path + '/test'):
            os.mkdir(output_path + '/test')

        for i in idx_shuffle:
            input_this = list_input_pairs[i]
            if i < split[0]:
                t = 'train'
            elif (split[0] < i) and (i < split[0] + split[1]):
                t = 'val'
            else:
                t = 'test'

            filename_wo_exe = ('.').join(input_this.split('.')[:-1])
            output_file = '{}/{}/{}.hdf5'.format(output_path, t, os.path.basename(filename_wo_exe))
            list_work.append([[input_this], output_file])

        return list_work

if __name__ == "__main__":
    import sys
    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    path = ['/home/swseo-ubuntu/mnt/sda2/datasets/deepphi_beta_result/BetaData01_Chest_cls2d/convert_hdf5']

    fraction = [80, 10, 10]
    dimension = '2D'
    converter = DataSplit()
    converter.convert(path, './', split=[10, 10, 10])


