#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import base64
from Crypto.Cipher import AES
from deepphi.io.encryption import *


BS = 16
pad = (lambda s: s + (BS - len(s) % BS) * chr(BS - len(s) % BS).encode())
unpad = (lambda s: s[:-ord(s[len(s)-1:])])


class AESCipher(object):
    def __init__(self, key, iv):
        self.key = key
        self.iv = iv

    def encrypt(self, message):
        cipher = AES.new(self.key, AES.MODE_CBC, IV=self.iv)
        beforeCipher = pad(message)
        afterCipher = base64.b64encode(cipher.encrypt(beforeCipher))
        return afterCipher

    def decrypt(self, enc):
        cipher = AES.new(self.key, AES.MODE_CBC, IV=self.iv)
        deciphed = cipher.decrypt(base64.b64decode(enc))
        deciphed = unpad(deciphed)
        return deciphed.decode('utf-8')


class DeepPhiAESCipher(object):
    def __init__(self, type='project'):
        if type == 'project':
            self.aes_key = PROJECT_AES_KEY
            self.iv = PROjECT_IV
        else:
            self.aes_key = DATASET_AES_KEY
            self.iv = DATASET_IV

        self.AESCipher = AESCipher(self.aes_key, self.iv)

    def encrypt(self, message):
        return self.AESCipher.encrypt(message)

    def decrypt(self, message):
        if message is None:
            return None
        return self.AESCipher.decrypt(message)

