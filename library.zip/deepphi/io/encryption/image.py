#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import hashlib
import numpy as np
import SimpleITK as sitk


def get_array(hashed, length, list_num, inverse=False):
    hashed_new = np.zeros(length)
    for num in list_num:
        array = np.array(list(hashed[:num]))
        div = (length // len(array) + 1)
        array = [array for i in range(div)]
        array = np.concatenate(array, axis=-1)[:length]

        hashed_new += array
    return hashed_new


def encryption(image, message):
    m = hashlib.sha512()
    m.update(message.encode())
    hashed = m.digest()

    masked_list = image.reshape([image.shape[0], -1])
    a = get_array(hashed, masked_list.shape[0], [59])
    b = get_array(hashed, masked_list.shape[1], [47])

    idx1 = np.argsort(a)
    idx2 = np.argsort(b)

    masked_list = masked_list[idx1][:, idx2]

    masked_list = masked_list.reshape([image.shape[1], -1])
    a = get_array(hashed, masked_list.shape[0], [41])
    b = get_array(hashed, masked_list.shape[1], [39])

    idx1 = np.argsort(a)
    idx2 = np.argsort(b)

    masked_list = masked_list[idx1][:, idx2]

    return masked_list.reshape(image.shape)


def decryption(image, message, dtype=None):
    m = hashlib.sha512()
    m.update(message.encode())
    hashed = m.digest()

    masked_list = image.reshape([image.shape[1], -1])
    a = get_array(hashed, masked_list.shape[0], [41])
    b = get_array(hashed, masked_list.shape[1], [39])

    idx1 = np.argsort(np.argsort(a))
    idx2 = np.argsort(np.argsort(b))

    masked_list = masked_list[:, idx2][idx1]

    masked_list = masked_list.reshape([image.shape[0], -1])
    a = get_array(hashed, masked_list.shape[0], [59])
    b = get_array(hashed, masked_list.shape[1], [47])

    idx1 = np.argsort(np.argsort(a))
    idx2 = np.argsort(np.argsort(b))

    masked_list = masked_list[:, idx2][idx1]

    if dtype is not None:
        masked_list = masked_list.astype(dtype)
    return masked_list.reshape(image.shape)


# def encrypt_file(path):


