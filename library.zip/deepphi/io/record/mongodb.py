import pymongo as mongo
from bson.objectid import ObjectId
import copy
import random
import string
import pandas as pd
import logging


# BACKEND INTERFACE
KEY_COLUMN_KEY = "columnKey"
KEY_COLUMN_NAME = "columnName"
KEY_COLUMN_DEFINITION = "columnDefinitions"
KEY_COLUMN_ORIGIN = "columnOrigin"
KEY_COLUMN_ORIGIN_MODULE_NAME = "columnOriginModuleName"
KEY_PREDICTION_ORIGIN_COLUMN = "predictionOriginColumn"

# DB INFORMATION
DBNAME = 'deepphi'
ATTR_COLLECTION_NAME = 'recordDataset'
DATA_COLLECTION_NAME = 'recordData'
KEY_DATASET_ID = "recordDatasetId"
AUTH_SOURCE = "deepphi"
AUTH_MECHANISM = "SCRAM-SHA-1"


class DeepphiMongoDB(object):

    def __init__(self, dataSource):
        host = dataSource['mongoHost']
        port = dataSource['mongoPort']
        user = dataSource['mongoUser']
        pwd = dataSource['mongoPassword']
        self.dataset_id = None
        self.dataset = None

        self.database = self.__connect__(host, port, user, pwd)

    @staticmethod
    def __connect__(host, port, user, pwd):
        client = mongo.MongoClient(host=str(host),
                                   port=int(port),
                                   username=user,
                                   password=pwd,
                                   authSource=AUTH_SOURCE,
                                   authMechanism=AUTH_MECHANISM)
        database = client[DBNAME]
        return database

    def set_obj_id(self, object_id):
        self.dataset_id = object_id

    def load(self, object_id, data_type=None):
        self.dataset_id = object_id
        self.dataset = self.database[ATTR_COLLECTION_NAME].find_one({'_id': ObjectId(object_id)})
        self._get_column_def()
        self._get_record_data(data_type)
        return

    def _get_column_def(self):
        self.table = DeepphiMongoDBTable()
        self.columnDefinition = DeepphiMongoColumnDefinitions()
        for col_info in self.dataset[KEY_COLUMN_DEFINITION]:
            col_info = DeepphiMongoColumnDefinition(col_info)
            self.columnDefinition.add_column(col_info)
            self.table[col_info[KEY_COLUMN_KEY]] = list()

    def _get_record_data(self, data_type):
        query = {KEY_DATASET_ID: ObjectId(self.dataset_id)}
        if data_type is not None:
            query["dataType"] = data_type
        list_row = self.database[DATA_COLLECTION_NAME].find(query)
        for row in list_row:
            # logging.info(row["dataType"])
            for key in self.columnDefinition.key_to_name.keys():
                try:
                    self.table[key].append(row["record"][key])
                except:
                    pass
            self.table["row_num"].append(row["record"]["row_num"])
            self.table["dataType"].append(row["dataType"])
        return

    def add_column_pred(self, data, col_key, module_name=None):
        if len(data) != len(self.table[col_key]):
            raise Exception()

        col_key_pred = get_random_column_key(cnt=1)[0]

        self.columnDefinition.add_column_pred(col_key, col_key_pred, module_name=module_name)
        self.table[col_key_pred] = data

    def save(self):
        self.save_col_def()
        self.save_row()

    def save_col_def(self):
        self.database[ATTR_COLLECTION_NAME].update_one({'_id': ObjectId(self.dataset_id)},
                                                       {'$set': {KEY_COLUMN_DEFINITION: self.columnDefinition.items}})

    def save_row(self):
        # df = pd.DataFrame(self.table).astype(str)
        df = self.table.get_record()
        data_type = self.table.get_data_type()

        list_row = list()
        for i in range(len(df)):
            data_row = dict(df.iloc[i])
            data_row['row_num'] = int(data_row['row_num'])
            list_row.append({KEY_DATASET_ID: ObjectId(self.dataset_id), "dataType": data_type[i], 'record': data_row})
        self.database[DATA_COLLECTION_NAME].insert_many(list_row)


class DeepphiMongoDBTable(dict):
    def __init__(self):
        super(DeepphiMongoDBTable, self).__init__()
        self["row_num"] = list()
        self["dataType"] = list()

    def get_record(self):
        df = pd.DataFrame(self).astype(str)
        df = df.drop(columns=["dataType"])
        return df

    def get_data_type(self):
        return self["dataType"]


class DeepphiMongoColumnDefinition(dict):
    def set_new_key(self):
        self[KEY_COLUMN_KEY] = get_random_column_key(cnt=1)[0]
        return self[KEY_COLUMN_KEY]

    def set_column_name(self, name):
        self[KEY_COLUMN_NAME] = get_random_column_key(cnt=1)[0]

    def add_column_attr(self, key, value):
        self[key] = value


class DeepphiMongoColumnDefinitions(object):
    def __init__(self, *args):
        self.items = list()

        self.key_to_name = dict()
        self.name_to_key = dict()

    def add_column(self, column_definition, sort_order=None):
        if sort_order is None:
            sort_order = len(self.items) + 1
            column_definition["sortOrder"] = sort_order
            self.items.append(column_definition)
        else:
            if sort_order > len(self.items) + 1:
                raise Exception()

            self.items = self.items[:sort_order - 1] + [column_definition] + self.items[sort_order - 1:]
            self._assign_sort_order()

        self.key_to_name[column_definition[KEY_COLUMN_KEY]] = column_definition[KEY_COLUMN_NAME]
        self.name_to_key[column_definition[KEY_COLUMN_NAME]] = column_definition[KEY_COLUMN_KEY]

    def add_column_pred(self, col_key, col_key_pred, module_name=None):
        col_df_orig = self.get_column_definition_by_key(col_key)
        col_df_pred = copy.deepcopy(col_df_orig)
        col_df_pred[KEY_COLUMN_NAME] = col_df_orig[KEY_COLUMN_NAME] + "_pred"
        col_df_pred[KEY_COLUMN_ORIGIN] = "PREDICTION"
        col_df_pred[KEY_COLUMN_ORIGIN_MODULE_NAME] = module_name
        col_df_pred[KEY_PREDICTION_ORIGIN_COLUMN] = col_df_orig[KEY_COLUMN_KEY]
        col_df_pred[KEY_COLUMN_KEY] = col_key_pred

        self.add_column(col_df_pred, sort_order=col_df_orig["sortOrder"] + 1)

    def _assign_sort_order(self):
        for i in range(len(self.items)):
            self.items[i]["sortOrder"] = i + 1

    def get_column_definition_by_key(self, key):
        for cdf in self.items:
            if cdf[KEY_COLUMN_KEY] == key:
                return cdf

        raise Exception()

    def get_column_definition_by_name(self, name):
        for cdf in self.items:
            if cdf[KEY_COLUMN_NAME] == name:
                return cdf

        raise Exception()


def get_random_column_key(cnt=1):
    def generate_random_key(cnt):
        key_list = []
        for _ in range(cnt):
            random_key = ''.join(
                random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(5))
            key_list.append(random_key)
        return key_list

    new_column_key = generate_random_key(cnt)
    return new_column_key