#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import h5py
import json
import numpy as np
import glob
import copy
import logging

import cv2
import SimpleITK as sitk

from deepphi.io.converter_v2.validation.exception import *
from deepphi.io.read_dicom_series import read_dicom_series
from deepphi.logger.error import DeepPhiError, ErrorAnalyzer
import deepphi.io.utils_io as utils_io
import deepphi.io.encryption.image as image_encryption
from deepphi.io.utils.deidentification import deidentify_one_file
from deepphi.logger.error import *
import xml.etree.cElementTree as ET
import numpy as np
import pylab as plt
import numpy as np
from matplotlib.path import Path

def sitk_image_to_npz(sitk_image, header=None, label=None):
    img = sitk.GetArrayFromImage(sitk_image)
    if header is None:
        header = dict()

    header['Direction'] = sitk_image.GetDirection()
    header['Origin'] = sitk_image.GetOrigin()
    header['Spacing'] = sitk_image.GetSpacing()

    header['metadata'] = dict()
    for key in sitk_image.GetMetaDataKeys():
        header['metadata'][key] = sitk_image.GetMetaData(key)

    # multi-channel
    num_channel = sitk_image.GetNumberOfComponentsPerPixel()

    header['isVector'] = num_channel > 1
    if num_channel == 1:
        img = img.reshape(list(img.shape) + [1])

    if label is not None:
        if header['label_type'] == 'segmentation':
            if np.prod(label.shape) == np.prod(img.shape):
                label = label.reshape(img.shape)
            elif np.prod(label.shape[:-1]) == np.prod(img.shape[:-1]):
                label = label.reshape(list(img.shape)[:-1] + [label.shape[-1]])

    data = {'array': img, 'header': header, 'label': label}
    return data


def npz_to_sitk_image(npz, target='array'):
    img = npz[target]
    header = npz['header']
    isVector = header['isVector']
    if not isVector:
        img = img.squeeze(axis=-1)

    sitk_image = sitk.GetImageFromArray(img, isVector=isVector)

    sitk_image.SetDirection(npz['header']['Direction'])
    sitk_image.SetOrigin(npz['header']['Origin'])
    sitk_image.SetSpacing(npz['header']['Spacing'])

    for key in header['metadata'].keys():
        sitk_image.SetMetaData(key, header['metadata'][key])

    return sitk_image


class DeepPhiImage(dict):
    def __init__(self):
        super(DeepPhiImage, self).__init__()
        self['array'] = np.array([])
        self['file_array'] = np.array([])

        self['header'] = {
            'Direction': np.array([]),
            'Origin': np.array([]),
            'Spacing': np.array([]),
            'IsVector': np.array([]),
            'metadata': dict(),
            'color_mode': "None",
            'color_mode_history': [],
            'history': [],
            'modality': "None",
            'dim': "None",
            'ndim': "None",
            'dtype': "None",
            'shape': "None",
        }

    def read_array(self, array, header=None):
        """
        array를 읽어서 DeepPhiImage object로 변환
        """

        self['array'] = array
        if header is not None:
            self['header'] = header
        # if header is not None:
        #     self['header'] = header
        #
        # if header['IsVector']:
        #     sitk_image = sitk.GetImageFromArray(array, isVector=header['IsVector'])
        # else:
        #     sitk_image = sitk.GetImageFromArray(array)
        #
        # self.read_sitk_image(sitk_image)

    def read_xml_mask(self, path, shape, class_dict):
        list_mask, list_cls = get_mask_xml(shape, path)
        mask = self.make_mask(list_mask, list_cls, shape, class_dict)
        self['array'] = np.uint8(mask)
        self['header']['dim'] = 2
        self['header']['ndim'] = 2
        self['header']['IsVector'] = False
        self['header']['color_mode'] = 'mask'


    def make_mask(self, list_mask, list_class_name, shape, class_dict):
        mask = np.zeros(shape)
        for i in range(len(list_mask)):
            cls_value = class_dict[list_class_name[i]]
            mask[list_mask[i]] = cls_value
        return mask


    def read_image(self, path, mask=False, dimension=None, deidentification=True, decryption_key=None):
        """
        SimpleITK를 이용해 읽을 수 있는 image file(png, jpg, dicom...)을 읽어 DeepPhiImage object로 변환
        """
        import logging
        info = dict()
        multi_channel = False

        if os.path.isdir(path):
            if len(glob.glob(path + '/*')) == 0:
                self.empty = True
                return 'empty_dir'
            exe = utils_io.check_exe(path, dimension="2D")[0]
            # logging.debug("extension: " + exe)
            if exe == 'dcm':
                sitk_image = self.read_dicom_series(path, deidentification=deidentification)
            elif exe == 'nii.gz':
                sitk_image = self.read_multi_channel(path, mask)
                if len(glob.glob(path + "/*.nii.gz")) > 1:
                    multi_channel = True
            elif exe == "":
                sitk_image = self.read_multi_channel(path, mask)
                if len(glob.glob(path + "/*")) > 1:
                    multi_channel = True
            else:
                sitk_image = self.read_img_series(path, mask)

            list_filename = list()
            for filename in np.sort(glob.glob(path + "/*")):
                list_filename.append(os.path.basename(filename))

            self.read_sitk_image(sitk_image, mask=mask, multi_channel=multi_channel, file_name=list_filename)
        else:
            exe = path.split(".")[-1]
            if exe == 'dcm' and deidentification:
                _ = deidentify_one_file(path)
            try:
                sitk_image = sitk.ReadImage(path)
            except:
                # msg = 'Unable to read file. Please check if the file is broken.'
                code = 'worker.dataset-converter.error.unreadable-file-include'
                raise DeepPhiError(code=code, parameter={})
            list_filename = [os.path.basename(path)]

            self.read_sitk_image(sitk_image, mask=mask, multi_channel=multi_channel, file_name=list_filename)
            if (exe.lower() in ['jpg', 'jpeg', 'tif', 'tiff', 'bmp', 'png']) and mask:
                if len(np.unique(self['array'])) != 2:
                    self['array'] = (self['array'] > np.max(self['array']) / 2).astype('int')
                if len(np.unique(self['array'])) == 2:
                    self['array'] = (self['array'] / np.max(self['array'])).astype('int')

        if decryption_key is not None:
            dtype = self['header']['dtype']
            if self['header']['dim'] == 2:
                self['array'] = image_encryption.decryption(self['array'], decryption_key
                                                                     , dtype=dtype)
            else:
                num_slice = self['array'].shape[0]
                for i in range(num_slice):
                    self['array'][i] = image_encryption.decryption(self['array'][i], decryption_key
                                                                            , dtype=dtype)
        return sitk_image

    def read_img_series(self, path, mask=False):
        list_filename = np.sort(glob.glob(path + '/*'))
        list_img = list()
        for filename in list_filename:
            self.read_image(filename, mask)
            list_img.append(copy.copy(self['array']))

        if len(list_img) > 1:
            new_array = np.stack(list_img, axis=0)
            sitk_image = sitk.GetImageFromArray(new_array)
        else:
            sitk_image = self.sitk_image()

        return sitk_image

    def read_dicom_series(self, path, deidentification=True):
        try:
            data_directory = path
            file_list = glob.glob(path + '/*')
            file_name = file_list[0]

            dicom_shape = deidentify_one_file(file_name)
            if deidentification:
                for name in file_list:
                    output_shape = deidentify_one_file(name)
                    if output_shape != dicom_shape:
                        # msg = 'The image shape of the dicom files in the folder is not the same.'
                        code = 'worker.dataset-converter.error.dicom-series-shape-mismatch'
                        raise DeepPhiError(code=code, parameter={})

            if len(file_list) == 1:
                img = sitk.ReadImage(file_list[0])
                return img

            file_reader = sitk.ImageFileReader()
            file_reader.SetFileName(file_name)
            file_reader.ReadImageInformation()
            series_ID = file_reader.GetMetaData('0020|000e')
            sorted_file_names = sitk.ImageSeriesReader.GetGDCMSeriesFileNames(data_directory, series_ID)

            img = sitk.ReadImage(sorted_file_names)
            # for key in file_reader.GetMetaDataKeys():
            #     try:
            #         img.SetMetaData(key, file_reader.GetMetaData(key))
            #     except:
            #         pass
            return img
        except Exception as e:
            raise TypeError(str(e))

    def read_multi_channel(self, path, mask=False):
        list_filename = np.sort(glob.glob(path + '/*'))
        list_img = list()
        for filename in list_filename:
            if os.path.isdir(filename):
                img = self.read_image(filename, mask)
            else:
                img = sitk.ReadImage(filename)
                # logging.info(filename)
            self.read_sitk_image(img)
            list_img.append(copy.copy(self['array']))

        if len(list_img) > 1:
            new_array = np.stack(list_img, axis=-1)
            self['array'] = new_array
            self['header']['IsVector'] = True

        return self.sitk_image()

    def read_sitk_image(self, sitk_image, mask=False, multi_channel=False, file_name=None):
        """
        SimpleITK image object를 DeepPhiImage Object로 변환
        """
        array = sitk.GetArrayFromImage(sitk_image)
        spacing = list(sitk_image.GetSpacing())
        origin = list(sitk_image.GetOrigin())
        direction = list(sitk_image.GetDirection())

        ## squeeze ###
        if 1 in sitk_image.GetSize():
            array = array.squeeze()
            dim = sitk_image.GetDimension()
            index = sitk_image.GetSize().index(1)
            spacing = spacing[:index] + spacing[index + 1:]
            origin = origin[:index] + origin[index + 1:]
            direction = direction[:dim * index] + direction[dim * (index + 1):]

            i = 0
            new_direction = list()
            while direction:
                d = direction.pop(0)
                if i % dim != index:
                    new_direction.append(d)
                i += 1

            direction = new_direction

        self['array'] = array
        # image info
        self['header']['Direction'] = direction
        self['header']['Origin'] = origin
        self['header']['Spacing'] = spacing
        self['header']['IsVector'] = sitk_image.GetNumberOfComponentsPerPixel() > 1
        self['header']['file_name'] = file_name


        if not mask and (self['header']['color_mode'] != 'mask'):
            if (multi_channel or (self['header']['color_mode'] == 'Series')) and (sitk_image.GetNumberOfComponentsPerPixel() != 1):
                color_mode = 'Series'
            else:
                if sitk_image.GetNumberOfComponentsPerPixel() == 3:
                    color_mode = 'RGB'
                elif sitk_image.GetNumberOfComponentsPerPixel() == 4:
                    # RGBA to RGB
                    self['array'] = cv2.cvtColor(self['array'], cv2.COLOR_RGBA2RGB)
                    color_mode = 'RGB'
                else:
                    color_mode = 'L'
        else:
            if not multi_channel:
                if sitk_image.GetNumberOfComponentsPerPixel() == 3:
                    self['array'] = cv2.cvtColor(self['array'], cv2.COLOR_RGB2GRAY)
                    self['header']['IsVector'] = False
                if sitk_image.GetNumberOfComponentsPerPixel() == 4:
                    self['array'] = cv2.cvtColor(self['array'], cv2.COLOR_RGBA2RGB)
                    self['array'] = cv2.cvtColor(self['array'], cv2.COLOR_RGB2GRAY)
                    self['header']['IsVector'] = False
            color_mode = 'mask'

        if multi_channel and (color_mode == 'mask'):
            tmp_array = np.zeros_like(array[...,0])
            for i in range(array.shape[-1]):
                tmp_array[array[...,i] == 1] = i+1
            self['array'] = tmp_array
            self['header']['IsVector'] = False

        self['header']['color_mode'] = color_mode
        self['header']['color_mode_history'] = list(np.append(self['header']['color_mode_history'], color_mode))

        # array info
        ndim = len(self['array'].shape)
        if self['header']['IsVector']:
            dim = ndim - 1
        else:
            dim = ndim

        self['header']['dim'] = dim
        self['header']['ndim'] = ndim
        self['header']['dtype'] = str(self['array'].dtype)

        for key in sitk_image.GetMetaDataKeys():
            self['header']['metadata'][key] = sitk_image.GetMetaData(key)

    def sitk_image(self):
        """
        DeepPhiImage object를 simple itk image object로 변환
        """
        header = self['header']

        sitk_image = sitk.GetImageFromArray(self['array'], isVector=header['IsVector'])
        sitk_image.SetDirection(header['Direction'])
        sitk_image.SetOrigin(header['Origin'])
        sitk_image.SetSpacing(header['Spacing'])

        for key in header['metadata'].keys():
            sitk_image.SetMetaData(key, header['metadata'][key])

        return sitk_image


class DeepPhiDataSet(dict):
    def __init__(self):
        super(DeepPhiDataSet, self).__init__()

        self['image'] = DeepPhiImage()
        self['label'] = {
            'classification': {"array": np.array([]),
                               "header": dict()},
            'segmentation': DeepPhiImage(),
            'transformation': DeepPhiImage(),
            'object_detection': {'bbox_coordinate': np.array([]),
                                 'bbox_class': np.array([]),
                                 'header': dict()}
        }
        self['header'] = {'patch': False,
                          'patch_original_filename': None,
                          'filename': "None",
                          'filename_hdf5': "None",
                          }  # patient info

        self['prediction'] = {
            'classification': {"array": np.array([]),
                               "grad_cam": np.array([]),
                               "header": dict()},
            'segmentation': DeepPhiImage(),
            'transformation': DeepPhiImage(),
            'object_detection': {'bbox_coordinate': np.array([]),
                                 'bbox_class': np.array([]),
                                 'header': dict()}
        }

    def __len__(self):
        return 1

    def get_name_classification_label(self):
        if len(self['label']['classification']['array']) == 0:
            return None
        elif 'class_name' in self['label']['classification']['header'].keys():
            idx = np.argmax(self['label']['classification']['array'])
            return self['label']['classification']['header']['class_name'][idx]
        else:
            return str(np.argmax(self['label']['classification']['array']))

    def get_name_classification_prediction(self):
        idx = np.argmax(self['prediction']['classification']['array'])
        probability = eval(str(round(self['prediction']['classification']['array'][idx],8)))
        if 'class_name' in self['label']['classification']['header'].keys():
            class_name = self['label']['classification']['header']['class_name'][idx]
        else:
            class_name = str(np.argmax(self['label']['classification']['array']))
        return class_name, probability, idx

    def get_name_classification_pred(self):
        if len(self['prediction']['classification']['array']) == 0:
            return None
        elif 'class_name' in self['label']['classification']['header'].keys():
            idx = np.argmax(self['prediction']['classification']['array'])
            return self['label']['classification']['header']['class_name'][idx]
        else:
            return str(np.argmax(self['prediction']['classification']['array']))

    def read_image(self, *args, **kwargs):
        self['image'] = DeepPhiImage()
        self['image'].read_image(*args, **kwargs)

    def read_segmentation_label(self, *args):
        self['label']['segmentation'] = DeepPhiImage()
        self['label']['segmentation'].read_image(*args)

    def read_transformation_label(self, *args):
        self['label']['transformation'] = DeepPhiImage()
        self['label']['transformation'].read_image(*args)

    def set_classification_label(self, label):
        self['label']['classification']['array'] = label

    def set_segmentation_label(self, label):
        self['label']['segmentation'] = label

    def set_transformation_label(self, label):
        self['label']['transformation'] = label

    def set_object_detection_label(self, label):
        self['label']['object_detection'] = label

    def add_necessary_info(self, target):
        if len(target['array']) != 0:
            target['header']['shape'] = list(target['array'].shape)
            target['header']['dtype'] = str(target['array'].dtype)
            target['header']['ndim'] = target['array'].ndim
            if target['header']['ndim'] == target['header']['dim']:
                target['header']['IsVector'] = False
            else:
                target['header']['IsVector'] = True
            target['header']['color_mode_history'] = list(np.append(target['header']['color_mode_history'],
                                                                    target['header']['color_mode']))
            target['header']['pixel_value_range'] = self._cal_pixel_range(target['array'])

    def _cal_pixel_range(self, array):
        if len(array) != 0:
            pixel_value_range = [np.min(array), np.max(array)]
        else:
            pixel_value_range = None
        return pixel_value_range

    def save(self, filename, encryption_key=None):
        if os.path.exists(filename):
            os.remove(filename)
        try:
            if not os.path.exists(os.path.dirname(filename)):
                os.mkdir(os.path.dirname(filename))
        except:
            pass

        # header update
        self['header']['filename'] = os.path.basename(filename)
        self['header']['filename_hdf5'] = os.path.basename(filename)

        for target in [self['image'], self['label']['segmentation'], self['label']['transformation']]:
            self.add_necessary_info(target)
        if len(self['label']['segmentation']['array']) != 0:
            mask = self['label']['segmentation']['array']
            list_fraction = [np.sum(mask[..., i]) / mask[..., i].size for i in range(mask.shape[-1])]
            self['label']['segmentation']['header']['class_fraction'] = list_fraction

        # encrypt image
        if encryption_key is not None:
            # logging.info(encryption_key)
            if self['image']['header']['dim'] == 2:
                self['image']['array'] = image_encryption.encryption(self['image']['array'], encryption_key)
            else:
                num_slice = self['image']['array'].shape[0]
                for i in range(num_slice):
                    self['image']['array'][i] = image_encryption.encryption(self['image']['array'][i], encryption_key)

        f = h5py.File(filename, 'w')
        self._save_dict_to_hdf5(f, self)
        f.close()

    def _save_dict_to_hdf5(self, hdf5_object, dict_object):
        for key in dict_object.keys():
            if key == 'header':
                self._save_header(hdf5_object, dict_object['header'])
            elif isinstance(dict_object[key], dict):
                # key 값에 대응되는 value가 dictionary type인 경우,
                # hdf5_object 하위에 key directory를 만들어 해당 dictionary를 저장
                hdf5_object_sub = hdf5_object.create_group(key)
                self._save_dict_to_hdf5(hdf5_object_sub, dict_object[key])
            elif isinstance(dict_object[key], np.ndarray):
                try:
                    hdf5_object[key] = dict_object[key]
                except:
                    hdf5_object[key] = str(dict_object[key])
            else:
                msg = 'key: {}, value: {}'.format(key, hdf5_object[key])
                msg += '\n모든 value는 dict-like object 혹은 np.ndarray 타입이여야 합니다.'
                raise DeepPhiError(code="worker.image-processing.error.invalid-header",
                                   parameter={"key": key, "value": hdf5_object[key]})

    def _save_header(self, hdf5_object, header):
        list_name_json = list()
        for key in header.keys():
            if isinstance(header[key], dict):
                # 해당 key 값에 value가 dict type인 경우 json format으로 치환하여 저장
                dict_str = self._convert_dict2byte(header[key])
                hdf5_object.attrs.create(key, dict_str)
                list_name_json.append(key)
            # elif isinstance(header[key], list):
            #     hdf5_object.attrs.create(key, str(header[key]))
            #     list_name_list.append(key)
            else:
                if header[key] is None:
                    header[key] = str(header[key])
                try:
                    hdf5_object.attrs.create(key, header[key])
                except:
                    hdf5_object.attrs.create(key, str(header[key]))

        hdf5_object.attrs.create('list_json', list_name_json)
        # hdf5_object.attrs.create('list_list', list_name_list)

    def _load_header(self, hdf5_object):
        header = dict(hdf5_object.attrs)
        for key in header['list_json']:
            header[key] = self._convert_byte2dict(header[key])

        # for key in header['list_list']:
        #     header[key] = eval(header[key])

        return header

    def load(self, filename, decryption_key=None):
        f = h5py.File(filename, 'r')
        filename_hdf5 = os.path.basename(filename)

        # load file header
        header_file = self._load_header(f)
        for key in header_file.keys():
            self['header'][key] = header_file[key]

        self["header"]["filename_hdf5"] = filename_hdf5

        # load iamge
        header_image = self._load_header(f['image'])
        self['image'] = DeepPhiImage()
        self['image'].read_array(f['image']['array'][:], header=header_image)
        self['image']['header']['shape'] = f['image']['array'].shape

        if decryption_key is not None:
            dtype = self['image']['header']['dtype']
            if self['image']['header']['dim'] == 2:
                self['image']['array'] = image_encryption.decryption(self['image']['array'], decryption_key
                                                                     , dtype=dtype)
            else:
                num_slice = self['image']['array'].shape[0]
                for i in range(num_slice):
                    self['image']['array'][i] = image_encryption.decryption(self['image']['array'][i], decryption_key
                                                                            , dtype=dtype)

        # load label & prediction
        for t in ['label', 'prediction']:
            self[t]['classification']['array'] = f[t]['classification']['array'][:]
            self[t]['classification']['header'] = self._load_header(f[t]['classification'])

            self[t]['segmentation'] = DeepPhiImage()
            if len(f[t]['segmentation']['array'][:]) > 0:
                header_label = self._load_header(f[t]['segmentation'])
                self[t]['segmentation'].read_array(f[t]['segmentation']['array'][:],
                                                         header=header_label)

                if 'file_array' in f[t]['segmentation'].keys():
                    self[t]['segmentation']['file_array'] = f[t]['segmentation']['file_array'][:]

            self[t]['transformation'] = DeepPhiImage()
            if 'transformation' in f[t]:
                if len(f[t]['transformation']['array'][:]) > 0:
                    header_label = self._load_header(f[t]['transformation'])
                    self[t]['transformation'].read_array(f[t]['transformation']['array'][:],
                                                             header=header_label)

                    if 'file_array' in f[t]['transformation'].keys():
                        self[t]['transformation']['file_array'] = f[t]['transformation']['file_array'][:]

            self[t]['object_detection']['bbox_coordinate'] = f[t]['object_detection']['bbox_coordinate'][:]
            self[t]['object_detection']['bbox_class'] = f[t]['object_detection']['bbox_class'][:]
            self[t]['object_detection']['header'] = self._load_header(f[t]['object_detection'])

        for key in f.keys():
            if key not in ['image', 'label', 'prediction', 'header']:
                self[key] = self.read_hdf5_element(f[key])
        f.close()

        self._post_processing()

    def _post_processing(self):
        def _to_cls_name_str(label_header):
            if 'class_name' in label_header.keys():
                dummy = list()
                for i in range(len(label_header['class_name'])):
                    dummy.append(str(label_header['class_name'][i]))
                label_header['class_name'] = dummy
            return label_header

        for t in ['label', 'prediction']:
            self[t]['classification']['header'] = _to_cls_name_str(self[t]['classification']['header'])
            self[t]['segmentation']['header'] = _to_cls_name_str(self[t]['segmentation']['header'])
            self[t]['object_detection']['header'] = _to_cls_name_str(self[t]['object_detection']['header'])

    def load_header(self, filename):
        # logging.info("load header")
        f = h5py.File(filename, 'r')

        # load file header
        header_file = self._load_header(f)
        for key in header_file.keys():
            self['header'][key] = header_file[key]

        # load iamge
        header_image = self._load_header(f['image'])
        self['image'] = DeepPhiImage()
        self['image']['header'] = header_image
        self['image']['header']['shape'] = list(f['image']['array'].shape)

        for t in ['label', 'prediction']:
            self[t]['classification']['header'] = self._load_header(f[t]['classification'])

            self[t]['segmentation'] = DeepPhiImage()
            self[t]['segmentation']['header'] = self._load_header(f[t]['segmentation'])

            self[t]['transformation'] = DeepPhiImage()
            if 'transformation' in f[t]:
                self[t]['transformation']['header'] = self._load_header(f[t]['transformation'])

            self[t]['object_detection']['header'] = self._load_header(f[t]['object_detection'])

        # for key in f.keys():
        #     if key not in ['image', 'label', 'header']:
        #         self[key] = self.read_hdf5_element(f[key])
        f.close()

    def read_hdf5_element(self, element):
        if isinstance(element, h5py._hl.group.Group):
            data = dict()
            for key in element.keys():
                data[key] = self.read_hdf5_element(element[key])
        else:
            data = element[:]
        return data

    @staticmethod
    def _convert_dict2byte(input_dict):
        dict_str = json.dumps(input_dict)
        return dict_str

    @staticmethod
    def _convert_byte2dict(input_byte):
        _dict = dict(json.loads(input_byte))
        return _dict


def get_mask_xml(shape, filename):
    xml_root = ET.parse(filename).getroot()
    annotations = xml_root.find('Annotations').findall('Annotation')
    list_mask = list()
    list_class_name = list()

    for annotation in annotations:
        mask = np.zeros(shape)
        class_name = annotation.attrib['class']
        if (class_name == '') or (',' in class_name):
            class_name = 'no class'

        coordinates = annotation.find('Coordinates').findall('Coordinate')
        list_coord = list()
        for coord in coordinates:
            coord_y = int(eval(coord.attrib['y']))
            if coord_y<0:
                coord_y =0
            if coord_y>=shape[0]:
                coord_y = shape[0]-1
            coord_x = int(eval(coord.attrib['x']))
            if coord_x<0:
                coord_x =0
            if coord_x>=shape[1]:
                coord_x = shape[1]-1

            list_coord.append([coord_y, coord_x])
            mask[coord_y, coord_x] = 1

        xyz = np.array(list_coord)

        poly_path = Path(xyz)

        x, y = np.mgrid[:shape[0], :shape[1]]
        coors = np.hstack((x.reshape(-1, 1), y.reshape(-1, 1)))  # coors.shape is (4000000,2)

        mask = poly_path.contains_points(coors).reshape(shape[0], shape[1])

        list_mask.append(mask)
        list_class_name.append(class_name)
    return list_mask, list_class_name

def __parse_annotations(self, xml_root):
    if self._dimension == "2D":
        annotations = {'labels': np.empty((len(xml_root.findall('object')),)),
                       'bboxes': np.empty((len(xml_root.findall('object')), 4))}
    elif self._dimension == "3D":
        annotations = {'labels': np.empty((len(xml_root.findall('object')),)),
                       'bboxes': np.empty((len(xml_root.findall('object')), 6))}

    for i, element in enumerate(xml_root.iter('object')):
        try:
            box, label = self.__parse_annotation(element)
        except ValueError as e:
            raise ValueError('could not parse object #{}: {}'.format(i, e))

        annotations['bboxes'][i, :] = box
        annotations['labels'][i] = label

    return annotations
