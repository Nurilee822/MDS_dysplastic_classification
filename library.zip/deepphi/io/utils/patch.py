#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------

import glob
import deepphi.io.sitk


class DatasetManager(object):
    _is_patch = False

    def __init__(self, path):
        self._list_filenames = list(glob.glob(path + "/*.hdf5"))
        self._list_filenames = sorted(self._list_filenames)
        if len(self._list_filenames) > 0:
            self._is_patch = self.load_header(self._list_filenames[0])['header']['patch']

    def get_filenames(self):
        return self._list_filenames

    def load_header(self, filename):
        data = deepphi.io.sitk.DeepPhiDataSet()
        data.load_header(filename)
        return data

    def is_patch(self):
        return self._is_patch


class PatchManager(DatasetManager):
    def __init__(self, path):
        super(PatchManager, self).__init__(path)
        self.group = dict()
        self._check_is_patch()
        self.grouping()

    def _check_is_patch(self):
        if not self._is_patch:
            raise Exception("This is not patch data")

    def get_list_original(self):
        return list(self.group.keys())

    def get_grouping(self):
        return self.group

    def grouping(self):
        for filename in self._list_filenames:
            data = self.load_header(filename)
            original_filename = data['header']['patch_original_filename']

            if original_filename not in self.group.keys():
                self.group[original_filename] = list()

            self.group[original_filename].append(filename)

        self.original_filename = sorted(list(self.group.keys()))

    def get_original_filename(self):
        return self.original_filename

    def get_patch_groups(self):
        list_group = list()
        for key in self.original_filename:
            list_group.append(self.group[key])

        return list_group

    def load_header(self, filename):
        data = deepphi.io.sitk.DeepPhiDataSet()
        data.load_header(filename)
        return data

