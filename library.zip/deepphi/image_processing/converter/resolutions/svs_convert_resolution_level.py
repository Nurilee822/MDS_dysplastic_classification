#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import openslide

""" 
2019.12.03

methods:

convert_to_max_location, 
convert_to_current_size, 

extracted from Crop-out code module. 

"""


class ConvertResolutionLevel(Preprocessing):
    """
    Converts resolution levels of svs format images.

    Methods:
    - convert to max location
    - convert to current size
    - convert to lowest resolution
    - convert to higher resolution
    - convert to highest resolution
    - check type
    - check level

    """
    @timeit
    def __init__(self, level=None):

        super(ConvertResolutionLevel, self).__init__()

        self.parent_class = 'Dimension'
        self.processed = []
        self.level_check = False
        self.type_check = False

        if level == 0 or level == 'highest':
            self.target_lvl = 'highest'
        elif level == 1 or level == 'higher':
            self.target_lvl = 'higher'
        elif level is None or level == 'high':
            self.target_lvl = 'high'

    @timeit
    def __call__(self, data, save_path=None):
        self.processed.append('ConvertResolutionLevel')

        hdf5_image = data

        if self.target_lvl == 'highest':
            hdf5_image = self.convert_to_highest_res(hdf5_image=data)

        elif self.target_lvl == 'higher':
            hdf5_image = self.convert_to_higher_res(hdf5_image=data)

        elif self.target_lvl == 'high':
            hdf5_image = self.convert_to_lowest_res(hdf5_image=data)

        update_ip_history(hdf5_image=hdf5_image,
                          parent_class=self.parent_class,
                          process_to_add=self.processed)

        return hdf5_image

    def check_type(self, hdf5_image):

        self.type_check = isinstance(hdf5_image['header']['ops'],
                                     openslide.OpenSlide)

        return self.type_check

    def check_level(self, hdf5_image, target_level):

        target_lvl = ''

        this_lvl = hdf5_image['header']['CurrentLevel']
        levels = hdf5_image['header']['levels']

        if target_level == 'high':
            target_lvl = levels - 1

        elif target_level == 'higher':
            target_lvl = 1

        elif target_level == 'highest':
            target_lvl = 0

        if this_lvl == target_lvl:
            self.level_check = False

        else:
            self.level_check = True

        return self.level_check

    @timeit
    def convert_to_max_location(self, orig_size, reduced_size, coords):
        """ convert the location of the left upper corner of the rectangle
        to the max dimension of the WSI.

        Args:
            orig_size ((int,int)): size of the original raw WSI
            reduced_size ((int,int)): size of the lowest resolution WSI
            coords (tuple(int, int, int, int)): tuple of coordinates of the
                                                rectangle
                                                (left, right, width, height)

        Returns:
            tuple (int, int): tuple of the converted location (x,y)

        Example:
            > > > convert_to_max_location(40000,20000,(100,100,200,200))
            (200,200)
        """
        self.processed.append('convert_to_max_location')

        x_ratio = orig_size[0] / reduced_size[0]
        y_ratio = orig_size[1] / reduced_size[1]

        new_x = int(math.floor(coords[0]*x_ratio))
        new_y = int(math.floor(coords[1]*y_ratio))

        return new_x, new_y

    @timeit
    def convert_to_current_size(self, crrnt_size, reduced_size, coords):
        """ convert the size of the rectangle to the ratio of max dimension of
        the WSI.

        Args:
            crrnt_size ((int,int)): size of the current level of WSI
            reduced_size ((int,int)): size of the lowest resolution WSI
            coords (tuple(int, int, int, int)): tuple of coordinates of the
                                                rectangle
                                                (left, right, width, height)

        Returns:
            tuple (int, int): tuple of the size of the rectangle (w,h)

        Example:
            > > > convert_to_current_size(40000,20000,(100,100,200,200))
            (400,400)
        """
        self.processed.append('convert_to_current_size')

        x_ratio = crrnt_size[0] / reduced_size[0]
        y_ratio = crrnt_size[1] / reduced_size[1]

        new_w = int(math.ceil(coords[2] * x_ratio))
        new_h = int(math.ceil(coords[3] * y_ratio))

        return new_w, new_h

    @timeit
    def convert_to_lowest_res(self, hdf5_image):

        self.processed.append('convert_to_lowest_res')

        self.type_check = self.check_type(hdf5_image=hdf5_image)
        self.level_check = self.check_level(hdf5_image=hdf5_image,
                                            target_level='high')

        if self.type_check:

            if self.level_check:

                ops_proc = OpsProcessing()
                ops_img = hdf5_image['header']['ops']

                # Image Processing
                hdf5_sdi = ops_proc.ops2hdf5(ops_image=ops_img,
                                             header=hdf5_image['header'],
                                             label_path=hdf5_image['label'],
                                             resolution='high')
                return hdf5_sdi

            else:
                print(':: Message :: Current dimension is already in the '
                      'lowest resolution.')
                hdf5_sdi = hdf5_image

                return hdf5_sdi

    @timeit
    def convert_to_higher_res(self, hdf5_image):

        self.processed.append('convert_to_higher_res')

        self.type_check = self.check_type(hdf5_image=hdf5_image)
        self.level_check = self.check_level(hdf5_image=hdf5_image,
                                            target_level='higher')

        if self.type_check:
            if self.level_check:

                ops_proc = OpsProcessing()

                ops_img = hdf5_image['header']['ops']

                # Image Processing
                hdf5_mdi = ops_proc.ops2hdf5(ops_image=ops_img,
                                             header=hdf5_image['header'],
                                             label_path=hdf5_image['label'],
                                             resolution='higher')
                return hdf5_mdi

            else:
                print(':: Message :: Current dimension is already in the '
                      'higher resolution.')
                hdf5_mdi = hdf5_image

                return hdf5_mdi

    @timeit
    def convert_to_highest_res(self, hdf5_image):

        self.processed.append('convert_to_highest_res')

        self.type_check = self.check_type(hdf5_image=hdf5_image)
        self.level_check = self.check_level(hdf5_image=hdf5_image,
                                            target_level='highest')

        if self.type_check:
            if self.level_check:

                ops_proc = OpsProcessing()

                ops_img = hdf5_image['header']['ops']

                # Image Processing
                hdf5_ldi = ops_proc.ops2hdf5(ops_image=ops_img,
                                             header=hdf5_image['header'],
                                             label_path=hdf5_image['label'],
                                             resolution='higher')
                return hdf5_ldi

            else:
                print(':: Message :: Current dimension is already in the '
                      'higher resolution.')
                hdf5_ldi = hdf5_image

                return hdf5_ldi


if __name__ == "__main__":
    pass
