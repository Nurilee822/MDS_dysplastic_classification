#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.dev.modules_to_test.Image_Converter.Dimension.svs_convert_resolution_level import ConvertResolutionLevel


class HigherResolution(Preprocessing):
    """Converts Image Resolution Level of Pathology HDF5 image."""
    @timeit
    def __init__(self):
        super(HigherResolution, self).__init__()
        self.zero_pt = (0, 0)
        self.parent_class = 'Dimension'
        self.processed = []
        self.type_check = False
        self.level_check = False

    @timeit
    def __call__(self, data, save_path=None):
        """Convert image dimension to of the level 1 resolution.

        Args:
            data         (hdf5)  hdf5 image
            save_path    (str)   path to save

        Returns:
            hdf5_higher  (hdf5)  hdf5 image with level 1 dimension array

        Examples:
             >>> cvt_to_mdi = HigherResolution()
             >>> hdf5_mdi = cvt_to_mdi(data=hdf5_image)
        """
        self.processed.append('HigherResolution')

        hdf5_higher = self.convert_to_higher_res(hdf5_image=data)

        update_ip_history(hdf5_image=hdf5_higher,
                          parent_class=self.parent_class,
                          process_to_add=self.processed)

        return hdf5_higher

    @timeit
    def convert_to_higher_res(self, hdf5_image):

        self.processed.append('convert_to_higher_res')

        cvt = ConvertResolutionLevel()

        self.type_check = cvt.check_type(hdf5_image=hdf5_image)
        self.level_check = cvt.check_level(hdf5_image=hdf5_image,
                                           target_level='higher')

        if self.type_check:
            if self.level_check:

                ops_proc = OpsProcessing()

                ops_img = hdf5_image['header']['ops']

                # Image Processing
                hdf5_mdi = ops_proc.ops2hdf5(ops_image=ops_img,
                                             header=hdf5_image['header'],
                                             label_path=hdf5_image['label'],
                                             resolution='higher')
                return hdf5_mdi

            else:
                print(':: Message :: Current dimension is already in the '
                      'higher resolution.')
                hdf5_mdi = hdf5_image

                return hdf5_mdi


if __name__ == "__main__":

    _, hdf5_image = test_prep(level='original')

    cvt_to_mdi = HigherResolution()
    hdf5_mdi = cvt_to_mdi(data=hdf5_image)
