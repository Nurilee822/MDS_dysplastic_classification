#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import numpy as np
import SimpleITK as sitk
from deepphi.io.sitk import DeepPhiImage, DeepPhiDataSet
from deepphi.image_processing import Preprocessing


TAGS_TO_COPY = ['0010|0010',  # PatientName
                '0010|0020',  # PatientID
                '0010|0030',  # PatientBirthDate
                '0018|0050',  # SliceThickness
                '0020|000D',  # StudyInstanceUID, for machine consumption
                '0020|0010',  # StudyID, for human consumption
                '0008|0020',  # StudyDate
                '0008|0050',  # StudyTime
                '0008|0060',  # Modality
                '0028|0002',  # SamplePerPixel
                '0028|1050',  # WindowCenter
                '0028|1051',  # WindowWidth
                '0028|1052',  # RescaleIntercept
                '0028|1053',  # RescaleSlope
               ]


def map_dtype(dtype):
        if dtype[:3] == 'int':
            return getattr(sitk, 'sitkInt' + dtype[3:])
        elif dtype[:4] == 'uint':
            return getattr(sitk, 'sitkUInt' + dtype[4:])
        elif dtype[:5] == 'float':
            return getattr(sitk, 'sitkFloat' + dtype[5:])
        else:
            return None


def map_sitk_dtype(value):
    if value in [0, 2, 4, 6]:
        return 'int{:d}'.format(int(2 ** (value / 2 + 3)))
    elif value in [1, 3, 5, 7]:
        return 'uint{:d}'.format(int(2 ** ((value -1) / 2 + 3)))
    elif value in [8, 9]:
        return 'float{:d}'.format(int(32 * (value - 7)))
    else:
        return None


def direction_to_orientation(direction, dim):
    if dim == 2:
        return np.array(direction)[[0, 2, 1, 3]]
    elif dim == 3:
        return np.array(direction)[[0, 3, 6, 1, 4, 7]]
    else:
        raise Exception


def modify_header(header, size, spacing, origin, direction, dtype):
    header['Origin'] = origin
    header['Spacing'] = spacing
    header['Direction'] = direction
    header['dtype'] = map_sitk_dtype(dtype)

    metadata = [(key, getattr(header['metadata'], key))
                for key in TAGS_TO_COPY if hasattr(header['metadata'], key)] + \
                [('0020|0032', '\\'.join(map(str, origin))),  # ImagePositionPatient
                ('0020|0037', '\\'.join(map(str, direction_to_orientation(direction, len(spacing))))),  # ImageOrientationPatient
                ('0028|0010', str(size[1])),  # Rows
                ('0028|0011', str(size[0])),  # Columns
                ('0028|0030', '\\'.join(map(str, spacing))),  # PixelSpacing
                ]
    header['metadata'] = {key: value for key, value in metadata}
    return header


class Resampler(Preprocessing):
    def __init__(self,
                 shape=None,
                 size=None,
                 spacing=None,
                 dtype=None):
        super(Resampler, self).__init__()
        self.logger = logging.getLogger()

        self._init_filter()
 
        self.size = self._convert_size(shape, size)
        self.spacing = spacing
        self.dtype = dtype

    def __call__(self, data, origin=None, index=None, direction=None):
        self.init_data(data)
        self.io_error_check(origin, index)

        self.sitk_image = self.get_data()['image'].sitk_image()

        self.origin = self._convert_origin(origin, index)
        if direction is None:
            self.direction = self.sitk_image.GetDirection()
        else:
            self.direction = direction

        return self.image_processing()

    def io_error_check(self, origin, index):
        """ Input data permission
        1. Check image data exists
        """
        # Empty_Check
        if len(self.get_image_array()) == 0:
            raise Exception('Exception occurred while processing data: There is no value in the input image array.')

        """
        2. Check arguments conflict
        """
        assert (origin is None) or (index is None), '`origin` and `index` are not be able to used together.'

    def image_processing(self):
        self._check_size()
        self._check_spacing()
        data = DeepPhiDataSet()
        data['image'] = self.execute(self.sitk_image)
        
        label = self.get_data()['label']['segmentation']
        if len(label['array']) > 0:
            label.read_sitk_image(self.execute(label.sitk_image()))
            data['label'] = label
        return data

    def _check_size(self):
        if self.size is None:
            self.size = self.sitk_image.GetSize()
        else:
            if type(self.size) in [tuple, list]:
                assert len(self.size) == self.get_image_dimension()
            else:
                raise TypeError
    
    def _check_spacing(self):
        if self.spacing is None:
            self.spacing = self.sitk_image.GetSpacing()
        else:
            if type(self.spacing) in [tuple, list]:
                assert len(self.spacing) == self.get_image_dimension()
            elif type(self.spacing) in [int, float]:
                self.spacing = [self.spacing] * self.get_image_dimension()
            else:
                raise TypeError      

    def _init_filter(self,
                     transform=sitk.Transform(),
                     interpolator=sitk.sitkLinear,
                     default_pixel_value=0):
        self.filter = sitk.ResampleImageFilter()
        self.filter.SetTransform(transform)
        self.filter.SetInterpolator(interpolator)
        self.filter.SetDefaultPixelValue(default_pixel_value)

    def _set_filter(self):
        self.filter.SetSize(self.size)
        self.filter.SetOutputOrigin(self.origin)
        self.filter.SetOutputSpacing(self.spacing)
        self.filter.SetOutputDirection(self.direction)
        self.filter.SetOutputPixelType(self.dtype or map_dtype(str(self.get_dtype())))

    def execute(self, sitk_image):
        self._set_filter()
        sitk_result = self.filter.Execute(sitk_image)

        image = DeepPhiImage()
        image['array'] = sitk.GetArrayFromImage(sitk_result)
        header_copy = {key: value for key, value in self.get_data()['image']['header'].items()}
        image['header'] = modify_header(header_copy, self.size, self.spacing, self.origin, self.direction, self.dtype)
        return image

    def _convert_size(self, shape, size):
        if shape is None:
            return size
        else:
            if size is None:
                if type(shape) in [tuple, list]:
                    return shape[::-1]
                else:
                    raise TypeError
            else:
                raise Exception('`shape` and `size` are not be able to used together.')


    def _convert_origin(self, origin, index):
        if index is None:
            if origin is None:
                return self.sitk_image.GetOrigin()
            else:
                assert type(origin) in [tuple, list]
                return origin
        else:
            assert type(index) in [tuple, list]
            if origin is None:
                return self.sitk_image.TransformContinuousIndexToPhysicalPoint(index[::-1])
