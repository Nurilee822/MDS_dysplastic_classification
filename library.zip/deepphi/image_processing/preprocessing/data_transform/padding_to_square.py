#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
from deepphi.io.sitk import *
import logging


class PaddingToSquare(Preprocessing):
    def __init__(self):
        super(PaddingToSquare, self).__init__()
        self.ndim_rule = [2, 3, 4]
        self.log = logging.getLogger()

    def __call__(self, data):
        # I/O Error Check Parameters
        self.io_error_check(data)

        # Load input data
        img = data['image']['array']
        ndim = data['image']['header']['ndim']

        # Image process
        if ndim == 2:
            height, width = img.shape
            margin = np.abs(height-width)//2
            margin_list = [[margin, margin], [0, 0]] \
                if height < width \
                else [[0, 0], [margin, margin]]

        elif ndim == 3:
            _, height, width = img.shape
            margin = np.abs(height-width)//2
            margin_list = [[0, 0], [margin, margin], [0, 0]] \
                if height < width \
                else [[0, 0], [0, 0], [margin, margin]]

        else:
            _, height, width, _ = img.shape
            margin = np.abs(height-width)//2
            margin_list = [[0, 0], [margin, margin], [0, 0], [0, 0]] \
                if height < width \
                else [[0, 0], [0, 0], [margin, margin], [0, 0]]

        img = np.pad(img, margin_list, mode='constant')
        img = img.astype(np.float32)

        # Update data
        data['image']['array'] = img
        data['image']['header']['marginlist'] = dict()
        data['image']['header']['marginlist']['values'] = [list(map(int, mar)) for mar in margin_list]

        return data

    def io_error_check(self, data):
        ndim = data['image']['header']['ndim']

        if self.ndim_rule is not None:
            assert ndim in self.ndim_rule, \
                'Input Image shape structure Must Match. \nAccepts--' + \
                str(self.ndim_rule)


if __name__ == '__main__':
    from deepphi.image_processing.utils import display
    from copy import deepcopy
    import os

    os.chdir('/home/hslisalee/Downloads/DL_team_codes/park_ms/dataset')
    # Initialize class
    padding = PaddingToSquare()

    # Input Data load (hdf5 data)
    ## Min max scaled data after passing MinMaxScaling
    ori_data = DeepPhiDataSet()
    ori_data.load('spine_sample_1.hdf5')

    # Output Data load (hdf5 data)
    padded_data = padding(ori_data)
    # padded_data.save('spine_sample_3.hdf5')

    # Data Change log(Input Data -> Output Data)
    ## 1. Padded image array
    padded_img = padded_data['image']['array']
    print('1. Input_image_shape', ori_data['image']['array'].shape)
    print('1. output_image_shape', padded_img.shape)

    ## 2. Margin info list
    marginlist = padded_data['image']['header']['marginlist']['values']
    print('\n2. header_marginlist', marginlist)

    # Display output
    display(
        np.squeeze(ori_data['image']['array']) * 255,
        cmap='gray',
        add_to_title='Original Image'
    )
    display(
        np.squeeze(padded_img) * 255,
        cmap='gray',
        add_to_title='Padded Image'
    )