import logging
import cv2
from deepphi.image_processing import Preprocessing
import numpy as np


class Resize(Preprocessing):
    def __init__(self, shape):
        super(Resize, self).__init__()
        """ Image Processing Parameters """
        self.y = shape[0]
        self.x = shape[1]

    def __call__(self, data, save_path=None):
        # Image_Processing
        img_array = data['image']['array']  # image array
        img_new = cv2.resize(img_array, (self.x, self.y), cv2.INTER_LINEAR)
        # image array 교체
        data['image'][
            'array'] = img_new  # data['image']['array']를 image processing 결과 이미지로 교체

        if np.any(data['label']['segmentation']['array']):
            label_array = data['label']['segmentation']['array']  # label array
            label_new = cv2.resize(label_array, (self.x, self.y),
                                   cv2.INTER_LINEAR)
            # label array 교체
            data['label']['segmentation']['array'] = label_new

        return data
