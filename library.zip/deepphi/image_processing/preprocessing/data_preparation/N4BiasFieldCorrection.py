#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
import SimpleITK as sitk

class N4BiasFieldCorrection(Preprocessing):
    def __init__(self, numberOfIterations=None, numberOfFittingLevels=4):
        """Implementation of the N4 bias field correction algorithm.
        self Args:
            self.numberOfIterations   (None or int)
            self.numberOfFittingLevels    (int)
        """
        super(N4BiasFieldCorrection, self).__init__()
        self.numberOfIterations = numberOfIterations
        self.numberOfFittingLevels = numberOfFittingLevels

    def __call__(self, data, save_path=None):
        if data['image']['array'].ndim>3:
            raise ValueError('Only 1-channel images are available for now. Please make image array shape (Height, Width) or (Batch, Height, Width)')
            
        inputImage = sitk.GetImageFromArray(data['image']['array'])
        maskImage = sitk.OtsuThreshold(inputImage, 0, 1, 200) # In the future, an option that mask images for the correction can be uploaded together should be added (multiple inputs)
        inputImage = sitk.Cast(inputImage, sitk.sitkFloat32)
        
        corrector = sitk.N4BiasFieldCorrectionImageFilter()
        if self.numberOfIterations:
            corrector.SetMaximumNumberOfIterations([int(self.numberOfIterations)]*self.numberOfFittingLevels)
        output = corrector.Execute(inputImage, maskImage)
        data['image']['array'] = sitk.GetArrayFromImage(output)
        return data

# reference: https://simpleitk.readthedocs.io/en/v1.2.0/Examples/N4BiasFieldCorrection/Documentation.html