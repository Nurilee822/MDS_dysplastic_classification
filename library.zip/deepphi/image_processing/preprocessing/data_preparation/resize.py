#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
import SimpleITK as sitk
from deepphi.io.sitk import npz_to_sitk_image, sitk_image_to_npz


class Resize(Preprocessing):
    def __init__(self, shape):
        super(Resize, self).__init__()
        if isinstance(shape, str):
            shape = eval(shape)
        self.shape = shape

    def __call__(self, data, save_path=None):
        sitk_image = data['image'].sitk_image()

        original_spacing = sitk_image.GetSpacing()
        original_size = sitk_image.GetSize()
        new_size = self.shape

        new_spacing = [(ospc * osz / nsz) for osz, ospc, nsz in
                       zip(original_size, original_spacing, new_size)]
        sitk_image = sitk.Resample(sitk_image, new_size, sitk.Transform(), sitk.sitkLinear, sitk_image.GetOrigin(),
                                    new_spacing, sitk_image.GetDirection(), 0, sitk_image.GetPixelID())
        data['image'].read_sitk_image(sitk_image)

        try:
            sitk_label = data['label']['segmentation'].sitk_image()
            sitk_label = sitk.Resample(sitk_label, new_size, sitk.Transform(), sitk.sitkNearestNeighbor, sitk_image.GetOrigin(),
                                       new_spacing, sitk_image.GetDirection(), 0, sitk_image.GetPixelID())

            data['label']['segmentation'].read_sitk_image(sitk_label)
        except:
            pass
        return data


