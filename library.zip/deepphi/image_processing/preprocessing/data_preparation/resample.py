from deepphi.image_processing import Preprocessing
import SimpleITK as sitk
import numpy as np
import logging
from deepphi.io.sitk import *



class Resample(Preprocessing):
    def __init__(self, spacing = 2):
        super(Resample, self).__init__()
        self.spacing = spacing

    def __call__(self,data):
        self.new_spacing = self.cal_space(data, self.spacing)
        img_array = data['image']['array']
        img_header = {'Direction': np.array([1.e+00, 1.e-06, 1.e-06, 1.e+00]), 'IsVector': True, 'Origin': np.array([0., 0.]), 'Spacing': np.array([0.6890191 , 0.66145833]), 'color_mode': 'RGB', 'color_mode_history': np.array(['RGB', 'RGB'], dtype=object), 'dim': 2, 'dtype': 'uint8',
                      'file_name': 'None',
                      'history': np.array([]), 'list_json': np.array(['metadata'], dtype=object), 'metadata': {}, 'modality': 'None', 'ndim': 3, 'original_shape': np.array([375, 500, 3]), 'shape': (200, 256, 3)}
        self.img_info = [img_header['IsVector'], img_header['Direction'], img_header['Origin'], img_header['Spacing']]
        new_image = self.img_resize(img_array, self.img_info)
        data['image'].read_sitk_image(new_image)


    def cal_space(self, data, spacing):
        img_header = {'Direction': np.array([1.e+00, 1.e-06, 1.e-06, 1.e+00]), 'IsVector': True, 'Origin': np.array([0., 0.]), 'Spacing': np.array([0.6890191, 0.66145833]), 'color_mode': 'RGB', 'color_mode_history': np.array(['RGB', 'RGB'], dtype=object), 'dim': 2, 'dtype': 'uint8',
                      'file_name': 'None',
                      'history': np.array([]), 'list_json': np.array(['metadata'], dtype=object), 'metadata': {}, 'modality': 'None', 'ndim': 3, 'original_shape': np.array([375, 500, 3]), 'shape': (200, 256, 3)}

        img_dimension = img_header['dim']
        try:
            len(spacing)
            spacing_type = 'list'
        except:
            spacing_type = 'int'

        if spacing_type == 'int':
            if spacing <= 0:
                raise ValueError("The input value of the parameter is not positive. \nPlease enter a positive value.")
            return [spacing] * img_dimension
        else:
            if img_dimension == 3:
                if len(spacing) != 3:
                    raise ValueError("The dataset is a 3D image. Enter three values ​​as 'spacing = [volume, height, width]'.")
                else:
                    return [spacing[2], spacing[1], spacing[0]]
            else:
                if len(spacing) != 2:
                    raise ValueError("The dataset is a 2D image. Enter two values ​​as 'spacing = [height, width]'.")
                else:
                    return [spacing[1], spacing[0]]

    def img_resize(self, img_array, img_info):
        sitk_image = sitk.GetImageFromArray(img_array, img_info[0])
        sitk_image.SetDirection(img_info[1])
        sitk_image.SetOrigin(img_info[2])
        sitk_image.SetSpacing(img_info[3])

        new_size = [int(round(ori_size * ori_space / new_space)) for ori_size, ori_space, new_space
                    in zip(sitk_image.GetSize(), sitk_image.GetSpacing(), self.new_spacing)]

        sitk_image = sitk.Resample(sitk_image, new_size, sitk.Transform(),
                                   sitk.sitkLinear,
                                   sitk_image.GetOrigin(),
                                   self.new_spacing, sitk_image.GetDirection(),
                                   0, sitk_image.GetPixelID())
        return sitk_image



if __name__ == "__main__":
    a = Resample()
    filename = '/home/hslisalee/PycharmProjects/tmp_project/hdf5_file/make/segmentation_hb.hdf5'
    data = h5py.File(filename, 'r')
    a(data)