#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
from deepphi.io.sitk import *
import logging


class SpineClsPatchExtractor(Preprocessing):
    def __init__(self, patch_size=(128, 128), angle=0, offset=1.6):
        super(SpineClsPatchExtractor, self).__init__()
        self.log = logging.getLogger()
        self.patch_size = patch_size
        self.angle = angle
        self.offset = offset

        self.patch_size_rule1 = (tuple, list)
        self.patch_size_rule2 = int
        self.patch_size_rule3 = 2
        self.angle_rule = [-10, 10]
        self.offset_rule = [0.8, 2]

    def __call__(self, data_original, data_mask_list):
        # I/O Error Check Parameters
        self.io_error_check()

        # Load input data

        ori_img = np.squeeze(data_original['image']['array'])
        data_output_list = []

        for idx, data_mask in enumerate(mask_data_list):

            mask_img = self._make_mask_img(ori_img, data_mask)

            # Image process
            contour = self._calculate_contour(mask_img)
            patch, bbox, min_area = self._extract_cls_patch(ori_img, contour)

            # Update data
            data_mask['image']['array'] = patch
            data_mask['image']['header']['bbox'] = dict()
            data_mask['image']['header']['bbox']['values'] = list(map(int, bbox))
            data_mask['image']['header']['min_area'] = dict()
            data_mask['image']['header']['min_area']['values'] = [list(map(int, ma)) for ma in min_area]

            mask_data_path_list = ['Spine mask patch {}'.format(idx) for idx in
                                   range(5)]
            for idx, mask_data_path in enumerate(mask_data_path_list):
                self.log.debug('Input mask data: {}'.format(mask_data_path))

            # Data Change log(Input Data -> Output Data)
            ## 1. whole image & mask patch image to cls patch image
            cls_patch_img = ori_img
            self.log.debug('\n0. Whole image shape: \t\t{}'.format(ori_img.shape))

            mask_patch_img = patch
            self.log.debug('1. Mask patch image shape: \t{}'.format(
                                                            mask_patch_img.shape))
            self.log.debug('1. Output_Cls image shape: \t{}'.format(
                                                            cls_patch_img.shape))
            ## 2. Bbox info list
            self.log.debug('2. Bbox info: \t\t\t\t{}'.format(
                  data_mask['image']['header']['bbox']['values']))

            ## 3. Minimum_area_info list
            self.log.debug('3. Minimum area info \t\t{}\n'.format(
                  data_mask['image']['header']['min_area']['values']))

            data_output_list.append(data_mask)

        return data_output_list

    def _make_mask_img(self, ori_img, data_mask):
        mask_img = np.zeros_like(ori_img)
        y_min, y_max, x_min, x_max = data_mask['image']['header']['coordinates']['values']
        mask = np.squeeze(data_mask['image']['array'])
        resized_mask = cv2.resize(mask, (x_max - x_min, y_max - y_min), interpolation=cv2.INTER_CUBIC)

        mask_img[y_min:y_max,x_min:x_max] = resized_mask
        mask_img = ((mask_img >= .5) * 255).astype(np.uint8)
        return mask_img

    def _calculate_contour(self, mask_img):
        _, threshold = cv2.threshold(mask_img, 127, 255, 0)
        contours_candidates, _ = cv2.findContours(threshold, 1, 2)

        temp = list()
        max_contour = np.max([cv2.contourArea(candidate) for candidate in contours_candidates[:]])
        for candidate in contours_candidates[:]:
            if cv2.contourArea(candidate) >= max_contour:
                temp.append(candidate)
            else:
                pass
        contour = temp[-1]
        return contour

    def _extract_cls_patch(self, ori_img, contour):
        x, y, w, h = cv2.boundingRect(contour)
        dw, dh = int(w / 14), int(h / 14)
        top, bottom, left, right = y-dh, y+h+dh+1, x-dw, x+w+dw+1
        bbox = [top, bottom, left, right]

        center, (width, height), theta = cv2.minAreaRect(contour)
        min_area = cv2.boxPoints((center, (width, height), theta))
        min_area = np.int0(min_area)

        theta += self.angle
        theta = np.deg2rad(theta)

        if theta <= -np.pi / 4:
            theta += np.pi / 2
            width, height = height, width

        longest_size = np.maximum(width, height)
        v_x = (np.cos(theta), np.sin(theta))
        v_y = (-np.sin(theta), np.cos(theta))

        s_x = center[0] - self.offset * (v_x[0] * ((longest_size - 1) / 2) + v_y[0] * ((longest_size - 1) / 2))
        s_y = center[1] - self.offset * (v_x[1] * ((longest_size - 1) / 2) + v_y[1] * ((longest_size - 1) / 2))

        mapping = np.array([[v_x[0], v_y[0], s_x], [v_x[1], v_y[1], s_y]])

        patch = cv2.warpAffine(
            ori_img,
            mapping,
            (int(self.offset * longest_size), int(self.offset * longest_size)),
            flags=cv2.WARP_INVERSE_MAP,
            borderMode=cv2.BORDER_REPLICATE
        )

        patch = cv2.resize(patch, self.patch_size, interpolation=cv2.INTER_AREA)
        patch = (patch - patch.min()) / (patch.max() - patch.min())
        patch = patch.astype(np.float32)

        return patch, bbox, min_area

    def io_error_check(self):
        if self.patch_size_rule1 is not None:
            assert isinstance(self.patch_size, self.patch_size_rule1), \
                'Patch size data type must be list or tuple'
        if self.patch_size_rule2 is not None:
            assert all(isinstance(p, self.patch_size_rule2) for p in self.patch_size), \
                'Value of patch size must be integer, not float'
        if self.patch_size_rule3 is not None:
            assert len(self.patch_size) == self.patch_size_rule3, \
                'Dimension of Patch size must be 2, like (m, n) or [m, n]'
        if self.angle_rule is not None:
            assert self.angle_rule[0] <= self.angle <= self.angle_rule[1], \
                'Angle must be the number between -10 and 10'
        if self.offset_rule is not None:
            assert self.offset_rule[0] <= self.offset <= self.offset_rule[1], \
                'Offset must be the number between 0.8 and 2'


if __name__ == '__main__':
    from deepphi.image_processing.utils import display, test_prep, get_image
    from copy import deepcopy
    import os

    os.chdir('/home/hslisalee/Downloads/DL_team_codes/park_ms/dataset')

    # Default parameter
    patch_size = (256, 256)
    angle = 0
    offset = 1.6

    # Initialize class
    cls_patch_extractor = SpineClsPatchExtractor(
        patch_size=patch_size, angle=angle, offset=offset)

    # Input Data load (one hdf5 data + one data list with 5 hdf5 data)
    ori_data = test_prep('spine_sample_1.hdf5', log=True)

    mask_data_path_list = ['spine_sample_9_{}.hdf5'.format(idx) for idx in range(5)]
    mask_data = DeepPhiDataSet()

    # Output Data load (data list with 5 hdf5 data)
    output_data_list = list()
    mask_data_list = list()
    mask_img_list = list()
    output_img_list = list()

    for idx, mask_data_path in enumerate(mask_data_path_list):
        mask_data.load(mask_data_path)
        mask_data_list.append(mask_data)

        mask_img_list.append(get_image(mask_data))

    output_data_list = cls_patch_extractor(deepcopy(ori_data),
                                           deepcopy(mask_data_list))
    for output_data in output_data_list:
        output_img_list.append(get_image(output_data))

    # Display output
    display(
        np.squeeze(ori_data['image']['array']) * 255,
        cmap='gray',
        add_to_title='Original Image'
    )

    for idx, mask_img in enumerate(mask_img_list):
        display(
            np.squeeze(mask_img) * 255,
            cmap='gray',
            add_to_title='Seg Patch Image {}'.format(idx + 1)
        )

    for idx, output_img in enumerate(output_img_list):
        display(
            np.squeeze(output_img) * 255,
            cmap='gray',
            add_to_title='Cls Patch Image {}'.format(idx + 1))
