#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
from deepphi.io.sitk import *
import logging


class PatchCenterPointLocalization(Preprocessing):
    def __init__(self, kernel_size=(5, 5)):
        super(PatchCenterPointLocalization, self).__init__()
        self.log = logging.getLogger()

        if kernel_size is not None:
            self.kernel_size = kernel_size
        else:
            raise KeyError("Kernel size information is required. ex)(5, "
                           "5) of type tuple or list is accepted.")

        self.kernel = np.ones(kernel_size, np.uint8)

        self.kernel_rule = (tuple, list)
        self.ndim_rule = 2

    def __call__(self, data):
        # I/O Error Check Parameters
        self.io_error_check(data)

        # Load input data
        img = np.squeeze(data['image']['array'])
        img_size = img.shape

        # Image process
        blurred_output, idx_zero = self._blur_color_map(img, self.kernel)
        idx_max_candidate, heat_map = self._select_points(blurred_output,
                                                          idx_zero)
        filtered_point_list = self._filter_points(idx_max_candidate, img_size)
        final_point_list = self._scoring(filtered_point_list, heat_map)

        # Update data
        img = img/(data['image']['array'].max()) * 255
        data['image']['array'] = img
        data['image']['header']['patch_center_point_localization']= dict()
        data['image']['header']['patch_center_point_localization']['centerpoint'] = dict()
        data['image']['header']['patch_center_point_localization']['centerpoint'][
            'values'] = final_point_list.tolist()

        ## 2. Centerpoint info list
        self.log.debug('Centerpoint locations: ')
        self.log.debug('1. \t{}'.format(final_point_list.tolist()[0]))
        self.log.debug('2. \t{}'.format(final_point_list.tolist()[1]))
        self.log.debug('3. \t{}'.format(final_point_list.tolist()[2]))
        self.log.debug('4. \t{}'.format(final_point_list.tolist()[3]))
        self.log.debug('5. \t{}'.format(final_point_list.tolist()[4]))

        return data

    def _blur_color_map(self, pose_output, kernel):
        '''
        Blur and normalize color map of PoseNet Outputs
        :param pose_output: Output of PoseNet, consists of several circle like heat-map
        :param kernel: kernel to execute erosion
        :return:
            blurred_output : blurred and normalized output
            idx_zero : index list which value is lower than threshold
        '''
        blurred_output = cv2.erode(
            src=pose_output,
            kernel=kernel,
            iterations=1
        )

        blurred_output = cv2.normalize(
            src=blurred_output,
            dst=None,
            alpha=0,
            beta=255,
            norm_type=cv2.NORM_MINMAX
        )

        blurred_output = np.uint8(blurred_output)
        _, threshold = cv2.threshold(
            src=blurred_output,
            thresh=0,
            maxval=255,
            type=cv2.THRESH_BINARY + cv2.THRESH_OTSU
        )

        threshold[threshold > 0] = 1
        threshold[threshold < 1] = 0

        blurred_output = np.multiply(blurred_output, threshold)

        idx_zero = np.array(np.where(threshold.flatten() == 0))

        return blurred_output, idx_zero

    def _select_points(self, blurred_output, idx_zero):
        '''
        select centerpoints of spines from blurred posenet output
        :param blurred_output: blurred output after _blur_color_map()
        :param idx_zero: index list which value is lower than threshold
        :return:
            idx_max_candidate : candidates of centerpoints
            heat_map : heat map of blurred_output
        '''
        size_row, size_column = blurred_output.shape[:2]

        window_row = 8
        window_column = 8

        heat_map = blurred_output / 255

        nms_map = np.zeros_like(heat_map)

        for idx_row in range(size_row - window_row + 1):
            for idx_column in range(size_column - window_column + 1):
                row_center = idx_row + int(np.round((window_row - 1) / 2))
                column_center = idx_column + int(
                    np.round((window_column - 1) / 2))
                max_value = np.max(heat_map[idx_row:idx_row + window_row - 1,
                                   idx_column:idx_column + window_column - 1])
                nms_map[row_center, column_center] = max_value
        difference_map = nms_map - heat_map
        idx_difference_zero = np.array(np.where(difference_map.flatten() == 0))
        idx_max_candidate = np.array(
            np.setdiff1d(idx_difference_zero, idx_zero))

        return idx_max_candidate, heat_map

    def _filter_points(self, idx_max_candidate, size):
        '''
        filter candidates of centerpoints to choose final centerpoints
        :param idx_max_candidate: candidates of centerpoints
        :param size: segmentation patch size after select centerpoints
        :return:
            filtered_point_list : filtered candidates
        '''
        point_list = np.zeros((2, idx_max_candidate.shape[0]))
        point_list[1, :], point_list[0, :] = np.array(
            np.unravel_index(idx_max_candidate, size))
        point_list = point_list.astype(int)
        point_list = np.transpose(point_list, [1, 0])

        filtered_point_list = []

        for idx in range(len(point_list)):
            if idx < len(point_list) - 1:
                distance = (point_list[idx, 0] - point_list[
                    idx + 1, 0]) ** 2 + (point_list[idx, 1] - point_list[
                    idx + 1, 1]) ** 2
                if distance > 100:
                    filtered_point_list.append(point_list[idx])
            else:
                filtered_point_list.append(point_list[idx])
        filtered_point_list = np.array(filtered_point_list)

        return filtered_point_list

    def _scoring(self, filtered_point_list, heat_map):
        '''
        final scoring to choose 5 centerpoints
        :param filtered_point_list: filtered candidates
        :param heat_map: heat map of blurred_output
        :return:
            final_point_list : final 5 centerpoints list
        '''
        score_list = np.zeros([filtered_point_list.shape[0], 1])

        for idx in range(filtered_point_list.shape[0]):
            box_x = filtered_point_list[idx, 0]
            box_y = filtered_point_list[idx, 1]

            cropped_heat_map = heat_map[box_y - 4:box_y + 4,
                               box_x - 4:box_x + 4]
            score_list[idx] = np.mean(cropped_heat_map)

        for threshold in range(3, 0, -1):
            idx_top_candidate = np.where(score_list > 0.1 * threshold)[0]
            temp_point_list = filtered_point_list[idx_top_candidate, :]
            final_point_list = temp_point_list[::-1][:5][::-1]

            if len(temp_point_list) >= 5:
                break
            else:
                continue

        return final_point_list

    def io_error_check(self, data):
        ndim = np.squeeze(data['image']['array']).ndim

        if self.ndim_rule is not None:
            assert ndim == self.ndim_rule, \
                'Only one image or image of one channel can be processed'

        if self.kernel_rule is not None:
            assert isinstance(self.kernel_size, self.kernel_rule), \
                'Kernel shape data type must be list or tuple'


if __name__ == '__main__':
    from deepphi.image_processing.utils import display, test_prep
    from copy import deepcopy
    import os

    os.chdir('/home/hslisalee/Downloads/DL_team_codes/park_ms/dataset')

    # Default parameter
    kernel_size = (5, 5)

    # Initialize class
    center_point_localization = PatchCenterPointLocalization(
        kernel_size=kernel_size)

    # Input Data load (hdf5 data)
    ## Centerpoint image data after passing AI segmentation model_1
    center_point_data = test_prep('spine_sample_5.hdf5', log=True)
    center_point_img = center_point_data['image']['array']
    display(np.squeeze(center_point_img) * 255)

    # Output Data load (hdf5 data)
    localized_data = center_point_localization(deepcopy(center_point_data))
    localized_img = localized_data['image']['array']

    # Display output
    display(np.squeeze(center_point_data['image']['array']) * 255,
            cmap='gray',
            add_to_title='Original Center-point Image'
            )
    display(localized_img * 255,
            cmap='gray',
            add_to_title='Out Center-point Image(Same as input image)'
            )
