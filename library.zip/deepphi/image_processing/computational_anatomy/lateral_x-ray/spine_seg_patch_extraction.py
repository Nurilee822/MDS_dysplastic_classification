#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
from deepphi.io.sitk import *
import logging


class SpineSegPatchExtractor(Preprocessing):
    def __init__(self, patch_size=(256, 256), offset=1.6):
        super(SpineSegPatchExtractor, self).__init__()
        self.log = logging.getLogger()
        self.patch_size = patch_size
        self.offset = offset

        self.patch_size_rule1 = (tuple, list)
        self.patch_size_rule2 = int
        self.patch_size_rule3 = 2
        self.offset_rule = [0.8, 2]

    def __call__(self, data_original, data_centerpoint):
        # I/O Error Check Parameters
        self.io_error_check()

        # Load input data
        ori_img = np.squeeze(data_original['image']['array'])
        ori_img_shape = ori_img.shape

        before_size = np.array([np.max(ori_img_shape)] * 2)
        after_size = data_centerpoint['image']['array'].shape

        center_points = data_centerpoint['image']['header']['centerpoint'][
            'values']
        center_points = center_points * (before_size / after_size)

        try:
            marginlist = data_centerpoint['image']['header']['marginlist'][
                'values']
        except KeyError:
            marginlist = [[0, 0], [0, 0]]

        # Image process
        margin = self._marginlist_to_margin(marginlist)
        center_points -= margin
        center_points = center_points.astype(np.int32)

        # Update data
        list_data = self._extract_seg_patches(ori_img, ori_img_shape,
                                              center_points, data_centerpoint)

        for idx in range(len(list_data)):
            ## 1. Whole image to patch image
            seg_patch_img = list_data[idx]['image']['array']
            self.log.debug('0. Input_image_shape: \t{}'.format(ori_data['image'][
                'array'].shape))
            self.log.debug('1. Output_image_shape: \t{}'.format(
                seg_patch_img.shape))
            ## 2. Coordinates info list
            self.log.debug('2. Coordinates info: \t{}'.format(list_data[idx]
            ['image']['header']['coordinates']['values']))
            ## 3. Spine index list
            self.log.debug('Spine index info: \t{}\n'.format(list_data[idx]
            ['image']['header']['spine_idx']['values']))

        return list_data

    def _extract_seg_patches(self, ori_img, img_shape, center_points,
                             data_centerpoint):
        '''
        extract segmentation patch from original x-ray image
        :param img: original x-ray image
        :param center_points: 5 C-Spine center points list from SelectCenterPoints()
        :param patch_size: size of each segmentation patch
        :param offset: patch zoom ratio
        :return:
            patches : 5 patch images,
            patches_coordinates : 5 patch coordinates list
        '''

        list_data = list()

        for idx in range(len(center_points)):
            data = deepcopy(data_centerpoint)
            if idx < len(center_points) - 1:
                width = center_points[idx, 0] - center_points[idx + 1, 0]
                height = center_points[idx, 1] - center_points[idx + 1, 1]
            else:
                width = center_points[idx, 0] - center_points[idx - 1, 0]
                height = center_points[idx, 1] - center_points[idx - 1, 1]
            length = int((width ** 2 + height ** 2) ** (0.5) * self.offset)

            x_min = np.clip(center_points[idx, 0] - length, 0, img_shape[1])
            x_max = np.clip(center_points[idx, 0] + length, 0, img_shape[1])

            y_min = np.clip(center_points[idx, 1] - length, 0, img_shape[0])
            y_max = np.clip(center_points[idx, 1] + length, 0, img_shape[0])

            patch = ori_img[y_min:y_max, x_min:x_max]
            patch = cv2.resize(patch, self.patch_size,
                               interpolation=cv2.INTER_AREA)
            patch = patch.flatten()
            patch = (patch - patch.min()) / (patch.max() - patch.min())
            patch = patch.reshape(self.patch_size)

            data['image']['array'] = patch
            data['image']['header']['coordinates'] = dict()
            data['image']['header']['coordinates']['values'] = list(
                map(int, [y_min, y_max, x_min, x_max]))
            data['image']['header']['spine_idx'] = dict()
            data['image']['header']['spine_idx']['values'] = idx + 1

            list_data.append(data)

        return list_data

    def _marginlist_to_margin(self, marginlist):
        '''
        make marginlist to margin
        :param marginlist: padded margin after passing padding_to_square
        :return: margin list with two values, like [margin1, margin2]
        '''
        if len(marginlist) == 2:
            margin = marginlist
        elif len(marginlist) == 3:
            margin = marginlist[1:]
        else:
            margin = marginlist[1:-1]
        margin = np.array(margin[::-1])[:, 0]

        return margin

    def io_error_check(self):
        if self.patch_size_rule1 is not None:
            assert isinstance(self.patch_size, self.patch_size_rule1), \
                'Patch size data type must be list or tuple'
        if self.patch_size_rule2 is not None:
            assert all(
                isinstance(p, self.patch_size_rule2) for p in self.patch_size), \
                'Value of patch size must be integer, not float'
        if self.patch_size_rule3 is not None:
            assert len(self.patch_size) == self.patch_size_rule3, \
                'Dimension of Patch size must be 2, like (m, n) or [m, n]'
        if self.offset_rule is not None:
            assert self.offset_rule[0] <= self.offset <= self.offset_rule[1], \
                'Offset must be the number between 0.8 and 2'


if __name__ == '__main__':
    from deepphi.image_processing.utils import display, test_prep
    from copy import deepcopy

    import os

    os.chdir('/home/hslisalee/Downloads/DL_team_codes/park_ms/dataset')

    # Default parameter
    patch_size = (256, 256)
    offset = 1.6

    # Input Data load (two hdf5 data)
    ## 1. Whole image data after passing first min_max_scaling
    # ori_data = DeepPhiDataSet()
    # ori_data.load('spine_sample_1.hdf5')
    ori_data = test_prep('spine_sample_1.hdf5', log=True)

    ## 2. Centerpoint image data after passing PacthCenterPointLocalization
    centerpoint_data = DeepPhiDataSet()
    centerpoint_data.load('spine_sample_6.hdf5')

    # Initialize class
    seg_patch_extractor = SpineSegPatchExtractor(data_centerpoint=centerpoint_data,
                                                 patch_size=patch_size,
                                                 offset=offset)

    # Output Data load (data list with 5 hdf5 data)
    output_data_list = seg_patch_extractor(deepcopy(ori_data))

    # Display output
    display(
        np.squeeze(ori_data['image']['array']) * 255,
        cmap='gray',
        add_to_title='Original Image'
    )
    for idx, output_data in enumerate(output_data_list):
        display(
            np.squeeze(output_data['image']['array']) * 255,
            cmap='gray',
            add_to_title='Seg Patch Image {}'.format(idx + 1)
        )