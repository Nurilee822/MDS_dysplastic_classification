#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import gc
import logging
import math
import cv2
from PIL import Image
from deepphi.image_processing import Preprocessing
from deepphi.image_processing.config.resize_keep_ratio_ import *
from deepphi.image_processing.utils import shape, timeit


class ResizeKeepRatio(Preprocessing):

    def __init__(self, *args, **kwargs):
        super(ResizeKeepRatio, self).__init__(self)
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.output_size = None
        self.num_patches = None
        if kwargs['patch_length'] is not None:
            if isinstance(kwargs['patch_length'], int):
                self.patch_length = kwargs['patch_length']
            else:
                raise TypeError("Input type must be int.")
        else:
            key = ' target patch_length '
            raise KeyError("For resizing," + key + "information is required.")

        if kwargs['overlap'] is not None:
            if isinstance(kwargs['overlap'], int):
                self.overlap = kwargs['overlap']
            else:
                raise TypeError("Input type must be int.")
        else:
            key = ' overlap length '
            raise KeyError("For resizing," + key + "information is required.")

        if kwargs['resize_length'] is not None:
            if isinstance(kwargs['resize_length'], int):
                self.resize_length = kwargs['resize_length']
            else:
                raise TypeError("Input type must be int.")
        else:
            key = ' resize length '
            raise KeyError("For resizing," + key + "information is required.")

    @timeit
    def __call__(self, data, save_path=None):
        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        hdf5_list = self.image_processing(source_image=source_image,
                                          param=[self.args, self.kwargs])

        # Logging_Info
        self.log.debug('Patch size:\t\t\t\t{}x{} (user input)'.format(
            self.patch_length, self.patch_length))
        self.log.debug('Patch overlaps:\t\t\t{} pixels (user input)'.format(
            self.overlap))
        self.log.debug('Target size:\t\t\t{}x{} (user input)'.format(
            self.resize_length, self.resize_length))

        self.log.debug('Patches extracted:\t\t{}'.format(self.num_patches))
        self.log.debug('Input image shape:\t\t{}'
                       .format(np.shape(source_image)))
        self.log.debug('Output image shape:\t\t{}'.format(self.output_size))
        self.log.debug('history:\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return hdf5_list

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply contrast adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Apply_CLAHE
            output_img_list = self.resize_keep_ratio(source_image)

            # Update_Info
            self.add_array(output_img_list, DTYPE_UINT8)
            self.output_size = np.shape(output_img_list[0])

            return self.generate_patch_dataset(output_img_list)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def resizing_image(self, source_image, height_and_width):
        """ Applies image resizing with the size of the given length on an
        image \and returns the re-sized image with fixed size.

        Args:
            source_image (image): numpy array of the image
            height_and_width (int): length of both height and width
                                         to be re-sized

        Returns:
            (numpy.ndarray): numpy representation of re-sized image in size of
                            (height_and_width, height_and_width)

        Example:
            > > > image = cv2.imread('1035642_.svs')
            > > > resizing_image(image, 1024)
            (numpy.ndarray)
        """

        try:
            if not isinstance(source_image, np.ndarray):
                source_image = np.asarray(source_image)

            if source_image.shape == (height_and_width,
                                      height_and_width):
                return source_image

            old_size = source_image.shape[:2]
            ratio = float(height_and_width) / max(old_size)
            new_size = tuple([int(x * ratio) for x in old_size])

            im = cv2.resize(source_image, (new_size[1], new_size[0]))
            delta_w = height_and_width - new_size[1]
            delta_h = height_and_width - new_size[0]
            top, bottom = delta_h // 2, delta_h - (delta_h // 2)
            left, right = delta_w // 2, delta_w - (delta_w // 2)

            return cv2.copyMakeBorder(im, top, bottom, left, right,
                                      cv2.BORDER_CONSTANT, value=COLOR_RGB)
        except Exception as error:
            raise Exception("Exception occurred while resizing the image: " + str(error))

    def resizing_list_images(self, list_of_images):
        """ Applies image resizing with the size of the given length on an image
        and returns the re-sized image with fixed size.

        Args:
            list_of_images (List<numpy.ndarray>): list of numpy array of the image
            height_and_width (int): length of both height and width to be re-sized

        Returns:
            List<numpy.ndarray>: list of re-sized numpy image in size of
            (height_and_width, height_and_width)

        Example:
            > > > resizing_list_images(list_of_images, 1024)
            List<numpy.ndarray>
        """
        return_list = []
        for i, img in enumerate(list_of_images):
            return_list.append(self.resizing_image(img, self.resize_length))
        return return_list

    def patch_extraction(self, image):
        """ Extract patch from the cropped image in the size of
        (height_and_width, height_and_width).

        Args:
            image (PIL.Image): image to be splitted.
            height_and_width (int): length of both height and width to be
                                    splitted.
            overlap (int): overlapping length.

        Returns:
            List<PIL.Image>: List of extracted patch images

        Example:
            > > > patch_extraction(cropped_image, 1024, 512)
            List<PIL.Image>
        """

        returning_patch_image = []
        crrnt_img_height, crrnt_img_width = shape(image)[:2]

        if (shape(image)[0] <= self.patch_length) \
                and (shape(image)[1] <= self.patch_length):
            returning_patch_image.append(self.resizing_image(image,
                                                             self.patch_length))
            return returning_patch_image
        else:
            w_iteration = int(math.ceil((shape(image)[1]-self.overlap)
                                        / (self.patch_length-self.overlap)))
            h_iteration = int(math.ceil((shape(image)[0]-self.overlap)
                                        / (self.patch_length-self.overlap)))
            for i in range(w_iteration):
                if i == (w_iteration-1):
                    left, right = shape(image)[1]-self.patch_length, \
                                  shape(image)[1]
                else:
                    left = ((self.patch_length-self.overlap)*i)
                    right = left + self.patch_length
                for j in range(h_iteration):
                    if j == (h_iteration - 1):
                        top, bottom = shape(image)[0] - self.patch_length, \
                                      shape(image)[0]
                    else:
                        top = ((self.patch_length - self.overlap) * j)
                        bottom = top + self.patch_length
                    if right > crrnt_img_width:
                        print("Current Width is " + str(crrnt_img_width)
                              + " but it exceeded with " + str(right))
                    if bottom > crrnt_img_height:
                        print("Current Height is " + str(crrnt_img_height)
                              + " but it exceeded with " + str(bottom))
                    returning_patch_image.append(image.crop((left, top, right, bottom)))
                    gc.collect()

        return returning_patch_image

    def resize_keep_ratio(self, source_image):
        """ Splitting image into the size of
        (height_and_width, height_and_width).

        Args:
            source_image (ndarray): image to be splitted

        Vars:
            self.height_and_width (int): length of both height and width
                                         to be splitted to.
            self.overlap (int): length of overlapping
            self.resize_length (int): length of the image to be resized
                                      for the final output.

        Returns:
            List<numpy.array): List of split images

        Example:
            > > > split_img(cropped_image, 2048, 1024)
            List<numpy.array>
        """
        image = Image.fromarray(source_image)
        patch_images = self.patch_extraction(image)
        split_images = self.resizing_list_images(patch_images)

        return split_images

    def generate_patch_dataset(self, output_img_list):
        from deepphi.io.sitk import DeepPhiDataSet

        self.num_patches = np.shape(output_img_list)[0]
        hdf5_list = []

        for idx, patch in enumerate(output_img_list):
            # Initialize DeepPhiDataSet
            hdf5_patch = DeepPhiDataSet()
            # Copy input hdf5
            data = self.get_data()
            keys = data.keys()
            for i, key in enumerate(keys):
                print('This is key no.{}: {}\n{}'.format(str(i + 1),
                                                         str(key),
                                                         data[key]))
            # Insert patch image
            hdf5_patch['image']['array'] = patch
            # Add to list
            hdf5_list.append(hdf5_patch)

        return hdf5_list


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, LOCAL_DATA

    DATA = LOCAL_DATA

    hdf5_input = test_prep(DATA, log=True)

    MODULE_NAME = 'ResizeKeepRatio'
    MODULE_ID = '1234'
    PATCH_LENGTH = 1124
    OVERLAP = 0
    NEW_SIZE = 512

    resize = ResizeKeepRatio(module_name=MODULE_NAME,
                             module_id=MODULE_ID,
                             patch_length=PATCH_LENGTH,
                             overlap=OVERLAP,
                             resize_length=NEW_SIZE)

    hdf5_output = resize(hdf5_input)

    hdf5_list = hdf5_output
    for hdf5 in hdf5_list:
        display(hdf5['image']['array'])

