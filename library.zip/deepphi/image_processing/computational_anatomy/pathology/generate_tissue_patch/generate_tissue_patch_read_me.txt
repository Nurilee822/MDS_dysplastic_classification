from deepphi.image_processing.color_processing.color_mode.rgb_to_hsv import RGBtoHSV
from deepphi.image_processing.segmentation.filter.color_filter import ColorFilter
from deepphi.image_processing.enhancement.contrast.custom_clahe import CustomClahe
from deepphi.image_processing.segmentation.thresholding.otsu_thresholding \
    import OtsuThresholding
from  deepphi.image_processing.segmentation.morphological_operation.dilation \
    import Dilation

<Group: Generate Tissue Mask >

Modules List:
-----------------------------------------------------------------------------
1. get_contours

path:
    deepphi.image_processing.segmentation.edge_detection.get_contours
param:
    area_thresh (str) minimum area size to find contours.
    line_color  (int) contour line color for display
    line_width  (int) contour line thickness for display.
    module_name (str)
    module_id   (str)
preset:
    area_thresh = 60
    line_color = 175
    line_width = 2

    get_contours = GetContours(area_thresh=MIN_AREA,
                               line_color=COLOR,
                               line_width=WIDTH)

-----------------------------------------------------------------------------
2. merge_if_overlaps

path:
    deepphi.image_processing.segmentation.filter.color_filter
param:
    lower_b     (list) 3-channel-color [lower_r, lower_g, lower_b]
    upper_b     (list) 3-channel-color [upper_r, upper_g, upper_b]
    module_name (str)
    module_id   (str)
preset:
    LOWER_RGB_THRESHOLD = [0, 100, 0]
    UPPER_RGB_THRESHOLD = [200, 200, 200]
    LOWER_HSV_THRESHOLD = [130, 0, 0]
    UPPER_HSV_THRESHOLD = [180, 255, 255]
    LOWER_B = LOWER_RGB_THRESHOLD
    UPPER_B = UPPER_RGB_THRESHOLD

-----------------------------------------------------------------------------
3. custom_clahe

path:
    deepphi.image_processing.enhancement.contrast.custom_clahe
param:
    thresh      (int)       Threshold for contrast limiting.
    tile_grid_size (tuple)  (int, int) Size of grid for histogram equalization.
    module_name (str)
    module_id   (str)
preset:
    THRESH = 5
    TILE_GRID_SIZE = (20, 20)

-----------------------------------------------------------------------------
4. otsu_thresholding

path:
    deepphi.image_processing.segmentation.thresholding.otsu_thresholding
param:
    module_name (str)
    module_id   (str)

-----------------------------------------------------------------------------
5. dilation

path:
    deepphi.image_processing.segmentation.morphological_operation.dilation
param:
    strel       (int)   radius of a disk structuring element.
    se_shape    (tuple) custom shape of structuring element.
    module_name (str)
    module_id   (str)
preset:
    * ONLY one can have value. The other must be None.
    STREL = 7
    SE_SHAPE = None
-----------------------------------------------------------------------------