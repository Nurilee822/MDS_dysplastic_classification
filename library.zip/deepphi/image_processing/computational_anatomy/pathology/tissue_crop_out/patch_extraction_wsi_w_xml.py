#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

from deepphi.io.sitk import DeepPhiDataSet
from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit
from deepphi.image_processing.computational_anatomy.pathology.utils import *


PROCESSING_ERROR_MSG = "Exception occurred while image processing: "
EMPTY_ERROR_MSG = "Exception occurred while processing data: There is no value in the input image array."
INPUT_TYPE_ERROR_MSG = "Exception occurred while processing data: Image data type is invalid. Must be in a form of array."
NP_NDARRAY = np.ndarray
DTYPE_UINT8 = 'uint8'
NP_UINT_ = np.uint8


class PatchExtractionWsiXml(Preprocessing):

    def __init__(self, *args, **kwargs):
        """
            self.xml_path (str): path to the xml file
            self.class_to_include (List<str>): names of the classes that will be
                                               ending up in the final mask
                                               image.
            self.patch_lengths (int): both lengths of the patches.
            self.overlap (int): overlap length for both horizontal and vertical.

        """
        super(PatchExtractionWsiXml, self).__init__(self)
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.max_dim = None
        self.num_patches = None
        self.class_name_list = None
        self.output_hdf5_list = None
        self.this_module = __class__.__name__

        if kwargs['xml_path'] is not None:
            self.xml_path = kwargs['xml_path']
        else:
            raise KeyError("Corresponding xml file path is required.")

        if kwargs['class_to_include'] is not None:
            if isinstance(kwargs['class_to_include'], list):
                self.class_to_include = kwargs['class_to_include']
            else:
                raise TypeError("Class to include must be provided as a list.")
        else:
            raise KeyError("Class to include is required to process.")

        if kwargs['patch_lengths'] is not None:
            if isinstance(kwargs['patch_lengths'], int):
                self.patch_lengths = kwargs['patch_lengths']
            else:
                raise TypeError("Patch lengths must be in type int.")
        else:
            raise KeyError("Patch length information is required.")

        if kwargs['overlap'] is not None:
            if isinstance(kwargs['overlap'], int):
                self.overlap = kwargs['overlap']
            else:
                raise TypeError("Overlap value must be in type int.")
        else:
            raise KeyError("Overlap value is required to process.")

    @timeit
    def __call__(self, data, save_path=None):
        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.max_dim = data['image']['header']['dimensions'][0]
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('module name: \t\t\t\t{}'.format(self.this_module))
        self.log.debug('existing classes: \t\t\t{}'.format(
            self.class_name_list))
        self.log.debug('class to include in mask: \t{}'.format(
            self.class_to_include))
        self.log.debug('number of patches: \t\t\t{} each '
                       '(mask={}, tissue={})'.format(self.num_patches,
                                                     self.num_patches,
                                                     self.num_patches))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.output_hdf5_list

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply contrast adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Patch Extraction
            patches_with_coords = self.patch_extraction_tissue(source_image)
            self.generate_patch_dataset(patches_with_coords)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def patch_extraction_tissue(self, source_image):
        """ Main function for segmentation data pre-processing.
        Takes xml and wsi path to the same tissue file. Takes the
        name of the classes that the final mask image will contain.
        Lastly takes length of the patch and overlap value for
        the size and iteration number for the patch extraction.

        Args:

            source_image (ndarray): whole slide image to perform patch extraction

        Vars:
            self.xml_path (str): path to the xml file
            self.class_to_include (List<str>): names of the classes that will be
                                               ending up in the final mask
                                               image.
            self.patch_lengths (int): both lengths of the patches.
            self.overlap (int): overlap length for both horizontal and vertical.
            self.next_dim_image (ndarray): source image array of the next
                                           level dimension.

        Returns:
            List<PIL.Image>, List<PIL.Image>: two lists of images
            which both contains patch extracted images,
            one from the label, and the other from the tissue image.

        """

        # Open WSI file and extract useful information (size of each level)
        # Create mask image from the xml file.
        # Individual classes in the xml file will be created with additional of
        # TOTAL mask image.
        class_name_list, class_mask_list = create_mask_from_xml(self.xml_path,
                                                                self.max_dim,
                                                                False)
        self.class_name_list = class_name_list[:-1]

        # extracting only the desired class mask images and combine them into
        # one single mask image.
        abnormal_mask = filter_only_needed_classes(class_name_list,
                                                   class_mask_list,
                                                   self.class_to_include)

        # In case the labeling is showing a poor quality,
        # compare the label mask image and tissue mask image to, at least,
        # get the label regions on the tissue territory and eliminate outside
        # of the area.
        overlap_mask = get_overlapping_regions_only(abnormal_mask,
                                                    source_image)

        # Since the background portion is too big, need to extract the ROI
        # (region of interest) to fast-forward and improve the quality of the
        # process of training, and pre-processing.
        label_mask, source_image = crop_existing_tissue_label_mask(
                                                            class_mask_list[-1],
                                                            overlap_mask,
                                                            source_image)

        # Finally, extract patches from both tissue and label mask images.
        patches_n_coords_lists = patch_extract_mask_and_tissue(
                                                            label_mask,
                                                            source_image,
                                                            self.patch_lengths,
                                                            self.overlap)

        return patches_n_coords_lists

    def generate_patch_dataset(self, patches_n_coords):

        mask_patch_list, tissue_patch_list, patch_coords_list = patches_n_coords

        self.num_patches = len(mask_patch_list)
        hdf5_list = []

        for idx in range(self.num_patches):
            mask = np.array(mask_patch_list[idx])
            tissue = np.array(tissue_patch_list[idx])

            # Initialize DeepPhiDataSet
            hdf5_patch = DeepPhiDataSet()
            self.log.debug('HDF5_Patch #{} Created.'.format(idx))

            # Copy input hdf5
            data = self.get_data()

            # Insert metadata
            hdf5_patch['image']['header']= data['image']['header']
            hdf5_patch['header'] = data['header']
            hdf5_patch['label'] = data['label']

            # Insert tissue patch image
            hdf5_patch['image']['array'] = tissue
            hdf5_patch['image']['patch'] = dict()

            # Insert mask patch image
            hdf5_patch['label']['array'] = mask

            # Insert header info
            hdf5_patch['image']['patch']['coords'] = patch_coords_list[idx]
            hdf5_patch['image']['patch']['total'] = self.num_patches
            hdf5_patch['image']['patch']['idx'] = idx
            hdf5_patch['image']['patch']['class'] = self.class_to_include

            # Add to list
            hdf5_list.append(hdf5_patch)

        self.output_hdf5_list = hdf5_list


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, LOCAL_DATA
    # import hdf5 image
    NEXT_DIM_DATA = '../../../data/1035154_lv1.hdf5'
    LOWEST_DIM_DATA = '../../../data/1035154_lv2.hdf5'
    # DATA = LOWEST_DIM_DATA
    DATA = LOCAL_DATA
    XML_PATH = '../../../data/1035154_.xml'
    DIMENSIONS = ((45816, 17989), (11454, 4497), (2863, 1124))
    CLASS = ['ACI']
    PATCH_L = 512
    OVERLAP = 20

    hdf5_input = test_prep(DATA, log=True)

    # insert max_dim dimension info(not initialized on this data)
    hdf5_input['image']['header']['dimensions'] = DIMENSIONS

    patch_extraction_wsi_xml = PatchExtractionWsiXml(xml_path=XML_PATH,
                                                     class_to_include=CLASS,
                                                     patch_lengths=PATCH_L,
                                                     overlap=OVERLAP)

    output_hdf5_list = patch_extraction_wsi_xml(hdf5_input)

    SAVING_PATH = '/home/hslisalee/DEEPPHI/image_processing/output/' \
                  'computational_anatomy/patch_extraction_wsi_xml/'
    img_name = '1035154_'

    for idx in range(len(output_hdf5_list)):
        hdf5_output = output_hdf5_list[idx]
        mp = Image.fromarray(hdf5_output['label']['array'])
        tp = Image.fromarray(hdf5_output['image']['array'])

        mp.save(SAVING_PATH + img_name + CLASS[0] + '_' + str(idx) + '_mp_' +
                '.png')
        print('\n\nMask Patch Extraction \t\t---- Completed ----')
        tp.save(SAVING_PATH + img_name + CLASS[0] + '_' + str(idx) + '_tp_' +
                '.png')
        print('Tissue Patch Extraction \t---- Completed ----')

        clss = hdf5_output['image']['patch']['class']
        print('Mask Patch Target Class = {}'.format(clss))

        total = hdf5_output['image']['patch']['total']
        patch_idx = hdf5_output['image']['patch']['idx']
        coords = hdf5_output['image']['patch']['coords']

        print('TYPE\t\tTOTAL\t\tIDX\t\tLOCATION(left, upper, right, lower)')
        print('Patch\t\t{}({}/{})\t\t#{}\t\t{}'.format(total,
                                                       patch_idx+1, total,
                                                       patch_idx,
                                                       coords))
