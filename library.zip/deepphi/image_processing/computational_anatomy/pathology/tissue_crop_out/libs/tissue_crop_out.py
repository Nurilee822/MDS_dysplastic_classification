#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import math

import cv2
import numpy as np
from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit


class CropOut(Preprocessing):
    """ Module to create tissue mask from pathology image.

        Takes a lower resolution level of the Whole-slide Image (WSI).
        Uses color filtering, clahe, and dilation to find contour of tissue
        existence. Then goes through two filtering of small regions and
        one merging of the overlapping area.
        Returns the resulting coordinates of the rectangles
        (tissue lying images)

        self variable:
            self.rect_list_out  (list<(int, int, int, int)>) : all merged and
                    large enough rectangle's coordinates list will be returned.
    """

    def __init__(self, *args, **kwargs):
        super(CropOut, self).__init__(self)
        self.processed = []

    @timeit
    def __call__(self, data, save_path=None):
        """ Takes a lower resolution level of the Whole-slide Image (WSI).
        Uses color filtering, clahe, and dilation to find
        contour of tissue existence. Then goes through two filtering of
        small regions and one merging of the overlapping area.
        Returns the resulting coordinates of the rectangles (tissue
        lying images)

        Args:
            data    (hdf5)          hdf5 image of SVS data

        Returns:
            List<DeepPhiDataset>: list of DeepPhiDatasets composing all
                                  merged and large enough rectangles will be
                                  returned.

        """
        # Open Whole-Slide Image and get the smallest dimension image.
        # path_to_wsi = data
        # ops_img = ops.open_slide(path_to_wsi)

        # ops_img = data['header']['ops']
        # levels = len(ops_img.level_dimensions)
        # max_dim = ops_img.dimensions
        # min_dim = ops_img.level_dimensions[levels - 1]
        # img = ops_img.read_region((0, 0), levels - 1, min_dim).convert('RGB')
        img = self.get_image_array()

        # Get the coordinates which represents the smallest rectangle that
        # contains tissues
        coords_list = self.crop_out_coordinates(img)
        crop_img_list = []

        # Iterate through the coordinates
        for i, (x, y, w, h) in enumerate(coords_list):
            # Since the image is too big, sometimes it causes Exceptions related
            # to memory issues.
            # Iterate through from the biggest dimension, and if it causes
            # exception, try the next level.
            for j in range(levels - 1):
                try:
                    current_dim = ops_img.level_dimensions[j + 1]
                    location = self.convert_to_max_location(max_dim, min_dim,
                                                            (x, y, w, h))
                    size = self.convert_to_current_size(current_dim, min_dim,
                                                        (x, y, w, h))
                    crop_img_list.append(
                        ops_img.read_region(location, j + 1, size).convert(
                            'RGB'))
                    break
                except Exception as e:
                    print("function crop_out caused " + str(e))
                gc.collect()

        return crop_img_list, self.processed

    @timeit
    def create_tissue_mask(self, image):
        self.processed.append('create_tissue_mask')

        img_color = np.asarray(image)

        # Convert RGB to HSV and apply color filtering to get the pixels
        # which displays purple- to pink-ish color.
        hsv_image = cv2.cvtColor(img_color, cv2.COLOR_RGB2HSV)
        mask = cv2.inRange(hsv_image, cfg.LOWER_RGB_THRESHOLD,
                           cfg.UPPER_RGB_THRESHOLD)

        # Apply CLAHE
        img_clahe = cfg.CLAHE.apply(mask)

        # Apply Dilation to smooth out the mask region and find rectangle
        # that contains these mask images.
        _, img_th = cv2.threshold(img_clahe, 50, 255, 0)
        img_dilate = cv2.dilate(img_th, np.array(
            [1] * int(math.pow(cfg.DILATION_INTENSITY, 2)))
                                .reshape(cfg.DILATION_INTENSITY,
                                         cfg.DILATION_INTENSITY))
        return img_dilate

    @timeit
    def rect_intersects(self, rect1, rect2, flexible_space):
        """ Function to see if the two input rectangle coordinates overlap.
        Since the tissues can be considered as one portion even without overlapping,
        flexible_space is considered to give a slight boundary to each rectangle.

        Args:
            rect1 ((int, int, int, int)): tuple coordinates for the 1st rectangle each represents left, upper, right, lower
            rect2 ((int, int, int, int)): tuple coordinates for the 2nd rectangle each represents left, upper, right, lower
            flexible_space (int): extra length to each coordinate as a border

        Returns:
            Bool: True if there is an overlapping area,
                  False if there is none.

        Example:
            > > > rect_intersects((0, 0, 350, 350), (100, 100, 200, 200), 100)
            True
        """

        self.processed.append('rect_intersects')

        x1, y1, w1, h1 = rect1[0]-flexible_space, \
                         rect1[1]-flexible_space, \
                         rect1[2]+flexible_space, \
                         rect1[3]+flexible_space

        x2, y2, w2, h2 = rect2[0]-flexible_space, \
                         rect2[1]-flexible_space, \
                         rect2[2]+flexible_space, \
                         rect2[3]+flexible_space

        if ((x1 <= x2) and ((x1+w1) >= x2)) and ((y1 <= y2) and ((y1+h1) >= y2)):
            return True
        elif ((x1+w1) >= (x2+w2)) and (x1 <= (x2+w2)) and (y1 <= y2) and ((y1+h1) >= y2):
            return True
        elif (x1 <= x2) and ((x1+w1) >= x2) and ((y1+h1) >= (y2+h2)) and ((y2+h2) >= y1):
            return True
        elif (x1 <= (x2 + w2)) and ((x2+w2) <= (x1+w1)) and (y1 <= (y2+h2)) and ((y2+h2) <= (y1+h1)):
            return True
        elif (x1 <= x2) and (x2 <= (x1+w1)) and ((x2+w2) <= (x1+w1)) \
                and (y1 <= y2) and (y2 <= (y2+h2)) and ((y2+h2) <= (y1+h1)):
            return True
        elif (x2 <= x1) and (x1 <= (x2+w2)) and ((x1+w1) <= (x2+w2)) \
                and (y2 <= y1) and (y1 <= (y1+h1)) and ((y1+h1) <= (y2+h2)):
            return True
        elif ((x1 <= x2 < (x2+w2) <= (x1+w1)) and (y2 <= y1 <= (y2+h2))) or \
                ((x2 <= x1 <= (x1+w1) <= (x2+w2)) and (y1 <= y2 <= (y1+h1))):
            return True
        elif ((x1 <= x2 <= (x1+w1) <= (x2 + w2)) and (y1 <= y2 <= (y2+h2) <= (y1+h1))) or \
                ((x2 <= x1 <= (x2+w2) <= (x1 + w1)) and (y2 <= y1 <= (y1+h1) <= (y2+h2))):
            return True
        elif (x1 <= x2 <= (x2+w2) <= (x1+w1) and (y1 <= y2 <= (y1+h1) <= (y2+h2))) or \
                (x2 <= x1 <= (x1+w1) <= (x2+w2) and (y2 <= y1 <= (y2+h2) <= (y1+h1))):
            return True
        elif ((x2 <= x1 <= (x2+w2) <= (x1+w1)) and (y1 <= y2 <= (y2+h2) <= (y1+h1))) or \
                ((x1 <= x2 <= (x1+w1) <= (x2+w2)) and (y2 <= y1 <= (y1+h1) <= (y2+h2))):
            return True
        else:
            return False

    @timeit
    def merge_overlapping_areas(self, rect_lst):
        """ Takes list of coordinates of rectangles, checks if there is any overlapping regions.
        If there are overlapping regions, merge them, else pass.

        Args:
            rect_lst (list<(int, int, int, int)>): List of rectangle coordinates

        Returns:
            list<(int, int, int, int)>: all overlapping rectangles are merged and the 'straightened' list will be returned.

        Example:
            > > > merge_overlapping_areas([(0, 0, 350, 350), (100, 100, 200, 200), (2000,2000,4000,4000)])
            [(0, 0, 350, 350), (2000,2000,4000,4000)]
        """
        any_rect_merged = True
        # When there is any change in the rectangle list, start over the loop process.
        while any_rect_merged:
            any_rect_merged = False
            for i, (x1, y1, w1, h1) in enumerate(rect_lst):
                for j, (x2, y2, w2, h2) in enumerate(rect_lst[1:]):

                    if i-1 == j:
                        continue

                    # Compare the tuples and see if there is any overlapping areas.
                    # If the two subject rectangles overlap, remove both of the corresponding coordinates and append the
                    # bigger coordinates which results from merging them.
                    if self.rect_intersects((x1, y1, w1, h1), (x2, y2, w2, h2),
                                        100):
                        any_rect_merged = True
                        rect_lst.remove((x1, y1, w1, h1))
                        rect_lst.remove((x2, y2, w2, h2))

                        # In terms of x-axis
                        if x1 < x2:
                            x = x1
                        else:
                            x = x2
                        if (x1 + w1) > (x2 + w2):
                            w = (x1 + w1) - x
                        else:
                            w = (x2 + w2) - x

                        # In terms of y-axis
                        if y1 < y2:
                            y = y1
                        else:
                            y = y2
                        if (y1 + h1) > (y2 + h2):
                            h = (y1 + h1) - y
                        else:
                            h = (y2 + h2) - y

                        rect_lst.append((x, y, w, h))
                        break
                if any_rect_merged:
                    break

        return rect_lst

    @timeit
    def convert_to_max_location(self, orig_size, reduced_size, coords):
        """ convert the location of the left upper corner of the rectangle to the max dimension of the WSI.

        Args:
            orig_size ((int,int)): size of the original raw WSI
            reduced_size ((int,int)): size of the lowest resolution WSI
            coords (tuple(int, int, int, int)): tuple of coordinates of the rectangle (left, right, width, height)

        Returns:
            tuple (int, int): tuple of the converted location (x,y)

        Example:
            > > > convert_to_max_location(40000,20000,(100,100,200,200))
            (200,200)
        """

        self.processed.append('convert_to_max_location')

        x_ratio = orig_size[0] / reduced_size[0]
        y_ratio = orig_size[1] / reduced_size[1]

        new_x = int(np.math.floor(coords[0] * x_ratio))
        new_y = int(math.floor(coords[1]*y_ratio))

        return new_x, new_y

    @timeit
    def convert_to_current_size(self, crrnt_size, reduced_size, coords):
        """ convert the size of the rectangle to the ratio of max dimension of the WSI.

        Args:
            crrnt_size ((int,int)): size of the current level of WSI
            reduced_size ((int,int)): size of the lowest resolution WSI
            coords (tuple(int, int, int, int)): tuple of coordinates of the rectangle (left, right, width, height)

        Returns:
            tuple (int, int): tuple of the size of the rectangle (w,h)

        Example:
            > > > convert_to_current_size(40000,20000,(100,100,200,200))
            (400,400)
        """

        self.processed.append('convert_to_current_size')

        x_ratio = crrnt_size[0] / reduced_size[0]
        y_ratio = crrnt_size[1] / reduced_size[1]

        new_w = int(math.ceil(coords[2] * x_ratio))
        new_h = int(math.ceil(coords[3] * y_ratio))

        return new_w, new_h

    @timeit
    def crop_out_coordinates(self, image):
        """ Takes a lower resolution level of the Whole-slide Image (WSI). Uses color filtering, clahe, and dilation to find
        contour of tissue existence. Then goes through two filtering of small regions and one merging of the overlapping
        area. Returns the resulting coordinates of the rectangles (tissue lying images)

        Args:
            image (PIL.Image): lowest resolution level of WSI.

        Returns:
            list<(int, int, int, int)>: all merged and large enough rectangle's coordinates list will be returned.

        Example:
            > > > crop_out_coordinates(low_wsi)
            [(0, 0, 350, 350), (2000,2000,4000,4000)]

        """
        tissue_mask = self.create_tissue_mask(image)
        cnts, _ = cv2.findContours(tissue_mask.astype(np.uint8), 0, 2)

        # Filter out the small images and merge them if overlapping.
        large_cnts = [cnt for cnt in cnts if cv2.contourArea(cnt) >= 1500]
        rect = [cv2.boundingRect(cnt) for cnt in large_cnts]
        rect = self.merge_overlapping_areas(rect)

        # Once again, filter out the small images.
        if len(rect) != 0:
            small_threshold = max([w * h for x, y, w, h in rect]) / 6
            rect = [(x, y, w, h) for x, y, w, h in rect if (w * h) > small_threshold]

        return rect


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, LOCAL_DATA
    """
    Example Usage Code
    Explanation:
        Both Source and Target images can be fed in in 3 different forms:
            Case 1: (str) path to the image
            Case 2: (numpy.array) array representation of the image.
            Case 3: (PIL.Image) actual image.
    """
    hdf5_image = test_prep(LOCAL_DATA, log=True)

    crop_out = CropOut()

    co_list, processed = crop_out(data=hdf5_image)
    # co_list, processed = crop_out(data=c.SAMPLE_SVS)

    # hdf5_image['array'] = co_list
    # ip_history = hdf5_image['header']['ImageProcessing']
    #
    # if ip_history is None:
    #     hdf5_image['header']['ImageProcessing'] = processed
    # else:
    #     hdf5_image['header']['ImageProcessing'] \
    #         = tuple(list(hdf5_image['header']['ImageProcessing']) + processed)

    for i, co_img in enumerate(co_list):
        co_img.save('/home/hslisalee/DEEPPHI/image_processing/output/'
                    'computational_anatomy/crop_out/'
                    + str(i)
                    + '.png')
