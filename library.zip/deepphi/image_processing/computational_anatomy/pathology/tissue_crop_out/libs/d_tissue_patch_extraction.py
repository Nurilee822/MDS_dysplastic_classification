#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

#     crop_img_list = self.iterate_through_rects(coords_list=coords_list,
#                                                ops_data=ops_data)
#
#     # update info
#
#     hdf5_co_tissues['array'] = crop_img_list
#
#     # save output
#     if save_path is not None:
#         for i, co_img in enumerate(crop_img_list):
#             co_img = Image.fromarray(co_img)
#             co_img.save(save_path
#                         + '/'
#                         + data['header']['filename']
#                         + str(i)
#                         + '.png')
#
#     return hdf5_co_tissues
#
#
# @timeit
# def iterate_through_rects(self, coords_list, ops_data):
#     """Iterate through the coordinates in rect_list
#
#     Args:
#         coords_list     (list)      list of coordinates in rects
#         ops_data        (dict)      dict of openslide data in hdf5_image
#
#     Returns:
#         crop_img_list   (list)    list of cropped tissues
#
#     """
#     self.applied_processes.append('iterate_through_rects')
#
#     crop_img_list = []
#
#     ops_img = ops_data['ops']
#     levels = ops_data['levels']
#     max_dim = ops_data['dimensions'][0]
#     min_dim = ops_data['dimensions'][-1]
#
#     # Iterate through the coordinates
#     c_res_level = ConvertResolutionLevel()
#
#     for i, (x, y, w, h) in enumerate(coords_list):
#
#         # Since the image is too big, sometimes it causes Exceptions
#         # related to memory issues.
#
#         # Iterate through from the biggest dimension,
#         # and if it causes exception, try the next level.
#
#         for j in range(levels - 1):
#             try:
#                 current_dim = ops_img.level_dimensions[j + 1]
#                 location = c_res_level.convert_to_max_location(max_dim,
#                                                                min_dim,
#                                                                (x, y, w, h)
#                                                                )
#                 size = c_res_level.convert_to_current_size(current_dim,
#                                                            min_dim,
#                                                            (x, y, w, h)
#                                                            )
#                 crop_img_list.append(np.asarray(ops_img
#                                                 .read_region(location,
#                                                              j + 1,
#                                                              size)
#                                                 .convert('RGB')
#                                                 )
#                                      .astype(np.uint8)
#                                      )
#                 break
#
#             except Exception as e:
#                 print("Exception | function 'iterate_through_rects' "
#                       "caused :: " + str(e))
#
#             gc.collect()
#
#     return crop_img_list
