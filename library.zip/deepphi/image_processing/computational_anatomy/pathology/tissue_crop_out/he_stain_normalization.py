#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing.color_processing.color_normalization\
    .vahadane_stain_normalizer import VahadaneStainNormalizer


class HEStainNormalization(VahadaneStainNormalizer):
    def __init__(self, *args, **kwargs):
        super(HEStainNormalization, self).__init__(self, *args, **kwargs)


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display

    IMAGE, ARRAY = 'image', 'array'
    DATA = '../../../data/1035154_lv2.hdf5'
    TARGET_DATA = '../../../data/1035155_lv2.hdf5'

    hdf5_target = test_prep(TARGET_DATA)
    target_img = hdf5_target[IMAGE][ARRAY]

    MODULE_NAME = 'StainColorNormalization'
    MODULE_ID = '1234'
    color_norm = HEStainNormalization(module_name=MODULE_NAME,
                                      module_id=MODULE_ID,
                                      target_data=TARGET_DATA)

    hdf5_source = test_prep(DATA, log=True)
    source_img = hdf5_source[IMAGE][ARRAY]

    hdf5_output = color_norm(hdf5_source)
    output_img = hdf5_output[IMAGE][ARRAY]

    display(target_img, add_to_title='target image')
    display(source_img, add_to_title='source image(before normalization)')
    display(output_img, add_to_title='source image(Vahadane normalization '
                                     'applied)')