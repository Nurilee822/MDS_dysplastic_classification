#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
from xml.dom import minidom
import gc
from PIL import Image, ImageDraw, ImageChops
import openslide as ops
import numpy as np
import cv2
import math
from deepphi.image_processing.config.pathology_ import *


def create_tissue_mask(image):
    img_color = np.asarray(image)

    # Convert RGB to HSV and apply color filtering to get the pixels
    # which displays purple- to pink-ish color.
    hsv_image = cv2.cvtColor(img_color, cv2.COLOR_RGB2HSV)
    mask = cv2.inRange(hsv_image, LOWER_RGB_THRESHOLD,
                       UPPER_RGB_THRESHOLD)

    # Apply CLAHE
    img_clahe = CLAHE.apply(mask)

    # Apply Dilation to smooth out the mask region and find rectangle
    # that contains these mask images.
    _, img_th = cv2.threshold(img_clahe, 50, 255, 0)
    img_dilate = cv2.dilate(img_th, np.array(
        [1] * int(math.pow(DILATION_INTENSITY, 2)))
                            .reshape(DILATION_INTENSITY,
                                     DILATION_INTENSITY))
    return img_dilate


def patch_extraction(image, patch_size, overlap):
    """ Extract patch from the cropped image in the size of
    (height_and_width, height_and_width).

    Args:
        image (PIL.Image): image to be splitted.
        patch_size (int): length of both height and width to be
                                splitted.
        overlap (int): overlapping length.

    Returns:
        List<PIL.Image>: List of extracted patch images

    Example:
        > > > patch_extraction(cropped_image, 1024, 512)
        List<PIL.Image>
    """

    returning_patch_image = []
    returning_coords_list = []
    crrnt_img_height, crrnt_img_width = shape(image)[:2]

    if (shape(image)[0] <= patch_size) \
            and (shape(image)[1] <= patch_size):
        returning_patch_image.append(resizing_image(image,
                                                    patch_size))
        return returning_patch_image
    else:
        w_iteration = int(math.ceil((shape(image)[1] - overlap)
                                    / (patch_size - overlap)))
        h_iteration = int(math.ceil((shape(image)[0] - overlap)
                                    / (patch_size - overlap)))
        for i in range(w_iteration):
            if i == (w_iteration - 1):
                left, right = shape(image)[1] - patch_size, \
                              shape(image)[1]
            else:
                left = ((patch_size - overlap) * i)
                right = left + patch_size
            for j in range(h_iteration):
                if j == (h_iteration - 1):
                    top, bottom = shape(image)[0] - patch_size, \
                                  shape(image)[0]
                else:
                    top = ((patch_size - overlap) * j)
                    bottom = top + patch_size
                if right > crrnt_img_width:
                    print("Current Width is " + str(crrnt_img_width)
                          + " but it exceeded with " + str(right))
                if bottom > crrnt_img_height:
                    print("Current Height is " + str(crrnt_img_height)
                          + " but it exceeded with " + str(bottom))
                patch_coords = (left, top, right, bottom)

                returning_patch_image.append(image.crop(patch_coords))
                returning_coords_list.append(patch_coords)

                gc.collect()

    return returning_patch_image, returning_coords_list


def resizing_image(source_image, height_and_width):
    """ Applies image resizing with the size of the given length on an
    image \and returns the re-sized image with fixed size.

    Args:
        source_image (image): numpy array of the image
        height_and_width (int): length of both height and width
                                     to be re-sized

    Returns:
        (numpy.ndarray): numpy representation of re-sized image in size of
                        (height_and_width, height_and_width)

    Example:
        > > > image = cv2.imread('1035642_.svs')
        > > > resizing_image(image, 1024)
        (numpy.ndarray)
    """

    try:
        if not isinstance(source_image, np.ndarray):
            source_image = np.asarray(source_image)

        if source_image.shape == (height_and_width,
                                  height_and_width):
            return source_image

        old_size = source_image.shape[:2]
        ratio = float(height_and_width) / max(old_size)
        new_size = tuple([int(x * ratio) for x in old_size])

        im = cv2.resize(source_image, (new_size[1], new_size[0]))
        delta_w = height_and_width - new_size[1]
        delta_h = height_and_width - new_size[0]
        top, bottom = delta_h // 2, delta_h - (delta_h // 2)
        left, right = delta_w // 2, delta_w - (delta_w // 2)

        return cv2.copyMakeBorder(im, top, bottom, left, right,
                                  cv2.BORDER_CONSTANT, value=COLOR_RGB)
    except Exception as error:
        raise Exception("Exception occurred while resizing the image: " + str(error))


def merge_overlapping_areas(rect_lst):
    """ Takes list of coordinates of rectangles, checks if there is any overlapping regions.
    If there are overlapping regions, merge them, else pass.

    Args:
        rect_lst (list<(int, int, int, int)>): List of rectangle coordinates

    Returns:
        list<(int, int, int, int)>: all overlapping rectangles are merged and the 'straightened' list will be returned.

    Example:
        > > > merge_overlapping_areas([(0, 0, 350, 350), (100, 100, 200, 200), (2000,2000,4000,4000)])
        [(0, 0, 350, 350), (2000,2000,4000,4000)]
    """
    any_rect_merged = True
    # When there is any change in the rectangle list, start over the loop process.
    while any_rect_merged:
        any_rect_merged = False
        for i, (x1, y1, w1, h1) in enumerate(rect_lst):
            for j, (x2, y2, w2, h2) in enumerate(rect_lst[1:]):

                if i - 1 == j:
                    continue

                # Compare the tuples and see if there is any overlapping areas.
                # If the two subject rectangles overlap, remove both of the corresponding coordinates and append the
                # bigger coordinates which results from merging them.
                if rect_intersects((x1, y1, w1, h1), (x2, y2, w2, h2), 100):
                    any_rect_merged = True
                    rect_lst.remove((x1, y1, w1, h1))
                    rect_lst.remove((x2, y2, w2, h2))

                    # In terms of x-axis
                    if x1 < x2:
                        x = x1
                    else:
                        x = x2
                    if (x1 + w1) > (x2 + w2):
                        w = (x1 + w1) - x
                    else:
                        w = (x2 + w2) - x

                    # In terms of y-axis
                    if y1 < y2:
                        y = y1
                    else:
                        y = y2
                    if (y1 + h1) > (y2 + h2):
                        h = (y1 + h1) - y
                    else:
                        h = (y2 + h2) - y

                    rect_lst.append((x, y, w, h))
                    break
            if any_rect_merged:
                break

    return rect_lst

def rect_intersects(rect1, rect2, flexible_space):
    """ Function to see if the two input rectangle coordinates overlap.
    Since the tissues can be considered as one portion even without overlapping,
    flexible_space is considered to give a slight boundary to each rectangle.

    Args:
        rect1 ((int, int, int, int)): tuple coordinates for the 1st rectangle each represents left, upper, right, lower
        rect2 ((int, int, int, int)): tuple coordinates for the 2nd rectangle each represents left, upper, right, lower
        flexible_space (int): extra length to each coordinate as a border

    Returns:
        Bool: True if there is an overlapping area,
              False if there is none.

    Example:
        > > > rect_intersects((0, 0, 350, 350), (100, 100, 200, 200), 100)
        True
    """

    x1, y1, w1, h1 = rect1[0]-flexible_space, \
                     rect1[1]-flexible_space, \
                     rect1[2]+flexible_space, \
                     rect1[3]+flexible_space

    x2, y2, w2, h2 = rect2[0]-flexible_space, \
                     rect2[1]-flexible_space, \
                     rect2[2]+flexible_space, \
                     rect2[3]+flexible_space

    if ((x1 <= x2) and ((x1+w1) >= x2)) and ((y1 <= y2) and ((y1+h1) >= y2)):
        return True
    elif ((x1+w1) >= (x2+w2)) and (x1 <= (x2+w2)) and (y1 <= y2) and ((y1+h1) >= y2):
        return True
    elif (x1 <= x2) and ((x1+w1) >= x2) and ((y1+h1) >= (y2+h2)) and ((y2+h2) >= y1):
        return True
    elif (x1 <= (x2 + w2)) and ((x2+w2) <= (x1+w1)) and (y1 <= (y2+h2)) and ((y2+h2) <= (y1+h1)):
        return True
    elif (x1 <= x2) and (x2 <= (x1+w1)) and ((x2+w2) <= (x1+w1)) \
            and (y1 <= y2) and (y2 <= (y2+h2)) and ((y2+h2) <= (y1+h1)):
        return True
    elif (x2 <= x1) and (x1 <= (x2+w2)) and ((x1+w1) <= (x2+w2)) \
            and (y2 <= y1) and (y1 <= (y1+h1)) and ((y1+h1) <= (y2+h2)):
        return True
    elif ((x1 <= x2 < (x2+w2) <= (x1+w1)) and (y2 <= y1 <= (y2+h2))) or \
            ((x2 <= x1 <= (x1+w1) <= (x2+w2)) and (y1 <= y2 <= (y1+h1))):
        return True
    elif ((x1 <= x2 <= (x1+w1) <= (x2 + w2)) and (y1 <= y2 <= (y2+h2) <= (y1+h1))) or \
            ((x2 <= x1 <= (x2+w2) <= (x1 + w1)) and (y2 <= y1 <= (y1+h1) <= (y2+h2))):
        return True
    elif (x1 <= x2 <= (x2+w2) <= (x1+w1) and (y1 <= y2 <= (y1+h1) <= (y2+h2))) or \
            (x2 <= x1 <= (x1+w1) <= (x2+w2) and (y2 <= y1 <= (y2+h2) <= (y1+h1))):
        return True
    elif ((x2 <= x1 <= (x2+w2) <= (x1+w1)) and (y1 <= y2 <= (y2+h2) <= (y1+h1))) or \
            ((x1 <= x2 <= (x1+w1) <= (x2+w2)) and (y2 <= y1 <= (y1+h1) <= (y2+h2))):
        return True
    else:
        return False


def parse_xml(xml_file_path):
    """ read xml file and return a parsed object from it

    Args:
        xml_file_path (str): path to the xml file

    Returns:
        parsed object from the xml file

    Example:
        > > > parse_xml('1035134_.xml')
        <parsed object>
    """
    xml_content = open(xml_file_path, 'r')
    xml_doc = minidom.parse(xml_content)
    xml_content.close()
    return xml_doc


def create_mask_from_xml(xml_file, wsi_dimension, save, save_dir=None):
    """ Takes the xml object, parse, get annotation information for each class.
    When new class is detected, new label mask image is created for the information to be drawn.
    Through this function, there will be n-number, number of classes in the xml file, plus an additional
    mask image that represents all the classes, as a total mask image. Will return a tuple of lists,
    one with names of the classes, and the other with mask images of the classes.

    Args:
        xml_file (str): path to the xml file
        wsi_dimension ((int, int)): dimension for the new masks to be created. Same with the dimension of the WSI.
        save (bool): toggle for debugging mode. If true, will save resulting mask images
        save_dir(str): if save is true, give a directory path to locate where to save the resulting images.

    Returns:
        List<str>: list of names of the classes with last class 'TOTAL'
        List<PIL.Image>: list of mask images of the classes with las class 'TOTAL' mask image

    Example:
        > > > create_mask_from_xml('1035134_.xml', (10234, 4547))
        (List<str>, List<PIL.Image>)
    """
    height, width = wsi_dimension
    parsed_xml = parse_xml(xml_file)
    cls_lst = []
    cls_img_lst = []
    total_img = Image.new('L', (height, width), 0)
    for i, annotation in enumerate(parsed_xml.getElementsByTagName('Annotation')):
        cls = annotation.getAttribute('class')
        if not (cls in cls_lst):
            cls_lst.append(cls)
            cls_img_lst.append(Image.new('L', (height, width), 0))
        for coordinates in annotation.childNodes:
            list_of_coordinates = []
            if isinstance(coordinates, minidom.Text):
                continue
            if coordinates.tagName == 'Coordinates':
                for coordinate in coordinates.childNodes:
                    if isinstance(coordinate, minidom.Element):
                        if coordinate.tagName == 'Coordinate':
                            x = float(coordinate.getAttribute('x'))
                            y = float(coordinate.getAttribute('y'))
                            list_of_coordinates.append((x, y))
            idx = cls_lst.index(cls)
            if len(list_of_coordinates) != 0:
                ImageDraw.Draw(cls_img_lst[idx]).polygon(list_of_coordinates, outline=1, fill='green')
                ImageDraw.Draw(total_img).polygon(list_of_coordinates, outline=1, fill=COLORS[idx])
            gc.collect()
    cls_img_lst.append(total_img)
    cls_lst.append('TOTAL')
    if save:
        for name, img in zip(cls_lst, cls_img_lst):
            img.save(os.path.join(save_dir, name[:-4] + name + 'png'))
    return cls_lst, cls_img_lst


def filter_only_needed_classes(class_names, class_masks, class_names_to_filter):
    """ From the label mask, filters the mask image to result with only the selected classes, which
    is passed in as a parameter.

    Args:
        class_names (List<str>): Names of classes that are in the label file (or xml file).
        class_masks (List<PIL.Image>): List of images of the mask image that has been created from the label file.
        class_names_to_filter (List<str>): list of classes that will be kept in the final mask image.

    Returns:
        PIL.Image: Mask image with only the selected classes.

    Example:
        > > > filter_only_needed_classes(['ACI', 'TAL', 'TOTAL'], mask_images, ['ADENOCA', 'CARCINOID'])
        <PIL.Image>
    """
    subtract_img = class_masks.pop(-1)
    class_names.pop(-1)
    for cls in class_names_to_filter:
        if cls in class_names:
            idx = class_names.index(cls)
            del class_names[idx], class_masks[idx]
    for cls_img in class_masks:
        subtract_img = ImageChops.subtract(subtract_img, cls_img)
    return subtract_img


def get_overlapping_regions_only(label_mask, wsi_img):
    """ Creates a tissue mask, and compute a overlapping mask image which both the tissue and the label exists
    in both of them.

    Args:
        label_mask (PIL.Image): Label image.
        wsi_img (PIL.Image): Tissue image.

    Returns:
        np.array: Mask image that results from the AND operation of label mask and tissue mask images.

    Example:
        > > > get_overlapping_regions_only(label_mask, tissue_mask)
        <np.array>
    """
    tissue_mask = np.asarray(create_tissue_mask(wsi_img))
    if not isinstance(label_mask, np.ndarray):
        label_mask = label_mask.resize((tissue_mask.shape[1], tissue_mask.shape[0]))
        label_mask = np.asarray(label_mask)
    return cv2.bitwise_and(tissue_mask, tissue_mask, mask=label_mask)


def get_overall_bbox(coords):
    """ Computes a coordinate of a bounding box, which will include all the bounding box coordinates that is passed in.

    Args:
        coords (List<(int, int, int, int)>): List of bbox coordinates

    Returns:
        (int, int, int, int): Coordinate which includes all the bounding boxes

    Example:
        > > > get_overall_bbox([(0, 0, 10000, 10000), (300, 300, 20000, 20000])
        (0, 0, 20000, 20000)
    """
    _x_1, _y_1, _x_2, _y_2 = 100000000, 100000000, 0, 0
    for _r in coords:
        _x, _y, _w, _h = _r
        if _x < _x_1:
            _x_1 = _x
        if _y < _y_1:
            _y_1 = _y
        if (_x + _w) > _x_2:
            _x_2 = _x + _w
        if (_y + _h) > _y_2:
            _y_2 = _y + _h
    return _x_1, _y_1, _x_2, _y_2


def get_bbox_coordinate(mask_image):
    """ Gets the coordinate of the bounding box that will contain all the parts of the overall overlapping,
    tissue and label mask image.

    Args:
        mask_image (np.array): mask image which results from the overlapping of the label and the tissue mask image.

    Returns:
        (int, int, int, int): Coordinate which includes all the bounding boxes

    Example:
        > > > get_bbox_coordinate(overall_mask_img)
        (0, 0, 20000, 20000)
    """
    # Get Bounding Box information of the tissue in the mask image.
    ret, thresh = cv2.threshold(mask_image, 64, 128, 0)
    cnts, _ = cv2.findContours(thresh, 1, 2)
    rect = [cv2.boundingRect(cnt) for cnt in cnts]
    rect = merge_overlapping_areas(rect)
    _x1, _y1, _x2, _y2 = get_overall_bbox(rect)
    return _x1, _y1, _x2, _y2


def crop_existing_tissue_label_mask(total_mask, label_mask, tissue_mask):
    """ Gets the coordinate of the bounding box that contains the overlapping regions of the tissue and label mask image.
    it crops out the background region.

    Args:
        total_mask (PIL.Image): label mask image that contains all the classes.
        label_mask (np.array): label mask image that contains only the requested classes.
        tissue_mask (PIL.Image): tissue image

    Returns:
        <np.array>, <PIL.Image>: label mask image that has been cropped, tissue image that has been cropped.

    Example:
        > > > crop_existing_tissue_label_mask(ttl_mask, lbl_mask, tss_mask)
        <np.array>, <PIL.Image>
    """
    # total_mask = Image.fromarray(total_mask)
    tissue_mask = Image.fromarray(tissue_mask)

    total_mask = total_mask.resize((shape(label_mask)[1], shape(label_mask)[0]))
    total_mask = np.asarray(total_mask)
    x1, y1, x2, y2 = get_bbox_coordinate(total_mask)

    returning_label_mask = label_mask[y1:y2, x1:x2]
    returning_tissue_mask = tissue_mask.crop((x1, y1, x2, y2))
    return returning_label_mask, returning_tissue_mask


def patch_extract_mask_and_tissue(mask_img, tissue_img, height_and_width, overlap):
    """ Extracts patch images from the cropped label mask image and the tissue image.
    The size and the overlapping length can be passed in as a value.

    Args:
        mask_img (np.array): label mask image.
        tissue_img (PIL.Image): tissue image.
        height_and_width (int): length for both sides of the patch.
        overlap (int): length for the overlapping length. (both vertical and horizontal

    Returns:
        List<PIL.Image>, List<PIL.Image>: two lists of images which both contains patch extracted images,
        one from the label, and the other from the tissue image.

    Example:
        > > > patch_extract_mask_and_tissue(mask_img, tissue_img, 512, 256)
        <PIL.Image>, <PIL.Image>
    """
    lst1, coords_list = patch_extraction(Image.fromarray(mask_img),
                                         height_and_width,
                                         overlap)
    lst2, coords_list = patch_extraction(tissue_img,
                                         height_and_width,
                                         overlap)
    return lst1, lst2, coords_list


def seg_prep_main(xml_path, wsi_path, clss_to_include, patch_lengths, overlap):
    """ Main function for segmentation data pre-processing. Takes xml and wsi path to the same tissue file. Takes the
    name of the classes that the final mask image will contain. Lastly takes length of the patch and overlap value for
    the size and iteration number for the patch extraction.

    Args:
        xml_path (str): path to the xml file
        wsi_path (str): path to the wsi file
        clss_to_include (List<str>): names of the classes that will be ending up in the final mask image.
        patch_lengths (int): both lengths of the patches.
        overlap (int): overlap length for both horizontal and vertical.

    Returns:
        List<PIL.Image>, List<PIL.Image>: two lists of images which both contains patch extracted images,
        one from the label, and the other from the tissue image.

    Example:
        > > > seg_prep_main(path_to_xml, path_to_wsi, ['ACI'], 512, 256)
        <PIL.Image>, <PIL.Image>
    """
    # Open WSI file and extract useful information (size of each level)
    ops_img = ops.open_slide(wsi_path)
    big_dim = ops_img.level_dimensions[0]
    next_dim = ops_img.level_dimensions[1]
    wsi_img = ops_img.read_region((0, 0), 1, next_dim).convert('RGB')

    # Create mask image from the xml file.
    # Individual classes in the xml file will be created with additional of TOTAL mask image.
    class_name_list, class_mask_list = create_mask_from_xml(xml_path, big_dim, False)

    # extracting only the desired class mask images and combine them into one single mask image.
    abnormal_mask = filter_only_needed_classes(class_name_list, class_mask_list, clss_to_include)

    # In case the labeling is showing a poor quality, compare the label mask image and
    # tissue mask image to, at least, get the label regions on the tissue territory and eliminate outside of the area.
    overlap_mask = get_overlapping_regions_only(abnormal_mask, wsi_img)

    # Since the background portion is too big, need to extract the ROI (region of interest) to
    # fast-forward and improve the quality of the process of training, and pre-processing.
    label_mask, wsi_img = crop_existing_tissue_label_mask(class_mask_list[-1], overlap_mask, wsi_img)

    # Finally, extract patches from both tissue and label mask images.
    mask_patch_list, wsi_patch_list = patch_extract_mask_and_tissue(label_mask, wsi_img, patch_lengths, overlap)
    return mask_patch_list, wsi_patch_list
