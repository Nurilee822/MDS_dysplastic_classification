#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

from deepphi.image_processing.computational_anatomy.pathology.utils import *
from deepphi.image_processing import Preprocessing

NAME = 'module_name'
DTYPE_UINT8 = np.uint8
COLOR_MODE = 'B'


class CreateMaskXml(Preprocessing):
    def __init__(self, *args, **kwargs):
        super(CreateMaskXml, self).__init__(self)
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.xml_path = kwargs['xml_path']
        self.class_to_include = kwargs['class_to_include']
        self.class_name_list = []
        self.this_module = __class__.__name__

    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('module name: \t\t\t\t{}'.format(self.this_module))
        self.log.debug('existing classes: \t\t\t{}'.format(
            self.class_name_list))
        self.log.debug('class to include in mask: \t{}'.format(
            self.class_to_include))
        self.log.debug('output color mode:\t\t\t{}'.format(self.get_color_mode()))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check xml data exists
        """

        # Empty_Check
        if not os.path.exists(self.xml_path):
            raise Exception("XML file does not exist. Please provide proper "
                            "path to xml file.")

    def image_processing(self, source_image, param):
        """create tissue mask image from the source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Create_Tissue_Mask
            output_img = self.create_mask_xml(source_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)
            self.add_color_mode(COLOR_MODE)
            self.add_class(self.class_to_include)

        except Exception as error:
            raise Exception("Exception occurred while processing:" + str(error))

    def create_mask_xml(self, source_image):
        """ Main function for segmentation data pre-processing.
        Takes xml and wsi path to the same tissue file. Takes the
        name of the classes that the final mask image will contain.
        Lastly takes length of the patch and overlap value for
        the size and iteration number for the patch extraction.

        Args:

            source_image (ndarray): whole slide image to perform patch extraction

        Vars:
            self.xml_path (str): path to the xml file
            self.class_to_include (List<str>): names of the classes that will be
                                               ending up in the final mask
                                               image.
            self.patch_lengths (int): both lengths of the patches.
            self.overlap (int): overlap length for both horizontal and vertical.

        Returns:
            List<PIL.Image>: list of images which contains patch extracted
            images from the label.

        """

        # Open WSI file and extract useful information (size of each level)
        # Create mask image from the xml file.
        # Individual classes in the xml file will be created with additional of
        # TOTAL mask image.

        data = self.get_data()
        max_dim = data['header']['dimensions'][0]
        class_name_list, class_mask_list = create_mask_from_xml(self.xml_path,
                                                                max_dim,
                                                                False)
        self.class_name_list = class_name_list[:-1]

        # extracting only the desired class mask images and combine them into
        # one single mask image.
        abnormal_mask = filter_only_needed_classes(class_name_list,
                                                   class_mask_list,
                                                   self.class_to_include)

        # In case the labeling is showing a poor quality,
        # compare the label mask image and tissue mask image to, at least,
        # get the label regions on the tissue territory and eliminate outside
        # of the area.

        # overlap_mask = get_overlapping_regions_only(abnormal_mask,
        #                                             source_image)
        #
        # return overlap_mask

        abnormal_mask = np.array(abnormal_mask)
        return abnormal_mask / abnormal_mask.max() * 255


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, LOCAL_DATA

    IMAGE = 'image'
    ARRAY = 'array'
    L = 'gray'

    DATA = LOCAL_DATA
    XML_PATH = '../../../../data/1035154_.xml'
    DIMENSIONS = ((45816, 17989), (11454, 4497), (2863, 1124))
    # CLASS = ['TAL', 'ACI']
    CLASS = ['TAL']
    # CLASS = ['ACI']

    crate_mask_img = CreateMaskXml(xml_path=XML_PATH,
                                   class_to_include=CLASS)

    """ PROCESSING """
    hdf5_input = test_prep(DATA, log=True)
    source_img = hdf5_input[IMAGE][ARRAY]

    # insert max_dim dimension info(not initialized on this data)
    hdf5_input['header']['dimensions'] = DIMENSIONS

    hdf5_output = crate_mask_img(hdf5_input)
    mask_img = hdf5_output[IMAGE][ARRAY]

    """ RESULT DISPLAY """
    display(source_img, add_to_title='Source Image')
    display(mask_img, add_to_title='Tissue Mask Image', cmap=L)

    # """ ADVANCED """
    # shape = source_img.shape[:-1]
    # resized_mask = cv2.resize(mask_img, (shape[1], shape[0]))
    # display(resized_mask, cmap='gray')
    # applied_img = cv2.bitwise_and(source_img, source_img, mask=resized_mask)
    # display(applied_img, add_to_title='Mask Applied Image', cmap=L)
