#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import sys

import cv2

from deepphi.image_processing.segmentation.thresholding import Thresholding
from deepphi.image_processing.utils import display
from deepphi.io.sitk import DeepPhiDataSet

TISSUE_BINARIZATION = 'TissueBinarization'

# For Threshold Filters
PRESET_THRESH = 50


class TissueBinarization(Thresholding):
    """Returns a binary image. Thresholding image with an input threshold value

        If the pixel value is greater than a threshold value,
        it is assigned one value (maybe white),
        else it is assigned another value (maybe black).

        Convert color mode from
        L(256 grayscale levels) to B(binary).

    """

    def __init__(self, *args, **kwargs):
        """Initialization of TissueBinarization Class Module.

        self Variables:
            self.log        (logger)  logger for logging.
            self.args       (tbd)     input argument for image processing.
            self.kwargs     (tbd)     keyword argument for image processing.
        """
        super(TissueBinarization, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.thresh = PRESET_THRESH
        self.thresh_by = 'Preset'


if __name__ == "__main__":
    from deepphi.image_processing.converter.color_mode.rgb_to_gray \
        import RGBtoGRAY

    # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    # import environment settings
    hdf5_input = DeepPhiDataSet()

    # import hdf5 image
    hdf5_input.load('../../data/1035154_lv2.hdf5')

    # run input hdf5
    rgb2gray = RGBtoGRAY()
    hdf5_gray = rgb2gray(hdf5_input)
    gray_img = hdf5_gray['image']['array']
    gray2bin = TissueBinarization(thresh=200)
    hdf5_output = gray2bin(hdf5_gray)
    simple_binary_img = hdf5_output['image']['array']

    # display
    display(gray_img, add_to_title='GRAY Image', cmap='gray')
    display(simple_binary_img, add_to_title='BINARY Image(Simple-thresholding)',
            cmap='gray')


