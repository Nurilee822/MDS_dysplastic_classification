#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import math

import cv2
import numpy as np

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit


ID = 'module_id'
NAME = 'module_name'
STRENGTH = 'strength'
BIN_THRESH = 'bin_thresh'
LOWER_THRESH = 'lower_thresh'
UPPER_THRESH = 'upper_thresh'

TYPE = 0
ONES = 1
SQUARE = 2
THRESH = 50
MAXVAL = 255
CLIPLIMIT = 5
TILEGRIDSIZE = (20, 20)


B = 'B'
HSV = 'HSV'
CLAHE = 'Clahe'
OPENING = 'Opening'
DILATION = 'Dilation'
RGB_TO_HSV = 'RGBtoHSV'
COLOR_FILTER = 'ColorFilter'

NP_UINT_ = np.uint8
NP_NDARRAY = np.ndarray
DTYPE_UINT8 = 'uint8'
COLOR_MODE = ['RGB']

KEY_ERROR_U_THRESH = "Threshold value is required. Please specify upper threshold value."
KEY_ERROR_L_THRESH = "Threshold value is required. Please specify lower threshold value."
KEY_ERROR_BIN_THRESH = "Binary threshold value must be provided. Threshold value can be any positive integer number."
TYPE_ERROR_BIN_THRESH = "Binary threshold value must be in form of type int."
KEY_ERROR_STRENGTH = "Dilation strength must be provided. Strength value can be any positive integer."
TYPE_ERROR_STRENGTH = "dilation strength value must be in form of type int."
PROCESSING_ERROR_MSG = "Exception occurred while image processing: "
EMPTY_ERROR_MSG = "Exception occurred while processing data: There is no value in the input image array."
INPUT_TYPE_ERROR_MSG = "Exception occurred while processing data: Image data type is invalid. Must be in a form of array."
COLOR_MODE_ERROR_MSG = "Exception occurred while reading data: \nInput array must be in Grayscale of 256 levels."


class GenerateTissueMaskWsi(Preprocessing):

    def __init__(self, *args, **kwargs):
        super(GenerateTissueMaskWsi, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.applied_processes = list()
        self.this_module = __class__.__name__

        if kwargs[STRENGTH] is not None:
            if isinstance(kwargs[STRENGTH], int):
                self.strength = kwargs[STRENGTH]
            else:
                raise TypeError(TYPE_ERROR_STRENGTH)
        else:
            raise KeyError(KEY_ERROR_STRENGTH)

        if kwargs[BIN_THRESH] is not None:
            if isinstance(kwargs[BIN_THRESH], int):
                self.bin_thresh = kwargs[BIN_THRESH]
            else:
                raise TypeError(TYPE_ERROR_BIN_THRESH)
        else:
            raise KeyError(KEY_ERROR_BIN_THRESH)

        if kwargs[LOWER_THRESH] is not None:
            self.lower_thresh = np.array(kwargs[LOWER_THRESH])
        else:
            raise KeyError(KEY_ERROR_L_THRESH)

        if kwargs[UPPER_THRESH] is not None:
            self.upper_thresh = np.array(kwargs[UPPER_THRESH])
        else:
            raise KeyError(KEY_ERROR_U_THRESH)

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        source_color_mode = self.get_color_mode().upper()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('module name: \t\t\t{}'.format(self.this_module))
        self.log.debug('applied processes: \t\t{}'.format(self.applied_processes))
        self.log.debug('original color mode: \t{}'.format(source_color_mode))
        self.log.debug('output color mode: \t\t{}'.format(self.get_color_mode()
                                                          .upper()))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check color mode
        """

        # Empty_Check
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

        # Type_Check
        if isinstance(self.get_image_array(), NP_NDARRAY):
            dtype = self.get_image_array().dtype
            if dtype is not NP_UINT_:
                self.change_dtype(DTYPE_UINT8)
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

        # Color_Check
        if self.get_color_mode().upper() not in COLOR_MODE:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """create tissue mask image from the source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Create_Tissue_Mask
            output_img = self.create_tissue_mask(source_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)
            self.add_color_mode(self.get_color_mode())

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def create_tissue_mask(self, source_image):

        # Convert RGB to HSV and apply color filtering to get the pixels
        # which displays purple- to pink-ish color.
        hsv_image = cv2.cvtColor(source_image, cv2.COLOR_RGB2HSV)
        self.applied_processes.append(RGB_TO_HSV)
        self.add_color_mode(HSV)

        mask = cv2.inRange(hsv_image,
                           self.lower_thresh,
                           self.upper_thresh)
        self.applied_processes.append(COLOR_FILTER)
        self.add_color_mode(B)

        # Apply CLAHE
        img_clahe = cv2.createCLAHE(CLIPLIMIT, TILEGRIDSIZE).apply(mask)
        self.applied_processes.append(CLAHE)

        # Apply Dilation to smooth out the mask region and find rectangle
        # that contains these mask images.
        _, img_th = cv2.threshold(img_clahe, THRESH, MAXVAL, TYPE)
        self.add_color_mode(B)
        dilated_mask = cv2.dilate(img_th, np.array([ONES] *
                                                   int(math.pow(
                                                      self.strength,
                                                      SQUARE)))
                                            .reshape(self.strength,
                                                     self.strength))
        self.applied_processes.append(DILATION)

        SIZE = self.strength + 2
        STREL = (np.array([1] * int(math.pow(SIZE, 2)))).reshape(SIZE, SIZE)
        tissue_mask = cv2.morphologyEx(dilated_mask, cv2.MORPH_OPEN, STREL)
        self.applied_processes.append(OPENING)

        return tissue_mask


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, LOCAL_DATA

    IMAGE = 'image'
    ARRAY = 'array'
    L = 'gray'
    DATA = LOCAL_DATA

    DILATION_INTENSITY = 15
    BIN_AT = 50
    LOWER_RGB_THRESHOLD = np.array([0, 100, 0])
    UPPER_RGB_THRESHOLD = np.array([200, 200, 200])

    """ PROCESSING """
    hdf5_input = test_prep(DATA, log=True)
    source_img = hdf5_input[IMAGE][ARRAY]
    crate_mask_img = GenerateTissueMaskWsi(strength=DILATION_INTENSITY,
                                   bin_thresh=BIN_AT,
                                   lower_thresh=LOWER_RGB_THRESHOLD,
                                   upper_thresh=UPPER_RGB_THRESHOLD)
    hdf5_output = crate_mask_img(hdf5_input)
    mask_img = hdf5_output[IMAGE][ARRAY]

    """ RESULT DISPLAY """
    display(source_img, add_to_title='Source Image')
    display(mask_img, add_to_title='Tissue Mask Image', cmap=L)

    """ ADVANCED """
    applied_img = cv2.bitwise_and(source_img, source_img, mask=mask_img)
    display(applied_img, add_to_title='Mask Applied Image', cmap=L)
