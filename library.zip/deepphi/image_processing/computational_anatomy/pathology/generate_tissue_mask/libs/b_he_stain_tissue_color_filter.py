#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import cv2

from deepphi.image_processing.config.remove_background_artifact_ import *
from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit, display

HSV_ = ['HSV']


class HEStainTissueColorFilter(Preprocessing):
    """Returns color processed input tissue image (in/out HDF5 format) """

    def __init__(self, *args, **kwargs):
        """Initialization of HEStainTissueColorFilter Class Module.

        self Variables:
            self.log        (logger)  logger for logging.
            self.args       (tbd)     input argument for image processing.
            self.kwargs     (tbd)     keyword argument for image processing.
            self.this_module(str)     Name of the current module.
            self.acceptable_colors(int)  color mode required to process this
                                         module.
            self.parent_class (str)   Name of the parent class category.
        """

        super(HEStainTissueColorFilter, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.acceptable_colors = HSV_
        self.this_mode = 'B'

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('Lower HSV threshold: \t{}'.format(LOWER_THRESHOLD))
        self.log.debug('Upper HSV threshold: \t{}'.format(UPPER_THRESHOLD))
        self.log.debug('Updated Color Mode: \t{}'.format(self.this_mode))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            self.color_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply edge adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Color_Filter: takes hsv image, generates hsv filtered image.
            output_img = self.non_tissue_color_filter(hsv_image=source_image,
                                                      upperLimit=None,
                                                      lowerLimit=None)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)
            self.add_color_mode(self.this_mode)
            self.add_history(self.kwargs['module_id'],
                             self.kwargs['module_name'])

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def non_tissue_color_filter(self, hsv_image, upperLimit=None,
                                lowerLimit=None):
        """Masks out image by color range of [lowerLimit, upperLimit].

        Args:
            hsv_image   (ndarray)   HSV color image .
            upperLimit  (ndarray)   Array of 'Hue', 'Saturation' and 'Value'
                                    values.
            lowerLimit  (ndarray)   Array of 'Hue', 'Saturation' and 'Value'
                                    values.

        """
        if upperLimit is None:
            upperLimit = UPPER_THRESHOLD
        if lowerLimit is None:
            lowerLimit = LOWER_THRESHOLD

        hsv_mask = cv2.inRange(hsv_image,
                               lowerLimit,
                               upperLimit)

        return hsv_mask


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep

    DATA = '../../../data/1035154_lv2.hdf5'
    hdf5_hsv = test_prep(DATA, level='HSV')
    hsv_img = hdf5_hsv['image']['array']

    MODULE_NAME = 'HEStainTissueColorFilter'
    MODULE_ID = '1234'

    color_filter = HEStainTissueColorFilter(module_name=MODULE_NAME,
                                            module_id=MODULE_ID)

    hdf5_hsv_filtered = color_filter(hdf5_hsv)
    hsv_filtered_img = hdf5_hsv_filtered['image']['array']

    # display
    display(hsv_img,
            add_to_title='HSV Image',
            cmap='gray')

    display(hsv_filtered_img,
            add_to_title='HSV Filtered Image'
                         '\n(threshold={}, {})'.format(LOWER_THRESHOLD,
                                                       UPPER_THRESHOLD),
            cmap='gray')
