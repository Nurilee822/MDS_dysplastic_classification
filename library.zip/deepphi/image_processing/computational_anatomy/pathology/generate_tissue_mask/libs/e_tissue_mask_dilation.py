#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing.segmentation.morphological_operation.dilation \
    import Dilation


class TissueMaskDilation(Dilation):
    def __init__(self, *args, **kwargs):
        super(TissueMaskDilation, self).__init__(self, *args, **kwargs)


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, invert_bin

    DATA = '../../../data/1035154_lv2.hdf5'
    hdf5_bin = test_prep(DATA, level='B', log=True)
