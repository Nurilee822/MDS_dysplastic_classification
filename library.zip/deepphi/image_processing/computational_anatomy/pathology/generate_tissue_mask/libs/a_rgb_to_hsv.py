#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2

from deepphi.image_processing.converter.color_mode import ColorMode
from deepphi.image_processing.utils import display

HSV = 'HSV'
RGB_ = ['RGB']


class RGBtoHSV(ColorMode):
    """Returns an HSV image. Converts RGB type image to HSV image type.

        Convert color mode from
        RGB(Red, Green, and Blue) to
        HSV(Hue, Saturation, and Value).

    """

    def __init__(self, *args, **kwargs):
        """Initialization of RGBtoHSV Class Module.

        self Variables:
            self.module_name        (logger)  name of the current module.
            self.acceptable_colors  (tbd)     list of acceptable colors.
            self.this_mode          (tbd)     color mode setting for the module.
        """
        super(RGBtoHSV, self).__init__(self, *args, **kwargs)
        self.acceptable_colors = RGB_
        self.this_mode = HSV

    def convert_color_mode(self, source_image):
        return cv2.cvtColor(source_image, cv2.COLOR_RGB2HSV)


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep

    # Setup Test Data
    DATA = '../../../data/1035154_lv2.hdf5'
    hdf5_input = test_prep(DATA)
    rgb_image = hdf5_input['image']['array']

    # run
    MODULE_NAME = 'RGBtoHSV'
    MODULE_ID = '1234'
    rgb2hsv = RGBtoHSV(module_name=MODULE_NAME,
                       module_id=MODULE_ID)
    hdf5_output = rgb2hsv(hdf5_input)
    hsv_image = hdf5_output['image']['array']

    # display
    display(rgb_image, add_to_title='RGB Image')
    display(hsv_image, add_to_title='HSV Image')


