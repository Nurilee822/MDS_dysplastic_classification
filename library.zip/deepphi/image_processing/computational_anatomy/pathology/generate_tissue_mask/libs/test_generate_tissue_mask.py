#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing.computational_anatomy.pathology.generate_tissue_mask.libs.a_rgb_to_hsv import RGBtoHSV
from deepphi.image_processing.computational_anatomy.pathology.generate_tissue_mask.libs.b_he_stain_tissue_color_filter import HEStainTissueColorFilter
from deepphi.image_processing.computational_anatomy.pathology.generate_tissue_mask.libs.c_clahe_for_tissues import ClaheForTissues
from deepphi.image_processing.computational_anatomy.pathology.generate_tissue_mask.libs.d_tissue_binarization import TissueBinarization
from deepphi.image_processing.computational_anatomy.pathology.generate_tissue_mask.libs.e_tissue_mask_dilation import TissueMaskDilation
from deepphi.image_processing.utils import test_prep, display

# ########################## TEST DATA PATH ########################## #


DATA = '../../../data/1035154_lv2.hdf5'


# ########################## INITIALIZATION ########################## #

IMAGE, ARRAY, L = 'image', 'array', 'gray'

MODULE_ID = '1'
MODULE_NAME = 'RGBtoHSV'
cvt_color = RGBtoHSV(module_name=MODULE_NAME, module_id=MODULE_ID)
MODULE_ID = '2'
MODULE_NAME = 'HEStainTissueColorFilter'
flt_color = HEStainTissueColorFilter(module_name=MODULE_NAME, module_id=MODULE_ID)
MODULE_ID = '3'
MODULE_NAME = 'ClaheForTissues'
adj_contrast = ClaheForTissues(module_name=MODULE_NAME, module_id=MODULE_ID)
MODULE_ID = '4'
MODULE_NAME = 'TissueBinarization'
binarize = TissueBinarization(module_name=MODULE_NAME, module_id=MODULE_ID)
MODULE_ID = '5'
MODULE_NAME = 'TissueMaskDilation'
dilate = TissueMaskDilation(module_name=MODULE_NAME, module_id=MODULE_ID)


# ########################## APPLICATIONS ########################## #

hdf5_rgb = test_prep(DATA, log=True)
rgb_img = hdf5_rgb[IMAGE][ARRAY]
hdf5_hsv = cvt_color(hdf5_rgb)
hsv_img = hdf5_hsv[IMAGE][ARRAY]
hdf5_flt_color = flt_color(hdf5_hsv)
flt_color_img = hdf5_flt_color[IMAGE][ARRAY]
hdf5_adj_cont = adj_contrast(hdf5_flt_color)
adj_cont_img = hdf5_adj_cont[IMAGE][ARRAY]
hdf5_bin = binarize(hdf5_adj_cont)
bin_img = hdf5_bin[IMAGE][ARRAY]
hdf5_dlt = dilate(hdf5_bin)
dlt_img = hdf5_dlt[IMAGE][ARRAY]

# ##########################  RESULT DISPLAY  ########################## #

display(rgb_img, add_to_title='Step 0. RGB Image', cmap=L)
display(hsv_img, add_to_title='Step 1. HSV Image', cmap=L)
display(flt_color_img, add_to_title='Step 2. Color Filtered Image', cmap=L)
display(adj_cont_img, add_to_title='Step 3. Contrast Adjusted Image', cmap=L)
display(bin_img, add_to_title='Step 4. Binary Image Mask', cmap=L)
display(dlt_img, add_to_title='Step 5. Dilated Image Mask', cmap=L)
