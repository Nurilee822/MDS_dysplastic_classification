#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

import cv2

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit
from deepphi.image_processing.config.clahe_ import *

COLORS_ = ['L', 'GRAY', 'B', 'BIN']


class ClaheForTissues(Preprocessing):
    """Returns contrast adjusted input tissue image (in/out HDF5 format) """

    def __init__(self, *args, **kwargs):
        """Initialization of ClaheForTissues Class Module.

        self Variables:
            self.log        (logger)  logger for logging.
            self.args       (tbd)     input argument for image processing.
            self.kwargs     (tbd)     keyword argument for image processing.
            self.acceptable_colors(int)  color mode required to process this
                                         module.
        """
        super(ClaheForTissues, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.acceptable_colors = COLORS_

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('CLAHE threshold: \t{}'.format(CLAHE_THRESHOLD))
        self.log.debug('CLAHE grid size: \t{}'.format(CLAHE_GRID_SIZE))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            self.color_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply contrast adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Apply_CLAHE
            output_img = self.clahe(source_img=source_image,
                                    threshold=CLAHE_THRESHOLD,
                                    grid_size=CLAHE_GRID_SIZE)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)
            self.add_history(self.kwargs['module_id'],
                             self.kwargs['module_name'])

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception(COLOR_MODE_ERROR_MSG)

    @timeit
    def clahe(self, source_img, threshold=None, grid_size=None):
        """Returns local adaptive histogram equalized contrast enhanced image.

        Args:
            source_img (ndarray) source image data
            threshold  (int)     contrast threshold limit
            grid_size  (tuple)   (int, int) grid size to divide image into tiles

        Returns:
            clahe_applied (ndarray) clahe applied image array
         """

        #  Image Processing
        if threshold is None:
            threshold = CLAHE_THRESHOLD

        if grid_size is None:
            grid_size = CLAHE_GRID_SIZE

        CLAHE = cv2.createCLAHE(threshold, grid_size)
        clahe_applied = CLAHE.apply(source_img)

        return clahe_applied


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display
    from deepphi.image_processing.computational_anatomy.pathology.generate_tissue_mask.libs.b_he_stain_tissue_color_filter import HEStainTissueColorFilter

    DATA = '../../../data/1035154_lv2.hdf5'
    # hdf5_gray = test_prep(DATA, level='GRAY')
    # gray_img = hdf5_gray['image']['array']

    hdf5_hsv = test_prep(DATA, level='HSV')
    hsv_img = hdf5_hsv['image']['array']

    MODULE_NAME = 'HEStainTissueColorFilter'
    MODULE_ID = '1234'

    color_filter = HEStainTissueColorFilter(module_name=MODULE_NAME,
                                            module_id=MODULE_ID)

    hdf5_hsv_filtered = color_filter(hdf5_hsv)
    hsv_filtered_img = hdf5_hsv_filtered['image']['array']

    MODULE_NAME = 'ClaheForTissues'
    MODULE_ID = '1234'

    contrast_adj = ClaheForTissues(module_name=MODULE_NAME,
                                   module_id=MODULE_ID)

    hdf5_clahe = contrast_adj(hdf5_hsv_filtered)
    clahe_img = hdf5_clahe['image']['array']

    # display
    display(hsv_filtered_img,
            add_to_title='hsv filtered Image',
            cmap='gray')

    display(clahe_img,
            cmap='gray',
            add_to_title='Computational Anatomy\n '
                         'CLAHE for tissues applied. ')
