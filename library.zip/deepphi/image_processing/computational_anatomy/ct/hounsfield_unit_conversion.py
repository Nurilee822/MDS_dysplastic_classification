#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import numpy as np
from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit


class HounsfieldUnitConversion(Preprocessing):
    """Returns Hounsfield Unit Converted input image"""
    def __init__(self, *args, **kwargs):
        """Initialization of Hounsfiled Unit Conversion Module.

                self Args:
                    self.log        (logger)  logger for logging.
                    self.args       (tbd)     input argument for image processing.
                    self.kwargs     (tbd)     keyword argument for image processing.
                    self.this_module(str)     Name of the current module.
                    self.color_mode     (str)   Color mode of the image array
                """

        super(HounsfieldUnitConversion, self).__init__(self)
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.this_module = __class__.__name__

        """ I/O Error Check Parameters """
        self.dtype_rule = np.int16
        self.color_rule = None
        self.ndim_rule = 3
        self.dim_rule = 3
        self.modality_rule = 'CT'
        self.rescale_intercept = None
        self.rescale_slope = None

        """ Image Processing Parameters """
        self.color_mode = 'L'


    @timeit
    def __call__(self, data, save_path=None):
        """
        todo: rescale_slope & rescale_intercept
        :param data:
        :param save_path:
        :return:
        """

        # IO_Error_Check
        self.io_error_check(data)

        # Image_Processing
        img_array = data['image']['array']  # image array
        new_array = (img_array * self.rescale_slope) + self.rescale_intercept

        # image array 교체
        data['image']['array'] = new_array  # data['image']['array']를 image processing 결과 이미지로 교체

        # header Add
        data['image']['header']['HU_convert'] = True

        # log는 debug level 이상만 사용자에게 노출 되며, 로깅이 필요할 경우 아래와 같이 로그 생성
        self.log.debug('Rescale Slope: \t\t\t{}'.format(self.rescale_slope))
        self.log.debug('Rescale Intercept: \t\t{}'.format(self.rescale_intercept))
        self.log.debug('Original Image Info: \tMin = {}, '
                     '\n\t\t\t\t\t\tMax = {}, '
                     '\n\t\t\t\t\t\tMean = {}, '
                     '\n\t\t\t\t\t\tStd = {}'.format(np.min(img_array),
                                                     np.max(img_array),
                                                     np.mean(img_array),
                                                     np.std(img_array)))
        self.log.debug('Converted Image Info: \tMin = {}, '
                     '\n\t\t\t\t\t\tMax = {}, '
                     '\n\t\t\t\t\t\tMean = {}, '
                     '\n\t\t\t\t\t\tStd = {}'.format(np.min(new_array),
                                                     np.max(new_array),
                                                     np.mean(new_array),
                                                     np.std(new_array)))
        return data

    def io_error_check(self, data):
        image_data = data['image']
        array = image_data['array']
        info = image_data['header']

        dtype = array.dtype
        color_mode = info['color_mode']
        dim = str(info['dim'])
        ndim = str(array.ndim)
        modality = info['modality']
        metadata = info['metadata']

        slope = '0028|1053'
        intercept = '0028|1052'

        if self.dtype_rule is not None:
            if dtype is not self.dtype_rule:
                image_data['array'] = array.astype('uint8')

        if self.color_rule is not None:
            assert color_mode in self.color_rule, \
                'Input Image color-mode Must Match. ' \
                '\nAccepts--' \
                + self.color_rule

        if self.dim_rule is not None:
            assert dim in str(self.dim_rule), \
                'Input Image Dimension Must Match. ' \
                '\nAccepts--' \
                + str(self.dim_rule)

        if self.ndim_rule is not None:
            assert ndim in str(self.ndim_rule), \
                'Input Image shape structure Must Match. ' \
                '\nAccepts--' \
                + str(self.ndim_rule)

        if self.modality_rule is not None:
            assert modality in self.modality_rule, \
                'Input Modality Type Must Match.' \
                '\nAccepts--' \
                + self.modality_rule

        if slope and intercept in metadata:
            if metadata[slope] is not None:
                self.rescale_slope = metadata[slope]  # 1
            else:
                raise ImportError("Vital information does not exist. Please "
                                  "provide 'slope' information.")

            if metadata[intercept] is not None:
                self.rescale_intercept = metadata[intercept]  # -1024
            else:
                raise ImportError("Vital information does not exist. Please "
                                  "provide 'intercept' information")
        else:
            raise ImportError("Vital information 'slope' and/or 'intercept' "
                              "does not exist.")


# Test code
if __name__ == '__main__':
    # libray Import
    from deepphi.image_processing.utils import display, get_image, test_prep

    input_path = '/home/hslisalee/Downloads/DL_team_codes/jeong_jh/dataset' \
                 '/filename.hdf5'
    data = test_prep(input_path, log=True)
    input_img = get_image(data)

    """ Add 'CT to modality type"""
    data['image']['header']['modality'] = 'CT'
    data['image']['header']['metadata']['0028|1053'] = 1
    data['image']['header']['metadata']['0028|1052'] = -1024

    huc = HounsfieldUnitConversion()
    data_out = huc(data)

    output_img = get_image(data_out)
    for idx in range(len(output_img)):
        if idx%5 == 0:
            slice_in = input_img[idx]
            slice_out = output_img[idx]
            display(slice_in)
            display(slice_out)


