#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
import numpy as np
from skimage import morphology
from skimage import measure
import logging
from deepphi.image_processing.utils import timeit


class LungAreaSegmentation(Preprocessing):
    '''Returns Segmented Lung Area input image'''
    def __init__(self, threshold_value=-1350):
        super(LungAreaSegmentation, self).__init__(self)
        self.log = logging.getLogger()
        self.this_module = __class__.__name__

        """ I/O Error Check Parameters """
        self.dtype_rule = np.int16
        self.color_rule = None
        self.ndim_rule = 3
        self.dim_rule = 3
        self.modality_rule = 'CT'

        """ Image Processing Parameters """
        self.color_mode = 'single'
        self.threshold_value = threshold_value

    @timeit
    def __call__(self, data, save_path=None):
        # IO_Error_Check
        self.io_error_check(data)

        # Image_Processing
        image_array = data['image']['array']  # image array

        arr_thres = np.where(image_array < self.threshold_value, 1, 0)
        for i in range(image_array.shape[0]):
            # Erosion and Dilation
            arr_eroded = morphology.erosion(arr_thres[i], np.ones([3, 3]))
            arr_dilation = morphology.dilation(arr_eroded, np.ones([8, 8]))
            # find good label
            labels = measure.label(arr_dilation)
            row_size = labels.shape[0]
            col_size = labels.shape[1]
            regions = measure.regionprops(labels)
            good_labels = []
            for prop in regions:
                B = prop.bbox
                if B[2] - B[0] < row_size / 10 * 9 and B[3] - B[1] < col_size / 10 * 9 and B[0] > row_size / 5 and B[
                    2] < col_size / 5 * 4:
                    good_labels.append(prop.label)
            mask = np.ndarray([row_size, col_size], dtype=np.int8)
            mask[:] = 0
            for N in good_labels:
                mask = mask + np.where(labels == N, 1, 0)
            mask = morphology.dilation(mask, np.ones([10, 10]))  # mask = np.where(labels == 0, 1, 0)
            # final image
            image_array[i] = mask * image_array[i]

        data['image']['array'] = image_array
        return data

    def io_error_check(self, data):
        image_data = data['image']
        array = image_data['array']
        info = image_data['header']

        dtype = array.dtype
        color_mode = info['color_mode']
        dim = str(info['dim'])
        ndim = str(array.ndim)
        modality = info['modality']
        if 'HU_convert' in info:
            HU_convert = data['image']['header']['HU_convert']
        else:
            raise KeyError("'HU_convert' information does not exist.")

        if self.dtype_rule is not None:
            if dtype is not self.dtype_rule:
                image_data['array'] = array.astype('uint8')

        if self.color_rule is not None:
            assert color_mode in self.color_rule, \
                'Input Image color-mode Must Match. ' \
                '\nAccepts--' \
                + self.color_rule

        if self.dim_rule is not None:
            assert dim in str(self.dim_rule), \
                'Input Image Dimension Must Match. ' \
                '\nAccepts--' \
                + str(self.dim_rule)

        if self.ndim_rule is not None:
            assert ndim in str(self.ndim_rule), \
                'Input Image shape structure Must Match. ' \
                '\nAccepts--' \
                + str(self.ndim_rule)

        if self.modality_rule is not None:
            assert modality in self.modality_rule, \
                'Input Modality Type Must Match.' \
                '\nAccepts--' \
                + self.modality_rule

        if not HU_convert:
            raise ValueError('Please insert the Hounsfield Unit converted '
                             'image into the input image.')


# test code
if __name__ == '__main__':
    # libray Import
    import sys
    import os
    from deepphi.io.sitk import *
    deepphi_dataset = DeepPhiDataSet()
    import matplotlib.image as mpimg

    # Test Data loading
    # input_path = sys.argv[0]
    # output_path = sys.argv[1]
    # data = deepphi_dataset.load(input_path)
    #
    # image_array = data['image']['array']
    # new_array = np.zeros(shape=image_array.shape)
    # threshold_value = -1350
    #
    # # Test Running
    # arr_thres = np.where(image_array < threshold_value, 1, 0)
    # for i in range(image_array.shape[0]):
    #     # Erosion and Dilation
    #     arr_eroded = morphology.erosion(arr_thres[i], np.ones([3, 3]))
    #     arr_dilation = morphology.dilation(arr_eroded, np.ones([8, 8]))
    #     # find good label
    #     labels = measure.label(arr_dilation)
    #     row_size = labels.shape[0]
    #     col_size = labels.shape[1]
    #     regions = measure.regionprops(labels)
    #     good_labels = []
    #     for prop in regions:
    #         B = prop.bbox
    #         if B[2] - B[0] < row_size / 10 * 9 and B[3] - B[1] < col_size / 10 * 9 and B[0] > row_size / 5 and B[
    #             2] < col_size / 5 * 4:
    #             good_labels.append(prop.label)
    #     mask = np.ndarray([row_size, col_size], dtype=np.int8)
    #     mask[:] = 0
    #     for N in good_labels:
    #         mask = mask + np.where(labels == N, 1, 0)
    #     mask = morphology.dilation(mask, np.ones([10, 10]))
    #     # final image
    #     new_array[i] = mask * image_array[i]
    #
    # zn = image_array.shape[0] // 2
    # mpimg.imsave(os.path.join(output_path, 'before_LungAreaSegment.png'), image_array[zn], cmap='gray')
    # mpimg.imsave(os.path.join(output_path, 'after_LungAreaSegment.png'), new_array[zn], cmap='gray')
    #
    from deepphi.image_processing.computational_anatomy.ct\
        .hounsfield_unit_conversion import HounsfieldUnitConversion
    from deepphi.image_processing.utils import test_prep, display, get_image

    CT_DATA = '/home/hslisalee/Downloads/DL_team_codes/jeong_jh/dataset/filename.hdf5'
    data = test_prep(CT_DATA, log=True)
    input_img = get_image(data)

    data['image']['header']['modality'] = 'CT'
    data['image']['header']['metadata']['0028|1053'] = 1
    data['image']['header']['metadata']['0028|1052'] = -1024

    huc = HounsfieldUnitConversion()
    data_huc = huc(data)

    las = LungAreaSegmentation()
    data_output = las(data_huc)

    output_img = get_image(data_output)

    for idx in range(len(output_img)):
        if idx % 5 == 0:
            slice_in = input_img[idx]
            slice_out = output_img[idx]
            display(slice_in)
            display(slice_out)
