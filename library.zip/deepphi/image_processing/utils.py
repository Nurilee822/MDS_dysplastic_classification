""" Things included in utils.py

class Pathology
class MagneticResonance
class DataFormat
"""
#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

# from deepphi.dev.test.pathology.color_processing import \
#     ColorProcessing
# from deepphi.dev.test.pathology.open_slide import \
#     OpsProcessing
# import deepphi.dev.test.pathology.config as cfg

import matplotlib.pyplot as plt
import numpy as np
import os


from deepphi.io.sitk import DeepPhiDataSet
import sys
import logging

IMAGE = 'image'
ARRAY = 'ARRAY'
L = 'gray'

LOCAL_DATA = '/home/hslisalee/DEEPPHI/io/hdf5/svs/1035154_lv2.hdf5'
TARGET_DATA = '/home/hslisalee/DEEPPHI/io/hdf5/svs/1035155_lv2.hdf5'
LOCAL_CHEST = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
               '/BetaData01_Chest_cls2d/test/CST_1.hdf5'


class DeepphiSaveQueue(object):
    def __init__(self, processing_module):
        self.processing_module = processing_module
        self.index = 0
        self.list_result = list()

    def append(self, data):
        self._save(data)

    def _save(self, data_output):
        pid = os.getpid()
        save_path = self.processing_module.map_pid_to_filename[pid]
        filename = self._save_hdf5(save_path, data_output)
        result = self._create_msg(filename, data_output)
        self.list_result.append(result)

    def _create_msg(self, output_file, data_output):
        # create msg
        shape = list(data_output['image']['array'].shape)
        if self.processing_module._create_method == 'link':
            shape = list(data_output['image']['header']['shape'])

        if not data_output['image']['header']['IsVector']:
            shape.append(1)
        color_mode = data_output['image']['header']['color_mode']
        label_info = self.processing_module._create_label_info(data_output)

        result = {"output_file": output_file, "status": 'COMPLETED',
                  "shape": str(shape), "color_mode": color_mode, "processingTime": 0,
                  'error_msg': None, 'labelDetails': label_info}

        if np.any(data_output['label']['transformation']['array']):
            label_shape = list(data_output['label']['transformation']['array'].shape)
            if not data_output['label']['transformation']['header']['IsVector']:
                label_shape.append(1)
            result['label_shape'] = str(label_shape)
        if np.any(data_output['label']['segmentation']['array']):
            label_shape = list(data_output['label']['segmentation']['array'].shape)
            if not data_output['label']['segmentation']['header']['IsVector']:
                label_shape = label_shape.append(1)
            result['label_shape'] = str(label_shape)
        return result

    def set_processing_time(self):
        pass

    def _save_hdf5(self, save_path, data):
        dirname = os.path.dirname(save_path)
        basename = os.path.basename(save_path)[:-5]  # without .hdf5

        filename = "{}/{}_{:04d}.hdf5".format(dirname, basename, self.index)
        data["header"]["patch"] = True
        data["header"]["patch_original_filename"] = "{}.hdf5".format(basename)
        data['header']['filename'] = os.path.basename(filename)

        data.save(filename, encryption_key=str(self.processing_module.encryption_key))
        self.index += 1
        return filename



def deepphidataset(data):

    if isinstance(data, DeepPhiDataSet):
        print('Yayyyyy')
    else:
        print('Nayyyy')


def test_dirs():
    chest_X = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
              '/BetaData01_Chest_cls2d/test/'
    body_CT = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
              '/BetaData02_BodyCT_cls3d/test/'
    lung_ = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
            '/BetaData03_Lung_seg2d/test'
    fundus_Photo = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
                   '/BetaData04_Fundus_seg2d/test'
    colon_ = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
             '/BetaData05_Colon_seg3d/test'
    pancreas_ = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
                '/BetaData06_Pancreas_seg3d/test'
    heart_ = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
             '/BetaData07_Heart_seg3d/test'

    return chest_X, body_CT, lung_, fundus_Photo, colon_, pancreas_, heart_


def data_list(data_dir):
    return os.listdir(data_dir)


def run_files(data_list, method):
    out_list = []
    for data in data_list:
        out_list = method(data)
    return out_list


def test_data(type, method):
    chest_X = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
              '/BetaData01_Chest_cls2d/test/'
    body_CT = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
              '/BetaData02_BodyCT_cls3d/test/'
    lung_ = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
            '/BetaData03_Lung_seg2d/test'
    fundus_Photo = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
                   '/BetaData04_Fundus_seg2d/test'
    colon_ = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
             '/BetaData05_Colon_seg3d/test'
    pancreas_ = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
                '/BetaData06_Pancreas_seg3d/test'
    heart_ = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
             '/BetaData07_Heart_seg3d/test'

    if type.upper == 'CHEST_X':
        dataset = chest_X
        data_lst = data_list(dataset)
        out_list = run_files(data_lst, method)
        return out_list

    if type.upper() == 'body_CT'.upper():
        dataset = body_CT
        data_lst = data_list(dataset)
        out_list = run_files(data_lst, method)
        return out_list

    if type.upper() == 'lung_'.upper():
        dataset = lung_
        data_lst = data_list(dataset)
        out_list = run_files(data_lst, method)
        return out_list

    if type.upper() == 'fundus_Photo'.upper():
        dataset = fundus_Photo
        data_lst = data_list(dataset)
        out_list = run_files(data_lst, method)
        return out_list

    if type.upper() == 'colon_'.upper():
        dataset = colon_
        data_lst = data_list(dataset)
        out_list = run_files(data_lst, method)
        return out_list

    if type.upper() == 'pancreas_'.upper():
        dataset = pancreas_
        data_lst = data_list(dataset)
        out_list = run_files(data_lst, method)
        return out_list

    if type.upper() == 'heart_'.upper():
        dataset = heart_
        data_lst = data_list(dataset)
        out_list = run_files(data_lst, method)
        return out_list


def shape(image):
    if not isinstance(image, np.ndarray):
        image = np.asarray(image)
    return image.shape


def test_prep(data=None, modality=None, level=None, log=False):
    from deepphi.image_processing.converter.color_mode.rgb_to_binary import \
        RGBtoBINARY
    from deepphi.image_processing.converter.color_mode.rgb_to_hsv import \
        RGBtoHSV
    from deepphi.image_processing.converter.color_mode.rgb_to_gray import \
        RGBtoGRAY
    from deepphi.image_processing.converter.color_mode.gray_to_binary import \
        GRAYtoBINARY

    RGB = ['RGB', 'rgb']
    HSV = ['HSV', 'hsv']
    GRAY = ['L', 'l', 'GRAY', 'gray']
    BINARY = ['B', 'b', 'BIN', 'bin', 'Binary', 'BINARY']
    PATHOLOGY = ['PATHOLOGY']
    XRAY = ['XRAY']
    MRI = ['MRI']
    PET = ['PET']

    CRC = '1035154_lv2.hdf5'
    DATA = '../../../data/'

    if log is True:
        log = setup_logger(level=logging.DEBUG)
        mpl_logger = logging.getLogger('matplotlib')
        mpl_logger.setLevel(logging.WARNING)

    # import hdf5 image
    if data is None:
        if isinstance(modality, str):
            if modality.upper() in PATHOLOGY:
                data = DATA + CRC
            elif modality.upper() in XRAY:
                pass
            elif modality.upper() in MRI:
                pass
            elif modality.upper() in PET:
                pass

    hdf5 = hdf5_init()

    if isinstance(data, str):
        hdf5_input = load_hdf5(data=data, hdf5=hdf5)

        if level is None:
            level = 'original'

        if level == 'original':
            return hdf5_input

        if hdf5_input['image']['header']['color_mode'] in RGB:

            # Return RGB
            if level in RGB:
                hdf5_rgb = load_hdf5(data=data)
                return hdf5_rgb

            # Return HSV
            elif level in HSV:
                hdf5_rgb = load_hdf5(data=data)

                rgb2hsv = RGBtoHSV()
                hdf5_hsv = rgb2hsv(hdf5_rgb)
                return hdf5_hsv

            # Return Grayscale
            elif level in GRAY:
                hdf5_rgb = load_hdf5(data=data)

                rgb2gray = RGBtoGRAY()
                hdf5_gray = rgb2gray(hdf5_rgb)
                return hdf5_gray

            # Return Binary
            elif level in BINARY:
                hdf5_rgb = load_hdf5(data=data)

                rgb2bin = RGBtoBINARY()
                hdf5_bin = rgb2bin(hdf5_rgb)

                return hdf5_bin

            else:
                return hdf5_input

        elif hdf5_input['image']['header']['color_mode'] in GRAY:

            # Return Grayscale
            if level in GRAY:
                hdf5_gray = load_hdf5(data=data)
                return hdf5_gray

            # Return Binary
            elif level in BINARY:
                hdf5_gray = load_hdf5(data=data)

                gray2bin = GRAYtoBINARY()
                hdf5_bin = gray2bin(hdf5_gray)
                return hdf5_bin

    else:
        raise TypeError
    return hdf5


def invert_bin(bin_img):
    inv_img = np.invert(bin_img)
    return inv_img


def hdf5_init():
    hdf5 = DeepPhiDataSet()
    return hdf5


def load_hdf5(data, hdf5=None):
    # loads hdf5 file as dictionary.
    if hdf5 is None:
        hdf5 = hdf5_init()
    hdf5.load(data)

    return hdf5


def setup_logger(level=logging.DEBUG):
    # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(level)

    return log

def get_image(hdf5):
    """Extracts image array from hdf5 image

    Args:
        hdf5    (hdf5)  hdf5 image
    Return:
        np.ndarray      image array
    """
    return hdf5['image']['array']


class DataFormat:
    # TODO: Complete the DataFormat Class.
    def __init__(self):
        self.parent_class = 'Converter'
        self.this_module = []
        self.data = ''
        self.current = ''
        self.tobe = ''

    def __call__(self, *args, **kwargs):
        self.data = args
        self.current = kwargs

        print('I am args:', self.data)
        print('I am kwargs:', self.current)

    def svs_to_ops(self):
        pass

    def ops_to_hdf5(self):
        pass

    def hdf5_to_pil(self):
        pass

    def hdf5_to_sitk(self):
        pass

    def hdf5_to_nda(self, hdf5_image):
        """
        Extracts and returns array portion of hdf5 image.

        Args:
            hdf5_image (hdf5)           hdf5 format image

        Returns:
            numpy.array                 image array portion of hdf5 image
        """

        return hdf5_image['image']['array']


def timeit(func):
    import time
    import functools

    """Print the runtime of the decorated function"""

    @functools.wraps(func)
    def wrapper_timer(*args, **kwargs):
        start_time = time.perf_counter()  # 1
        value = func(*args, **kwargs)

        # do something after
        end_time = time.perf_counter()  # 2
        run_time = end_time - start_time

        print(f"Finished {func.__name__!r} in {run_time:.4f} secs")

        return value

    return wrapper_timer

#
# class Display:
#     # TODO: COmplete the Display Class.
#     def __init__(self):
#         pass
#
#     def __call__(self, *args, **kwargs):
#         pass


def ops_display(ops_image):
    zero_pt = (0, 0)
    filename = ops_image.properties['aperio.Filename']
    min_lvl = ops_image.level_count - 1
    min_dim = ops_image.level_dimensions[min_lvl]
    min_img = ops_image.read_region(location=zero_pt,
                                    level=min_lvl,
                                    size=min_dim).convert('RGB')
    sdi = np.array(min_img)

    plt.figure()

    plt.imshow(sdi)
    plt.title(filename + ' @ level ' + str(min_lvl) + ' (OpenSlide)')
    plt.show()


def display(array, cmap=None, add_to_title=None):

    f = plt.figure()
    f.set_figwidth(30)
    f.set_figheight(15)

    if add_to_title is None:
        add_to_title = ''

    plt.title(add_to_title)

    if cmap is None:
        plt.imshow(array)
    else:
        plt.imshow(array,
                   cmap=cmap,
                   vmin=0,
                   vmax=255)

    plt.show()


def hdf5_display(hdf5_image, cmap=None, add_to_title=None):
    """Display the input HDF5 data's ['array'] as an image.

    Args:
        hdf5_image   (hdf5)  HDF5 type data with ['array'].
        cmap         (str)   'gray' to display in grayscale/binary
        add_to_title (str)   Comment to be added on the display image.

    Returns:
        None
    """
    if add_to_title is None:
        add_to_title = ''

    array = hdf5_image['image']['array']
    filename = hdf5_image['image']['header']['filename']
    # this_lvl = hdf5_image['image']['header']['CurrentLevel']

    f = plt.figure()
    f.set_figwidth(30)
    f.set_figheight(15)

    if cmap is not None:
        plt.imshow(array,
                   cmap=cmap,
                   vmin=0,
                   vmax=255)
    else:
        plt.imshow(array)

    plt.title(filename
              + ' (HDF5) \n'
              + add_to_title)
    plt.show()


def plot_hist(image, cdf=False, size=None, add_to_title=None,
              x_range=None):
    """Display histogram and cumulative distribution function of the image.

    Args:
         image (array)  image array to plot histogram.
         cdf   (bool)   boolean to toggle cumulative distribution function.
         size  (list)   [plot_width(int), plot_height(int)].
         add_to_title   (str)   Comment to add to title.
         x_range        (list)  x range to display in plot.

    Returns:
        None
    """
    f = plt.figure()

    if size is not None:
        f.set_figwidth(size[0])
        f.set_figheight(size[1])

    hist, bins = np.histogram(image.flatten(),
                              256,
                              [0, 256])

    if cdf is True:
        cdf = hist.cumsum()
        cdf_normalized = cdf * hist.max() / cdf.max()

        plt.plot(cdf_normalized,
                 color='r')

    plt.hist(image.flatten(),
             bins=256,
             range=[0, 256],
             color='k')
    if x_range is not None:
        plt.xlim(x_range)
    else:
        plt.xlim([0, 255])

    if cdf is True:
        plt.legend(('cdf', 'histogram'),
                   loc='upper left')
    else:
        plt.legend('histogram',
                   loc='upper left')

    plt.title(add_to_title)
    plt.show()

#
# class Pathology:
#     def __init__(self):
#         pass
#
#     def __call__(self, *args, **kwargs):
#         pass
#
#
# def test_prep(svs_image=None, xml_label=None,
#               image_display=False, image_type=None, level=None):
#
#     """  PATHS & CONFIGS  """
#
#     if svs_image is None:
#         svs_image = cfg.SAMPLE_SVS
#     if xml_label is None:
#         xml_label = cfg.SAMPLE_XML
#
#     """  PREP: open_slide.py  """
#
#     ops_proc = OpsProcessing()
#     ops_image = ops_proc.load_svs(svs_path=svs_image)
#     hdf5_image = ops_proc.ops2hdf5(ops_image=ops_image,
#                                    label_path=xml_label)
#
#     original = hdf5_image['array']
#     rgb_image = original
#
#     if level == 'original':
#         return rgb_image, hdf5_image
#
#     """  PREP: color_processing.py  """
#
#     color_proc = ColorProcessing()
#
#     #  Original Image as HDF5
#     hdf5_image['array'] = original
#
#     if image_display:
#         color_proc.hdf5_display(hdf5_image=hdf5_image,
#                                 add_to_title='Original')
#
#     #  RGB to HSV conversion
#     hdf5_image['array'] = rgb_image
#
#     hsv = color_proc.rgb2hsv(hdf5_image_rgb=hdf5_image)
#     hsv_image = hsv['array']
#
#     if image_display:
#         color_proc.hdf5_display(hdf5_image=hsv,
#                                 add_to_title='HSV')
#
#     #  HSV filtering
#     hdf5_image['array'] = hsv_image
#
#     hsv_mask = color_proc.hsv_filter(hdf5_image_HSV=hdf5_image)
#     hsv_filtered_image = hsv_mask['array']
#
#     if image_display:
#         color_proc.hdf5_display(hdf5_image=hsv_mask,
#                                 cmap='gray',
#                                 add_to_title='hsv_bg_filtered')
#
#     #  CLAHE
#     hdf5_image['array'] = hsv_filtered_image
#
#     clahe_applied = color_proc.clahe(hdf5_image=hdf5_image)
#     hsv_clahe_applied_image = clahe_applied['array']
#
#     if image_display:
#         color_proc.hdf5_display(hdf5_image=clahe_applied,
#                                 cmap='gray',
#                                 add_to_title='clahe_applied')
#
#     #  RGB to BGR conversion
#     hdf5_image['array'] = original
#
#     bgr = color_proc.rgb2bgr(hdf5_image_rgb=hdf5_image)
#     bgr_image = bgr['array']
#
#     if image_type is None:
#         hdf5_image['array'] = hsv_clahe_applied_image
#     elif image_type == 'bgr':
#         hdf5_image['array'] = bgr_image
#
#     return original, hsv_filtered_image, hdf5_image

