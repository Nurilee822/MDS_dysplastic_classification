#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging  # logging을 위해 반드시 import
import numpy as np
from deepphi.image_processing import Preprocessing  # deepphi 모듈로 작동하기 위해 Preprocessing Class 상속이 필요


class SampleModule(Preprocessing):  # Preprocessing Class 상속이 반드시 필요함

    def __init__(self, parameter_name1=None, parameter_name2=None):  # 외부에서 parameter 입력이 필요한 경우 해당 parameter 명을 key값으로 받도록 __init__에서 정의함
        """Initialization of Image Processing Class Module.

        self Args:
            self.parent_class   (str)
            self.module_name    (list)
            self.dtype_rule     (type)  Mostly uint8.
                                            If different, please modify.
            self.color_rule     (str)   Specify if color restriction exists.
                                            'RGB' or 'HSV' for 3-channel.
                                            'L' for grayscale.
                                            'B' for binary.
            self.ndim_rule      (int)   Specify if shape(ndim) is restricted.
            self.dim_rule       (int)   Specify if image dimension is restricted.
                                            1, for any.
                                            2, for 2-D only.
                                            3, for 3-D only.
            self.modality_rule  (str)   Specify if modality restrictions exists.

            self.data           (hdf5)  input hdf5 data
            self.args           (tbd)   input argument for image processing.
            self.kwargs         (tbd)   keyword argument for image processing.
            self.color_mode     (str)   Color mode of the image array
        """

        super(SampleModule, self).__init__()

        """ I/O Error Check Parameters """

        self.dtype_rule = np.uint8
        self.color_rule = None
        self.ndim_rule = None
        self.dim_rule = None
        self.modality_rule = None

        """ Image Processing Parameters """
        self.color_mode = ''  # TODO: FILL
        self.parameter_name1 = parameter_name1
        self.parameter_name2 = parameter_name2

    def __call__(self, data, save_path=None):
        """
        __call__ method에 input으로는 DeepphiDataset이 data에 input으로 들어옴 (method를 작성할 때는 dictionary와 같이 사용)

        한개의 DeepphiDataset을 input으로 받는 경우
            __call__(self, data)

        두개 이상의 data를 input으로 받는 경우 ex) input으로 앞에 두개 이상의 모듈이 연결됨
            argument 갯수를 늘리는 방법으로 input 갯수를 늘리면 됨
            __call__(self, data1, data2)
        """

        # IO_Error_Check
        self.io_error_check(data)

        # Image_Processing
        img_array = data['image']['array']  # image array
        header = data['image']['header']  # header는 dictionary 형태이며, image processing에 필요한 정보들을 포함하고 있음.

        # image array 교체
        data['image']['array'] = new_array  # data['image']['array']를 image processing 결과 이미지로 교체

        # header 추가
        """
        - header는 python dictionary 형식으로 변환되어 제공됨
        - Restrictions
            - header 내부에 value 값으로 일반적인 python object나 다른 패키지에서 정의된 object들을 포함시키면 안됨.
            - 숫자형 데이터: float, int
            - 문자열: str
            - 위의 두가지 형태로 구성된 리스트 
            ex) [1, 2, 3]
            - header에 depth를 주고 싶은 경우, 위 양식을 지키는 dictionary를 value 값으로 사용가능
            ex) 
            data['image']['header']['new_depth'] = dict()
            data['image']['header']['new_depth']['new_key'] = new_value
        """
        data['image']['header']['info_name'] = new_info  # image processing 결과 생기는 정보를 header에 담고 싶은 경우 일반 dictionary와 동일하게 key-value를 추가하면 됨

        # log는 info level 이상만 사용자에게 노출 되며, 로깅이 필요할 경우 아래와 같이 로그 생성
        logging.debug('msg')
        logging.info('msg')

        # Return_Output_HDF5
        """
        - 기본형태
            data['image']['array'] = somthing_new
            return data
            
        - 서로 다른 정보를 갖는 2개 이상의 output이 생성되는 경우
            data1['image']['array'] = somthing_new1
            data2['image']['array'] = somthing_new2
            return data1, data2
            
        - 하나의 정보를 포함하지만 patch extraction과 같이 여러개의 output이 생성되는 경우
            import copy
        
            img = data['image']['array']
            list_patch = list()
            
            for xy in coordinates:
                patch_img = crop(img, xy)
                
                data_patch = copy.copy(data)
                data_patch['image']['array'] = patch_img
                list_patch.appned(data_patch)
                
            return list_patch  # 해당 patch extraction 결과를 list로 묶어서 return
        """
        return data

    def io_error_check(self, data):
        pass
        # TODO: Complete the error checking method
        """ Input data permission

        Check image type 
        Check image data type
        Check color mode
        Check dimension
        Check imaging modality
        Check parameters that are unique to this module
        Check history - prerequisite image processing modules

        Throw an Error if type, color, ndim, modality is different
        """

        image_data = data['image']
        array = image_data['array']
        info = image_data['header']

        dtype = array.dtype
        color_mode = info['color_mode']
        dim = info['dim']
        ndim = array.ndim
        modality = info['modality']

        if self.dtype_rule is not None:
            if dtype is not self.dtype_rule:
                image_data['array'] = array.astype('uint8')

        if self.color_rule is not None:
            assert color_mode in self.color_rule, \
                'Input Image color-mode Must Match. ' \
                '\nAccepts--' \
                + self.color_rule

        if self.dim_rule is not None:
            assert dim in self.dim_rule, \
                'Input Image Dimension Must Match. ' \
                '\nAccepts--' \
                + self.dim_rule

        if self.ndim_rule is not None:
            assert ndim in self.ndim_rule, \
                'Input Image shape structure Must Match. ' \
                '\nAccepts--' \
                + self.ndim_rule

        if self.modality_rule is not None:
            assert modality in self.modality_rule, \
                'Input Modality Type Must Match.' \
                '\nAccepts--' \
                + self.modality_rule


if __name__ == "__main__":

    # import hdf5 image
    # import environment settings

    # run input hdf5
    # check output hdf5
    pass
