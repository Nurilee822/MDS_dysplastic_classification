#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
import SimpleITK as sitk
import logging


GRAY = 'Gray'
L = 'L'


class N4BiasFieldCorrection(Preprocessing):
    def __init__(self, numberOfIterations=None, numberOfFittingLevels=4):
        """Implementation of the N4 bias field correction algorithm.
        self Args:
            self.numberOfIterations   (None or int)
            self.numberOfFittingLevels    (int)
        """
        super(N4BiasFieldCorrection, self).__init__()
        self.log = logging.getLogger()
        self.numberOfIterations = numberOfIterations
        self.numberOfFittingLevels = numberOfFittingLevels
        self.acceptable_colors = [GRAY, L]
        self.acceptable_modality = 'MRI'

    def __call__(self, data, save_path=None):
        self.init_data(data)

        if data['image']['array'].ndim > 3:
            raise ValueError(
                'Only 1-channel images are available for now. Please make image array shape (Height, Width) or (Batch, Height, Width)')

        if 'color_mode' not in data['image']['header']:
            raise KeyError("color_mode information is required to process. "
                           "This module accepts 'Gray' or 'L' modes only.")
        elif self.get_color_mode().upper() not in self.acceptable_colors:
            raise ValueError("Only grayscale images('Gray' or 'L' color mode) "
                             "are accepted. ")

        if 'modality' not in data['image']['header']:
            raise KeyError("modality information is required to process. This module accepts images from 'MRI' modality only.")
        elif self.get_modality().upper() not in self.acceptable_modality:
            raise ValueError("Bias field correction can be applied to "
                             "MRI images only. Please provide MRI images to "
                             "run the module.")

        inputImage = sitk.GetImageFromArray(data['image']['array'])
        maskImage = sitk.OtsuThreshold(inputImage, 0, 1,
                                       200)  # In the future, an option that mask images for the correction can be uploaded together should be added (multiple inputs)
        inputImage = sitk.Cast(inputImage, sitk.sitkFloat32)

        corrector = sitk.N4BiasFieldCorrectionImageFilter()
        if self.numberOfIterations:
            corrector.SetMaximumNumberOfIterations(
                [int(self.numberOfIterations)] * self.numberOfFittingLevels)
        output = corrector.Execute(inputImage, maskImage)
        data['image']['array'] = sitk.GetArrayFromImage(output)
        return data

# reference: https://simpleitk.readthedocs.io/en/v1.2.0/Examples/N4BiasFieldCorrection/Documentation.html
'''
Implementation of the N4 bias field correction algorithm.

The nonparametric nonuniform intensity normalization (N3) algorithm,
as introduced by Sled et al. in 1998 is a method for correcting
nonuniformity associated with MR images. The algorithm assumes a
simple parametric model (Gaussian) for the bias field and does not
require tissue class segmentation. In addition, there are only a
couple of parameters to tune with the default values performing quite
well. N3 has been publicly available as a set of perl scripts
( http://www.bic.mni.mcgill.ca/ServicesSoftwareAdvancedImageProcessingTools/HomePage )

The N4 algorithm, encapsulated with this class, is a variation of the
original N3 algorithm with the additional benefits of an improved
B-spline fitting routine which allows for multiple resolutions to be
used during the correction process. We also modify the iterative
update component of algorithm such that the residual bias field is
continually updated

Notes for the user:
Since much of the image manipulation is done in the log space of the
intensities, input images with negative and small values (< 1) can
produce poor results.

The original authors recommend performing the bias field correction on
a downsampled version of the original image.

A binary mask or a weighted image can be supplied. If a binary mask is
specified, those voxels in the input image which correspond to the
voxels in the mask image are used to estimate the bias field. If a
UseMaskLabel value is set to true, only voxels in the MaskImage that
match the MaskLabel will be used; otherwise, all non-zero voxels in
the MaskImage will be masked. If a confidence image is specified, the
input voxels are weighted in the b-spline fitting routine according to
the confidence voxel values.

The filter returns the corrected image. If the bias field is wanted,
one can reconstruct it using the class
itkBSplineControlPointImageFilter. See the IJ article and the test
file for an example.

The 'Z' parameter in Sled's 1998 paper is the square root of the class
variable 'm_WienerFilterNoise'.
 The basic algorithm iterates between sharpening the intensity
histogram of the corrected input image and spatially smoothing those
results with a B-spline scalar field estimate of the bias field.

Nicholas J. Tustison
 Contributed by Nicholas J. Tustison, James C. Gee in the Insight
Journal paper: https://hdl.handle.net/10380/3053

REFERENCE
 J.G. Sled, A.P. Zijdenbos and A.C. Evans. "A Nonparametric Method
for Automatic Correction of Intensity Nonuniformity in Data" IEEE
Transactions on Medical Imaging, Vol 17, No 1. Feb 1998.

N.J. Tustison, B.B. Avants, P.A. Cook, Y. Zheng, A. Egan, P.A.
Yushkevich, and J.C. Gee. "N4ITK: Improved N3 Bias Correction" IEEE
Transactions on Medical Imaging, 29(6):1310-1320, June 2010.
See:
 itk::simple::N4BiasFieldCorrection for the procedural interface

 itk::N4BiasFieldCorrectionImageFilter for the Doxygen on the original ITK class.
'''

if __name__=="__main__":
    from deepphi.image_processing.utils import test_prep, get_image, display
    from deepphi.io.sitk import DeepPhiDataSet
    import os

    os.chdir('/home/hslisalee/Downloads/DL_team_codes/jeong_dy')
    BRAIN_TUMOUR = 'brain_tumour.hdf5'

    deepphi_dataset = DeepPhiDataSet()
    deepphi_dataset.load('brain_tumour.hdf5')

    hdf5_input = test_prep(BRAIN_TUMOUR, log=True)
    input_img = get_image(hdf5_input)

    """ Add metadata information """
    hdf5_input['image']['header']['modality'] = 'MRI'
    # hdf5_input['image']['header']['color_mode'] = 'Gray'

    bfc = N4BiasFieldCorrection()

    hdf5_output = bfc(hdf5_input)
    output_img = get_image(hdf5_output)

    num_slices = len(output_img)
    # for num, slice in enumerate(output_img):
    #     if num % 10 == 0:
    #         # display(slice, add_to_title='[After] Slice number ' + str(num))
    #         # display(input_img[num],
    #         #         add_to_title='[Original] Slice number ' + str(
    #         #             num))
    #         difference = slice - input_img[num]
    #         display(difference, add_to_title='Difference after correction ('
    #                                          'slice {}'.format(num))
    #         logging.debug('Slice #{} is on display.'.format(num))

    idx = 70
    display(input_img[idx], add_to_title='Input #{}'.format(idx))
    display(output_img[idx], add_to_title='Output #{}'.format(idx))
    # display(input_img)
    # display(output_img)
    # from deepphi.io.sitk import *
    # import matplotlib.pyplot as plt
    # import os
    #
    # os.chdir('/home/hslisalee/Downloads/DL_team_codes/jeong_dy')
    # BRAIN_TOMOUR='brain_tumour.hdf5'
    # deepphi_dataset = DeepPhiDataSet()
    # deepphi_dataset.load(BRAIN_TOMOUR)
    #
    # n4 = N4BiasFieldCorrection(numberOfIterations=None, numberOfFittingLevels=4) # default argument values
    # output_data = n4(deepphi_dataset)
    #
    # deepphi_dataset_before = DeepPhiDataSet()
    # deepphi_dataset_before.load('brain_tumour.hdf5')
    #
    # fig, ax = plt.subplots(132, 2, figsize=(10, 660))
    # ax[0][0].set_title('Image before')
    # ax[0][1].set_title('Image after Effect')
    # for i in range(10, 142):
    #     ax[i-10][0].imshow(deepphi_dataset_before['image']['array'][i], 'gray')
    #     ax[i-10][1].imshow(deepphi_dataset['image']['array'][i], 'gray')
    # plt.tight_layout()
    # plt.show()