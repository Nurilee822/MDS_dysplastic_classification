#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

import numpy as np
import cv2

from deepphi.image_processing import Preprocessing

PROCESSING_ERROR_MSG = "Exception occurred while processing: "
EMPTY_ERROR_MSG = "Exception occurred while processing data: There " \
                    "is no value in the input image array."
INPUT_TYPE_ERROR_MSG = "Exception occurred while processing data: Image " \
                         "data type is invalid. Must be in a form of array."
NP_NDARRAY = np.ndarray
NP_UINT_ = np.uint8
DTYPE_UINT8 = 'uint8'
IMAGE = 'image'
ARRAY = 'array'

"""
EXAMPLE: 

    GAMMA = 1.3
    
    adjust_gamma = GammaCorrection(gamma=GAMMA)
    hdf5_adjusted = adjust_gamma(hdf5_input)

"""


class GammaCorrection(Preprocessing):

    def __init__(self, *args, **kwargs):
        super(GammaCorrection, self).__init__(self)
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.this_module = __class__.__name__
        if isinstance(kwargs['gamma'], float):
            self.gamma = kwargs['gamma']
        elif isinstance(kwargs['gamma'], int):
            self.gamma = kwargs['gamma']
        self.lut = None

    def __call__(self, data, save_path=None):
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        self.image_processing(self.get_image_array(),
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('module processed: \t\t\t{}'.format(self.this_module))
        self.log.debug('gamma value: \t\t\t\t{}'.format(self.gamma))
        self.log.debug('Look-up table: \t\t\t\t{}'.format(self.lut))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check keyword argument value
        """

        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            if self.gamma == 0.0:
                raise KeyError("gamma value must be greater than 0.0")
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def image_processing(self, source_image, param):
        """ Generates and Performs a look-up table transform of an array.
        Ignore when gamma is 1 (there will be no change to the image)

        """
        # if self.gamma == 1:
            # output_image = source_image

        # else:
        self.compute_gamma_lut()
        output_image = self.gamma_correction(source_image)
        # Update_Info
        self.add_array(output_image, np.uint8)

    def compute_gamma_lut(self):
        """
        build a lookup table mapping the pixel values [0, 255] to their
        adjusted gamma values

        """
        invGamma = 1.0 / self.gamma
        self.lut = np.array(
                            [((i / 255.0) ** invGamma)
                             * 255
                             for i in np.arange(0, 256)]
                            ).astype("uint8")

    def gamma_correction(self, source_image):
        """apply gamma correction using the lookup table."""

        return cv2.LUT(source_image, self.lut)


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, get_image, \
        LOCAL_CHEST, L

    GAMMA = 1.3
    hdf5_input = test_prep(LOCAL_CHEST, level='L')
    adjust_gamma = GammaCorrection(gamma=GAMMA)
    hdf5_adjusted = adjust_gamma(hdf5_input)
    display(array=get_image(hdf5_adjusted),
            add_to_title='Adjusted\nGamma={}'.format(GAMMA),
            cmap=L)

    # for gamma in np.arange(0.0, 3.5, 0.5):
    #
    #     gamma = gamma if gamma > 0 else 0.1
    #     hdf5_input = test_prep(LOCAL_CHEST, level='L')
    #     adjust_gamma = GammaCorrection(gamma=gamma)
    #     hdf5_adjusted = adjust_gamma(hdf5_input)
    #     display(array=get_image(hdf5_adjusted),
    #             add_to_title='Adjusted\nGamma={}'.format(gamma),
    #             cmap=L)

