#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.config.edges_ import *
from deepphi.image_processing.utils import timeit


class EdgeAdjustment(Preprocessing):
    """Returns an edge adjusted image.

        Edge Adjustment Types:
        - Sharpening
        - Smoothing

    """

    def __init__(self, *args, **kwargs):
        """Initialization of EdgeAdjustment Class Module.

        self Variables:
            self.log        (logger)  logger for logging.
            self.args       (tbd)     input argument for image processing.
            self.kwargs     (tbd)     keyword argument for image processing.
            self.strength   (int)     Edge adjustment strength, sigma value.
        """
        super(EdgeAdjustment, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.this_module = None

        if kwargs['strength'] is not None:
            if isinstance(kwargs['strength'], float):
                self.kwargs = kwargs
                self.strength = kwargs['strength']
            elif isinstance(kwargs['strength'], int):
                self.kwargs = kwargs
                self.strength = kwargs['strength']
            else:
                raise TypeError("Strength must be in float or int type.")
        else:
            raise KeyError("Strength value must be provided.")

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.add_logs()

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        """

        # Empty_Check
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

        # Type_Check
        if isinstance(self.get_image_array(), NP_NDARRAY):
            dtype = self.get_image_array().dtype
            if dtype is not NP_UINT_:
                self.change_dtype(DTYPE_UINT8)
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply edge adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Edge_Adjustment
            output_img = self.edge_adjustment(source_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def add_logs(self):
        self.log.debug('edge adjustment type: \t{}'.format(self.this_module))
        self.log.debug('strength: \t\t\t\t{}'.format(self.strength))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

    def edge_adjustment(self, source_image):
        raise NotImplementedError

