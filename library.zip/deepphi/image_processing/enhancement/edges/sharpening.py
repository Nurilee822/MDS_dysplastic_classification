#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import sys

import numpy as np
import cv2
from deepphi.image_processing.utils import display

from deepphi.io.sitk import DeepPhiDataSet
from deepphi.image_processing.enhancement.edges import EdgeAdjustment


class Sharpening(EdgeAdjustment):
    """Return an edge enhanced image. Applies image sharpening."""

    def __init__(self, *args, **kwargs):
        """Initialization of Sharpening Class Module.

        self Variables:
            self.kwargs     (tbd)     keyword argument for image processing.
            self.strength   (float)   Edge adjustment strength, sigma value.
            self.this_module(str)     Name of the current module.
        """
        super(Sharpening, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.kwargs = kwargs
        self.strength = kwargs['strength']
        self.this_module = __class__.__name__

    def edge_adjustment(self, source_image):
        s = self.strength
        b = (1 - s) / 8

        sharpening_kernel = np.array([[b, b, b],
                                      [b, s, b],
                                      [b, b, b]])

        output_img = cv2.filter2D(source_image,
                                  -1,
                                  sharpening_kernel)
        return output_img


if __name__ == "__main__":
    from deepphi.image_processing.converter.color_mode.rgb_to_gray \
        import RGBtoGRAY
    from deepphi.image_processing.utils import LOCAL_DATA

    # Initialization

    STRENGTH = 3
    sharpening = Sharpening(strength=STRENGTH)

    rgb2gray = RGBtoGRAY()

    # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    # import hdf5 image
    hdf5_input = DeepPhiDataSet()
    hdf5_input.load(LOCAL_DATA)

    # import hdf5 image
    hdf5_input_ = DeepPhiDataSet()
    hdf5_input_.load(LOCAL_DATA)

    # Apply
    hdf5_gray = rgb2gray(hdf5_input_)

    """ COLOR IMAGE EDGE ENHANCEMENT """

    # Apply
    color_img = hdf5_input['image']['array']
    hdf5_output = sharpening(hdf5_input)
    color_sharp = hdf5_output['image']['array']

    # Display
    display(color_img, add_to_title='Color Image')
    display(color_sharp,
            add_to_title='Color Image\n(Sharpened, strength={}'.format(STRENGTH)
            )

    """ GRAYSCALE IMAGE EDGE ENHANCEMENT """

    gray_img = hdf5_gray['image']['array']
    hdf5_output = sharpening(hdf5_gray)
    gray_sharp = hdf5_output['image']['array']

    logging.shutdown()

    # display
    display(gray_img, add_to_title='GRAY Image', cmap='gray')
    display(gray_sharp,
            add_to_title='GRAY Image\n(Sharpened, strength={}'.format(STRENGTH),
            cmap='gray')


