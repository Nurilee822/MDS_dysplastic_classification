#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

import cv2

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit
from deepphi.image_processing.config.clahe_ import *

COLORS_ = ['L', 'GRAY', 'B', 'BIN']

"""
EXAMPLE: 

    THRESH = 5
    TILE_GRID_SIZE = (20, 20)
    
    contrast_adj = CustomClahe(thresh=CLAHE_THRESHOLD,
                               tile_grid_size=CLAHE_GRID_SIZE)
    hdf5_clahe = contrast_adj(hdf5_chest)

"""


class CustomClahe(Preprocessing):
    """Returns contrast adjusted input image using the customized openCV local
    adaptive histogram equalization. """

    def __init__(self, *args, **kwargs):
        """Initialization of ClaheForTissues Class Module.

        self Variables:
            self.log        (logger)  logger for logging.
            self.args       (tbd)     input argument for image processing.
            self.kwargs     (tbd)     keyword argument for image processing.
            self.acceptable_colors(int)  color mode required to process this
                                         module.
        """
        super(CustomClahe, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.acceptable_colors = COLORS_
        self.this_module = __class__.__name__

        if kwargs['tile_grid_size'] is not None:
            if isinstance(kwargs['tile_grid_size'], list):
                self.tile_grid_size = tuple(kwargs['tile_grid_size'])
            elif isinstance(kwargs['tile_grid_size'], tuple):
                self.tile_grid_size = kwargs['tile_grid_size']
        else:
            raise KeyError("tile_grid_size input is required. i.e. tile_grid_size=(20, 20)")
        if kwargs['thresh'] is not None:
            self.thresh = kwargs['thresh']
        else:
            raise KeyError("thresh input is required. i.e. thresh=5")

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('module processed: \t\t\t{}'.format(self.this_module))
        self.log.debug('CLAHE threshold: \t\t\t{}'.format(self.thresh))
        self.log.debug('CLAHE grid size: \t\t\t{}'.format(self.tile_grid_size))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            self.color_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply contrast adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Apply_CLAHE
            output_image = self.custom_clahe(source_image=source_image,
                                             threshold=self.thresh,
                                             tile_grid_size=self.tile_grid_size)

            # Update_Info
            self.add_array(output_image, DTYPE_UINT8)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def custom_clahe(self, source_image, threshold, tile_grid_size):
        """Returns local adaptive histogram equalized contrast enhanced image.

        Args:
            source_image    (ndarray) source image data
            threshold       (int)     contrast threshold limit
            tile_grid_size  (tuple)   (int, int) grid size to divide image into tiles

        Returns:
            clahe_applied (ndarray) clahe applied image array
         """

        #  Image Processing
        if threshold is None:
            threshold = CLAHE_THRESHOLD

        if tile_grid_size is None:
            tile_grid_size = CLAHE_GRID_SIZE

        CLAHE = cv2.createCLAHE(threshold, tile_grid_size)
        clahe_applied = CLAHE.apply(source_image)

        return clahe_applied


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, \
        LOCAL_CHEST, LOCAL_DATA

    data_dir = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
               '/BetaData01_Chest_cls2d/test/'
    cst = 'CST_1.hdf5'
    CLAHE_THRESHOLD = 5
    # GRID_SIZE = (20, 20)
    GRID_SIZE = [20, 20]

    # DATA = data_dir + abd
    # DATA = data_dir + cst
    # DATA = LOCAL_CHEST
    DATA = LOCAL_DATA
    hdf5_chest = test_prep(DATA, level='L', log=True)
    chest_img = hdf5_chest['image']['array']

    contrast_adj = CustomClahe(thresh=CLAHE_THRESHOLD,
                               tile_grid_size=GRID_SIZE)
    hdf5_clahe = contrast_adj(hdf5_chest)
    clahe_img = hdf5_clahe['image']['array']

    # display
    display(chest_img,
            add_to_title='Input Image',
            cmap='gray')

    display(clahe_img,
            cmap='gray',
            add_to_title='CLAHE applied with\n '
                         'thresh = {}, grid_size = {}'.format(CLAHE_THRESHOLD,
                                                              CLAHE_GRID_SIZE))
