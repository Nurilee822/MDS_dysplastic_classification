#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

import SimpleITK as sitk

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.config.clahe_ import *
from deepphi.image_processing.utils import timeit


class Clahe(Preprocessing):
    """Returns contrast adjusted input image using the simpleITK local
    adaptive histogram equalization."""
    def __init__(self, *args, **kwargs):
        """Initialization of Clahe Class Module.

        self Variables:
            self.log        (logger)  logger for logging.
            self.args       (tbd)     input argument for image processing.
            self.kwargs     (tbd)     keyword argument for image processing.
            self.this_module(str)     Name of the current module.
            self.acceptable_colors(int)  color mode required to process this
                                         module.
            self.parent_class (str)   Name of the parent class category.
        """

        super(Clahe, self).__init__(self)
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.this_module = __class__.__name__

    @timeit
    def __call__(self, data, save_path=None):
        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('module name: \t\t\t{}'.format(self.this_module))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply contrast adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Apply_CLAHE
            output_image = self.clahe(source_image)

            # Update_Info
            self.add_array(output_image, DTYPE_UINT8)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def clahe(self, source_image):
        sitk_image = sitk.GetImageFromArray(source_image)
        output_image = sitk.AdaptiveHistogramEqualization(sitk_image)

        return sitk.GetArrayFromImage(output_image)


if __name__ == "__main__":
    import sys

    from deepphi.io.sitk import DeepPhiDataSet
    from deepphi.image_processing.utils import display, LOCAL_CHEST

    # # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    # import environment settings
    hdf5_input = DeepPhiDataSet()
    hdf5_input.load(LOCAL_CHEST)

    # initialization
    clahe = Clahe()

    # Grayscale Image
    gray_img = hdf5_input['image']['array']
    hdf5_output = clahe(hdf5_input)
    gray_proc = hdf5_output['image']['array']

    display(gray_img, add_to_title='Input Image', cmap='gray')
    display(gray_proc,
            add_to_title='Applied Image\n(CLAHE applied)', cmap='gray')
