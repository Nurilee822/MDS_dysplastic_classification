#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

from deepphi.image_processing.color_processing.color_normalization \
    import StainColorNormalizer

REINHARD_ = 'Reinhard'


class ReinhardStainNormalizer(StainColorNormalizer):
    """Returns tissue-stain-color normalized hdf5 image.
    Initializes Vahadane normalizer with target image,
    Applies pre-set normalizer onto the source image.
    """

    def __init__(self, *args, **kwargs):
        """Initialization of ReinhardStainNormalizer Class Module.

        self Variables:
            self.log           (logger) logger for logging.
            self.args           (tbd)   input argument for image processing.
            self.kwargs         (tbd)   keyword argument for image processing.
        """
        super(ReinhardStainNormalizer, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.type = REINHARD_
        self.this_module = __class__.__name__

    def set_normalizer(self):
        #  Import_Color_Normalizers
        from deepphi.image_processing.color_processing.libs \
            .stain_norm_reinhard import Normalizer

        # Initiate_Color_Normalizer
        normalizer = Normalizer()

        return normalizer


if __name__ == "__main__":
    from deepphi.image_processing.utils import display
    from deepphi.io.sitk import DeepPhiDataSet
    from deepphi.image_processing.utils import LOCAL_DATA, TARGET_DATA
    import sys

    # Set Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    # import environment settings
    hdf5_source = DeepPhiDataSet()
    hdf5_target = DeepPhiDataSet()

    # import hdf5 image
    hdf5_source.load(LOCAL_DATA)
    target_data = TARGET_DATA
    hdf5_target.load(target_data)

    source_img = hdf5_source['image']['array']
    target_img = hdf5_target['image']['array']

    # run input hdf5

    scn = ReinhardStainNormalizer(target_data=target_data)
    hdf5_output = scn(source_data=hdf5_source)
    output_img = hdf5_output['image']['array']

    # display
    display(source_img, add_to_title='source image(before normalization)')
    display(output_img, add_to_title='source image(Reinhard normalization '
                                     'applied)')
    display(target_img, add_to_title='target image')
