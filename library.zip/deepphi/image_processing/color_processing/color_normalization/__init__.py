#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import sys

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.color_processing.libs.stain_utils import *
from deepphi.image_processing.utils import timeit, display


class StainColorNormalizer(Preprocessing):
    """Returns tissue-stain-color normalized hdf5 image.
    Initializes stain color normalizer with target image,
    Applies pre-set normalizer onto the source image.
    """

    def __init__(self, *args, **kwargs):
        """Initialization of StainColorNormalizer Class Module.

        self Variables:
            self.log           (logger) logger for logging.
            self.args           (tbd)   input argument for image processing.
            self.kwargs         (tbd)   keyword argument for image processing.
        """
        super(StainColorNormalizer, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.type = None
        self.this_module = __class__.__name__

        if kwargs[TARGET_DATA] is None:
            raise Exception(MANDATORY_ARGS_ERROR_MSG)
        else:
            self.kwargs = kwargs

    @timeit
    def __call__(self, source_data, save_path=None):

        self.init_data(source_data)
        self.io_error_check()
        source_img = self.get_image_array()
        target_img = get_target_data(self.kwargs[TARGET_DATA])
        self.image_processing(source_image=source_img,
                              target_image=target_img,
                              param=[self.args,
                                     self.kwargs])
        self.add_logs()

        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check imaging modality
        4. Check image color mode
        5. Check image dimension(2D)
        """
        #  1. Empty_Check
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

        #  2. Type_Check
        if isinstance(self.get_image_array(), NP_NDARRAY):
            dtype = self.get_image_array().dtype
            if dtype is not NP_UINT_:
                self.change_dtype(DTYPE_UINT8)

            #  3. Modality_Check
            assert self.get_modality() in PATHOLOGY, MODALITY_ERROR_MSG

            #  4. Color_Check
            assert self.get_color_mode() in MODE, COLOR_MODE_ERROR_MSG

            #  5. Dimension_Check
            assert self.get_image_dimension() in DIM, DIMENSION_ERROR_MSG
        else:
            raise Exception(INPUT_TYPE_ERROR_MESSAGE)

    def image_processing(self, source_image, target_image, param):
        """Generates color normalizer from target image and applies onto
        source image.

        Args:
            source_image (np.ndarray)   input image array to process color
                                        normalization.
            target_image (np.ndarray)   model image array for color
                                        normalization.
            param        (list)         input arguments: norm_type, args and
                                        kwargs.

        """
        try:
            # Initiate_Color_Normalizer
            normalizer = self.set_normalizer()
            normalizer.fit(target_image)

            # Apply_Color_Normalizer
            normalized_image = normalizer.transform(source_image)

            # Update_Info
            self.add_array(normalized_image)

        except Exception as error:
            raise Exception("Exception occurred while processing stain color "
                            "normalization: \n" + str(error))

    def add_logs(self):
        self.log.debug('module processed: \t\t{}'.format(self.this_module))
        self.log.debug('stain norm type: \t\t{}'.format(self.type))
        self.log.debug('target image data: \t\t{}'.format(
            get_name(self.kwargs[TARGET_DATA])))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

    def set_normalizer(self):
        raise ImportError


if __name__ == "__main__":
    from deepphi.image_processing.utils import LOCAL_DATA, TARGET_DATA

    # Set Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    # import environment settings
    hdf5_source = DeepPhiDataSet()
    hdf5_target = DeepPhiDataSet()

    # import hdf5 image
    hdf5_source.load(LOCAL_DATA)
    target_data = TARGET_DATA
    hdf5_target.load(TARGET_DATA)

    source_img = hdf5_source['image']['array']
    target_img = hdf5_target['image']['array']

    # run input hdf5
    scn = StainColorNormalizer(target_data=target_data)
    hdf5_output = scn(source_data=hdf5_source)

    source_img_ = hdf5_source['image']['array']

    # display
    display(source_img, add_to_title='source image(before normalization)')
    display(source_img_, add_to_title='source image(Reinhard normalization '
                                      'applied)')
    display(target_img, add_to_title='target image')
