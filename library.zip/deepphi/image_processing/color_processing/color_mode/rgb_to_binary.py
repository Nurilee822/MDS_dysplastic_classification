#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
from skimage.filters import threshold_otsu
import logging
from deepphi.image_processing.converter.color_mode import ColorMode
from deepphi.image_processing.utils import display

B = 'B'
RGB = 'RGB'
TYPE_BINARY = 0
MAXVAL = 255
COLOR_MODE_ERROR_MSG = "Exception occurred while reading data, Input array must be a 3-channel, RGB color image."


class RGBtoBINARY(ColorMode):
    """Returns a binary image. Converts 'RGB' type image to 'B' image type.

        Convert color mode from
        RGB(Red, Green, and Blue) to B(binary).

    """

    def __init__(self, *args, **kwargs):
        """Initialization of RGBtoBINARY Class Module.

        self Variables:
            self.acceptable_colors  (tbd)     list of acceptable colors.
            self.this_mode          (tbd)     color mode setting for the module.
            self.thresh             (tbd)     threshold value for binarization.
        """
        super(RGBtoBINARY, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.acceptable_colors = [RGB, B]
        self.this_mode = B
        self.thresh = None
        self.this_module = __class__.__name__
        self.error_msg = COLOR_MODE_ERROR_MSG

    def convert_color_mode(self, source_image):
        # Convert_To_Gray
        gray_img = cv2.cvtColor(source_image, cv2.COLOR_RGB2GRAY)

        # Apply_Threshold
        self.set_thresh_value(gray_img)
        _, output_img = cv2.threshold(src=gray_img,
                                      thresh=self.thresh,
                                      maxval=MAXVAL,
                                      type=TYPE_BINARY)
        return output_img

    def set_thresh_value(self, source_image):
        self.thresh = threshold_otsu(source_image)

    def add_logging(self):
        self.log.debug('threshold value: \t\t\t{}(auto)'.format(self.thresh))


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, LOCAL_DATA

    # import hdf5 image
    hdf5_input = test_prep(LOCAL_DATA, log=True)
    rgb_img = hdf5_input['image']['array']

    # run input hdf5
    rgb2bin = RGBtoBINARY()

    hdf5_output = rgb2bin(hdf5_input)
    bin_img = hdf5_output['image']['array']

    # display
    THRESH_LEVEL = 183  # ONLY for display purpose:
                        # Fill in the threshold value according to output logs.

    display(rgb_img, add_to_title='RGB Image')
    display(bin_img,
            add_to_title='BINARY Image(threshold level={})'.format(THRESH_LEVEL),
            cmap='gray')
