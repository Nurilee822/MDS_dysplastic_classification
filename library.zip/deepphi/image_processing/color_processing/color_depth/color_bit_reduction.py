#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import numpy as np
import sys
from PIL import Image
from deepphi.io.sitk import DeepPhiDataSet
import logging
from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit
from deepphi.image_processing.config.color_bit_reduction_ import *


class ColorBitReduction(Preprocessing):
    """ Returns a color-bit reduced hdf5 image.
        Applies color bit reduction (to 8-bit) on an image to convert
        RGB channel into Palette.

    """

    def __init__(self, *args, **kwargs):
        """Initialization of ColorBitReduction Class Module.

        self Variables:
            self.log        (logger)  logger for logging.
            self.args       (tbd)     input argument for image processing.
            self.kwargs     (tbd)     keyword argument for image processing.
        """
        super(ColorBitReduction, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.this_module = __class__.__name__

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        source_color_mode = self.get_color_mode().upper()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])
        output_img = self.get_image_array()

        # Logging_Info
        self.add_logs(source_image, output_img, source_color_mode)

        # Return_Output_HDF5
        return self.get_data()

    def add_logs(self, source_image, output_img, source_color_mode):
        original_image_size = str(sys.getsizeof(source_image))
        reduced_image_size = str(sys.getsizeof(output_img))
        self.log.debug('module processed: \t\t{}'.format(self.this_module))
        self.log.debug('original_image_size: \t{} (24-bit)'.format(
            original_image_size))
        self.log.debug('reduced_image_size: \t{} (8-bit)'.format(
            reduced_image_size))
        self.log.debug('original color mode: \t{}'.format(source_color_mode))
        self.log.debug('output color mode: \t\t{} (Palette)'.format(
            self.get_color_mode()))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check color mode
        """

        # Empty_Check
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

        # Type_Check
        if isinstance(self.get_image_array(), NP_NDARRAY):
            dtype = self.get_image_array().dtype
            if dtype is not NP_UINT_:
                self.change_dtype(DTYPE_UINT8)
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

        # Color_Check
        if self.get_color_mode() not in COLOR_MODE:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Applies color bit reduction (to 8-bit) on an image to convert
        color mode from RGB to Palette.
        Return a numpy array.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Convert_Color_Mode
            source_image = Image.fromarray(source_image)
            output_img = source_image.convert(MODE)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)
            self.add_color_mode(MODE)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))


if __name__ == "__main__":
    from deepphi.image_processing.utils import LOCAL_DATA

    # Setup Logger
    log = logging.getLogger()
    handler = logging.StreamHandler(sys.stdout)
    log.addHandler(handler)
    log.setLevel(logging.DEBUG)

    # import environment settings
    hdf5_input = DeepPhiDataSet()

    # import hdf5 image
    hdf5_input.load(LOCAL_DATA)

    # run input hdf5
    cbr = ColorBitReduction()
    hdf5_output = cbr(data=hdf5_input)


