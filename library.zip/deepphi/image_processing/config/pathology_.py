#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from PIL import Image
import numpy as np
import cv2


# For Big Image handling
Image.MAX_IMAGE_PIXELS = None

# For Image class variables
ACI = 'ACI'
ADEN = 'ADENOCA'
CAR = 'CARCINOID'
HYPER = 'HYPER'
TAL = 'TAL'
TAH = 'TAH'
ABNORMAL = [ADEN, HYPER, TAL, TAH]

# For Color Filtering
LOWER_HSV_THRESHOLD = np.array([0, 100, 0])
UPPER_HSV_THRESHOLD = np.array([200, 200, 200])
LOWER_RGB_THRESHOLD = np.array([0, 100, 0])
UPPER_RGB_THRESHOLD = np.array([200, 200, 200])
CLAHE = cv2.createCLAHE(5, (20, 20))
BIN_THRESH = 50
OTSU_TYPE = 0  # CV2.THRESH_BINARY
BIN = 0  # gray2bin mode variable
INV = 1  # gray2bin mode variable

# For Threshold Filters
THRESH_BINARY = cv2.THRESH_BINARY
THRESH_BINARY_INV = cv2.THRESH_BINARY_INV
THRESH_TRUNC = cv2.THRESH_TRUNC
THRESH_TOZERO = cv2.THRESH_TOZERO
THRESH_TOZERO_INV = cv2.THRESH_TOZERO_INV

SIMPLE_THRESH = 50

THRESH_MAXVAL = 255
THRESH_TYPE = 0

# For cropout contours
AREA_THRESH = 1500

# For coloring border area for aspect_ratio resize
COLOR_RGB = [256, 256, 256]

# For handling image processing, opening, dilation, and threshold for artifacts
OPENING_STRUCT_ELEMENT = (4, 5)
DILATE_STRUCT_ELEMENT = (30, 30)
OBJ_DETECT_THRESHOLD = 20

# For mask creation and fine_tuning.
COLORS = ["red", "green", "blue", "orange", "yellow", "pink", "white"]
DILATION_INTENSITY = 15

# For unit test : data path
SVS_DIR = '/home/hslisalee/DEEPPHI/datasets/crc/svs/'
XML_DIR = '/home/hslisalee/DEEPPHI/datasets/crc/xml/'

SAMPLE_SVS = SVS_DIR + '1035154_.svs'
SAMPLE_XML = XML_DIR + '1035154_.xml'

# For stain normalization test
SOURCE_SVS = SAMPLE_SVS
TARGET_SVS = SVS_DIR + '1035155_.svs'

# For histogram plot
HIST_SIZE = [15, 10]
PLOT_RANGE = [0, 255]

# For CLAHE
CLAHE_THRESHOLD = 5
CLAHE_GRID_SIZE = (20, 20)

# For Edge Enhancement
SHARPENING_STRENGTH = 2

# For Edge Smoothing
SMOOTHING_STRENGTH = 1

# For Saving Image Processing Outputs
SAVE_OUTPUT = '/home/hslisalee/DEEPPHI/image_processing/output'


def shape(image):
    if not isinstance(image, np.ndarray):
        image = np.asarray(image)
    return image.shape


