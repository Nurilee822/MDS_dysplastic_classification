#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import numpy as np

PROCESSING_ERROR_MSG = "Exception occurred while image thresholding: "
EMPTY_ERROR_MSG = "Exception occurred while processing data: There " \
                    "is no value in the input image array."
INPUT_TYPE_ERROR_MSG = "Exception occurred while processing data: Image " \
                         "data type is invalid. Must be in a form of array."
COLOR_MODE_ERROR_MSG = "Exception occurred while reading data: " \
                        "\nInput array must be in Grayscale of 256 levels."

NP_NDARRAY = np.ndarray
NP_UINT_ = np.uint8
PARENT_CLASS = 'enhancement'
DTYPE_UINT8 = 'uint8'

