#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import numpy as np

DIMENSION_ERROR_MSG = "Exception occurred while processing data: " \
                      "Image dimension is invalid. " \
                      "Stain color normalization only accepts 2D images."

INPUT_TYPE_ERROR_MESSAGE = "Exception occurred while processing data: Image " \
                            "data type is invalid. Must be in a form of array."

COLOR_MODE_ERROR_MSG = "Exception occurred while reading data: " \
                       "\nInput array must be a 3-channel, RGB color image."

MODALITY_ERROR_MSG = "Exception occurred while reading data: \nStain color " \
                     "normalization can only be applied to pathology images."

EMPTY_ERROR_MSG = "Exception occurred while importing data: There is " \
                  "no value in the input image array."

FORMAT_ERROR_MSG = "Exception occurred while processing target data:\n " \
                   "Data format must be one of the following - " \
                   "'.svs', '.tif', '.png', or '.hdf5'(recommended)."

DNE_ERROR_MSG = "Exception occurred while processing target data: " \
                   "\nFile does not exist."

MANDATORY_ARGS_ERROR_MSG = "Exception occurred while reading target data:\n" \
                            "Expects a target data. This parameter is " \
                            "mandatory. Should be in formats of '.svs', " \
                            "'.png', '.tif' or '.hdf5'."

NP_NDARRAY = np.ndarray
NP_UINT_ = np.uint8

VAHADANE_ = 'Vahadane'
MACENKO_ = 'Macenko'
REINHARD_ = 'Reinhard'
COLOR_MODE = 'color_mode'
MODALITY = 'modality'
HISTORY = 'history'
HEADER = 'header'
ARRAY = 'array'
IMAGE = 'image'
DIM = '2'
DTYPE_UINT8 = 'uint8'
MODE = ['RGB', 'rgb']
PATHOLOGY = ['pathology', 'Pathology']
PARENT_CLASS = 'color_processing'

TIFF_ = 'TIFF'
TIF_ = 'TIF'
HDF_ = 'HDF5'
PNG_ = 'PNG'
SVS_ = 'SVS'
TIFS_ = [TIF_, TIFF_]
FORMATS_ = [SVS_, PNG_, HDF_, TIF_, TIFF_]

TARGET_DATA = 'target_data'
