#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import numpy as np
import matplotlib.pyplot as plt
from skimage.color import rgb2gray
from skimage import data
from skimage.filters import gaussian
from skimage.segmentation import active_contour

from deepphi.image_processing.utils import test_prep, display, get_image, \
    LOCAL_DATA, LOCAL_CHEST

# DATA = LOCAL_DATA
DATA = LOCAL_CHEST
hdf5_data = test_prep(DATA, log=True)
img = get_image(hdf5_data)
# img = data.astronaut()
img = rgb2gray(img)

# Setup Init
height, width = np.shape(img)
s = np.linspace(0, 2*np.pi, 400)
r = height/2 + height/2*np.sin(s)
c = width/2 + width/2*np.cos(s)
init = np.array([r, c]).T

"""
 Active contours by fitting snakes to features of images. Supports single
    and multichannel 2D images. Snakes can be periodic (for segmentation) or
    have fixed and/or free ends.
    The output snake has the same length as the input boundary.
    As the number of points is constant, make sure that the initial snake
    has enough points to capture the details of the final contour.
"""
# Active Contour
snake = active_contour(gaussian(img, 3),
                       init,
                       alpha=0.015,
                       beta=10,
                       gamma=0.001)

# Display
fig, ax = plt.subplots(figsize=(7, 7))
ax.imshow(img, cmap='gray')
ax.plot(init[:, 1], init[:, 0], '--r', lw=3)
ax.plot(snake[:, 1], snake[:, 0], '-b', lw=3)
ax.set_xticks([]), ax.set_yticks([])
ax.axis([0, img.shape[1], img.shape[0], 0])

plt.show()
