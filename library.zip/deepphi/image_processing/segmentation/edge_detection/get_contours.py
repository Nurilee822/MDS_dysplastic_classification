#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
import logging
import numpy as np

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit

ALL_CONTOURS = -1
B_ = 'B'
COLOR_ = 200
WIDTH_ = 1

"""
EXAMPLE: 

    AREA_THRESH = 60
    LINE_COLOR = 175
    LINE_WIDTH = 5

    get_contours = GetContours(area_thresh=AREA_THRESH,
                               line_color=LINE_COLOR,
                               line_width=LINE_WIDTH)
    hdf5_output = get_contours(hdf5_mask_wsi)

"""


class GetContours(Preprocessing):
    """Returns contours in a binary image as a list of pixel coordinates."""

    def __init__(self, *args, **kwargs):
        """Initialization of GetContours Class Module.

        self Variables:
            self.area_thresh    (int)   object area limit for computing contours
            self.line_color     (int)   contour line color for visualization
            self.line_width     (int)   contour line width for visualization
            self.log            (logger) logger for logging.
            self.args           (tbd)   input argument for image processing.
            self.kwargs         (tbd)   keyword argument for image processing.
            self.acceptable_colors (list)   list of acceptable colors.
            self.cnt_array      (ndarray) contours image array.
            self.cnt_coords     (ndarray) coordinates list of contours.
        """
        super(GetContours, self).__init__(self)
        self.log = logging.getLogger()
        if kwargs['area_thresh'] is None:
            self.area_thresh = 0
        else:
            self.area_thresh = kwargs['area_thresh']
        if kwargs['line_color'] is None:
            self.line_color = COLOR_
        else:
            self.line_color = kwargs['line_color']
        if kwargs['line_width'] is None:
            self.line_width = WIDTH_
        else:
            self.line_width = kwargs['line_width']

        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.acceptable_colors = B_
        self.cnt_array = None
        self.contours = None
        self.this_module = __class__.__name__

    @timeit
    def __call__(self, source_data, save_path=None):
        self.init_data(source_data)
        self.io_error_check()

        source_img = self.get_image_array()
        self.image_processing(source_image=source_img,
                              param=[self.args,
                                     self.kwargs])
        output_data = self.update_data()
        self.add_logs()

        return output_data

    def update_data(self):
        output_data = self.get_data()
        output_data['image']['get_contours'] = dict()
        output_data['image']['get_contours']['array'] = self.cnt_array
        output_data['image']['get_contours']['contours'] = self.contours
        output_data['image']['get_contours']['num_contours'] = len(
            self.contours)

        return output_data

    def add_logs(self):
        self.log.debug('module processed: \t\t{}'.format(self.this_module))
        self.log.debug('minimum area limit: \t{}'.format(self.area_thresh))
        self.log.debug('number of contours: \t{}'.format(len(self.contours)))
        # self.log.debug('contours: \t\t\t\t{}'.format(self.contours))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """

        self.empty_check()
        if isinstance(self.get_image_array(), np.ndarray):
            self.type_check()
            self.color_check()
        else:
            raise Exception("Input image data must be an ndarray.")

    def image_processing(self, source_image, param):
        """Get contours of binary image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Get_Contours
            self.get_contours(source_image)
            # Draw_Contours
            self.draw_contours(source_image)

            # Update_Info
            self.add_array(self.cnt_array, 'uint8')

        except Exception as error:
            raise Exception("Exception occurred while processing" + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception("Input data has an empty array.")

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not np.uint8:
            self.change_dtype('uint8')

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception("Input data must be a binary image.")

    def get_contours(self, source_image):
        # find contours
        contours, _ = cv2.findContours(source_image,
                                       cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)

        # find contours of large enough area
        min_obj_area = self.area_thresh
        self.contours = [cnt for cnt in contours if
                         cv2.contourArea(cnt) > min_obj_area]

    def draw_contours(self, bin_image):
        self.cnt_array = cv2.drawContours(image=bin_image,
                                          contours=self.contours,
                                          contourIdx=ALL_CONTOURS,
                                          color=self.line_color,
                                          thickness=self.line_width
                                          )


if __name__ == "__main__":
    from deepphi.image_processing.utils import LOCAL_DATA, test_prep, \
        display, get_image
    from deepphi.image_processing.computational_anatomy.pathology\
        .generate_tissue_mask.libs.generate_tissue_mask_wsi import \
        GenerateTissueMaskWsi

    L = 'gray'
    B = 'B'
    IDX_DATA = 0
    IMAGE = 'image'
    ARRAY = 'array'

    # DATA = '/home/hslisalee/DEEPPHI/io/hdf5/svs/1035154_lv2.hdf5'
    DATA = LOCAL_DATA
    # hdf5_input = test_prep(DATA, log=True, level=B)
    # bin_img = get_image(hdf5_input)
    # display(bin_img, cmap=L)

    DILATION_INTENSITY = 15
    BIN_AT = 50
    LOWER_RGB_THRESHOLD = [0, 100, 0]
    UPPER_RGB_THRESHOLD = [200, 200, 200]

    AREA_THRESH = 60
    LINE_COLOR = 175
    LINE_WIDTH = 15

    """ PROCESSING """
    hdf5_input = test_prep(DATA)
    create_mask_img = GenerateTissueMaskWsi(strength=DILATION_INTENSITY,
                                            bin_thresh=BIN_AT,
                                            lower_thresh=LOWER_RGB_THRESHOLD,
                                            upper_thresh=UPPER_RGB_THRESHOLD)

    hdf5_mask_wsi = create_mask_img(hdf5_input)
    display(get_image(hdf5_mask_wsi), cmap=L)

    get_contours = GetContours(area_thresh=AREA_THRESH,
                               line_color=LINE_COLOR,
                               line_width=LINE_WIDTH)
    hdf5_output = get_contours(hdf5_mask_wsi)
    display(get_image(hdf5_output), cmap=L)

    # dirs = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5/' \
    #        'BetaData01_Chest_cls2d/test/'
    # lst = data_list(dirs)
    # DATA = dirs + lst[IDX_DATA]

    # dirs = test_dirs()
    # IDX_DIR = 0
    # for file in lst:
    #     DATA = dirs[IDX_DIR] + file
    #
    #     hdf5_input = test_prep(DATA, log=True, level=B)
    #     bin_img = get_image(hdf5_input)
    #     # display(bin_img, cmap=L)
    #
    #     AREA_THRESH = 10
    #     LINE_COLOR = 150
    #     LINE_WIDTH = 2
    #     get_contours = GetContours(area_thresh=AREA_THRESH, line_color=LINE_COLOR,
    #                                line_width=LINE_WIDTH)
    #     hdf5_output = get_contours(hdf5_input)
    #     display(get_image(hdf5_output), cmap=L)
