#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import numpy as np
from deepphi.image_processing.segmentation.patch_extraction import \
    PatchExtraction


class RectangularGrid(PatchExtraction):
    def __init__(self, shape=[64, 64], strides=[8, 8], padding=False):
        super(RectangularGrid, self).__init__(shape=shape)
        self.shape = shape
        self.strides = strides
        self.padding = padding
        self.data = None

    def __call__(self, data):
        self.data = data
        self.init_data(data)
        self.io_error_check()

        original_image = self.get_data()['image']
        original_shape = original_image['array'].shape

        self.num_patches = (np.subtract(original_shape,
                                        self.size[::-1]) / self.strides).astype(
            int) + 1
        if self.padding:
            for idx in range(len(self.shape)):
                if (self.num_patches[idx] - 1) * self.strides[idx] + self.shape[idx] < original_shape[idx]:
                    self.num_patches[idx] += 1

        X, Y = np.meshgrid(
            np.linspace(0, self.strides[0] * self.num_patches[0],
                        self.num_patches[0], endpoint=False),
            np.linspace(0, self.strides[1] * self.num_patches[1],
                        self.num_patches[1], endpoint=False))

        indicies = [(int(ox), int(oy)) for ox, oy in
                    zip(X.T.ravel(), Y.T.ravel())]

        return super(RectangularGrid, self).__call__(data, indicies=indicies)

    def io_error_check(self, origin=None, index=None):
        info = self.data['image']['header']
        color_mode = info['color_mode']
        assert color_mode in ['L']


if __name__ == '__main__':
    import matplotlib.pyplot as plt
    from deepphi.io.sitk import *
    from deepphi.image_processing.utils import display, test_prep, LOCAL_CHEST

    # data = DeepPhiDataSet()
    # data.read_image('./samples/filename.jpeg')
    data = test_prep(LOCAL_CHEST, level='L', log=True)
    display(data['image']['array'], cmap='gray')

    extractor = RectangularGrid(shape=[256, 256], strides=[256, 256],
                                padding=False)
    patches = extractor(data)
    plt.figure(figsize=(15, 10))
    for idx, patch in enumerate(patches):
        ax = plt.subplot(*extractor.num_patches, idx + 1)
        plt.imshow(patch['image']['array'], cmap='gray')
        ax.axis('off')

    extractor = RectangularGrid(shape=[256, 256], strides=[256, 256],
                                padding=True)
    patches = extractor(data)
    plt.figure(figsize=(15, 10))
    for idx, patch in enumerate(patches):
        ax = plt.subplot(*extractor.num_patches, idx + 1)
        plt.imshow(patch['image']['array'], cmap='gray')
        ax.axis('off')