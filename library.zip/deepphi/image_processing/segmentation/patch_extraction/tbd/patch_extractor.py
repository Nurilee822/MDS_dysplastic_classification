#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import numpy as np
from deepphi.image_processing.preprocessing.data_transform import Resampler


class PatchExtraction(Resampler):
    def __init__(self,
                 shape=None,
                 size=None,
                 spacing=None,
                 dtype=None):
        super(PatchExtraction, self).__init__(shape=shape,
                                              size=size,
                                              spacing=spacing,
                                              dtype=dtype)
        self.logger = logging.getLogger()

    def __call__(self,
                 data,
                 origins=None,
                 indicies=None,
                 directions=None,
                 shape=None,
                 size=None,
                 spacing=None):
        if (shape is not None) or (size is not None):
            self.size = self._convert_size(shape, size)
        if spacing is not None:
            self.spacing = spacing

        results = []
        for origin, index, direction in zip(*self._init_args(origins, indicies, directions)):
            results.append(super(PatchExtraction, self).__call__(data, origin, index, direction))
        return results

    def _init_args(self, *args):
        NoneType = type(None)
        lens = []
        for value in args:
            if type(value) == NoneType:
                lens.append(0)
            else:
                lens.append(1)
        if lens == [0, 0, 0]:
            raise Exception
        elif lens == [0, 0, 1]:
            return [None] * len(args[2]), [None] * len(args[2]), args[2]
        elif lens == [0, 1, 0]:
            return [None] * len(args[1]), args[1], [None] * len(args[1])
        elif lens == [1, 0, 0]:
            return args[0], [None] * len(args[0]), [None] * len(args[0])
        elif lens == [0, 1, 1]:
            assert len(args[1]) == len(args[2])
            return [None] * len(args[1]), args[1], args[2]
        elif lens == [1, 0, 1]:
            assert len(args[0]) == len(args[2])
            return args[0], [None] * len(args[0]), args[2]
        elif lens == [1, 1, 0]:
            assert len(args[0]) == len(args[1])
            return args[0], args[1], [None] * args[0]
        else:
            assert len(args[0]) == len(args[1]) == len(args[2])
            return args