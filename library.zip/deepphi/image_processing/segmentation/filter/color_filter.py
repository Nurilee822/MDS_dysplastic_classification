#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

import cv2
import numpy as np
from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit

RGB = 'RGB'
HSV = 'HSV'
COLORS_ = [RGB, HSV]
COLOR_MODE_ERROR_MSG = "Exception occurred while reading data, Input array must be a 3-channel, RGB or HSV color image."
PROCESSING_ERROR_MSG = "Exception occurred while converting image color mode: "
EMPTY_ERROR_MSG = "Exception occurred while processing data: There " \
                    "is no value in the input image array."
INPUT_TYPE_ERROR_MSG = "Exception occurred while processing data: Image " \
                         "data type is invalid. Must be in a form of array."

NP_NDARRAY = np.ndarray
NP_UINT_ = np.uint8
DTYPE_UINT8 = 'uint8'

"""
EXAMPLE:
    (HSV input case)
    
    LOWER_B=[130, 0, 0]
    UPPER_B=[180, 255, 255]
     
    color_filter = ColorFilter(lower_b=LOWER_B,
                               upper_b=UPPER_B)
    hdf5_input_filtered = color_filter(hdf5_input)

"""


class ColorFilter(Preprocessing):
    """Returns a binary mask image of the specified color range."""

    def __init__(self, *args, **kwargs):
        """Initialization of ColorFilter Class Module.

        self Variables:
            self.log        (logger)    logger for logging.
            self.args       (tbd)       input argument for image processing.
            self.kwargs     (tbd)       keyword argument for image processing.
            self.acceptable_colors(int) color mode required to process this
                                        module.
            self.this_mode   (tbd)      color mode setting for the module.
            self.lower_b    (ndarray)   lower boundary HSV values:
                                        Array of 'Hue', 'Saturation' and 'Value'
            self.upper_b    (ndarray)   upper boundary HSV values:
                                        Array of 'Hue', 'Saturation' and 'Value'
        """
        super(ColorFilter, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.acceptable_colors = COLORS_
        self.this_mode = 'B'
        self.this_module = __class__.__name__

        if kwargs['lower_b'] is not None:
            if kwargs['upper_b'] is not None:
                self.lower_b = np.array(kwargs['lower_b'])
                self.upper_b = np.array(kwargs['upper_b'])
                self.kwargs = kwargs
            else:
                raise KeyError("Upper boundary list must be provided.")
        else:
            raise TypeError("Lower boundary list must be provided.")

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        original_color_mode = self.get_color_mode().upper()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])
        updated_color_mode = self.get_color_mode().upper()

        # Logging_Info
        self.log.debug('module processed: \t\t\t{}'.format(self.this_module))
        self.log.debug('Lower boundary: \t\t\t{}'.format(self.lower_b))
        self.log.debug('Upper boundary: \t\t\t{}'.format(self.upper_b))
        self.log.debug('Original Color Mode: \t\t{}'.format(
            original_color_mode))
        self.log.debug('Updated Color Mode: \t\t{}'.format(updated_color_mode))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            self.color_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply edge adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Color_Filter: takes image, generates filtered image.
            output_img = self.non_tissue_color_filter(source_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)
            self.add_color_mode(self.this_mode.upper())

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def non_tissue_color_filter(self, source_image):
        """Masks out image by color range of [lower_b, upper_b].
        Args:
            source_image    (ndarray)   3-Channel HSV color image.
        Returns:
            filtered_mask   (ndarray)   Binary area mask of filtered color area.
        """

        filtered_mask = cv2.inRange(src=source_image,
                                    lowerb=self.lower_b,
                                    upperb=self.upper_b)
        return filtered_mask


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, LOCAL_DATA

    DATA = LOCAL_DATA
    L = 'gray'
    HSV = 'HSV'
    ARRAY = 'array'
    IMAGE = 'image'

    """  Setup Keyword Arguments  """

    LOWER_RGB_THRESHOLD = [0, 100, 0]
    UPPER_RGB_THRESHOLD = [200, 200, 200]
    LOWER_HSV_THRESHOLD = [130, 0, 0]
    UPPER_HSV_THRESHOLD = [180, 255, 255]

    # LOWER_B = None
    # UPPER_B = None

    """  Apply Color Filter  : RGB """

    # hdf5_rgb = test_prep(DATA, log=True)
    # rgb_img = hdf5_rgb[IMAGE][ARRAY]
    # LOWER_B = LOWER_RGB_THRESHOLD
    # UPPER_B = UPPER_RGB_THRESHOLD

    """  Apply Color Filter  : HSV """

    hdf5_input = test_prep(DATA, level='HSV', log=True)
    input_img = hdf5_input[IMAGE][ARRAY]
    LOWER_B = LOWER_HSV_THRESHOLD
    UPPER_B = UPPER_HSV_THRESHOLD

    color_filter = ColorFilter(lower_b=LOWER_B,
                               upper_b=UPPER_B)

    hdf5_input_filtered = color_filter(hdf5_input)
    mask_img = hdf5_input_filtered[IMAGE][ARRAY]

    display(input_img)
    display(mask_img,
            add_to_title='RGB Color Filtered Image'
                         '\n(boundary={}, {})'.format(LOWER_B,
                                                      UPPER_B),
            cmap=L)

    combined_img = cv2.bitwise_and(input_img, input_img, mask=mask_img)

    display(combined_img,
            add_to_title='RGB Color Filtered Image Applied Onto Original RGB.',
            cmap=L)
