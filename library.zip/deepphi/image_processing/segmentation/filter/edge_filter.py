#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import numpy as np
from skimage.filters import sobel, sobel_h, sobel_v
from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit


PROCESSING_ERROR_MSG = "Exception occurred while image processing: "
EMPTY_ERROR_MSG = "Exception occurred while processing data: There is no value in the input image array."
INPUT_TYPE_ERROR_MSG = "Exception occurred while processing data: Image data type is invalid. Must be in a form of array."
COLOR_MODE_ERROR_MSG = "Exception occurred while reading data: \nInput array must be a binary image."
NP_NDARRAY = np.ndarray
NP_UINT_ = np.uint8
DTYPE_UINT8 = 'uint8'
COLORS_ = ['B']
DIRECTIONS_ = ['V', 'H', 'A']


"""
EXAMPLE: 

    DIRECTION='Horizontal' ('Any', 'Horizontal' or 'Vertical') 
    
    edge_filter = EdgeFilter(direction=DIRECTION)
    hdf5_input_filtered = edge_filter(hdf5_b)

"""


class EdgeFilter(Preprocessing):
    """Returns a binary image containing object edges. Sobel Edge Filter."""

    def __init__(self, *args, **kwargs):
        """Initialization of EdgeFilter Class Module.

        self Variables:
            self.log        (logger)    logger for logging.
            self.args       (tbd)       input argument for image processing.
            self.kwargs     (tbd)       keyword argument for image processing.
            self.acceptable_colors(int) color mode required to process this
                                        module.

        """
        super(EdgeFilter, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.acceptable_colors = COLORS_
        self.kwargs = kwargs
        self.this_module = __class__.__name__

        if kwargs['direction'] is not None:
            if isinstance(kwargs['direction'], str):
                self.direction = kwargs['direction'].capitalize()
                if self.direction[0] not in DIRECTIONS_:
                    raise KeyError("Edge direction is optional(vertical or "
                                   "horizontal.)")
        else:
            self.direction = None

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('module processed: \t\t\t{}'.format(self.this_module))
        self.log.debug('Filter Type: \t\t\t\tSobel')
        if self.direction is None:
            self.log.debug('Detecting: \t\t\t\t\tEdges')
        else:
            self.log.debug('Detecting: \t\t\t\t\t{} Edges'.format(self.direction))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            self.color_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply sobel filter to source image and extract object edges.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Edge_Filter: takes image, generates filtered image.
            output_img = self.filter(source_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def filter(self, source_image):
        """Masks out image by range of [lower_b, upper_b].
        Args:
            source_image    (ndarray)   binary input source image
                                        (8-bit single-channel image).
        Returns:
            filtered_mask   (ndarray)   binary area-filtered image.
        """
        if self.direction[0] == 'V':
            filtered_edges = sobel_v(source_image)
        elif self.direction[0] == 'H':
            filtered_edges = sobel_h(source_image)
        else:
            filtered_edges = sobel(source_image)
        return filtered_edges * 255


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, \
        LOCAL_DATA
    from deepphi.image_processing.segmentation.morphological_operation.dilation \
        import Dilation

    DATA = LOCAL_DATA
    ARRAY = 'array'
    IMAGE = 'image'
    L = 'gray'

    """  Setup Keyword Arguments  """

    DIRECTION = 'Any'  # None, 'Horizontal' or 'Vertical'

    """  Apply Edge Filter """

    hdf5_b = test_prep(DATA,
                       level='B',
                       log=True)
    bin_img = hdf5_b[IMAGE][ARRAY]
    edge_filter = EdgeFilter(direction=DIRECTION)
    hdf5_input_filtered = edge_filter(hdf5_b)
    mask_img = hdf5_input_filtered[IMAGE][ARRAY]

    dilation = Dilation(strel=5,
                        se_shape=None)
    hdf5_dilated = dilation(hdf5_b)
    dilated_img = hdf5_dilated['image']['array']
    hdf5_input_filtered = edge_filter(hdf5_dilated)
    dil_mask_img = hdf5_input_filtered[IMAGE][ARRAY]

    display(bin_img, add_to_title='binary input image', cmap=L)
    display(mask_img, add_to_title='sobel edge filtered image', cmap='gray')
    display(dil_mask_img, add_to_title='dilated mask image', cmap='gray')
