#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2

from deepphi.image_processing.segmentation.filter.color_filter import \
    ColorFilter
from deepphi.image_processing.utils import display, test_prep
from deepphi.image_processing.segmentation.morphological_operation.closing \
    import Closing
from deepphi.image_processing.segmentation.morphological_operation.opening \
    import Opening
from deepphi.image_processing.segmentation.morphological_operation.dilation \
    import Dilation
import numpy as np


DATA = '../../../data/1035154_lv2.hdf5'
L = 'gray'
HSV = 'HSV'
ARRAY = 'array'
IMAGE = 'image'

hdf5_rgb = test_prep(DATA)
rgb_img = hdf5_rgb[IMAGE][ARRAY]

MODULE_NAME = 'ColorFilter'
MODULE_ID = '1234'
LOWER_B = np.array([130, 0, 0])
UPPER_B = np.array([180, 255, 255])
hdf5_input = hdf5_rgb
input_img = rgb_img

display(rgb_img,
        add_to_title='Input Image',
        cmap=L)

color_filter = ColorFilter(module_name=MODULE_NAME,
                           module_id=MODULE_ID,
                           lower_b=LOWER_B,
                           upper_b=UPPER_B)

hdf5_input_filtered = color_filter(hdf5_input)
mask_img = hdf5_input_filtered[IMAGE][ARRAY]

display(mask_img,
        add_to_title='Color Filtered Image'
                     '\n(boundary={}, {})'.format(LOWER_B,
                                                  UPPER_B),
        cmap=L)

MODULE_NAME = 'Dilation'
MODULE_ID = '1234'
dilation = Dilation(se_shape=(10, 10),
                    module_name=MODULE_NAME,
                    module_id=MODULE_ID)

hdf5_dilated = dilation(hdf5_input_filtered)
dilated_img = hdf5_dilated['image']['array']

display(dilated_img, add_to_title='dilated mask image', cmap='gray')


closing = Closing(se_shape=(10, 30),
                  module_name=MODULE_NAME,
                  module_id=MODULE_ID)

hdf5_closed = closing(hdf5_opened)
closed_img = hdf5_closed['image']['array']
display(closed_img, add_to_title='Morphological Operations Applied onto Color Filtered Mask.', cmap='gray')


MODULE_NAME = 'Opening'
MODULE_ID = '1234'
opening = Opening(se_shape=(10, 30),
                  module_name=MODULE_NAME,
                  module_id=MODULE_ID)
hdf5_opened = opening(hdf5_dilated)
opened_img = hdf5_opened['image']['array']
display(opened_img, add_to_title='opened mask image', cmap='gray')


#
# MODULE_NAME = 'Opening'
# MODULE_ID = '1234'
#
# opening = Opening(se_shape=(1, 15),
#                   module_name=MODULE_NAME,
#                   module_id=MODULE_ID)
#
# hdf5_opened = opening(hdf5_input_filtered)
# opened_img = hdf5_opened['image']['array']
#
# display(opened_img, add_to_title='opened mask image', cmap='gray')

mask_img = dilated_img
combined_img = cv2.bitwise_and(rgb_img, rgb_img, mask=mask_img)


display(combined_img, add_to_title=''
'Morphological Operations Applied onto '
                                   'Color Filtered Mask.'
                                   '\nCombined with input RGB image',
        cmap=L)

# MODULE_NAME = 'Opening'
# MODULE_ID = '1234'
#
# opening = Opening(se_shape=(50, 1),
#                   module_name=MODULE_NAME,
#                   module_id=MODULE_ID)
#
# hdf5_opened = opening(hdf5_input_filtered)
# opened_img = hdf5_opened['image']['array']
#
# display(opened_img, add_to_title='opened mask image', cmap='gray')
#
#
# #
# MODULE_NAME = 'Closing'
# MODULE_ID = '1234'
#
# closing = Closing(se_shape=(10, 30),
#                   module_name=MODULE_NAME,
#                   module_id=MODULE_ID)
#
# hdf5_closed = closing(hdf5_opened)
# closed_img = hdf5_closed['image']['array']
# display(closed_img, add_to_title='Morphological Operations Applied onto Color Filtered Mask.', cmap='gray')
#
# mask_img = closed_img
#
# combined_img = cv2.bitwise_and(input_img, input_img, mask=mask_img)
# display(input_img,
#         add_to_title='Input Image',
#         cmap=L)

# display(combined_img,
#         add_to_title=''
#         # 'Morphological Operations Applied onto '
#                      'Color Filtered Mask. '
#                      '\nCombined with input HSV image',
#         cmap=L)


# opening = Opening(se_shape=(30, 5),
#                   module_name=MODULE_NAME,
#                   module_id=MODULE_ID)
# hdf5_opened = opening(hdf5_input_filtered)
# opened_img = hdf5_opened['image']['array']
#
# display(opened_img, add_to_title='opened mask image', cmap='gray')
#
# opening = Opening(se_shape=(5, 30),
#                   module_name=MODULE_NAME,
#                   module_id=MODULE_ID)
#
# hdf5_opened = opening(hdf5_input_filtered)
# opened_img = hdf5_opened['image']['array']
#
# display(opened_img, add_to_title='opened mask image', cmap='gray')

# filtered_img = cv2.bitwise_and(rgb_img, rgb_img, mask=mask_img)
# display(filtered_img, add_to_title='filtered image', cmap='gray')
# display(rgb_img, add_to_title='rgb image', cmap='gray')
#
# opened_filtered_img = cv2.bitwise_and(rgb_img, rgb_img, mask=closed_img)
# display(opened_filtered_img, add_to_title='closed filtered image', cmap='gray')

# row, col, plane = input_img.shape
# blue = np.zeros((row, col, plane), np.uint8)
# blue[:, :, 0] = input_img[:, :, 0]
# display(blue, add_to_title='blue')
#
# green = np.zeros((row, col, plane), np.uint8)
# green[:, :, 1] = input_img[:, :, 1]
# display(blue, add_to_title='green')
#
# red = np.zeros((row, col, plane), np.uint8)
# red[:, :, 2] = input_img[:, :, 2]
# display(blue, add_to_title='red')

# LOWER_RGB_THRESHOLD = np.array([0, 100, 0])
# UPPER_RGB_THRESHOLD = np.array([200, 200, 200])
# hsv_image = cv2.cvtColor(rgb_img, cv2.COLOR_RGB2HSV)
# mask = cv2.inRange(hsv_image,
#                    LOWER_RGB_THRESHOLD,
#                    UPPER_RGB_THRESHOLD)
#
# display(hsv_image)
# display(mask)
#
# """ TEST """
# # Read
# # img = cv2.imread("sunflower.jpg")
# img = rgb_img
#
# # # convert to hsv
# # hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
# hsv = input_img
#
# # # mask of pink/purple (130, 0, 0), (180, 255, 255)
# mask1 = cv2.inRange(hsv, (130, 0, 0), (180, 255, 255))
#
# # # mask o red (0, 0, 0), (20, 255, 255)
# # mask2 = cv2.inRange(hsv, (0, 0, 0), (20, 255, 255))
#
# # # final mask and masked
# # mask = cv2.bitwise_or(mask1, mask2)
# target = cv2.bitwise_and(img, img, mask=mask1)
# L = 'gray'
# display(mask1, add_to_title='mask1_pink/purple', cmap=L)
# # display(mask2, add_to_title='mask2_red', cmap=L)
# # display(mask, add_to_title='bitwise_or mask1 or mask2', cmap=L)
# display(target, add_to_title='bitwise_and img and mask', cmap=L)
# # cv2.imwrite("target.png", target)