#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.segmentation.edge_detection.get_contours import \
    GetContours
from deepphi.image_processing.utils import *

PROCESSING_ERROR_MSG = "Exception occurred while image processing: "
EMPTY_ERROR_MSG = "Exception occurred while processing data: rect coordinate value is empty."
INPUT_TYPE_ERROR_MSG = "Exception occurred while processing data: Image data type is invalid. Must be in a form of array."
COLOR_MODE_ERROR_MSG = "Exception occurred while reading data: \nInput array must be a 3 channel RGB image."
NP_UINT_ = np.uint8
NP_NDARRAY = np.ndarray
DTYPE_UINT8 = 'uint8'
COLOR_MODE = ['B']
RATIO = 1/6


class MergeOverlaps(Preprocessing):
    """ Returns a list of cropped tissues image after iteratively merging
        smaller pieces if their boundary overlaps.
    """

    def __init__(self, *args, **kwargs):
        super(MergeOverlaps, self).__init__(self)
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.applied_processes = list()
        self.rect_list = None
        self.rect_out = None
        self.output_mask_list = None
        if kwargs['flexible_space'] is not None:
            if isinstance(kwargs['flexible_space'], int):
                self.flexible_space = kwargs['flexible_space']
            else:
                raise TypeError("flexible space must be type int.")

    def __call__(self, data, save_path=None):
        """ Returns list of cropped tissues image after iteratively merging
        smaller pieces if their boundary overlaps.

        Args:
            data      (hdf5)    hdf5 data with binary tissue mask in 'array'
            save_path (str)     path to save data

        Returns:
            hdf5_co_tissues  (hdf5)  hdf5 data with tissues list

        """

        # IO_Error_Check
        self.init_data(data)
        self.get_contours()
        contours = data['image']['get_contours']['contours']
        self.get_rect_list(contours)
        rect_in = self.rect_list

        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])
        rect_out = self.rect_list

        # Update data
        output_data = self.get_data()
        output_data['image']['merge_overlaps'] = dict()
        output_data['image']['merge_overlaps']['rect_list'] = self.rect_out
        output_data['image']['header']['rect_list'] = self.rect_out

        if self.output_mask_list is not None:
            output_data['image']['merge_overlaps']['array'] = dict()
            for idx in range(len(self.output_mask_list)):
                mask = self.output_mask_list[idx]
                output_data['image']['merge_overlaps']['array'][str(idx)] \
                    = mask

        # Logging_Info
        self.log.debug('module name: \t\t\t{}'
                       .format(__class__.__name__))
        self.log.debug('applied processes: \t\t{}'
                       .format(self.applied_processes))
        self.log.debug('input # of rects:\t\t{}'
                       .format(len(rect_in)))
        self.log.debug('input rects: \t\t\t(top_left_x, top_left_y, '
                       'rect_width, rect_height)\n\t\t\t\t\t\t{}'
                        .format(list(rect_in)))
        self.log.debug('output # of rects:\t\t{}'
                       .format(len(rect_out)))
        self.log.debug('output rects: \t\t\t(top_left_x, top_left_y, '
                       'rect_width, rect_height)\n\t\t\t\t\t\t{}'
                       .format(rect_out))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        # return self.get_data()
        return output_data

    def io_error_check(self):
        """ Input data permission
        1. Check rect coords data exists
        2. Check image type & data type
        3. Check color mode
        """

        # Empty_Check
        if len(self.rect_list) == 0:
            raise Exception(EMPTY_ERROR_MSG)

        # Type_Check
        if isinstance(self.get_image_array(), NP_NDARRAY):
            dtype = self.get_image_array().dtype
            if dtype is not NP_UINT_:
                self.change_dtype(DTYPE_UINT8)
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

        # Color_Check
        if self.get_color_mode().upper() not in COLOR_MODE:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """create tissue mask image from the source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            self.merge_if_overlaps()
            self.filter_out_small_rects()
            # self.crop_out_rects(source_image)

            # Update_Info
            self.add_array(source_image, DTYPE_UINT8)
            self.add_color_mode(self.get_color_mode())

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def get_rect_list(self, contours):
        self.rect_list = tuple(contours)

    def rect_intersects(self, rect1, rect2, flexible_space):
        """Function to see if the two input rectangle coordinates overlap.

        Since the tissues can be considered as one portion even without
        overlapping,
        flexible_space is considered to give a slight boundary to each
        rectangle.

        Args:
            rect1 ((int, int, int, int)): tuple coordinates for the
                                          1st rectangle each represents
                                          left, upper, right, lower
            rect2 ((int, int, int, int)): tuple coordinates for the 2nd
                                          rectangle each represents
                                          left, upper, right, lower
            flexible_space (int): extra length to each coordinate as a border

        Returns:
            Bool: True  if there is an overlapping area,
                  False if there is none.
        Example:
            > > > rect_intersects((0, 0, 350, 350), (100, 100, 200, 200), 100)
            True
        """
        self.applied_processes.append("rect_intersects")

        x1, y1, w1, h1 = rect1[0] - flexible_space, \
                         rect1[1] - flexible_space, \
                         rect1[2] + flexible_space, \
                         rect1[3] + flexible_space

        x2, y2, w2, h2 = rect2[0] - flexible_space, \
                         rect2[1] - flexible_space, \
                         rect2[2] + flexible_space, \
                         rect2[3] + flexible_space

        if ((x1 <= x2) and ((x1 + w1) >= x2)) \
                and ((y1 <= y2) and ((y1 + h1) >= y2)):
            return True

        elif ((x1 + w1) >= (x2 + w2)) \
                and (x1 <= (x2 + w2)) \
                and (y1 <= y2) \
                and ((y1 + h1) >= y2):
            return True

        elif (x1 <= x2) \
                and ((x1 + w1) >= x2) \
                and ((y1 + h1) >= (y2 + h2)) \
                and ((y2 + h2) >= y1):
            return True

        elif (x1 <= (x2 + w2)) and ((x2 + w2) <= (x1 + w1)) and (
                y1 <= (y2 + h2)) and ((y2 + h2) <= (y1 + h1)):
            return True

        elif (x1 <= x2) \
                and (x2 <= (x1 + w1)) \
                and ((x2 + w2) <= (x1 + w1)) \
                and (y1 <= y2) \
                and (y2 <= (y2 + h2)) \
                and ((y2 + h2) <= (y1 + h1)):
            return True

        elif (x2 <= x1) \
                and (x1 <= (x2 + w2)) \
                and ((x1 + w1) <= (x2 + w2)) \
                and (y2 <= y1) \
                and (y1 <= (y1 + h1)) \
                and ((y1 + h1) <= (y2 + h2)):
            return True

        elif ((x1 <= x2 < (x2 + w2) <= (x1 + w1)) and (y2 <= y1 <= (y2 + h2))) \
                or ((x2 <= x1 <= (x1 + w1) <= (x2 + w2)) and (y1 <= y2 <= (y1 + h1))):
            return True

        elif ((x1 <= x2 <= (x1 + w1) <= (x2 + w2)) and (y1 <= y2 <= (y2 + h2) <= (y1 + h1))) \
                or ((x2 <= x1 <= (x2 + w2) <= (x1 + w1)) and (y2 <= y1 <= (y1 + h1) <= (y2 + h2))):
            return True

        elif (x1 <= x2 <= (x2 + w2) <= (x1 + w1) and (y1 <= y2 <= (y1 + h1) <= (y2 + h2))) \
                or (x2 <= x1 <= (x1 + w1) <= (x2 + w2) and (y2 <= y1 <= (y2 + h2) <= (y1 + h1))):
            return True

        elif ((x2 <= x1 <= (x2 + w2) <= (x1 + w1)) and (y1 <= y2 <= (y2 + h2) <= (y1 + h1))) \
                or ((x1 <= x2 <= (x1 + w1) <= (x2 + w2)) and (y2 <= y1 <= (y1 + h1) <= (y2 + h2))):
            return True

        else:
            return False

    def merge_if_overlaps(self):
        """
        Takes list of coordinates of rectangles,
        Checks if there is any overlapping regions.
        If there are overlapping regions, merge them, else pass.

        Args:
            rect_list (list<(int, int, int, int)>): List of rectangle coordinates

        Returns:
            list<(int, int, int, int)>: all overlapping rectangles are merged
                                        and the 'straightened' list will be
                                        returned.

        Example:
            > > > merge_overlapping_areas([(0, 0, 350, 350),
                                           (100, 100, 200, 200),
                                           (2000, 2000, 4000, 4000)])
            [(0, 0, 350, 350), (2000,2000,4000,4000)]
        """
        rect_list = list(self.rect_list)
        self.applied_processes.append('merge_if_overlaps')
        any_rect_merged = True

        # When there is any change in the rectangle list,
        # start over the loop process.

        while any_rect_merged:
            any_rect_merged = False
            for i, (x1, y1, w1, h1) in enumerate(rect_list):
                for j, (x2, y2, w2, h2) in enumerate(rect_list[1:]):

                    if i - 1 == j:
                        continue

                    # Compare the tuples and see if
                    # there is any overlapping areas.

                    # If the two subject rectangles overlap,
                    # remove both of the corresponding coordinates and append
                    # the bigger coordinates which results from merging them.

                    if self.rect_intersects((x1, y1, w1, h1), (x2, y2, w2, h2),
                                            self.flexible_space):
                        any_rect_merged = True
                        rect_list.remove((x1, y1, w1, h1))
                        rect_list.remove((x2, y2, w2, h2))

                        # In terms of x-axis
                        if x1 < x2:
                            x = x1
                        else:
                            x = x2
                        if (x1 + w1) > (x2 + w2):
                            w = (x1 + w1) - x
                        else:
                            w = (x2 + w2) - x

                        # In terms of y-axis
                        if y1 < y2:
                            y = y1
                        else:
                            y = y2
                        if (y1 + h1) > (y2 + h2):
                            h = (y1 + h1) - y
                        else:
                            h = (y2 + h2) - y

                        rect_list.append((x, y, w, h))
                        break
                if any_rect_merged:
                    break

        self.rect_list = tuple(rect_list)

    def filter_out_small_rects(self):
        """ Once again, filter out the small images.

        Args:
            merged_rect_list        (list)  rect list of coordinates
        Returns:
            rect_list   (list)  rect list of coordinates filtered by size
        """
        self.applied_processes.append('filter_out_small_rects')
        merged_rect_list = self.rect_list

        if len(merged_rect_list) != 0:
            small_threshold = max([w * h for x, y, w, h in merged_rect_list]) * RATIO
            self.rect_out = [(x, y, w, h) for x, y, w, h in merged_rect_list if
                             (w * h) > small_threshold]

    # def crop_out_rects(self, source_image):
    #     self.applied_processes.append('crop_out_rects')
    #     coords_list = self.rect_out
    #     crop_img_list = []
    #     img = Image.fromarray(source_image)
    #
    #     # Iterate through the coordinates
    #     for i, (x, y, w, h) in enumerate(coords_list):
    #         try:
    #             crop_img_list.append(np.array(img.crop((x, y, x+w, y+h))))
    #         except Exception as e:
    #             self.log.debug("function crop_out_rects caused " + str(e))
    #         gc.collect()
    #
    #     self.output_mask_list = crop_img_list


if __name__ == "__main__":
    from deepphi.image_processing.utils import test_prep, display, get_image
    from deepphi.image_processing.computational_anatomy.pathology.generate_tissue_mask.libs.generate_tissue_mask_wsi import \
        GenerateTissueMaskWsi
    L = 'gray'
    B = 'B'
    IMAGE = 'image'
    ARRAY = 'array'

    DATA = '/home/hslisalee/DEEPPHI/io/hdf5/svs/1035154_lv2.hdf5'
    hdf5_image = test_prep(DATA, log=True)

    generate_tissue_mask = GenerateTissueMaskWsi(
        strength=15,
        lower_thresh=[0, 100, 0],
        upper_thresh=[200, 200, 200],
        bin_thresh=50
    )
    get_contours = GetContours(
        area_thresh=1500,
        line_color=175,
        line_width=5
    )
    merge = MergeOverlaps(
        flexible_space=100
    )
    hdf5_tissue_mask = generate_tissue_mask(hdf5_image)
    hdf5_mask_contours = get_contours(hdf5_tissue_mask)

    rect_list_in = hdf5_mask_contours['image']['get_contours']['rect_list']

    hdf5_merged_contours = merge(hdf5_mask_contours)

    rect_list_out = hdf5_merged_contours['image']['get_contours']['rect_list']

    # print(rect_list_in)
    # print(rect_list_out)
    #
    # co_tissues_mask = hdf5_merged_contours['image']['merge_overlaps']['array']
    # for cnt, tissue in enumerate(co_tissues_mask):
    #
    #     mask_arr = co_tissues_mask[str(cnt)]
    #     display(mask_arr,
    #             add_to_title='Mask Cropped '
    #                          + str(cnt + 1)
    #                          + ' of '
    #                          + str(len(co_tissues_mask)),
    #             cmap=L
    #             )
