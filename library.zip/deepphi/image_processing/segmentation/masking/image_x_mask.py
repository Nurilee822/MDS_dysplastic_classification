#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
import logging
import numpy as np

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit

PROCESSING_ERROR_MSG = "Exception occurred while processing: "
EMPTY_ERROR_MSG = "Exception occurred while processing data: There " \
                    "is no value in the input image array."
INPUT_TYPE_ERROR_MSG = "Exception occurred while processing data: Image " \
                         "data type is invalid. Must be in a form of array."
NP_NDARRAY = np.ndarray
NP_UINT_ = np.uint8
DTYPE_UINT8 = 'uint8'
COLORS_ = ['B']
IMAGE = 'image'
ARRAY = 'array'

"""
EXAMPLE: 
    
    image_x_mask = ImageXMask()
    combined_data = image_x_mask(source_data=hdf5_source_data,
                                 mask_data=hdf5_mask_data)


"""


class ImageXMask(Preprocessing):
    """Returns an input mask applied source image. """

    def __init__(self, *args, **kwargs):
        """Initialization of ImageXMask Class Module.

        self Variables:
            self.log        (logger)    logger for logging.
            self.args       (tbd)       input argument for image processing.
            self.kwargs     (tbd)       keyword argument for image processing.

        """
        super(ImageXMask, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.mask_data = None
        self.mask = None
        self.this_module = __class__.__name__

    @timeit
    def __call__(self, source_data, mask_data, save_path=None):

        # IO_Error_Check
        self.init_data(source_data)
        self.mask_data = mask_data
        self.io_error_check()

        # Image_Processing
        self.image_processing(self.get_image_array(),
                              self.mask,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('module processed: \t\t{}'.format(self.this_module))
        self.log.debug('history: \t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        0. Check mask data exists
        1. Check image data exists
        2. Check image type & data type
        3. Check image data and mask data shape matches.
        """
        if self.mask_data is None:
            raise KeyError("mask_data is required.")

        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

        self.shape_check()

    def shape_check(self):
        source_image = self.get_image_array()
        mask_image = self.mask_data[IMAGE][ARRAY]

        if np.shape(source_image)[:2] == np.shape(mask_image):
            self.mask = mask_image
        else:
            raise Exception("Image shape and mask shape does not match.")

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def image_processing(self, source_image, mask_image, param):
        """Apply mask onto source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Area_Opening: takes image, generates filtered image.
            output_img = self.apply_mask(source_image, mask_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def apply_mask(self, source_image, mask_image):
        """apply mask onto the source image.
        Args:
            source_image    (ndarray)   input source image

        Returns:
            mask_applied   (ndarray)   mask applied source image.
        """
        mask_applied = cv2.bitwise_and(src1=source_image,
                                        src2=source_image,
                                        mask=mask_image)
        return mask_applied


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, \
        invert_bin, LOCAL_DATA
    from deepphi.image_processing.segmentation.filter.area_filter \
        import AreaFilter
    from deepphi.image_processing.segmentation.morphological_operation.dilation\
        import Dilation

    DATA = LOCAL_DATA
    ARRAY = 'array'
    IMAGE = 'image'
    L = 'gray'

    """  Preset Keyword Arguments  """

    AREA_THRESH = 2000

    SE_SHAPE = (10, 10)
    SE_SIZE = 10

    """  Input Data Preparation  """

    hdf5_b = test_prep(DATA, level='B', log=True)
    hdf5_b[IMAGE][ARRAY] = invert_bin(hdf5_b[IMAGE][ARRAY])
    bin_img = hdf5_b[IMAGE][ARRAY]

    dilation = Dilation(strel=SE_SIZE, se_shape=None)
    hdf5_dilated = dilation(hdf5_b)
    dilated_img = hdf5_dilated[IMAGE][ARRAY]

    # display(bin_img, add_to_title='binary input image', cmap=L)
    # display(dilated_img, add_to_title='dilated mask image', cmap='gray')

    """  Apply Area Opening """

    area_filter = AreaFilter(area_thresh=AREA_THRESH)
    hdf5_mask_data = area_filter(hdf5_dilated)
    mask_img = hdf5_mask_data[IMAGE][ARRAY]


    """ Multiply mask onto original RGB image"""

    hdf5_source_data = test_prep(DATA)
    source_img = hdf5_source_data[IMAGE][ARRAY]

    image_x_mask = ImageXMask()
    combined_data = image_x_mask(source_data=hdf5_source_data,
                                 mask_data=hdf5_mask_data)

    display(source_img, add_to_title='Source Image')
    display(mask_img, add_to_title='Mask Image', cmap='gray')
    display(combined_data[IMAGE][ARRAY], add_to_title='Combined data')

    # combined_img = cv2.bitwise_and(rgb_img, rgb_img, mask=mask_img)
    # display(combined_img,
    #         add_to_title='(VIEWING PURPOSE ONLY)Area Opened Image Applied Onto '
    #                      'Original RGB.', cmap=L)
