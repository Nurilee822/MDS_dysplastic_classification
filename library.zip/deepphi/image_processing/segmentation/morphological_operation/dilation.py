#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
import logging
from deepphi.image_processing.segmentation.morphological_operation import \
    Morphology

"""
EXAMPLE: 

    SE_SIZE = 2 
    
    dilation = Dilation(strel=SE_SIZE,
                        se_shape=None)
    hdf5_output = dilation(hdf5_bin)

"""


class Dilation(Morphology):
    """Returns morphological dilation applied image."""

    def __init__(self, *args, **kwargs):
        """Initialization of Morphology Class Module."""
        super(Dilation, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.this_module = __class__.__name__

    def morphological_operator(self, source_image):
        output_img = cv2.dilate(src=source_image,
                                kernel=self.se_shape)
        return output_img


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, invert_bin, LOCAL_DATA
    from deepphi.image_processing.segmentation.thresholding.otsu_thresholding \
        import OtsuThresholding

    SE_SIZE = 2
    DATA = LOCAL_DATA
    hdf5_input = test_prep(DATA, level='L', log=True)
    image_array = hdf5_input['image']['array']
    display(image_array)

    otsu = OtsuThresholding()
    hdf5_bin = otsu(hdf5_input)
    hdf5_bin['image']['array'] = invert_bin(hdf5_bin['image']['array'])
    binary_img = hdf5_bin['image']['array']
    display(binary_img)

    dilation = Dilation(strel=SE_SIZE,
                        se_shape='None')

    hdf5_output = dilation(hdf5_bin)
    dilated_img = hdf5_output['image']['array']

    # display
    display(binary_img,
            add_to_title='Source Image',
            cmap='gray')

    display(dilated_img,
            add_to_title='Dilated Image(structuring element={})'.format(
                SE_SIZE),
            cmap='gray')

    hdf5_rgb = test_prep(DATA)
    rgb_img = hdf5_rgb['image']['array']
    applied_dlt = cv2.bitwise_and(rgb_img, rgb_img, mask=dilated_img)
    display(applied_dlt, cmap='gray')
