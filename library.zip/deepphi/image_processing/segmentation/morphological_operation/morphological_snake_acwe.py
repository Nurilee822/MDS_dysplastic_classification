#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging  # logging을 위해 반드시 import
import numpy as np
from deepphi.image_processing import Preprocessing  # deepphi 모듈로 작동하기 위해 Preprocessing Class 상속이 필요
import math
import cv2


class ACWE(Preprocessing):

    def __init__(self, Num_iteration = 20, nu = 0.003 * 255 * 255, Start_point = (10, 10), Length = 20, Threshold = 0):  # 외부에서 parameter 입력이 필요한 경우 해당 parameter 명을 key값으로 받도록 __init__에서 정의함
        """Initialization of Image Processing Class Module.

        self Args:
            self.Num_iteration  (int)   The number of iteration to minimize LSF.
            self.nu             (float32) The hyperparameter of contour's length
            Start_point         (tuple) Point of initial contour
            Length              (int)   The length of initial square contour
            Threshold           (int)   The threshold value of binary segmentation
        """
        super(ACWE, self).__init__()

        """ I/O Error Check Parameters """
        self.ImageExist = 'Exist'
        self.color_rule = 'L'
        self.ndim = (2, 3)

        """ Image Processing Parameters """
        self.Num_iteration = Num_iteration
        self.nu = nu
        self.Start_point = Start_point
        self.Length = Length
        self.Threshold = Threshold


    def __call__(self, data, save_path=None):

        def mat_math(intput, str):
            output = intput
            for i in range(intput.shape[0]):
                for j in range(intput.shape[1]):
                    if str == "atan":
                        output[i, j] = math.atan(intput[i, j])
                    if str == "sqrt":
                        output[i, j] = math.sqrt(intput[i, j])
            return output

        def CV(LSF, img, mu, nu, epison, step):
            Drc = (epison / math.pi) / (epison * epison + LSF * LSF)
            Hea = 0.5 * (1 + (2 / math.pi) * mat_math(LSF / epison, "atan"))
            Iy, Ix = np.gradient(LSF)
            s = mat_math(Ix * Ix + Iy * Iy, "sqrt")
            Nx = Ix / (s + 0.000001)
            Ny = Iy / (s + 0.000001)
            Mxx, Nxx = np.gradient(Nx)
            Nyy, Myy = np.gradient(Ny)
            cur = Nxx + Nyy
            Length = nu * Drc * cur
            Lap = cv2.Laplacian(LSF, -1)
            Penalty = mu * (Lap - cur)

            s1 = Hea * img
            s2 = (1 - Hea) * img
            s3 = 1 - Hea
            C1 = s1.sum() / Hea.sum()
            C2 = s2.sum() / s3.sum()
            CVterm = Drc * (-1 * (img - C1) * (img - C1) + 1 * (img - C2) * (img - C2))

            LSF = LSF + step * (Length + Penalty + CVterm)
            return LSF

        nu = self.nu
        Num_iteration = self.Num_iteration
        start_x = self.Start_point[0]
        start_y = self.Start_point[1]
        length = self.Length
        Threshold = self.Threshold
        epison = 1
        step = 0.01
        mu = 1

        Image = data['image']['array']

        # IO_Error_Check
        self.io_error_check(data)
        logging.info('IO error checking has been finished.')

        # Convert data type for cv2 processing
        convert_image = np.zeros(Image.shape)
        for i in range(0, Image.shape[0]):
            if len(Image.shape) == 3:
                convert_image[i, :, :] = Image[i, :, :].astype('float32')
            else:
                convert_image = Image.astype('float32')
        logging.info('The data type convert to float32.')

        #Implement ACWE
        if len(Image.shape) == 3:
            result_image = np.zeros(convert_image.shape)
            for k in range(0, convert_image.shape[0]):
                # Define initial LSF
                img = np.squeeze(convert_image[k,:,:])
                IniLSF = np.ones((img.shape[0], img.shape[1]), img.dtype)
                IniLSF[start_x:start_x + length, start_y:start_y + length] = -1
                IniLSF = -IniLSF
                LSF = IniLSF

                #To solve minimization problem
                for i in range(1, Num_iteration):
                    LSF = CV(LSF, img, mu, nu, epison, step)
                _, binary_LSF = cv2.threshold(LSF, Threshold, 1, cv2.THRESH_BINARY_INV)
                result_image[k, :, :] = binary_LSF
                logging.info('Image'+ str(k+1) +' segmentation has been finished.')
        else:
            # Define initial LSF
            img = convert_image
            IniLSF = np.ones((img.shape[0], img.shape[1]), img.dtype)
            IniLSF[start_x:start_x + length, start_y:start_y + length] = -1
            IniLSF = -IniLSF
            LSF = IniLSF

            # To solve minimization problem
            for i in range(1, Num_iteration):
                LSF = CV(LSF, img, mu, nu, epison, step)
            _, binary_LSF = cv2.threshold(LSF, Threshold, 1, cv2.THRESH_BINARY_INV)
            result_image = binary_LSF
            logging.info('Image segmentation has been finished.')

        # Return_Output_HDF5
        data['image']['array'] = result_image
        return data

    def io_error_check(self, data):
        pass
        """ Input data permission  
        Check color mode
        Check dimensionality
        Throw an Error if color, ndim is different
        """

        image_data = data['image']
        array = image_data['array']
        info = image_data['header']

        color_mode = info['color_mode']
        array_dim = len(array.shape)

        if self.ImageExist is not None:
            if array is not None:
                Exist = 'Exist'
            else:
                Exist = 'None'
            assert Exist in self.ImageExist, \
                'Input Image Must Exist. ' \
                '\nAccepts--' \
                + self.ImageExist

        if self.color_rule is not None:
            assert color_mode in self.color_rule, \
                'Input Image color-mode Must Match. ' \
                '\nAccepts--' \
                + self.color_rule

        if self.ndim is not None:
            assert array_dim in self.ndim, \
                'Input Array dimensionality Must Match. ' \
                '\nAccepts--' \
                + str(self.ndim)

#
# if __name__ == "__main__":
# #Inserted Library
#
# import matplotlib.pyplot as plt
#
# import os.path as join
# # import h5py
# import matplotlib.pyplot as plt
# from deepphi.image_processing.utils import test_prep
#
#     path = '/data/hskim/CRC/progress/2020/0210/deepphi_test/ex_file/hdf5 example/filename.hdf5'
#     test = test_prep(path, log = True)
#     inputput_array = test['image']['array']
#     for k in range(0, inputput_array.shape[0]):
#         temp2 = inputput_array[k, :, :]
#         plt.imshow(temp2).set_cmap("gray")
#         plt.show()
#
#     # run input hdf5
#     temp = ACWE(Num_iteration = 50)
#     result = temp(data = test)
#
#     # check output hdf5
#     output_array = result['image']['array']
#     for k in range(0, output_array.shape[0]):
#         temp2 = output_array[k, :, :]
#         plt.imshow(temp2).set_cmap("gray")
#         plt.show()
#

if __name__ == "__main__":

    import os
    from deepphi.image_processing.utils import display, test_prep

    os.chdir('/home/hslisalee/Downloads/DL_team_codes/kim_hs')
    # path = '/data/hskim/CRC/progress/2020/0210/deepphi_test/ex_file/hdf5 example/filename.hdf5'
    data = 'filename.hdf5'
    test = test_prep(data, log=True)

    # run input hdf5
    acwe = ACWE(Num_iteration=50)
    result = acwe(data=test)

    # check output hdf5
    output_array = result['image']['array']
    for idx, img in enumerate(output_array):
        display(img, cmap='gray', add_to_title=str(idx))
    # for k in range(0, output_array.shape[0]):
    #     temp2 = output_array[k, :, :]
    #     plt.imshow(temp2).set_cmap("gray")
    #     plt.show()