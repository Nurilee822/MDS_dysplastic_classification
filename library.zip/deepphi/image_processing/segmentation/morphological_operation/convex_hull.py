#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

import cv2
from skimage.morphology import convex_hull_image

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.utils import timeit
import numpy as np
from deepphi.image_processing.config.morphology_ import *

COLORS_ = ['B']


class ConvexHull(Preprocessing):
    """Returns a binary image with pixels inside convex hull set to True."""

    def __init__(self, *args, **kwargs):
        """Initialization of ConvexHull Class Module.

        self Variables:
            self.log        (logger)    logger for logging.
            self.args       (tbd)       input argument for image processing.
            self.kwargs     (tbd)       keyword argument for image processing.
            self.acceptable_colors(int) color mode required to process this
                                        module.
        """
        super(ConvexHull, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.acceptable_colors = COLORS_
        self.kwargs = kwargs
        self.this_module = __class__.__name__

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('morphological operator: \t{}'.format(self.this_module))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            self.color_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply edge adjustment to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Area_Opening: takes image, generates filtered image.
            output_img = self.morphological_operator(source_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def morphological_operator(self, source_image):
        """Masks out image by range of [lower_b, upper_b].
        Args:
            source_image    (ndarray)   binary input source image
                                        (8-bit single-channel image).
        Returns:
            filtered_mask   (ndarray)   binary area-filtered image.
        """
        chull = convex_hull_image(source_image)
        row, col = np.shape(chull)
        chull_v = np.array([1] * int(row * col))
        filtered_mask = chull_v.reshape(row, col)

        for i in range(row):
            for j in range(col):
                if not chull[i, j]:
                    filtered_mask[i, j] = 0

        return filtered_mask * 255


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, \
        invert_bin, LOCAL_DATA

    DATA = LOCAL_DATA
    ARRAY = 'array'
    IMAGE = 'image'
    L = 'gray'

    """  Preset Keyword Arguments  """
    #
    # AREA_THRESH = 2000
    #
    # SE_SHAPE = (10, 10)
    # SE_SIZE = 10

    """  Input Data Preparation  """

    hdf5_b = test_prep(DATA, level='B', log=True)
    hdf5_b[IMAGE][ARRAY] = invert_bin(hdf5_b[IMAGE][ARRAY])
    bin_img = hdf5_b[IMAGE][ARRAY]
    display(bin_img, add_to_title='binary input image', cmap=L)

    """  Apply Dilation"""

    # MODULE_NAME = 'Dilation'
    # MODULE_ID = '1234'
    # dilation = Dilation(selem=SE_SIZE,
    #                     se_shape=None,
    #                     module_name=MODULE_NAME,
    #                     module_id=MODULE_ID)
    # hdf5_dilated = dilation(hdf5_b)
    # dilated_img = hdf5_dilated['image']['array']
    # display(dilated_img, add_to_title='dilated mask image', cmap='gray')

    """  Apply Area Opening """

    # MODULE_NAME = 'AreaOpening'
    # MODULE_ID = '1234'
    # area_filter = AreaOpening(module_name=MODULE_NAME,
    #                           module_id=MODULE_ID,
    #                           area_threshold=AREA_THRESH)
    #
    # hdf5_input_filtered = area_filter(hdf5_dilated)
    # mask_img = hdf5_input_filtered[IMAGE][ARRAY]
    # display(mask_img,
    #         add_to_title='Area Opened Image'
    #                      '\n(area threshold={})'.format(AREA_THRESH),
    #         cmap='gray')

    """  Apply Convex Hull  """

    chull = ConvexHull()

    hdf5_chull = chull(hdf5_b)
    mask_img = hdf5_chull[IMAGE][ARRAY]
    display(mask_img,
            add_to_title='Convex Hull Image',
            cmap='gray')

    """ Apply mask onto original RGB image"""
    #
    # rgb = test_prep(DATA)
    # rgb_img = rgb[IMAGE][ARRAY]
    #
    # combined_img = cv2.bitwise_and(rgb_img, rgb_img, mask=mask_img)
    #
    # display(combined_img,
    #         add_to_title='(VIEWING PURPOSE ONLY)Convex Hull Image '
    #                      'Applied Onto Original RGB.',
    #         cmap=L)
