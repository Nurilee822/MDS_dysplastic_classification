#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
import math
import numpy as np

from skimage.morphology import disk

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.config.morphology_ import *
from deepphi.image_processing.utils import timeit

ACCEPTABLE_COLORS = ['B', 'BINARY', 'BIN']


class Morphology(Preprocessing):
    """Returns morphological operation applied images.

        Morphological Operator Types:
        - Dilation
        - Erosion
        - Opening
        - Closing
        # - Skeletonize (Not in plan)
        # - Convex Hull (Not in plan)

    """

    def __init__(self, *args, **kwargs):
        """Initialization of Morphology Class Module.

        self Variables:
            self.log            (logger)   logger for logging.
            self.args           (tbd)      input argument for image processing.
            self.kwargs         (tbd)      keyword argument for image processing.
            self.acceptable_colors (list)  list of acceptable color modes.
            self.strel          (int)      radius of a disk-shaped structuring
                                           element for morphological operation.
            self.se_shape       (tuple)    (int, int) shape of a morphological
                                            structuring element.
        """
        super(Morphology, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.acceptable_colors = ACCEPTABLE_COLORS
        self.strel = None
        self.this_module = None

        if kwargs['strel'] is None:
            raise KeyError("Size of the structuring element must be provided.")
        else:
            if isinstance(kwargs['strel'], int):
                self.strel = kwargs['strel']
                self.se_shape = disk(self.strel)
            else:
                raise TypeError("Structuring element diameter must be in "
                                "'int' type.")

        # if kwargs['se_shape'] is 'None':
        #     if kwargs['strel'] is 'None':
        #         raise KeyError("Either Size or Shape information of the "
        #                        "structuring element must be provided.")
        #     else:
        #         if isinstance(kwargs['strel'], int):
        #             self.strel = kwargs['strel']
        #             self.se_shape = disk(self.strel)
        #         else:
        #             raise TypeError("Structuring element diameter must be in "
        #                             "'int' type.")
        # elif self.strel is not 'None':
        #     raise KeyError("Only one argument can be accepted. Please choose "
        #                    "either the size of the structuring element("
        #                    "disk shape diameter), or any other custom shape.")
        # else:
        #     if isinstance(kwargs['se_shape'], tuple):
        #         self.se_shape = kwargs['se_shape']
        #         self.strel = self.se_shape[0]
        #
        #     else:
        #         raise KeyError("Shape information of the structuring element "
        #                        "'se_shape' must be entered.")

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])

        # Logging_Info
        self.log.debug('morphological operator: \t{}'.format(self.this_module))
        if self.strel is not None:
            self.log.debug(
                'structuring element shape: \t{}({})'.format(self.strel,
                                                             'length'))
        else:
            self.log.debug('structuring element shape: \t{}'.format(
                np.shape(self.se_shape)))
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check image color mode
        """
        self.empty_check()
        if isinstance(self.get_image_array(), NP_NDARRAY):
            self.type_check()
            self.color_check()
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply morphological operation to source image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Morphological_Operation
            if self.strel is None:
                self.set_structuring_element()

            output_img = self.morphological_operator(source_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def empty_check(self):
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

    def type_check(self):
        dtype = self.get_image_array().dtype
        if dtype is not NP_UINT_:
            self.change_dtype(DTYPE_UINT8)

    def color_check(self):
        if self.get_color_mode().upper() not in self.acceptable_colors:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def morphological_operator(self, source_image):
        pass

    def set_structuring_element(self):
        se_vector = np.array([1] * int(self.se_shape[0] * self.se_shape[1]))
        self.strel = se_vector.reshape(self.se_shape)



