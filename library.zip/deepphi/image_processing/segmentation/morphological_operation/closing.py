#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
from deepphi.image_processing.config.morphology_ import *
from deepphi.image_processing.segmentation.morphological_operation import \
    Morphology
import logging

"""
EXAMPLE: 
    
    SE_SIZE = 3
    
    closing = Closing(strel=SE_SIZE,
                      se_shape=None)
    hdf5_output = closing(hdf5_bin)

"""


class Closing(Morphology):
    """Returns morphological closing applied image."""

    def __init__(self, *args, **kwargs):
        """Initialization of Morphology Class Module."""
        super(Closing, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.this_module = __class__.__name__

    def morphological_operator(self, source_image):
        output_img = cv2.morphologyEx(src=source_image,
                                      op=cv2.MORPH_CLOSE,
                                      kernel=self.se_shape)
        return output_img


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, invert_bin, LOCAL_DATA
    from deepphi.image_processing.segmentation.thresholding.otsu_thresholding\
        import OtsuThresholding

    SE_SIZE = 3

    DATA = LOCAL_DATA
    hdf5_gray = test_prep(DATA, level='gray', log=True)

    thresh = OtsuThresholding()
    hdf5_bin = thresh(hdf5_gray)
    
    hdf5_bin['image']['array'] = invert_bin(hdf5_bin['image']['array'])
    binary_img = hdf5_bin['image']['array']

    closing = Closing(strel=SE_SIZE,
                      se_shape='None')
    hdf5_output = closing(hdf5_bin)
    closed_img = hdf5_output['image']['array']

    # display
    # display(binary_img, add_to_title='Source Image', cmap='gray')
    display(closed_img, add_to_title='Closed Image(structuring element={})'
            .format(SE_SIZE), cmap='gray')

    # Advanced
    # hdf5_rgb = test_prep(DATA)
    # rgb_img = hdf5_rgb['image']['array']
    # applied_to_bin = cv2.bitwise_and(rgb_img, rgb_img, mask=binary_img)
    # applied_to_cls = cv2.bitwise_and(rgb_img, rgb_img, mask=closed_img)
    #
    # display(applied_to_bin, cmap='gray')
    # display(applied_to_cls, cmap='gray')
