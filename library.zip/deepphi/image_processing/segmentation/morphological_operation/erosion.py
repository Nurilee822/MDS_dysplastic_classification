#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
import logging
from deepphi.image_processing.segmentation.morphological_operation import \
    Morphology

"""
EXAMPLE:
    
    SE_SIZE=3
    
    erosion = Erosion(selem=SE_SIZE,
                      se_shape=None)
    hdf5_output = erosion(hdf5_bin)

"""


class Erosion(Morphology):
    """Returns morphological erosion applied image."""

    def __init__(self, *args, **kwargs):
        """Initialization of Morphology Class Module."""
        super(Erosion, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.this_module = __class__.__name__

    def morphological_operator(self, source_image):
        output_img = cv2.erode(src=source_image,
                               kernel=self.se_shape)
        return output_img


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, invert_bin, LOCAL_DATA

    SE_SIZE = 3
    DATA = LOCAL_DATA
    hdf5_bin = test_prep(DATA,
                         level='BIN',
                         log=True)

    binary_img = invert_bin(hdf5_bin['image']['array'])
    hdf5_bin['image']['array'] = binary_img

    erosion = Erosion(strel=SE_SIZE,
                      se_shape='None')

    hdf5_output = erosion(hdf5_bin)
    eroded_img = hdf5_output['image']['array']

    # display
    display(binary_img,
            add_to_title='Source Image',
            cmap='gray')

    display(eroded_img,
            add_to_title='Eroded Image(structuring element={})'.format(SE_SIZE),
            cmap='gray')

    hdf5_rgb = test_prep(DATA)
    rgb_img = hdf5_rgb['image']['array']
    applied_ers = cv2.bitwise_and(rgb_img, rgb_img, mask=eroded_img)
    display(applied_ers, cmap='gray')
