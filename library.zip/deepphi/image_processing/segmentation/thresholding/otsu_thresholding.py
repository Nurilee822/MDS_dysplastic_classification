#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
from skimage.filters import threshold_otsu

from deepphi.image_processing.segmentation.thresholding import Thresholding


class OtsuThresholding(Thresholding):
    """Returns a binary image. Thresholding image with otsu-threshold value.

        The algorithm finds the optimal value and thresholds with it.
        If pixel value is greater than a threshold value,
        it is assigned one value (may be white),
        else it is assigned another value (may be black).

        Convert color mode from
        L(256 grayscale levels) to B(binary).

    """

    def __init__(self, *args, **kwargs):
        """Initialization of OtsuThresholding Class Module.

        self Variables:
            self.thresh_by  (str)   threshold method type.
        """
        super(OtsuThresholding, self).__init__(self, *args, **kwargs)
        self.log = logging.getLogger()
        self.thresh_by = "Auto by Otsu's Method"
        self.this_module = __class__.__name__

    def set_thresh_value(self, source_image):
        self.thresh = threshold_otsu(source_image)


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep

    # Setup Test Data
    data_dir = '/home/hslisalee/DEEPPHI/datasets/hdf5/deepphi_beta_hdf5' \
               '/BetaData01_Chest_cls2d/test/'
    cst = 'CST_1.hdf5'
    DATA = data_dir + cst

    hdf5_gray = test_prep(DATA, level='gray', log=True)
    gray_img = hdf5_gray['image']['array']

    thresh = OtsuThresholding()
    hdf5_output = thresh(hdf5_gray)
    otsu_binary_img = hdf5_output['image']['array']

    # display
    display(gray_img, add_to_title='GRAY Image', cmap='gray')
    display(otsu_binary_img, add_to_title='BINARY Image(Otsu-thresholding)',
            cmap='gray')


