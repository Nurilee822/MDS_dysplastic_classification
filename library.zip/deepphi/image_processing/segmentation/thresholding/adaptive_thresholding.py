#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import cv2
import logging
from deepphi.image_processing.segmentation.thresholding import Thresholding

"""
EXAMPLE:
    
    BLOCKSIZE=101 (must be an odd number)
    
    adaptive_thresh = AdaptiveThresholding(blockSize=BLOCKSIZE)
    hdf5_output = adaptive_thresh(hdf5_gray)


"""


class AdaptiveThresholding(Thresholding):
    """Returns a binary image. Thresholding image with an input threshold value

        If the pixel value is greater than a threshold value,
        it is assigned one value (maybe white),
        else it is assigned another value (maybe black).

        Convert color mode from
        L(256 grayscale levels) to B(binary).

    """
    def __init__(self, *args, **kwargs):
        """Initialization of AdaptiveThresholding Class Module.

        self Variables:
            self.kwargs     (tbd)       keyword argument for image processing.
            self.thresh     (int)       threshold value for binarization.
            self.thresh_by  (str)       threshold method type.
        """
        super(AdaptiveThresholding, self).__init__(self, *args, *kwargs)
        self.log = logging.getLogger()
        self.this_module = __class__.__name__

        if kwargs['block_size'] is not None:
            if isinstance(kwargs['block_size'], int):
                self.kwargs = kwargs
                self.block_size = kwargs['block_size']
            else:
                raise TypeError("block_size must be type 'int'.")
        else:
            raise KeyError("Requires block_size value as an argument. "
                           "Please specify a value.")

    def apply_thresholding(self, source_image):
        output_img = cv2.adaptiveThreshold(src=source_image,
                                           maxValue=255,
                                           adaptiveMethod=cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                           thresholdType=cv2.THRESH_BINARY,
                                           blockSize=self.block_size,
                                           C=2)
        return output_img

    def add_logging(self):
        self.log.debug('neighborhood blocksize: \t{}'.format(self.block_size))


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, LOCAL_DATA

    # Setup Test Data
    DATA = LOCAL_DATA
    BLOCKSIZE = 101  # must be block_size % 2 = 1

    hdf5_gray = test_prep(DATA, level='gray', log=True)
    gray_img = hdf5_gray['image']['array']

    adaptive_thresh = AdaptiveThresholding(block_size=BLOCKSIZE)
    hdf5_output = adaptive_thresh(hdf5_gray)
    simple_binary_img = hdf5_output['image']['array']

    # display
    display(gray_img, add_to_title='GRAY Image', cmap='gray')
    display(simple_binary_img, add_to_title='BINARY Image(Adaptive-thresholding)'
                                            '\nAdaptive Neighborhood '
                                            'blocksize = {}'.format(BLOCKSIZE),
            cmap='gray')
