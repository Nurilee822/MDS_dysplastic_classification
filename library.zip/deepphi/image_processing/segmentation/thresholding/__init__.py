#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging

import cv2

from deepphi.image_processing import Preprocessing
from deepphi.image_processing.config.thresholding_ import *
from deepphi.image_processing.utils import timeit


class Thresholding(Preprocessing):
    """Returns a binary image. Applies image thresholding.

        Convert color mode from
        L(256 grayscale levels) to B(binary).

        Thresholding Types:
        - Simple Thresholding
        - Adaptive Thresholding
        - Otsu's Thresholding
    """

    def __init__(self, *args, **kwargs):
        """Initialization of Thresholding Class Module.

        self Variables:
            self.log        (logger)  logger for logging.
            self.args       (tbd)     input argument for image processing.
            self.kwargs     (tbd)     keyword argument for image processing.
            self.thresh     (int)     threshold value for binarization.
            self.thresh_by  (str)     threshold method type.
        """
        super(Thresholding, self).__init__()
        self.log = logging.getLogger()
        self.args = args
        self.kwargs = kwargs
        self.thresh = None
        self.thresh_by = None
        self.this_module = None

    @timeit
    def __call__(self, data, save_path=None):

        # IO_Error_Check
        self.init_data(data)
        self.io_error_check()

        # Image_Processing
        source_image = self.get_image_array()
        original_color_mode = (self.get_color_mode()).upper()
        self.image_processing(source_image=source_image,
                              param=[self.args,
                                     self.kwargs])
        converted_color_mode = self.get_color_mode()

        # Logging_Info
        self.log.debug('thresholding type: \t\t\t{}'.format(self.this_module))
        self.log.debug('original_color_mode: \t\t{}'.format(
            original_color_mode))
        self.log.debug('converted_color_mode: \t\t{}'.format(
            converted_color_mode))
        self.add_logging()
        self.log.debug('history: \t\t\t\t\t{}'.format(self.get_history()))

        # Return_Output_HDF5
        return self.get_data()

    def io_error_check(self):
        """ Input data permission
        1. Check image data exists
        2. Check image type & data type
        3. Check color mode
        """

        # Empty_Check
        if len(self.get_image_array()) == 0:
            raise Exception(EMPTY_ERROR_MSG)

        # Type_Check
        if isinstance(self.get_image_array(), NP_NDARRAY):
            dtype = self.get_image_array().dtype
            if dtype is not NP_UINT_:
                self.change_dtype(DTYPE_UINT8)
        else:
            raise Exception(INPUT_TYPE_ERROR_MSG)

        # Color_Check
        if self.get_color_mode() not in COLOR_MODE:
            raise Exception(COLOR_MODE_ERROR_MSG)

    def image_processing(self, source_image, param):
        """Apply image thresholding and create a binary image.

        Args:
            source_image (numpy array)  numpy array image
            param       (tbd)           image processing argument.(if, any)
        """
        try:
            # Check_Image_Min_Max
            if source_image.min() == source_image.max():
                output_img = source_image
            else:
                # Get_Threshold_Point
                self.set_thresh_value(source_image)
                # Apply_Threshold
                output_img = self.apply_thresholding(source_image)

            # Update_Info
            self.add_array(output_img, DTYPE_UINT8)
            self.add_color_mode(MODE)

        except Exception as error:
            raise Exception(PROCESSING_ERROR_MSG + str(error))

    def set_thresh_value(self, source_image):
        pass

    def apply_thresholding(self, source_image):
        _, output_img = cv2.threshold(src=source_image,
                                      thresh=self.thresh,
                                      maxval=MAXVAL,
                                      type=TYPE_BINARY)
        return output_img

    def add_logging(self):
        self.log.debug('threshold_value: \t\t\t{}({})'.format(self.thresh,
                                                              self.thresh_by))