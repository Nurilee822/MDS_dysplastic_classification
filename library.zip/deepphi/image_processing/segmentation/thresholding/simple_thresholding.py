#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import logging
from deepphi.image_processing.segmentation.thresholding import Thresholding

"""
EXAMPLE:
    
    THRESH=200
    
    gray2bin = SimpleThresholding(thresh=THRESH)
    hdf5_output = gray2bin(hdf5_gray)

"""


class SimpleThresholding(Thresholding):
    """Returns a binary image. Thresholding image with an input threshold value

        If the pixel value is greater than a threshold value,
        it is assigned one value (maybe white),
        else it is assigned another value (maybe black).

        Convert color mode from
        L(256 grayscale levels) to B(binary).

    """
    def __init__(self, *args, **kwargs):
        """Initialization of SimpleThresholding Class Module.

        self Variables:
            self.kwargs     (tbd)       keyword argument for image processing.
            self.thresh     (int)       threshold value for binarization.
            self.thresh_by  (str)       threshold method type.
        """
        super(SimpleThresholding, self).__init__(self, *args, *kwargs)
        self.log = logging.getLogger()
        self.this_module = __class__.__name__

        if kwargs['thresh'] is not None:
            if isinstance(kwargs['thresh'], int):
                self.kwargs = kwargs
            else:
                raise TypeError("Thresholding level must be an 'int'.")
        else:
            raise KeyError("Requires thresholding value as an argument. "
                           "Please specify a value.")
        self.thresh = self.kwargs['thresh']
        self.thresh_by = 'User input'


if __name__ == "__main__":
    from deepphi.image_processing.utils import display, test_prep, LOCAL_DATA

    # Setup Test Data
    DATA = LOCAL_DATA

    hdf5_gray = test_prep(DATA, level='gray', log=True)
    gray_img = hdf5_gray['image']['array']

    gray2bin = SimpleThresholding(thresh=200)
    hdf5_output = gray2bin(hdf5_gray)
    simple_binary_img = hdf5_output['image']['array']

    # display
    display(gray_img, add_to_title='GRAY Image', cmap='gray')
    display(simple_binary_img, add_to_title='BINARY Image(Simple-thresholding)',
            cmap='gray')


