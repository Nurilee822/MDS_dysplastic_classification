#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import SimpleITK as sitk
import numpy as np
from skimage import measure

""" Connected thresholding: Exactly the region growing segmentation method. """


def region_growing(self, seeds, lower_threshold, upper_threshold):
    return sitk.ConnectedThreshold(self.sitk_data,
                                   seedList=seeds,
                                   lower=lower_threshold,
                                   upper=upper_threshold)


def get_seed_list(self, sitk_seg):
    filtered_seg = self.filter_out(sitk_seg, self.cfg.BBOX)

    region_props = measure.regionprops(filtered_seg, cache=False)
    areas = np.array([r.area for r in region_props])

    seeds = []
    # Get largest three components
    for i in areas.argsort()[-3:]:
        coords = region_props[i].coords
        y, x = coords[int(len(coords) / 2)]
        seeds.append((int(x), int(y), self.cfg.SLICE_IDX))
        self.logger.debug('Seed point for region growing: ({:d}, {:d}, {:d})'.format(x, y, self.cfg.SLICE_IDX))
    return seeds


def get_sitk_img(self, source_image):
    return sitk.GetImageFromArray(source_image)