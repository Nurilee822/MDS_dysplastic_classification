#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import os
import time
import glob
import logging
import json
import traceback
import numpy as np
import multiprocessing
import deepphi.io.sitk
from deepphi.io.converter.utils import *
from deepphi.io.utils.patch import DatasetManager, PatchManager
from deepphi.logger.error import *
from deepphi.utils.label_info import *
import shutil
import copy
from deepphi.image_processing.utils import *


class Converter:
    MODE = 'TRAIN'
    LIST_TYPE = {'TRAIN': ['train', 'val'], 'TEST': ['test'], 'SAMPLE': ['sample']}
    PRINT_CONVERTING = True

    def __init__(self, mode=None, encryption_key=None, decryption_key=None, *args, **kwargs):
        self.MODE = mode
        self.kafka_brokers = None
        self.encryption_key = encryption_key
        self.decryption_key = decryption_key

        # method
        self._create_method = "create"  # create, copy, link

        self.map_pid_to_filename = dict()

    def __call__(self, data_input):
        return data_input

    def _check_structure(self, input_path):
        check_msg = 'Please Check the Status of the Previous Image Processing Module whether the Module was Finished Sucessfully.'

        path_datasets = glob.glob(input_path + '/*')
        dataset_type = [os.path.basename(p) for p in path_datasets]

        if self.MODE == 'TRAIN':
            if 'train' not in dataset_type:
                logging.error('The Directory Name "train" Dose not Exist.')
                raise Exception(check_msg)

            # if 'val' not in dataset_type:
            #     logging.error('The Directory Name "val" Dose not Exist.')
            #     raise Exception(check_msg)
        elif self.MODE == 'TEST':
            if 'test' not in dataset_type:
                logging.error('The Directory Name "test" Dose not Exist.')
                raise Exception(check_msg)

    def convert_batch(self, batch, num_worker, kafka_brokers):
        # convert batch

        with multiprocessing.Pool(num_worker) as p:
            result = p.map(self._work, batch)

        result_not_None = self.process_result_one_batch(result, kafka_brokers)
        return result_not_None

    def process_result_one_batch(self, result, kafka_brokers):
        # send kafka msg
        result_not_None = list()
        for r in result:
            if isinstance(r, list):
                for rr in r:
                    self._send_file_status_message(rr, kafka_brokers=kafka_brokers)
                    result_not_None.append(rr)
            else:
                if r is not None:
                    self._send_file_status_message(r, kafka_brokers=kafka_brokers)
                    result_not_None.append(r)
        return result_not_None

    def convert(self, input_path, output_path, num_worker=1, kafka_brokers=None, split=None, concat=False, include_data_path=None):
        if split is None:
            for path in input_path:
                self._check_structure(path)
            batch_size = 20
        else:
            self._create_method = "link"
            # num_worker = 8
            batch_size = 20
        list_work = self._get_work(input_path, output_path, split=split, concat=concat, include_data_path=include_data_path)
        logging.info('The Number of Images: {}'.format(len(list_work)))
        logging.info('-' * 80)

        ##### multi-processing ####
        # create batch
        num_work = len(list_work)
        num_batch = num_work // batch_size + 1
        # list_batch = [list_work[i*batch_size: (i+1)*batch_size] for i in range(num_batch+1)]
        list_batch = [list_work[i * batch_size: (i + 1) * batch_size] for i in range(num_batch + 1) if
                      len(list_work[i * batch_size: (i + 1) * batch_size]) > 0]

        num_completed = 0
        list_result = list()
        num_batch = len(list_batch)
        for i in range(num_batch):
            batch = list_batch[i]
            logging.debug('Batch {} is Started, num_batch={}'.format(i, len(batch)))

            result = self.convert_batch(batch, num_worker, kafka_brokers)

            list_result = list_result + result
            num_completed += len(batch)
            logging.info("[Processing] {} / {} Files".format(num_completed, num_work))

        # result
        dict_class_info = {'classification': dict(), 'segmentation': dict(), 'detection': dict()}
        list_shape = list()
        list_label_shape = list()
        for r in list_result:
            for label_info in r['labelDetails']:
                cat = label_info["labelType"].lower()

                if (cat == 'classification') and (label_info['className'] != ""):
                    cls_name = label_info['className']
                    if cls_name not in dict_class_info[cat].keys():
                        dict_class_info[cat][cls_name] = {"name": str(cls_name), "count": 0, "avg_fraction": 0,
                                                          "index": 0}

                    if cls_name is not None:
                        dict_class_info[cat][cls_name]['count'] += 1

                if cat == 'segmentation':
                    for seg_info in label_info['avgFraction']:
                        cls_name = seg_info['className']
                        if cls_name not in dict_class_info[cat].keys():
                            dict_class_info[cat][cls_name] = {"name": str(cls_name), "count": 0, "avg_fraction": 0,
                                                              "index": 0}

                        dict_class_info[cat][cls_name]['avg_fraction'] += seg_info['avgFraction'] / len(list_result)
                        if np.isnan(dict_class_info[cat][cls_name]['avg_fraction']):
                            dict_class_info[cat][cls_name]['avg_fraction'] = 0

                if cat == 'detection':
                    for det_info in label_info['boxCount']:
                        cls_name = det_info["className"]
                        if cls_name not in dict_class_info[cat].keys():
                            dict_class_info[cat][cls_name] = {"name": str(cls_name), "count": 0, "avg_fraction": 0,
                                                              "index": 0}

                        dict_class_info[cat][cls_name]['count'] += det_info['count']


            list_shape.append(r['shape'])
            list_shape = list(np.unique(list_shape))

            if 'label_shape' in list(r.keys()):
                list_label_shape.append(r['label_shape'])
                list_label_shape = list(np.unique(list_label_shape))

        sample = glob.glob(f"{output_path}/*.hdf5") + glob.glob(f"{output_path}/*/*.hdf5")
        try:
            header_sample = self.load_header(sample[0])
        except:
            msg = 'Processing cannot be performed because the number of data is 0. \nPlease check the number of data.'
            raise DeepPhiError(code='worker.image-processing.error.zero-input-data')
        is_patch = header_sample['header']['patch']

        ## shape ##
        if 'pass' in list_shape:
            list_shape.remove('pass')

        if len(list_shape) == 0:
            result_shape = None
        else:
            result_shape = eval(list_shape[0])
            for s in np.unique(list_shape):
                s = eval(s)
                for i in range(len(result_shape)):
                    if result_shape[i] != s[i]:
                        result_shape[i] = None

        ## label shape ##
        if 'pass' in list_label_shape:
            list_label_shape.remove('pass')
        try:
            if len(list_label_shape) == 0:
                result_label_shape = None
            else:
                result_label_shape = eval(list_label_shape[0])
                for s in np.unique(list_label_shape):
                    s = eval(s)
                    for i in range(len(result_label_shape)):
                        if result_label_shape[i] != s[i]:
                            result_label_shape[i] = None
        except:
            result_label_shape = None

        # list class format
        pjt_module_class = dict()
        i = 0
        for cat in ['classification', 'segmentation', 'detection']:
            class_info = list()
            idx_cls = 0
            for name in dict_class_info[cat].keys():
                dict_class_info[cat][name]['index'] = idx_cls
                class_info.append(dict_class_info[cat][name])
                idx_cls += 1

            pjt_module_class[cat + "_class"] = {"class_info": class_info}
            i += 1

        msg_result_shape = {'moduleShape': str(result_shape), 'labelShape': str(result_label_shape),
                            'pjt_module_class': pjt_module_class, "patch": str(is_patch)}
        kafka_brokers.send_massage("deepphi-module-output-shape", None, msg_result_shape)
        logging.info('The Processing is Completed to the {} Images.\n'.format(len(list_work)))

    def _get_work(self, input_path, output_path, split=None, concat=False, include_data_path=None):
        list_work = list()
        # num_output = self._get_num_output(input_path, split=split)
        num_output = 1
        logging.debug("The number of output: {}".format(num_output))

        # output이 복수개 존재할 경우 하위 폴더 생성
        # if num_output > 1:
        #     for t in self.LIST_TYPE[self.MODE]:
        #         for i in range(num_output):
        #             output_subdir = output_path + '/{}/{}'.format(t, i)
        #             if not os.path.exists(output_subdir):
        #                 os.makedirs(output_subdir)

        list_input_pairs = self._get_input_path(input_path, split=split, concat=concat, include_data_path=include_data_path)
        if split is None:
            for t in self.LIST_TYPE[self.MODE]:
                output_path_this = output_path + '/' + t

                if not os.path.exists(output_path_this):
                    os.makedirs(output_path_this)

                inputs_this = list_input_pairs[t]
                for input_files in inputs_this:
                    i = 0
                    while isinstance(input_files[i], list):
                        i += 1

                    filename_wo_exe = ('.').join(input_files[i].split('.')[:-1])

                    # if num_output > 1:
                    #     output_file = [output_path_this + '/{}/{}.hdf5'.format(i, os.path.basename(filename_wo_exe)) for
                    #                    i in range(num_output)]
                    # else:
                    output_file = output_path_this + '/{}.hdf5'.format(os.path.basename(filename_wo_exe))
                    list_work.append([input_files, output_file])
        else:
            if len(input_path) > 1:
                raise Exception("split error, number of input > 1")

            if not os.path.exists(output_path + '/train'):
                os.mkdir(output_path + '/train')
            if not os.path.exists(output_path + '/val'):
                os.mkdir(output_path + '/val')
            if not os.path.exists(output_path + '/test'):
                os.mkdir(output_path + '/test')

            for j in range(len(list_input_pairs)):
                input_this = list_input_pairs[j]
                t = input_this[1]
                input_this = input_this[0]
                filename_wo_exe = ('.').join(input_this.split('.')[:-1])
                output_file = '{}/{}/{}.hdf5'.format(output_path, t, os.path.basename(filename_wo_exe))
                list_work.append([[input_this], output_file])
        return list_work

    def _get_input_path(self, input_path_list, split=None, concat=False, include_data_path=None):
        list_inputs = dict()
        list_input_pairs = dict()

        if split is None:
            for t in self.LIST_TYPE[self.MODE]:
                list_inputs[t] = list()

                list_is_patch = list()
                for input_path in input_path_list:
                    dm = DatasetManager(input_path + '/' + t)
                    list_is_patch.append(dm.is_patch())

                reconstruction = ((np.sum(list_is_patch) != 0)
                                  and (np.sum(list_is_patch) != len(list_is_patch)))

                list_original_filename = list()
                for input_path in input_path_list:
                    data_manager = DatasetManager(input_path + '/' + t)
                    inputs_this = data_manager.get_filenames()
                    if len(inputs_this) == 0:
                        continue

                    sample = self.load_header(inputs_this[0])
                    is_patch = sample['header']['patch']
                    if is_patch and reconstruction:
                        patch_manager = PatchManager(input_path + '/' + t)
                        inputs_this = patch_manager.get_patch_groups()

                    if len(inputs_this) > 0:
                        original_filename = inputs_this
                        if is_patch and reconstruction:
                            original_filename = patch_manager.get_original_filename()

                        list_inputs[t].append(inputs_this)
                        list_original_filename.append(original_filename)

                    if list_inputs[t]:
                        if not concat:
                            if is_patch and reconstruction:
                                inputs_this = patch_manager.get_original_filename()
                                self._get_patient_matched(list_original_filename[0], inputs_this)
                            self._get_patient_matched(list_original_filename[0], inputs_this)
                        else:
                            self._check_type_mixed(list_inputs[t][0], inputs_this)
                            pass

                if concat:
                    list_new = list()
                    for l in list_inputs[t]:
                        list_new = list_new + l

                    for i in range(len(list_new)):
                        list_new[i] = [list_new[i]]

                    list_inputs[t] = list_new
                    list_input_pairs[t] = np.array(list_inputs[t])
                else:
                    # 각 input path에서 대응되는 파일들끼리 묶어줌
                    list_input_pairs[t] = list(zip(*list_inputs[t]))
            # check duplicate
            if concat:
                list_filename = list()
                for t in self.LIST_TYPE[self.MODE]:
                    for filename in list_input_pairs[t]:
                        basename = os.path.basename(filename[0])
                        if basename in list_filename:
                            msg = "There are duplicated files in your inputs. filename : {}".format(basename)
                            raise DeepPhiError(code="worker.image-processing.error.concat-duplicate", parameter={'basename': basename})
                        else:
                            list_filename.append(basename)

            return list_input_pairs
        else:
            input_path = input_path_list[0]
            if include_data_path == None:
                inputs_this = glob.glob(input_path + '/*.hdf5')
            else:
                inputs_this = list()
                for key in include_data_path.keys():
                    t = key[:-4]
                    if t == "validation":
                        t = "val"
                    include_data = open(f"{include_data_path[key]}", 'r')
                    include_list = eval(include_data.read())
                    include_data.close()
                    for filename in include_list:
                        inputs_this.append([input_path + filename, t])
            return inputs_this

    def _check_type_mixed(self, list_patient1, list_patient2):
        filename1 = list_patient1[0]
        filename2 = list_patient2[0]

        data1 = self.load_header(filename1)
        data2 = self.load_header(filename2)

        if data1['header']['patch'] != data2['header']['patch']:
            raise Exception('"Normal image" and "Patch image" must not be mixed in the "concat" method.')

    def _get_patient_matched(self, list_patient1, list_patient2):
        dirname1 = os.path.basename(os.path.dirname(list_patient1[0]))
        dirname2 = os.path.basename(os.path.dirname(list_patient2[0]))
        if len(list_patient1) != len(list_patient2):
            # raise Exception(
                # 'The number of input files in {} and {} does not matched. Please Check Your Inputs.'.format(dirname1,
                #                                                                                             dirname2))
            raise DeepPhiError(code='worker.image-processing.error.merge-input-file-mismatch',
                               parameter={"dirname1": dirname1, "dirname2": dirname2})

        list_basepath1 = self._get_basepath(list_patient1)
        list_basepath2 = self._get_basepath(list_patient2)

        if list_basepath1 != list_basepath2:
            raise Exception('The files in the {} and {} dose not mateched.'.format(dirname1, dirname2))

        return list_basepath1

    def _get_basepath(self, list_path):
        list_basepath = list()
        for path in list_path:
            list_basepath.append(os.path.basename(path))

        return list_basepath

    def _work_processing(self, input_files, output_file):
        data_input = list()
        for i in range(len(input_files)):
            filename = input_files[i]
            if self.decryption_key is not None:
                data_input.append(self.load(filename, decryption_key=str(self.decryption_key[i])))
            else:
                data_input.append(self.load(filename))

        if output_file[-7:] == "/_/pass":
            data_output = data_input[0]
            output_file = output_file[:-7]
            # is_shape_pass = True
        else:
            if self._create_method == "link":
                data_output = data_input[0]
            else:
                data_output = self.__call__(*data_input)

                if data_output is not None:
                    if isinstance(data_output, list):
                        for i, d in enumerate(data_output):
                            data_output[i] = self._validation_label(d)
                    elif isinstance(data_output, DeepphiSaveQueue):
                        pass
                    else:
                        data_output = self._validation_label(data_output)

        return data_output

    def _validation_label(self, data_output):
        # mask = data_output['label']['segmentation']['array']
        # if len(mask) > 0:
        #     object_map = np.sum(mask, axis=-1) < 1
        #     mask[..., 0][object_map] = 1
        #     data_output['label']['segmentation']['array'] = mask
        return data_output

    def _work(self, work):
        input_files, output_file = work
        output_file_base = output_file[:]
        if isinstance(output_file, list):
            for i in range(len(output_file_base)):
                output_file_base[i] = os.path.basename(output_file_base[i])
        elif isinstance(output_file, str):
            output_file_base = os.path.basename(output_file_base)

        start_time = time.time()
        pid = os.getpid()
        self.map_pid_to_filename[pid] = output_file
        data_output = self._work_processing(input_files, output_file)
        processing_time = time.time() - start_time

        if isinstance(data_output, DeepphiSaveQueue):
            result = data_output.list_result
        elif data_output is not None:
            if self._create_method == "link":
                for input in input_files:
                    # logging.info("create symlink")
                    shutil.copy(input, output_file, follow_symlinks=True)
            else:
                output_file = self.save(output_file, data_output)

            def _create_msg(output_file, data_output):
                # create msg
                shape = list(data_output['image']['array'].shape)
                if self._create_method == 'link':
                    shape = list(data_output['image']['header']['shape'])

                if not data_output['image']['header']['IsVector']:
                    shape.append(1)
                color_mode = data_output['image']['header']['color_mode']
                label_info = self._create_label_info(data_output)

                result = {"output_file": output_file, "status": 'COMPLETED',
                          "shape": str(shape), "color_mode": color_mode, "processingTime": processing_time,
                          'error_msg': None, 'labelDetails': label_info}

                if np.any(data_output['label']['transformation']['array']):
                    label_shape = list(data_output['label']['transformation']['array'].shape)
                    if not data_output['label']['transformation']['header']['IsVector']:
                        label_shape.append(1)
                    result['label_shape'] = str(label_shape)
                if np.any(data_output['label']['segmentation']['array']):
                    label_shape = list(data_output['label']['segmentation']['array'].shape)
                    if not data_output['label']['segmentation']['header']['IsVector']:
                        label_shape = label_shape.append(1)
                    result['label_shape'] = str(label_shape)
                return result

            if isinstance(output_file, list):
                result = list()
                for of, do in zip(output_file, data_output):
                    r = _create_msg(of, do)
                    result.append(r)
            else:
                result = _create_msg(output_file, data_output)
        else:
            result = None
        return result

    def _create_label_info(self, data_output):
        label_details = get_label_info(data_output)
        return label_details

    def _send_kafka_message(self, msg, kafka_brokers=None):
        result_topic = 'deepphi-module-execute-output'
        msg['path'] = os.path.abspath(msg['path'])
        if kafka_brokers is not None:
            kafka_brokers.send_massage(result_topic, msg['resultStatus'], msg)
        else:
            logging.info(msg)

    def _send_file_status_message(self, result, kafka_brokers=None):
        output_file = result['output_file']
        status = result['status']
        shape = result['shape']
        color_mode = result['color_mode']
        label_info = copy.deepcopy(result['labelDetails'])

        output_file = os.path.abspath(output_file)
        train_val = output_file.split('/')[-2]
        if status not in ('RUNNING', 'COMPLETED', 'WAITING', 'ERROR'):
            raise Exception('The status "{}" is not available status. Please check your status.'.format(status))

        msg = {"patientId": "", "path": "where", "filename": "None", "resultStatus": status,
               "size": "None", "shape": shape, "color_mode": color_mode, 'processingTime': result['processingTime'],
               'train_val': train_val, 'labelDetails': label_info}

        if isinstance(output_file, list):
            for filename in output_file:
                msg['path'] = filename

                basename = os.path.basename(filename)
                dirname = os.path.dirname(filename).split('/')[-1]
                msg['filename'] = "{}/{}".format(dirname, basename)
                if status == 'COMPLETED':
                    msg['size'] = os.path.getsize(filename)

                self._send_kafka_message(msg, kafka_brokers=kafka_brokers)
        else:
            filename = output_file
            msg['path'] = output_file
            basename = os.path.basename(filename)
            dirname = os.path.dirname(filename).split('/')[-1]
            msg['filename'] = "{}/{}".format(dirname, basename)

            if status == 'COMPLETED':
                msg['size'] = os.path.getsize(filename)
            self._send_kafka_message(msg, kafka_brokers=kafka_brokers)

        if status == "ERROR":
            raise Exception(result['error_msg'])

    def load(self, filename, decryption_key=None):
        if self._create_method == "link":
            data = deepphi.io.sitk.DeepPhiDataSet()
            data.load(filename, decryption_key=decryption_key)
            # data = self.load_header(filename)
        else:
            if isinstance(filename, list):
                data = list()
                for f in filename:
                    d = deepphi.io.sitk.DeepPhiDataSet()
                    d.load(f, decryption_key=decryption_key)
                    data.append(d)
            else:
                data = deepphi.io.sitk.DeepPhiDataSet()
                data.load(filename, decryption_key=decryption_key)
        return data

    def load_header(self, filename):
        data = deepphi.io.sitk.DeepPhiDataSet()
        data.load_header(filename)
        return data

    def save(self, save_path, data):
        if len(save_path) > 1 and not isinstance(save_path, str):
            for d, p in zip(data, save_path):
                d.save(p, encryption_key=self.encryption_key)
            output_file = save_path
        elif isinstance(data, list):
            output_file = list()

            dirname = os.path.dirname(save_path)
            basename = os.path.basename(save_path)[:-5]  # without .hdf5

            for i in range(len(data)):
                filename = "{}/{}_{:04d}.hdf5".format(dirname, basename, i)
                data[i]["header"]["patch"] = True
                data[i]["header"]["patch_original_filename"] = "{}.hdf5".format(basename)
                data[i]['header']['filename'] = os.path.basename(filename)

                data[i].save(filename, encryption_key=str(self.encryption_key))
                # logging.info(filename, str(self.encryption_key))
                output_file.append(filename)
        else:
            data.save(save_path, encryption_key=self.encryption_key)
            output_file = save_path

        return output_file

    def _get_num_output(self, input_path, split=None):
        data_input = list()
        output = None
        i = 0
        while output is not None:
            for path in input_path:
                if split is None:
                    input_file = glob.glob(path + '/*/*.hdf5')[i]
                else:
                    input_file = glob.glob(path + '/*.hdf5')
                    input_file = input_file[i]
                data_input.append(self.load(input_file))
            output = self.__call__(*data_input)
            i += 1

        return len(output)


class TemplateConvereter2(Converter):
    def __init__(self, fraction, dimension):
        super(TemplateConvereter2, self).__init__()

        self._fraction = fraction
        self._dimension = dimension
        self.list_type = ['train', 'test', 'val']

    def convert(self, input_path, output_path, num_worker=1, kafka_brokers=None):
        logging.info('-' * 80)
        self.kafka_brokers = kafka_brokers

        for path in input_path:
            self._check_structure(path)

        list_work = self._get_work(input_path, output_path)

        # create batch
        batch_size = 20
        num_work = len(list_work)
        num_batch = num_work // batch_size + 1
        list_batch = [list_work[i * batch_size: (i + 1) * batch_size] for i in range(num_batch + 1)]

        num_completed = 0
        for i in range(num_batch):
            batch = list_batch[i]
            logging.debug('Batch {} is Started, num_batch={}'.format(i, len(batch)))

            # convert batch
            with multiprocessing.Pool(num_worker) as p:
                p.map(self._work, batch)

            num_completed += len(batch)
            logging.info("[Converting] {} / {} Files".format(num_completed, num_work))


from deepphi.io.sitk import DeepPhiDataSet


class Preprocessing(Converter):
    def __init__(self, mode=None, name=None):
        super(Preprocessing, self).__init__(mode=mode)
        self._input_node = None
        self._output_node = None
        self._data = None
        if name is None:
            self.name = self.__class__.__name__
        else:
            self.name = name

    def __call__(self, data):
        img = data['array']
        output = {'array': img, 'header': data['header'], 'label': data['label']}
        return output

    def init_data(self, data):
        if isinstance(data, DeepPhiDataSet):
            self._data = data
        else:
            raise ImportError("Input Data is not in DeepPhiDataSet format.")

    def add_array(self, output_img, dtype=None):
        if dtype is None:
            dtype = 'uint8'
        self._data['image']['array'] = np.asarray(output_img, dtype)

    def add_color_mode(self, mode):
        self._data['image']['header']['color_mode'] = mode

    def add_class(self, clss):
        """ Add label class information of the image array.
        Args:
        clss    (str)   label class information

        Example:
              add_class('pneumonia')

        """
        self._data['image']['header']['class'] = clss

    def change_dtype(self, dtype):
        """
        Args:
        dtype  (str)   dtype to change into.

        Example:
            change_dtype('uint8')
        """
        self._data['image']['array'] = (self._data['image']['array']).astype(dtype)

    def get_dtype(self):
        return self._data['image']['array'].dtype

    def get_image_array(self):
        return self._data['image']['array']

    def get_data(self):
        return self._data

    def get_history(self):
        return self._data['image']['header']['history']

    def get_color_mode(self):
        return self._data['image']['header']['color_mode']

    def get_modality(self):
        return self._data['image']['header']['modality']

    def get_image_dimension(self):
        return self._data['image']['header']['dim']

    def connect(self, node):
        node._input_node = self
        self._output_node = node

    def previous(self):
        return self._input_node

    def next(self):
        return self._output_node

    def process_to(self, array, target_name):
        array = self.__call__(array)
        if self.name != target_name:
            array = self._output_node.process_to(array, target_name)
        return array

    def process_from(self, array, target_name):
        if self.name != target_name:
            array = self._input_node.process_from(array, target_name)
        array = self.__call__(array)
        return array
