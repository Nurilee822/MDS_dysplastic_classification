#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#

import openslide as ops
from deepphi.image_processing.utils import timeit, display
import numpy as np


@timeit
def load_svs(svs_path):
    return ops.open_slide(svs_path)


@timeit
def svs2array(svs_path):
    ops_image = load_svs(svs_path)

    zero_pt = (0, 0)
    level = ops_image.level_count - 1
    dimension = ops_image.level_dimensions[level]

    img_array = np.array(ops_image.read_region(location=zero_pt,
                                               level=level,
                                               size=dimension)
                                  .convert('RGB'))
    return img_array


if __name__ == "__main__":

    """  TEST: class OpsProcessing()  """
    # For unit test : data path
    SVS_DIR = '/home/hslisalee/DEEPPHI/datasets/crc/svs/'
    XML_DIR = '/home/hslisalee/DEEPPHI/datasets/crc/xml/'

    SAMPLE_SVS = SVS_DIR + '1035154_.svs'
    SAMPLE_XML = XML_DIR + '1035154_.xml'

    img_array = svs2array(SAMPLE_SVS)

    #  Result Display
    display(img_array, add_to_title='Image array from .svs file')
