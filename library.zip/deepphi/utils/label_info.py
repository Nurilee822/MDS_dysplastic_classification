import numpy as np


def get_label_info(data_output):
    # label info
    label_details = list()

    info_cls = {"labelType": "CLASSIFICATION", "className": "", "index": 0,
                "prediction": None, "probability": None}
    if len(data_output['label']['classification']['array']) > 0:
        class_name = data_output.get_name_classification_label()
        index = np.argmax(data_output['label']['classification']['array'])
        info_cls["className"] = class_name
        info_cls["index"] = index

        if len(data_output['prediction']['classification']['array']) > 0:
            prediction_class_name, probability, index = data_output.get_name_classification_prediction()
            info_cls["prediction"] = prediction_class_name
            info_cls["probability"] = probability
    label_details.append(info_cls)

    info_seg = {"labelType": "SEGMENTATION", "avgFraction": list()}
    if 'class_name' in data_output['label']['segmentation']['header'].keys():
        list_class = list(data_output['label']['segmentation']['header']['class_name'])
        total = np.sum(data_output['label']['segmentation']['array'])
        for i in range(len(list_class)):
            cls_name = list_class[i]
            count = np.sum(data_output['label']['segmentation']['array'][..., i])
            fraction = count / total
            if np.isnan(fraction):
                fraction = 0
            info = {"className": cls_name, "index": i, "avgFraction": fraction}
            info_seg['avgFraction'].append(info)
    label_details.append(info_seg)

    info_det = {"labelType": "DETECTION", "boxCount": [], "objectCount": None}
    if 'class_name' in data_output['label']['object_detection']['header'].keys():
        list_det_cls = list(
            data_output['label']['object_detection']['header']['class_name'])
    elif 'classes' in data_output['label']['object_detection']['header'].keys():
        list_det_cls = list(
            data_output['label']['object_detection']['header']['classes'].keys())
    else:
        list_det_cls = list()

    if len(list_det_cls) > 0:
        idx_cls = 0
        if np.any(data_output['label']['object_detection']['bbox_class']):
            label = np.argmax(data_output['label']['object_detection']['bbox_class'], axis=-1)
            total_count = 0
            for cls_name in list_det_cls:
                count = np.sum(label == idx_cls)
                total_count += count
                info = {
                    "className": cls_name,
                    "index": idx_cls,
                    "count": count
                }
                info_det["boxCount"].append(info)
                idx_cls += 1
            info_det["objectCount"] = total_count
    label_details.append(info_det)
    return label_details


def get_label_info_total(list_label_info):
    info_total = {"classification_class": {"class_info": list()},
                  "segmentation_class": {"class_info": list()},
                  "detection_class": {"class_info": list()}
                  }

    for label_info in list_label_info:
        info_total = update_cls_info(info_total, label_info)
        info_total = update_seg_info(info_total, label_info)
        info_total = update_det_info(info_total, label_info)

    return info_total


def update_cls_info(info_total, label_info):
    cls_info = label_info[0]
    name = cls_info["className"]
    index = cls_info["index"]

    name_to_idx = dict()
    for i in range(len(info_total["classification_class"]["class_info"])):
        info = info_total["classification_class"]["class_info"][i]
        name_to_idx[info['name']] = i

    if name not in name_to_idx.keys():
        info = {"name": name, "count": 0, "avg_fraction": 0, "index": index}
        info_total["classification_class"]["class_info"].append(info)
    else:
        idx = name_to_idx[name]
        info_total["classification_class"]["class_info"][idx]["count"] += 1

    return info_total


def update_seg_info(info_total, label_info):
    seg_info = label_info[1]['avgFraction']

    if len(info_total["segmentation_class"]["class_info"]) == 0:
        for info in seg_info:
            info2 = {"name": info["className"], "count": 0, "avg_fraction": 0, "index": info["index"]}
            info_total["segmentation_class"]["class_info"].append(info2)

    for i in range(len(seg_info)):
        avg_fraction = seg_info[i]["avgFraction"]
        info_total["segmentation_class"]["class_info"][i]["avg_fraction"] += avg_fraction

    return info_total


def update_det_info(info_total, label_info):
    det_info = label_info[2]['boxCount']

    if len(info_total["detection_class"]["class_info"]) == 0:
        for info in det_info:
            info2 = {"name": info["className"], "count": 0, "avg_fraction": 0, "index": info["index"]}
            info_total["detection_class"]["class_info"].append(info2)

    for i in range(len(det_info)):
        count = det_info[i]["count"]
        info_total["detection_class"]["class_info"][i]["count"] += count

    return info_total

