from source.image_processing import rescale
import cv2


def overlay_convert(ori_convert, label_convert):
    ori_convert = rescale(ori_convert)
    label_convert = rescale(label_convert)

    if ori_convert.ndim == 2:
        if label_convert.ndim == 3:
            ori_convert = cv2.cvtColor(ori_convert,cv2.COLOR_GRAY2RGB)
    else:
        if label_convert.ndim == 2:
            label_convert = cv2.cvtColor(label_convert, cv2.COLOR_GRAY2RGB)

    overlay_img = cv2.addWeighted(ori_convert, 0.5, label_convert, 0.5, 0)
    return overlay_img
