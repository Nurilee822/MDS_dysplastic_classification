import numpy as np
import cv2, math
from PIL import ImageFont, ImageDraw, Image
from source.image_processing import *
from source.class_color.color_dictionary import color_dictionary
from source.class_color.rgb2hex import hex_to_rgb


def classification_convert(image, class_color_info, label_array, class_name_info):
    if len(image.shape) == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    font_size = math.ceil(image.shape[1] / 20) + 1
    y_blank = math.ceil(font_size * 1.4)
    height = image.shape[0]
    margin_list = [[0, y_blank], [0, 0]]
    if image.ndim == 3:
        margin_list.append([0, 0])
    image = np.pad(image, margin_list, mode='constant')
    class_name_info = list(map(str, class_name_info))
    class_name = class_name_info[int(np.where(label_array == 1.)[0][0])]
    if class_color_info == []:
        class_color = color_dictionary()[int(np.where(label_array == 1.)[0][0])]
    else:
        class_color = hex_to_rgb(class_color_info[int(np.where(label_array == 1.)[0][0])])
    font_path = './font/NanumGothicBold.ttf'
    font = ImageFont.truetype(font_path, font_size)
    text = "Class Name : %s" %class_name

    image = Image.fromarray(image)
    draw = ImageDraw.Draw(image)
    draw.text((0,height), text,font=font, fill=class_color)
    image = np.array(image)
    return image
