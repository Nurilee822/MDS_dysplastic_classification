import numpy as np


def dif_convert(label, prediction):
    ch_idx = np.argmax(label, axis=-1)
    one_hot_img = np.zeros_like(label)
    for i in range(label.shape[-1]):
        one_hot_img[..., i] = (ch_idx == i).astype(int)
    label = one_hot_img

    ch_idx = np.argmax(prediction, axis=-1)
    one_hot_img = np.zeros_like(prediction)
    for i in range(prediction.shape[-1]):
        one_hot_img[..., i] = (ch_idx == i).astype(int)
    prediction = one_hot_img

    tmp_prediction = np.float32(prediction)
    tmp_label = np.float32(label)
    tmp_backgroud = label[:, :, 0]
    dif_seg_img = np.zeros((tmp_label.shape[0], tmp_label.shape[1], 3))
    prediction_idx = np.argmax(tmp_prediction, axis=-1)
    label_idx = np.argmax(tmp_label, axis=-1)
    dif_seg_img[label_idx == prediction_idx] = (0, 255, 0)
    dif_seg_img[tmp_backgroud == 1] = (0, 0, 0)
    dif_seg_img[label_idx != prediction_idx] = (255, 0, 0)
    return dif_seg_img