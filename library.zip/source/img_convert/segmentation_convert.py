import numpy as np
from source.class_color.color_dictionary import color_dictionary
from source.class_color.rgb2hex import hex_to_rgb


def segmentation_convert(image, class_color):
    if image.ndim == 2:
        img_convert = image
        img_ch = 0
    else:
        if image.shape[-1] == 1:
            img_convert = image[:,:,0]
            img_ch = 0
        else:
            ch_idx = np.argmax(image, axis=-1)
            one_hot_img = np.zeros_like(image)
            for i in range(image.shape[-1]):
                one_hot_img[..., i] = (ch_idx == i).astype(int)
            image = one_hot_img
            img_ch = image.shape[2]
            # if img_ch == 2:
            #     img_convert = image[:, :, 1]
            # else:
            tmp_img = np.float32(np.zeros((image.shape[0], image.shape[1], 3)))
            if class_color == []:
                tmp_img[image[:, :, 0] == 1] = (0, 0, 0)
                tmp_img[image[:, :, 1] == 1] = (255, 255, 255)
                for i in range(2, img_ch):
                    tmp_img[image[:, :, i] == 1] = color_dictionary()[i - 2]
            else:
                for i in range(img_ch):
                    tmp_img[image[:, :, i] == 1] = hex_to_rgb(class_color[i])
            img_convert = tmp_img
    return img_convert, img_ch


