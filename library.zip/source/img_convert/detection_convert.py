import numpy as np
from source.class_color.rgb2hex import hex_to_rgb
from source.class_color.color_dictionary import color_dictionary
from PIL import ImageFont, ImageDraw, Image
import cv2


def detection_convert(image, class_name, bbox_coordinate, bbox_class, class_color_info):
    if np.any(bbox_class):
        class_color = np.zeros((bbox_class.shape[1], 3))
        for i in range(len(class_name)):
            if class_color_info == []:
                class_color[i,] = color_dictionary()[i]
            else:
                class_color[i,] = hex_to_rgb(class_color_info[i])
    horizontal_size = image.shape[1]
    font_size = int(image.shape[1] / 15)
    font_path = './font/NanumGothicBold.ttf'
    font = ImageFont.truetype(font_path, font_size)
    box_thick = int(round(horizontal_size * (2 / 512)))
    for i in range(len(bbox_class)):
        tmp = np.zeros_like(bbox_class[0])
        tmp[list(bbox_class[i]).index(max(bbox_class[i]))] = 1.
        bbox_class[i] = tmp
    if bbox_class.shape[0] > 0:
        for i in range(bbox_class.shape[0]):
            if np.any(bbox_coordinate[i]):
                if len(image.shape) == 2:
                    image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
                image = cv2.rectangle(image, (int(bbox_coordinate[i, 1]), int(bbox_coordinate[i, 0])),
                                      (int(bbox_coordinate[i, 3]), int(bbox_coordinate[i, 2])),
                                      class_color[np.where(bbox_class[i] == 1)[0][0]], box_thick)
                text_name = class_name[np.where(bbox_class[i] == 1)[0][0]]
                image = Image.fromarray(image)
                draw = ImageDraw.Draw(image)
                draw.text((int(bbox_coordinate[i, 1]), int(bbox_coordinate[i, 0])), text_name,
                          font=font, fill=(255, 0, 255))
                tmp = np.array(image)
                image = tmp
    return image, 3