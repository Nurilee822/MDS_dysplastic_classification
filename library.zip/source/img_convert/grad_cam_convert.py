from source.image_processing import *
from source.image_processing import rescale


def grad_cam_convert(ori_convert, cam_img):
    ori_convert = rescale(ori_convert)
    cam_img = rescale(cam_img)
    if ori_convert.ndim == 2:
        ori_convert = cv2.cvtColor(ori_convert, cv2.COLOR_GRAY2RGB)
    new_cam_img = np.copy(ori_convert)
    [i,j] = np.where(cam_img[:,:,0] > 30)
    if np.any(i):
        new_cam_img[i,j] = cv2.addWeighted(cam_img[i,j], 0.5, new_cam_img[i,j], 0.5, 0)
    # else:
    #     new_cam_img = cv2.addWeighted(cam_img, 0.5, new_cam_img, 0.5, 0)
    return new_cam_img