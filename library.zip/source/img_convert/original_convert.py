import numpy as np
from source.img_convert.segmentation_convert import segmentation_convert


def original_convert(ori_img, color_mode = None):
    if ori_img.ndim == 2:
        ori_convert = ori_img
        ori_img_ch = 0
    else:
        ori_img_ch = ori_img.shape[-1]
        if color_mode == 'mask':
            tmp_img = np.float32(np.zeros((ori_img.shape[0:2])))
            for i in range(1, ori_img_ch):
                tmp_img = ori_img[:, :, i] * i  + tmp_img
            ori_convert = tmp_img
            # ori_convert = ori_img.sum(axis=2)
            ori_img_ch = 1

        elif (ori_img_ch == 3) & (color_mode != 'Series'):
            ori_convert = ori_img
        else:
            tmp_img = np.float32(np.zeros((ori_img.shape[0:2])))
            for i in range(ori_img_ch):
                tmp_img = ori_img[:, :, i] * (i + 1) + tmp_img
            ori_convert = tmp_img
            # ori_convert = ori_img.sum(axis=2)
            ori_img_ch = 1
    return ori_convert, ori_img_ch

