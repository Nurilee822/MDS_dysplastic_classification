import numpy as np


def transformation_convert(image, color_mode = None):
    if image.ndim == 2:
        img_convert = image
        img_ch = 0
    else:
        img_ch = image.shape[-1]
        if (img_ch == 3) & (color_mode != 'Series'):
            img_convert = image
        else:
            tmp_img = np.float32(np.zeros((image.shape[0:2])))
            for i in range(img_ch):
                tmp_img = image[:, :, i] * (i + 1) + tmp_img
            img_convert = tmp_img
    return img_convert, img_ch