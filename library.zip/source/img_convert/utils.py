import io, base64
from source.image_processing import *
from PIL import Image
from encryption.aes_encryption import DeepPhiAESCipher


# base64 encoding
def image2base64(image):
    image = rescale(image)
    image = resize(image)
    image = Image.fromarray(image)
    rawBytes = io.BytesIO()
    image.save(rawBytes, "JPEG")
    rawBytes.seek(0)
    output = base64.b64encode(rawBytes.read())
    output = output.decode('utf-8')
    return output


# Image Key
def find_key(request_msg):
    if request_msg['isDataset']:
        image_key = DeepPhiAESCipher(type='dataset').decrypt(request_msg['encryptionKey'])
    else:
        image_key = DeepPhiAESCipher(type='project').decrypt(request_msg['encryptionKey'])
    return image_key


# class color
def class_color_setting(request_msg):
    if 'pjtColor' in request_msg:
        class_color_info = request_msg['pjtColor']['colorDTO']
        color_type = 'pjtColor'
    elif 'datasetColor' in request_msg:
        try:
            tmp_class_color_info = request_msg['datasetColor']['classInfos']
            tmp_label = [tmp_class_color_info[i]['labelType'] for i in range(len(tmp_class_color_info))]
            tmp_class_info = [tmp_class_color_info[i]['class_info'] for i in range(len(tmp_class_color_info))]
            class_color_info = [
                {'labelType': 'CLASSIFICATION', 'class_info': tmp_class_info[tmp_label.index('CLASSIFICATION')]},
                {'labelType': 'SEGMENTATION', 'class_info': tmp_class_info[tmp_label.index('SEGMENTATION')]},
                {'labelType': 'DETECTION', 'class_info': tmp_class_info[tmp_label.index('DETECTION')]}]
            color_type = 'datasetColor'
        except:
            class_color_info = []
            color_type = 'None'
    else:
        class_color_info = []
        color_type = 'None'
    return class_color_info, color_type


