import numpy as np

class DataLoad(object):
    def __init__(self, request_labelType = None):
        self.request_labelType = request_labelType

    def load_original(self, data, slice=None):
        img_array = np.array([])
        if slice != None:
            img_array = data['image']['array'][slice,]
        else:
            img_array = data['image']['array'][:]
        return img_array

    def load_label(self, data, slice=None):
        label_array = np.array([])
        if self.request_labelType == 'CLASSIFICATION':
            if np.any(data['label']['classification']['array'].shape):
                label_array = data['label']['classification']['array'][:]
        if self.request_labelType == 'SEGMENTATION':
            if np.any(data['label']['segmentation']['array'].shape):
                if slice != None:
                    label_array = data['label']['segmentation']['array'][slice,]
                else:
                    label_array = data['label']['segmentation']['array'][:]
        if self.request_labelType == 'TRANSFORMATION':
            if 'transformation' in data['label']:
                if np.any(data['label']['transformation']['array'].shape):
                    if slice != None:
                        label_array = data['label']['transformation']['array'][slice,]
                    else:
                        label_array = data['label']['transformation']['array'][:]
        if self.request_labelType == 'DETECTION':
            if np.any(data['label']['object_detection']['bbox_coordinate'].shape):
                label_array =[]
                label_array.append(data['label']['object_detection']['bbox_coordinate'][:])
                label_array.append(data['label']['object_detection']['bbox_class'][:])
        return label_array

    def load_prediction(self, data, slice=None):
        prediction_array = np.array([])
        if self.request_labelType == 'CLASSIFICATION':
            if np.any(data['prediction']['classification']['array'].shape):
                prediction_array = data['prediction']['classification']['array'][:]
        if self.request_labelType == 'SEGMENTATION':
            if np.any(data['prediction']['segmentation']['array'].shape):
                if slice != None:
                    prediction_array = data['prediction']['segmentation']['array'][slice,]
                else:
                    prediction_array = data['prediction']['segmentation']['array'][:]
        if self.request_labelType == 'TRANSFORMATION':
            if 'transformation' in data['prediction']:
                if np.any(data['prediction']['transformation']['array'].shape):
                    if slice != None:
                        prediction_array = data['prediction']['transformation']['array'][slice,]
                    else:
                        prediction_array = data['prediction']['transformation']['array'][:]
        if self.request_labelType == 'DETECTION':
            if np.any(data['prediction']['object_detection']['bbox_coordinate'].shape):
                prediction_array = []
                prediction_array.append(data['prediction']['object_detection']['bbox_coordinate'][:])
                prediction_array.append(data['prediction']['object_detection']['bbox_class'][:])
        return prediction_array

    def load_cam(self, data, slice=None):
        cam_array = np.array([])
        if 'grad_cam' in data['prediction']['classification']:
            if np.any(data['prediction']['classification']['grad_cam'].shape):
                if slice != None:
                    cam_array = data['prediction']['classification']['grad_cam'][slice,]
                else:
                    cam_array = data['prediction']['classification']['grad_cam'][:]
        return cam_array

class InfoLoad(object):

    def info_original(self, data):
        img_shape = data['image']['array'].shape
        img_header = dict(data['image'].attrs)
        return img_shape, img_header

    def info_label(self, data):
        label_shape = {}
        label_header = {}
        label_type = []
        if np.any(data['label']['classification']['array'].shape):
            label_type.append('CLASSIFICATION')
            label_shape['Classification'] = data['label']['classification']['array'].shape
            label_header['Classification'] = dict(data['label']['classification'].attrs)
        if np.any(data['label']['segmentation']['array'].shape):
            label_type.append('SEGMENTATION')
            label_shape['Segmentation'] = data['label']['segmentation']['array'].shape
            label_header['Segmentation'] = dict(data['label']['segmentation'].attrs)
        if np.any(data['label']['object_detection']['bbox_coordinate'].shape):
            label_type.append('DETECTION')
            label_shape['Detection'] = data['label']['object_detection']['bbox_coordinate'].shape
            label_header['Detection'] = dict(data['label']['object_detection'].attrs)
        # transformation 추가되어서 기존 데이터들 key없는 것들 고려
        if 'transformation' in data['label']:
            if np.any(data['label']['transformation']['array'].shape):
                label_type.append('TRANSFORMATION')
                label_shape['Transformation'] = data['label']['transformation']['array'].shape
                label_header['Transformation'] = dict(data['label']['transformation'].attrs)
        return label_shape, label_header, label_type

    def info_prediction(self, data):
        prediction_type = []
        if np.any(data['prediction']['classification']['array'].shape):
            prediction_type.append('CLASSIFICATION')
        if np.any(data['prediction']['segmentation']['array'].shape):
            prediction_type.append('SEGMENTATION')
        if np.any(data['prediction']['object_detection']['bbox_coordinate'].shape):
            prediction_type.append('DETECTION')
        if 'transformation' in data['prediction']:
            if np.any(data['prediction']['transformation']['array'].shape):
                prediction_type.append('TRANSFORMATION')
        return prediction_type