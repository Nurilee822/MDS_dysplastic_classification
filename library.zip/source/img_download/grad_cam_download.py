import os
from source.data_load import *
from source.image_processing import rescale
from source.img_save import img_save
from encryption.image_encryption import decryption
from source.img_convert.grad_cam_convert import grad_cam_convert

def grad_cam_download(data, image_key, output_path, filename):
    img_shape, img_header = InfoLoad().info_original(data)
    img_dimension = img_header['dim']
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    output_path = output_path + os.sep

    if img_dimension == 2:
        ori_img = DataLoad('CLASSIFICATION').load_original(data)
        ori_img = decryption(ori_img, image_key)
        # fourier image
        if 'fourier' in img_header:
            complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
            ori_img = np.float32(np.log(np.abs(complex_img)))
        cam_img = DataLoad().load_cam(data)
        if ori_img.shape[0:2] == cam_img.shape[0:2]:
            cam_convert = grad_cam_convert(ori_img, cam_img)
            download_path = output_path + '%s.jpg' % (filename[0:-5])
            img_save(cam_convert, download_path, 3)
    else:
        if not os.path.exists(output_path + '%s' % (filename[0:-5])):
            os.mkdir(output_path + '%s' % (filename[0:-5]))
        for slice in range(img_shape[0]):
            ori_img = DataLoad('CLASSIFICATION').load_original(data, slice=slice)
            ori_img = decryption(ori_img, image_key)
            # fourier image
            if 'fourier' in img_header:
                complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
                ori_img = np.float32(np.log(np.abs(complex_img)))
            cam_img = DataLoad().load_cam(data, slice=slice)
            if ori_img.shape[0:2] == cam_img.shape[0:2]:
                cam_convert = grad_cam_convert(ori_img, cam_img)
                download_path = output_path + '%s' % (filename[0:-5]) + os.sep + '%s_%s.jpg' % ((filename[0:-5]), str(slice + 1).zfill(len(str(img_shape[0]))))
                img_save(cam_convert, download_path, 3)