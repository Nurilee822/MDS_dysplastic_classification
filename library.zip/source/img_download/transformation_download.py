import os
from source.data_load import *
from source.img_save import img_save
from source.img_convert.transformation_convert import transformation_convert

def transformation_download(data, label_shape, label_header, output_path, filename, data_type = None):
    img_dimension = label_header['dim']
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    output_path = output_path + os.sep
    if label_shape[0] > 0:
        if img_dimension == 2:
            if data_type == 'label':
                image = DataLoad('TRANSFORMATION').load_label(data)
            else:
                image = DataLoad('TRANSFORMATION').load_prediction(data)
            download_path = output_path + '%s.jpg' % (filename[0:-5])
            image_convert, image_ch = transformation_convert(image)
            img_save(image_convert, download_path, image_ch)
        else:
            if not os.path.exists(output_path + '%s' % (filename[0:-5])):
                os.mkdir(output_path + '%s' % (filename[0:-5]))
            for slice in range(label_shape[0]):
                if data_type == 'label':
                    image = DataLoad('TRANSFORMATION').load_label(data, slice=slice)
                else:
                    image = DataLoad('TRANSFORMATION').load_prediction(data, slice=slice)
                download_path = output_path + '%s' % (filename[0:-5]) + os.sep + '%s_%s.jpg' % ((filename[0:-5]), str(slice+1).zfill(len(str(label_shape[0]))))
                image_convert, image_ch = transformation_convert(image)
                img_save(image_convert, download_path, image_ch)