import os
from source.data_load import *
from source.image_processing import rescale
from source.img_save import img_save
from encryption.image_encryption import decryption
from source.img_convert.detection_convert import detection_convert
from source.class_color.color_matching import class_color_match

def detection_download(data, image_key, label_header, output_path, filename, color_type, class_color_info, data_type = None):
    img_shape, img_header = InfoLoad().info_original(data)
    img_dimension = img_header['dim']
    color_mode = img_header['color_mode']
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    output_path = output_path + os.sep
    if data_type == 'label':
        bbox_coordinate, bbox_class = DataLoad('DETECTION').load_label(data)
    else:
        bbox_coordinate, bbox_class = DataLoad('DETECTION').load_prediction(data)
    if 'class' in label_header:
        class_name = list((eval(label_header['class'])).keys())
    else:
        class_name = list((eval(label_header['classes'])).keys())

    if img_dimension == 2:
        ori_img = DataLoad('DETECTION').load_original(data)
        ori_img = decryption(ori_img, image_key)
        # fourier image
        if ('fourier' in img_header) and (ori_img.shape[-1] == 2):
            complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
            ori_img = np.float32(np.log(np.abs(complex_img)))
        image = rescale(np.copy(ori_img))
        class_color = class_color_match(color_type, class_name, class_color_info, data_type=2)
        image_convert, image_ch = detection_convert(image, class_name, bbox_coordinate, bbox_class, class_color)
        download_path = output_path + '%s.jpg' % (filename[0:-5])
        img_save(image_convert, download_path, image_ch)
    else:
        if not os.path.exists(output_path + '%s' % (filename[0:-5])):
            os.mkdir(output_path + '%s' % (filename[0:-5]))
        for slice in range(img_shape[0]):
            ori_img = DataLoad('DETECTION').load_original(data, slice=slice)
            ori_img = decryption(ori_img, image_key)
            # fourier image
            if ('fourier' in img_header) and (ori_img.shape[-1] == 2):
                complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
                ori_img = np.float32(np.log(np.abs(complex_img)))
            image = rescale(np.copy(ori_img))
            bbox_coordinate_tmp = np.array([np.delete(np.copy(bbox_coordinate[k,]), [0, 3], -1) for k in range(bbox_class.shape[0])
                                            if bbox_coordinate[k, 0] <= slice <= bbox_coordinate[k, 3]])
            bbox_class_tmp = np.array([np.copy(bbox_class[k,]) for k in range(bbox_class.shape[0])
                                       if bbox_coordinate[k, 0] <= slice <= bbox_coordinate[k, 3]])
            class_color = class_color_match(color_type, class_name, class_color_info, data_type=2)
            image_convert, image_ch = detection_convert(image, class_name, bbox_coordinate_tmp, bbox_class_tmp, class_color)
            download_path = output_path + '%s' % (filename[0:-5]) + os.sep + '%s_%s.jpg' % ((filename[0:-5]), str(slice+1).zfill(len(str(img_shape[0]))))
            img_save(image_convert, download_path, image_ch)
