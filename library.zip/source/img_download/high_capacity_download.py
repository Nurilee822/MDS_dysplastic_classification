#-*- coding: utf-8 -*-
import copy, time, os, requests, shutil, logging
import numpy as np
from flask import Flask, request, jsonify
from random import randint
from function.py_server_download import hdf5_to_download
from source.img_save import img_zip
from source.img_download import zip_path

def high_capacity(request_msg, URL):
    try:
        logging.basicConfig(level=logging.INFO)
        total_length = len(request_msg['fileList'])
        download_path = request_msg['downloadPath']
        dstFolder = zip_path(output_path=request_msg['downloadPath'], zipNm = request_msg['zipNm'])
        # request_msg['zipNm'] = os.path.basename(dstFolder[0:-4])
        cumulative_time = 0.
        folder_name = str(randint(1, 10 ** 10))
        str_time = time.time()
        for number in range(total_length):
            time.sleep(0.1)
            tmp = copy.deepcopy(request_msg)
            tmp['fileList'] = [tmp['fileList'][number]]
            start_time = time.time()
            if not os.path.exists(request_msg['downloadPath'] + os.sep + folder_name):
                os.mkdir(request_msg['downloadPath'] + os.sep + folder_name)
            time.sleep(0.001)
            response_msg, folder_name = hdf5_to_download(tmp, folder_name)
            response_msg['downloadPath'] = dstFolder
            total_time = time.time() - start_time
            response_msg['result']['time'] = {}
            cumulative_time += total_time
            if number == 0:
                base_time = total_time * (total_length)
            if number == (total_length - 1):
                response_msg['result']['time']['progress'] = 99
            else:
                response_msg['result']['time']['progress'] = int(np.floor(((number + 1) / total_length) * 100))
            response_msg['result']['time']['elapsedTime'] = np.around(cumulative_time, 4)
            remainingTime = np.around(base_time - total_time, 4)
            if remainingTime < 0:
                remainingTime = 0
            response_msg['result']['time']['remainingTime'] = remainingTime
            base_time = base_time - total_time
            if response_msg['result']['status'] != 'FAILED':
                response_msg['result']['status'] = 'COMPRESSING'
            status_check = response_msg['result']['status']
            data = jsonify(response_msg).json
            requests.post(URL, json=data)
            time.sleep(0.01)
            if status_check == "FAILED":
                break

        if status_check != "FAILED":
            start_time = time.time()
            img_zip(output_path=download_path, folder_name= folder_name, folder=dstFolder)
            total_time = time.time() - start_time
            response_msg['result'] = {'time': {}}
            response_msg['result']['time']['progress'] = 100
            response_msg['result']['time']['elapsedTime'] = np.around(cumulative_time + total_time, 4)
            response_msg['result']['time']['remainingTime'] = 0.
            response_msg['result']['status'] = 'SUCCESS'
            data = jsonify(response_msg).json
            requests.post(URL, json=data)
            logging.info(time.time() - str_time)
            return 'SUCCESS'
        else:
            shutil.rmtree(download_path + os.sep + folder_name)
            time.sleep(0.01)
            return 'FAILED'
    except Exception as e:
        shutil.rmtree(download_path + os.sep + folder_name)
        time.sleep(0.01)
        response_msg['result']['msgErr'] = {'errData': [], 'errMessage': str(e), 'errType': 'Server Error'}
        response_msg['result']['status'] = "FAILED"
        logging.info(str(e))
        return response_msg