import os
from source.data_load import *
from source.img_save import *
from source.img_convert.original_convert import original_convert
from encryption.image_encryption import decryption

def origianl_download(data, image_key, output_path, filename):
    img_shape, img_header = InfoLoad().info_original(data)
    img_dimension = img_header['dim']
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    output_path = output_path + os.sep
    if img_dimension == 2:
        download_path = output_path + '%s.jpg' % (filename[0:-5])
        ori_img = DataLoad().load_original(data)
        ori_img = decryption(ori_img, image_key)
        # fourier image
        if ('fourier' in img_header) and (ori_img.shape[-1] == 2):
            complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
            ori_img = np.float32(np.log(np.abs(complex_img)))
        ori_convert, ori_ch = original_convert(ori_img, img_header['color_mode'])
        img_save(ori_convert, download_path, ori_ch)
    else:
        if not os.path.exists(output_path + '%s' % (filename[0:-5])):
            os.mkdir(output_path + '%s' % (filename[0:-5]))
        for slice in range(img_shape[0]):
            download_path = output_path + '%s' % (filename[0:-5]) + os.sep + '%s_%s.jpg' % ((filename[0:-5]), str(slice + 1).zfill(len(str(img_shape[0]))))
            ori_img = DataLoad().load_original(data, slice=slice)
            ori_img = decryption(ori_img,image_key)
            # fourier image
            if ('fourier' in img_header) and (ori_img.shape[-1] == 2):
                complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
                ori_img = np.float32(np.log(np.abs(complex_img)))
            ori_convert, ori_ch = original_convert(ori_img, img_header['color_mode'])
            img_save(ori_convert, download_path, ori_ch)