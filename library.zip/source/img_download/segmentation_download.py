import os
from source.data_load import *
from source.img_save import img_save
from source.img_convert.segmentation_convert import segmentation_convert
from source.class_color.color_matching import class_color_match

def segmentation_download(data, label_shape, label_header, output_path, filename, color_type, class_color_info, data_type = None):
    img_dimension = label_header['dim']
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    output_path = output_path + os.sep
    if label_shape[0] > 0:
        if img_dimension == 2:
            if data_type == 'label':
                image = DataLoad('SEGMENTATION').load_label(data)
            else:
                image = DataLoad('SEGMENTATION').load_prediction(data)
            download_path = output_path + '%s.jpg' % (filename[0:-5])
            class_color = class_color_match(color_type, label_header['class_name'], class_color_info, data_type=1)
            image_convert, image_ch = segmentation_convert(image, class_color)
            img_save(image_convert, download_path, image_ch)
        else:
            if not os.path.exists(output_path + '%s' % (filename[0:-5])):
                os.mkdir(output_path + '%s' % (filename[0:-5]))
            for slice in range(label_shape[0]):
                if data_type == 'label':
                    image = DataLoad('SEGMENTATION').load_label(data, slice=slice)
                else:
                    image = DataLoad('SEGMENTATION').load_prediction(data, slice=slice)
                download_path = output_path + '%s' % (filename[0:-5]) + os.sep + '%s_%s.jpg' % ((filename[0:-5]), str(slice+1).zfill(len(str(label_shape[0]))))
                class_color = class_color_match(color_type, label_header['class_name'], class_color_info, data_type=1)
                image_convert, image_ch = segmentation_convert(image, class_color)
                img_save(image_convert, download_path, image_ch)