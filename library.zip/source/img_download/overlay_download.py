import os, logging
from source.data_load import *
from source.image_processing import rescale
from source.img_save import img_save
from source.img_convert.segmentation_convert import segmentation_convert
from source.class_color.color_matching import class_color_match
from source.img_convert.original_convert import original_convert
from source.img_convert.overlay_convert import overlay_convert
from encryption.image_encryption import decryption

def overlay_download(data, image_key, label_shape, label_header, output_path, filename, color_type, class_color_info):
    img_shape, img_header = InfoLoad().info_original(data)
    img_dimension = img_header['dim']
    label_dimension = label_header['dim']
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    output_path = output_path + os.sep
    if label_shape[0] > 0:
        if img_dimension == 2:
            download_path = output_path + '%s.jpg' % (filename[0:-5])
            ori_img = DataLoad().load_original(data)
            ori_img = decryption(ori_img, image_key)
            # fourier image
            if ('fourier' in img_header) and (ori_img.shape[-1] == 2):
                complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
                ori_img = np.float32(np.log(np.abs(complex_img)))
            ori_convert, ori_ch = original_convert(ori_img, img_header['color_mode'])

            label_img = DataLoad('SEGMENTATION').load_label(data)
            class_color = class_color_match(color_type, label_header['class_name'], class_color_info, data_type=1)
            label_convert, label_ch = segmentation_convert(label_img, class_color)

            if ori_convert.shape[0:2] == label_convert.shape[0:2]:
                over_convert = overlay_convert(ori_convert, label_convert)
                if over_convert.ndim == 3:
                    over_ch = 3
                else:
                    over_ch = 0
                img_save(over_convert, download_path, over_ch)

        else:
            if data['image']['array'].shape[0:3] == data['label']['segmentation']['array'].shape[0:3]:
                if not os.path.exists(output_path + '%s' % (filename[0:-5])):
                    os.mkdir(output_path + '%s' % (filename[0:-5]))
                for slice in range(img_shape[0]):
                    download_path = output_path + '%s' % (filename[0:-5]) + os.sep + '%s_%s.jpg' % ((filename[0:-5]), str(slice + 1).zfill(len(str(img_shape[0]))))
                    ori_img = DataLoad().load_original(data, slice=slice)

                    ori_img = decryption(ori_img, image_key)
                    # fourier image
                    if ('fourier' in img_header) and (ori_img.shape[-1] == 2):
                        complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
                        ori_img = np.float32(np.log(np.abs(complex_img)))
                    ori_convert, ori_ch = original_convert(ori_img, img_header['color_mode'])

                    label_img = DataLoad('SEGMENTATION').load_label(data, slice=slice)
                    class_color = class_color_match(color_type, label_header['class_name'], class_color_info, data_type=1)
                    label_convert, label_ch = segmentation_convert(label_img, class_color)

                    if ori_convert.shape[0:2] == label_convert.shape[0:2]:
                        over_convert = overlay_convert(ori_convert, label_convert)
                        if over_convert.ndim == 3:
                            over_ch = 3
                        else:
                            over_ch = 0
                        img_save(over_convert, download_path, over_ch)
