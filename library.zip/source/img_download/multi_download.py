import numpy as np
import copy, h5py, time, os, requests, shutil, logging
from flask import Flask, request, jsonify
from source.img_download.original_download import origianl_download
from source.img_download.classification_download import classification_download
from source.img_download.grad_cam_download import grad_cam_download
from source.img_download.segmentation_download import segmentation_download
from source.img_download.overlay_download import overlay_download
from source.img_download.difference_download import difference_download
from source.img_download.transformation_download import transformation_download
from source.img_download.detection_download import detection_download
from source.data_load import *

def multi_download(app, len_list, input,image_key, folder_name, color_type, class_color_info, response_msg, total_length, kafka_producer):
    time.sleep(0.01)
    input_path = input[len_list:]
    number = int(input[0:len_list].lstrip("0")) - 1
    cumulative_time = 0.
    start_time = time.time()
    # hdf5 path 설정
    filename = os.path.basename(input_path)
    # data read
    data = h5py.File(input_path, 'r')

    # original image

    output_path = folder_name + os.sep + 'Image'
    origianl_download(data, image_key, output_path, filename)

    label_shape, label_header, label_type = InfoLoad().info_label(data)
    prediction_type = InfoLoad().info_prediction(data)
    # label image

    # label load
    # classification case
    if 'CLASSIFICATION' in label_type:
        output_path = folder_name + os.sep + 'Label (Classification)'
        classification_download(data, image_key, label_header['Classification'], output_path, filename, color_type,
                                class_color_info, data_type='label')

    # segmentation case
    if 'SEGMENTATION' in label_type:
        output_path = folder_name + os.sep + 'Label (Segmentation)'
        segmentation_download(data, label_shape['Segmentation'], label_header['Segmentation'], output_path, filename, color_type,
                              class_color_info, data_type='label')
        if 'SEGMENTATION' not in prediction_type:
            output_path = folder_name + os.sep + 'Overlay Image (Segmentation)'
            overlay_download(data, image_key, label_shape['Segmentation'], label_header['Segmentation'], output_path, filename, color_type,
                             class_color_info)

    # transformation case
    if 'TRANSFORMATION' in label_type:
        output_path = folder_name + os.sep + 'Label (Transformation)'
        transformation_download(data, label_shape['Transformation'], label_header['Transformation'], output_path, filename, data_type='label')

    # detection case
    if 'DETECTION' in label_type:
        output_path = folder_name + os.sep + 'Label (Detection)'
        detection_download(data, image_key, label_header['Detection'], output_path, filename, color_type,
                           class_color_info, data_type='label')

    # prediction
    # classification case
    if 'CLASSIFICATION' in prediction_type:
        output_path = folder_name + os.sep + 'Prediction (Classification)'
        classification_download(data, image_key, label_header['Classification'], output_path, filename, color_type,
                                class_color_info, data_type='prediction')
        # grad_cam
        output_path = folder_name + os.sep + 'Grad-CAM Image (Classification)'
        grad_cam_download(data, image_key, output_path, filename)

    # segmentation case
    if 'SEGMENTATION' in prediction_type:
        output_path = folder_name + os.sep + 'Prediction (Segmentation)'
        segmentation_download(data, label_shape['Segmentation'], label_header['Segmentation'], output_path, filename, color_type,
                              class_color_info, data_type='prediction')
        output_path = folder_name + os.sep + 'Difference Image (Segmentation)'
        difference_download(data, label_shape['Segmentation'], label_header['Segmentation'], output_path, filename)

    # transformation case
    if 'TRANSFORMATION' in prediction_type:
        output_path = folder_name + os.sep + 'Prediction (Transformation)'
        transformation_download(data, label_shape['Transformation'], label_header['Transformation'], output_path, filename, data_type='prediction')

    # detection case
    if 'DETECTION' in prediction_type:
        output_path = folder_name + os.sep + 'Prediction (Detection)'
        detection_download(data, image_key, label_header['Detection'], output_path, filename, color_type,
                           class_color_info, data_type='prediction')

    if number == (total_length - 1):
        response_msg['result']['progress'] = 99
    else:
        response_msg['result']['progress'] = int(np.floor(((number + 1) / total_length) * 100))

    response_msg['result']['status'] = 'COMPRESSING'
    tmp_msg = copy.deepcopy(response_msg)
    ori_percent = kafka_producer.percent


    kafka_producer.percent = response_msg['result']['progress']
    if response_msg['result']['progress'] > ori_percent:
        with app.app_context():
            kafka_producer.send_massage(tmp_msg)

    data.clear()
    data.close()


def delete_empty_folder(app, e,kafka_producer,response_msg,empty_foler):
    shutil.rmtree(empty_foler)
    response_msg['result']['detail'] = str(e)
    response_msg['result']['status'] = "FAILED"
    with app.app_context():
        kafka_producer.send_massage(response_msg)