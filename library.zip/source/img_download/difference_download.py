import os
from source.data_load import *
from source.img_save import img_save
from source.img_convert.difference_convert import dif_convert

def difference_download(data, label_shape, label_header, output_path, filename):
    img_dimension = label_header['dim']
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    output_path = output_path + os.sep
    if label_shape[0] > 0:
        if img_dimension == 2:
            download_path = output_path + '%s.jpg' % (filename[0:-5])
            label_img = DataLoad('SEGMENTATION').load_label(data)
            prediction_img = DataLoad('SEGMENTATION').load_prediction(data)
            if (label_img.ndim == 3) and (label_img.shape == prediction_img.shape):
                difference_convert = dif_convert(label_img, prediction_img)
                img_save(difference_convert, download_path, 3)
        else:
            if data['label']['segmentation']['array'].shape[0:3] == data['prediction']['segmentation']['array'].shape[0:3]:
                if not os.path.exists(output_path + '%s' % (filename[0:-5])):
                    os.mkdir(output_path + '%s' % (filename[0:-5]))
                for slice in range(label_shape[0]):
                    label_img = DataLoad('SEGMENTATION').load_label(data, slice=slice)
                    prediction_img = DataLoad('SEGMENTATION').load_prediction(data, slice=slice)
                    download_path = output_path + '%s' % (filename[0:-5]) + os.sep + '%s_%s.jpg' % ((filename[0:-5]), str(slice+1).zfill(len(str(label_shape[0]))))
                    if (label_img.ndim == 3) and (label_img.shape == prediction_img.shape):
                        difference_convert = dif_convert(label_img, prediction_img)
                        img_save(difference_convert, download_path, 3)