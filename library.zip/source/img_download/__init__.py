#-*- coding: utf-8 -*-
import datetime, os

def zip_path(output_path, moduleNm=None, zipNm=None):
    if moduleNm != None:
        now = datetime.datetime.now()
        nowDate = int(now.strftime('%Y%m%d'))
        nowTime = int(now.strftime('%H%M%S')) + 90000
        if nowTime > 240000:
            nowDate = nowDate + 1
            nowTime = nowTime - 240000
        tmp_name = moduleNm + '_' + str(nowDate) + '_' + str(nowTime) + '.zip'
    else:
        tmp_name = zipNm
    dstFolder = output_path + os.sep + tmp_name
    return dstFolder