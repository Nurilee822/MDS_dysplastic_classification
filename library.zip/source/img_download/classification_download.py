import os
from source.data_load import *
from source.image_processing import rescale
from source.img_save import img_save
from encryption.image_encryption import decryption
from source.img_convert.classification_convert import classification_convert
from source.class_color.color_matching import class_color_match

def classification_download(data, image_key, label_header, output_path, filename, color_type, class_color_info, data_type = None):
    img_shape, img_header = InfoLoad().info_original(data)
    img_dimension = img_header['dim']
    if not os.path.exists(output_path):
        os.mkdir(output_path)
    output_path = output_path + os.sep
    if data_type == 'label':
        class_array = DataLoad('CLASSIFICATION').load_label(data)
    else:
        class_array = DataLoad('CLASSIFICATION').load_prediction(data)
        tmp = np.zeros_like(class_array)
        tmp[list(class_array).index(max(class_array))] = 1.
        class_array = tmp

    if img_dimension == 2:
        ori_img = DataLoad('CLASSIFICATION').load_original(data)
        ori_img = decryption(ori_img, image_key)
        # fourier image
        if 'fourier' in img_header:
            complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
            ori_img = np.float32(np.log(np.abs(complex_img)))

        image = rescale(np.copy(ori_img))
        class_color = class_color_match(color_type, label_header['class_name'], class_color_info, data_type=0)
        image_convert = classification_convert(image, class_color, class_array, label_header['class_name'])
        download_path = output_path + '%s.jpg' % (filename[0:-5])
        img_save(image_convert, download_path, 3)
    else:
        if not os.path.exists(output_path + '%s' % (filename[0:-5])):
            os.mkdir(output_path + '%s' % (filename[0:-5]))
        for slice in range(img_shape[0]):
            ori_img = DataLoad('CLASSIFICATION').load_original(data, slice=slice)
            ori_img = decryption(ori_img, image_key)
            # fourier image
            if 'fourier' in img_header:
                complex_img = ori_img[..., 0] + ori_img[..., 1] * 1j
                ori_img = np.float32(np.log(np.abs(complex_img)))
            image = rescale(np.copy(ori_img))
            class_color = class_color_match(color_type, label_header['class_name'], class_color_info, data_type=0)
            image_convert = classification_convert(image, class_color, class_array, label_header['class_name'])
            download_path = output_path + '%s' % (filename[0:-5]) + os.sep + '%s_%s.jpg' % ((filename[0:-5]), str(slice+1).zfill(len(str(img_shape[0]))))
            img_save(image_convert, download_path, 3)
