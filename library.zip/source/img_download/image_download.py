from function.py_server_header import MakeHeader
import os, time
from source.data_load import *
from source.img_save import *
from source.img_convert.original_convert import original_convert
from encryption.image_encryption import decryption
from source.class_color.color_matching import class_color_match
from source.img_convert.classification_convert import classification_convert
from source.img_convert.segmentation_convert import segmentation_convert
from source.img_convert.overlay_convert import overlay_convert
from source.img_convert.transformation_convert import transformation_convert
from source.img_convert.detection_convert import detection_convert
from source.img_convert.grad_cam_convert import grad_cam_convert
from source.img_convert.difference_convert import dif_convert

class ConvertDownload(object):
    def __init__(self, data, image_key, filename, color_type, class_color_info,
                 output_path, origin, label, prediction):
        self.data = data
        self.image_key = image_key
        self.filename = filename
        self.color_type = color_type
        self.class_color_info = class_color_info
        self.output_path = output_path
        self.img_shape, self.img_header = InfoLoad().info_original(self.data)
        self.img_dimension = self.img_header['dim']
        _, self.label_header, self.label_type = InfoLoad().info_label(self.data)
        self.prediction_type = InfoLoad().info_prediction(self.data)
        self.origin = origin
        self.label = label
        self.prediction = prediction
        self.output_slice = int()
        self.slice_file_name = str()

    def convert(self):
        if self.img_dimension == 2:
            slice_min, slice_max = -1, 0
        else:
            slice_min, slice_max = 0, self.img_shape[0]
        for self.output_slice in range(slice_min, slice_max):
            ori_img = self.make_ori_image()
            self.slice_file_name = '/' + self.filename[0:-5]
            # original image

            origin_path = self.output_path + 'Image'
            download_path = self.make_download_path(origin_path)
            self.original_download(ori_img, download_path)
            time.sleep(0.001)

            self.target_download(self.label_type, ori_img, data_output='label')

            self.target_download(self.prediction_type, ori_img, data_output='prediction')

    def make_download_path(self, path):
        if self.img_dimension == 3:
            path += '%s' % self.slice_file_name
            file_name = self.slice_file_name + '_' + \
                                   str(self.output_slice + 1).zfill(len(str(self.img_shape[0])))
        else:
            file_name = self.slice_file_name
        self.create_folder(path)
        download_path = path + file_name + '.jpg'
        return download_path

    def make_ori_image(self):
        if self.output_slice < 0:
            self.output_slice = None
        img = DataLoad().load_original(self.data, slice=self.output_slice)
        img = decryption(img, self.image_key)
        # fourier image
        if ('fourier' in self.img_header) and (img.shape[-1] == 2):
            complex_img = img[..., 0] + img[..., 1] * 1j
            img = np.float32(np.log(np.abs(complex_img)))
        return img

    def original_download(self, ori_img, download_path):
        ori_convert, ori_ch = original_convert(ori_img, self.img_header['color_mode'])
        img_save(ori_convert, download_path, ori_ch)

    def target_download(self, target_type, ori_img, data_output=None):
        for target in target_type:
            target_path = self.output_path + '%s (%s)' % (data_output, target.capitalize())
            download_path = self.make_download_path(target_path)

            if target == 'CLASSIFICATION':
                self.classification_download(ori_img, download_path,
                                             self.label_header['Classification']['class_name'], data_output=data_output)
            if target == 'SEGMENTATION':
                overlay_type = 'SEGMENTATION' not in self.prediction_type
                self.segmentation_download(ori_img, download_path, self.label_header['Segmentation']['class_name'],
                                           data_output=data_output, overlay=overlay_type)
            if target == 'TRANSFORMATION':
                self.transformation_download(download_path, data_output=data_output)
            if target == 'DETECTION':
                self.detection_download(ori_img, download_path, self.label_header['Detection'], data_output=data_output)
            time.sleep(0.001)

    def classification_download(self, ori_img, download_path, class_name, data_output=None):
        if data_output == 'label':
            class_array = DataLoad('CLASSIFICATION').load_label(self.data)
        else:
            class_array = DataLoad('CLASSIFICATION').load_prediction(self.data)
        one_hot_array = np.zeros_like(class_array)
        one_hot_array[list(class_array).index(max(class_array))] = 1.
        image = rescale(np.copy(ori_img))
        class_color = class_color_match(self.color_type, class_name, self.class_color_info, data_type=0)
        image_convert = classification_convert(image, class_color, one_hot_array, class_name)
        img_save(image_convert, download_path, 3)
        if data_output == 'prediction':
            cam_path = self.output_path + 'Grad-CAM Image (Classification)'
            download_path = self.make_download_path(cam_path)
            self.grad_cam_download(ori_img, download_path)

    def grad_cam_download(self, ori_img, download_path):
        cam_img = DataLoad().load_cam(self.data, slice=self.output_slice)
        if ori_img.shape[0:2] == cam_img.shape[0:2]:
            cam_convert = grad_cam_convert(ori_img, cam_img)
            img_save(cam_convert, download_path, 3)

    def segmentation_download(self, ori_img, download_path, class_name, data_output=None, overlay=False):
        if data_output == 'label':
            image = DataLoad('SEGMENTATION').load_label(self.data, slice=self.output_slice)
        else:
            image = DataLoad('SEGMENTATION').load_prediction(self.data, slice=self.output_slice)
        class_color = class_color_match(self.color_type, class_name, self.class_color_info, data_type=1)
        image_convert, image_ch = segmentation_convert(image, class_color)
        img_save(image_convert, download_path, image_ch)
        if (data_output == 'label') and overlay:
            overlay_path = self.output_path + 'Overlay Image (Segmentation)'
            download_path = self.make_download_path(overlay_path)
            self.overlay_download(ori_img, image_convert, download_path)
        if data_output == 'prediction':
            diff_path = self.output_path + 'Difference Image (Segmentation)'
            download_path = self.make_download_path(diff_path)
            self.difference_download(download_path)

    def overlay_download(self, ori_img, image_convert, download_path):
        ori_convert, _ = original_convert(ori_img, self.img_header['color_mode'])
        if ori_convert.shape[0:2] == image_convert.shape[0:2]:
            over_convert = overlay_convert(ori_convert, image_convert)
            if over_convert.ndim == 3:
                over_ch = 3
            else:
                over_ch = 0
            img_save(over_convert, download_path, over_ch)

    def difference_download(self, download_path):
        label_img = DataLoad('SEGMENTATION').load_prediction(self.data, slice=self.output_slice)
        prediction_img = DataLoad('SEGMENTATION').load_prediction(self.data, slice=self.output_slice)
        if (label_img.ndim == 3) and (label_img.shape == prediction_img.shape):
            difference_convert = dif_convert(label_img, prediction_img)
            img_save(difference_convert, download_path, 3)

    def transformation_download(self, download_path, data_output=None):
        if data_output == 'label':
            image = DataLoad('TRANSFORMATION').load_label(self.data)
        else:
            image = DataLoad('TRANSFORMATION').load_prediction(self.data)
        image_convert, image_ch = transformation_convert(image)
        img_save(image_convert, download_path, image_ch)

    def detection_download(self, ori_img, download_path, label_header, data_output=None):
        if data_output == 'label':
            bbox_coordinate, bbox_class = DataLoad('DETECTION').load_label(self.data)
        else:
            bbox_coordinate, bbox_class = DataLoad('DETECTION').load_prediction(self.data)
        if 'class_name' in label_header:
            class_name = list(label_header['class_name'])
        elif 'class' in label_header:
            class_name = list((eval(label_header['class'])).keys())
        else:
            class_name = list((eval(label_header['classes'])).keys())
        image = rescale(np.copy(ori_img))
        class_color = class_color_match(self.color_type, class_name, self.class_color_info, data_type=2)
        image_convert, image_ch = detection_convert(image, class_name, bbox_coordinate, bbox_class, class_color)
        img_save(image_convert, download_path, image_ch)

    def create_folder(self, path):
        if not os.path.exists(path):
            try:
                os.mkdir(path)
            except:
                self.create_folder(os.path.dirname(path))
                self.create_folder(path)

