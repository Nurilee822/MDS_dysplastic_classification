import cv2
import numpy as np


# normalization image
def rescale(array):
    min_value = np.min(array)
    max_value = np.max(array)
    diviser = max_value - min_value
    if diviser == 0:
        if max_value != 0:
            array = np.uint8((array / max_value) * 255)
        else:
            array = np.uint8(array)
    else:
        array = np.uint8((array - min_value) / (diviser) * 255)
    return array


# resize image
def resize(array):
    height = array.shape[0]
    width = array.shape[1]
    ratio = height / width
    if ratio > 1:
        if height > 512:
            height = 512
            width = int(height / ratio)
        elif height < 256:
            height = 256
            width = int(height / ratio)
        if width == 0:
            width = 1
        array = cv2.resize(array, (width, height), cv2.INTER_LINEAR)
    else:
        if width > 512:
            width = 512
            height = int(width * ratio)
        elif width < 256:
            width = 256
            height = int(width * ratio)
        if height == 0:
            height = 1
        array = cv2.resize(array, (width, height), cv2.INTER_LINEAR)
    return array