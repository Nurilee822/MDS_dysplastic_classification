import numpy as np

def class_color_match(color_type, label_class, class_color_info, data_type):
    try:
        if color_type == "pjtColor":
            class_color = [class_color_info[data_type]['colorMap'][str(label_class[i])] for i in range(len(label_class))]
        else:
            class_colo_tmp = {class_color_info[data_type]['class_info'][i]['name']:
                                  class_color_info[data_type]['class_info'][i]['color']
                              for i in range(len(class_color_info[data_type]['class_info']))}
            class_color = [class_colo_tmp[str(label_class[i])] for i in range(len(label_class))]
    except:
        class_color = []
    return class_color
