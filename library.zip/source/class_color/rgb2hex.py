def hex_to_rgb(hex):
    r = int(hex[1:3],16)
    g = int(hex[3:5],16)
    b = int(hex[5:7],16)
    rgb_color = (r, g, b)
    return rgb_color

def rgb_to_hex(rgb):
    hex_color = '#' + hex(rgb[0])[2:].zfill(2) + hex(rgb[1])[2:].zfill(2) + hex(rgb[2])[2:].zfill(2)
    return hex_color
