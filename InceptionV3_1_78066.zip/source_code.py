import sys
from tensorflow import keras
import tensorflow.keras.backend as K
import inspect
import os

file_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(f"{file_path}/layers")
sys.path.append(f"{file_path}/utils")


from base_model import BaseModel
from inspect import getmembers, isfunction

import tensorflow as tf
import layer_618b86a04df69c5d778968e8 as layer_618b86a04df69c5d778968e8
import layer_618b86a04df69c5d778968ec as layer_618b86a04df69c5d778968ec
import layer_618b86a04df69c5d778968f0 as layer_618b86a04df69c5d778968f0
import layer_618b86a04df69c5d778968ee as layer_618b86a04df69c5d778968ee
import layer_618b86a04df69c5d778968f2 as layer_618b86a04df69c5d778968f2
import layer_618b86a04df69c5d778968f4 as layer_618b86a04df69c5d778968f4
import layer_618b86a04df69c5d778968f6 as layer_618b86a04df69c5d778968f6
import layer_618b86a04df69c5d778968f8 as layer_618b86a04df69c5d778968f8
import layer_618b86a04df69c5d778968fa as layer_618b86a04df69c5d778968fa
import layer_618b86a04df69c5d778968fc as layer_618b86a04df69c5d778968fc
import layer_618b86a04df69c5d778968fe as layer_618b86a04df69c5d778968fe
import layer_618b86a04df69c5d7789693c as layer_618b86a04df69c5d7789693c
import layer_618b86a04df69c5d77896904 as layer_618b86a04df69c5d77896904
import layer_618b86a04df69c5d77896908 as layer_618b86a04df69c5d77896908
import layer_618b86a04df69c5d7789690c as layer_618b86a04df69c5d7789690c
import layer_618b86a04df69c5d77896910 as layer_618b86a04df69c5d77896910
import layer_618b86a04df69c5d7789691c as layer_618b86a04df69c5d7789691c
import layer_618b86a04df69c5d77896920 as layer_618b86a04df69c5d77896920
import layer_618b86a04df69c5d77896932 as layer_618b86a04df69c5d77896932
import layer_618b86a04df69c5d77896936 as layer_618b86a04df69c5d77896936
import layer_618b86a04df69c5d7789693a as layer_618b86a04df69c5d7789693a
import layer_618b86a04df69c5d77896906 as layer_618b86a04df69c5d77896906
import layer_618b86a04df69c5d7789690e as layer_618b86a04df69c5d7789690e
import layer_618b86a04df69c5d77896914 as layer_618b86a04df69c5d77896914
import layer_618b86a04df69c5d77896918 as layer_618b86a04df69c5d77896918
import layer_618b86a04df69c5d7789691e as layer_618b86a04df69c5d7789691e
import layer_618b86a04df69c5d77896924 as layer_618b86a04df69c5d77896924
import layer_618b86a04df69c5d77896928 as layer_618b86a04df69c5d77896928
import layer_618b86a04df69c5d77896938 as layer_618b86a04df69c5d77896938
import layer_618b86a04df69c5d77896916 as layer_618b86a04df69c5d77896916
import layer_618b86a04df69c5d77896926 as layer_618b86a04df69c5d77896926
import layer_618b86a04df69c5d7789692c as layer_618b86a04df69c5d7789692c
import layer_618b86a04df69c5d77896930 as layer_618b86a04df69c5d77896930
import layer_618b86a04df69c5d7789692e as layer_618b86a04df69c5d7789692e
import layer_618b86a04df69c5d77896941 as layer_618b86a04df69c5d77896941
import layer_618b86a04df69c5d7789697f as layer_618b86a04df69c5d7789697f
import layer_618b86a04df69c5d77896947 as layer_618b86a04df69c5d77896947
import layer_618b86a04df69c5d7789694b as layer_618b86a04df69c5d7789694b
import layer_618b86a04df69c5d7789694f as layer_618b86a04df69c5d7789694f
import layer_618b86a04df69c5d77896953 as layer_618b86a04df69c5d77896953
import layer_618b86a04df69c5d7789695f as layer_618b86a04df69c5d7789695f
import layer_618b86a04df69c5d77896963 as layer_618b86a04df69c5d77896963
import layer_618b86a04df69c5d77896975 as layer_618b86a04df69c5d77896975
import layer_618b86a04df69c5d77896979 as layer_618b86a04df69c5d77896979
import layer_618b86a04df69c5d7789697d as layer_618b86a04df69c5d7789697d
import layer_618b86a04df69c5d77896949 as layer_618b86a04df69c5d77896949
import layer_618b86a04df69c5d77896951 as layer_618b86a04df69c5d77896951
import layer_618b86a04df69c5d77896957 as layer_618b86a04df69c5d77896957
import layer_618b86a04df69c5d7789695b as layer_618b86a04df69c5d7789695b
import layer_618b86a04df69c5d77896961 as layer_618b86a04df69c5d77896961
import layer_618b86a04df69c5d77896967 as layer_618b86a04df69c5d77896967
import layer_618b86a04df69c5d7789696b as layer_618b86a04df69c5d7789696b
import layer_618b86a04df69c5d7789697b as layer_618b86a04df69c5d7789697b
import layer_618b86a04df69c5d77896959 as layer_618b86a04df69c5d77896959
import layer_618b86a04df69c5d77896969 as layer_618b86a04df69c5d77896969
import layer_618b86a04df69c5d7789696f as layer_618b86a04df69c5d7789696f
import layer_618b86a04df69c5d77896973 as layer_618b86a04df69c5d77896973
import layer_618b86a04df69c5d77896971 as layer_618b86a04df69c5d77896971
import layer_618b86a04df69c5d77896984 as layer_618b86a04df69c5d77896984
import layer_618b86a04df69c5d778969c2 as layer_618b86a04df69c5d778969c2
import layer_618b86a04df69c5d7789698a as layer_618b86a04df69c5d7789698a
import layer_618b86a04df69c5d7789698e as layer_618b86a04df69c5d7789698e
import layer_618b86a04df69c5d77896992 as layer_618b86a04df69c5d77896992
import layer_618b86a04df69c5d77896996 as layer_618b86a04df69c5d77896996
import layer_618b86a04df69c5d778969a2 as layer_618b86a04df69c5d778969a2
import layer_618b86a04df69c5d778969a6 as layer_618b86a04df69c5d778969a6
import layer_618b86a04df69c5d778969b8 as layer_618b86a04df69c5d778969b8
import layer_618b86a04df69c5d778969bc as layer_618b86a04df69c5d778969bc
import layer_618b86a04df69c5d778969c0 as layer_618b86a04df69c5d778969c0
import layer_618b86a04df69c5d7789698c as layer_618b86a04df69c5d7789698c
import layer_618b86a04df69c5d77896994 as layer_618b86a04df69c5d77896994
import layer_618b86a04df69c5d7789699a as layer_618b86a04df69c5d7789699a
import layer_618b86a04df69c5d7789699e as layer_618b86a04df69c5d7789699e
import layer_618b86a04df69c5d778969a4 as layer_618b86a04df69c5d778969a4
import layer_618b86a04df69c5d778969aa as layer_618b86a04df69c5d778969aa
import layer_618b86a04df69c5d778969ae as layer_618b86a04df69c5d778969ae
import layer_618b86a04df69c5d778969be as layer_618b86a04df69c5d778969be
import layer_618b86a04df69c5d7789699c as layer_618b86a04df69c5d7789699c
import layer_618b86a04df69c5d778969ac as layer_618b86a04df69c5d778969ac
import layer_618b86a04df69c5d778969b2 as layer_618b86a04df69c5d778969b2
import layer_618b86a04df69c5d778969b6 as layer_618b86a04df69c5d778969b6
import layer_618b86a04df69c5d778969b4 as layer_618b86a04df69c5d778969b4
import layer_618b86a04df69c5d778969c7 as layer_618b86a04df69c5d778969c7
import layer_618b86a04df69c5d778969d3 as layer_618b86a04df69c5d778969d3
import layer_618b86a04df69c5d778969d7 as layer_618b86a04df69c5d778969d7
import layer_618b86a04df69c5d778969d9 as layer_618b86a04df69c5d778969d9
import layer_618b86a04df69c5d778969db as layer_618b86a04df69c5d778969db
import layer_618b86a04df69c5d778969df as layer_618b86a04df69c5d778969df
import layer_618b86a04df69c5d778969e1 as layer_618b86a04df69c5d778969e1
import layer_618b86a04df69c5d778969e3 as layer_618b86a04df69c5d778969e3
import layer_618b86a04df69c5d778969e7 as layer_618b86a04df69c5d778969e7
import layer_618b86a04df69c5d778969e9 as layer_618b86a04df69c5d778969e9
import layer_618b86a04df69c5d778969eb as layer_618b86a04df69c5d778969eb
import layer_618b86a04df69c5d778969ed as layer_618b86a04df69c5d778969ed
import layer_618b86a04df69c5d778969cd as layer_618b86a04df69c5d778969cd
import layer_618b86a04df69c5d778969cf as layer_618b86a04df69c5d778969cf
import layer_618b86a04df69c5d778969d1 as layer_618b86a04df69c5d778969d1
import layer_618b86a04df69c5d778969f1 as layer_618b86a04df69c5d778969f1
import layer_618b86a04df69c5d77896a25 as layer_618b86a04df69c5d77896a25
import layer_618b86a04df69c5d778969f7 as layer_618b86a04df69c5d778969f7
import layer_618b86a04df69c5d778969fb as layer_618b86a04df69c5d778969fb
import layer_618b86a04df69c5d778969ff as layer_618b86a04df69c5d778969ff
import layer_618b86a04df69c5d77896a03 as layer_618b86a04df69c5d77896a03
import layer_618b86a04df69c5d77896a15 as layer_618b86a04df69c5d77896a15
import layer_618b86a04df69c5d77896a19 as layer_618b86a04df69c5d77896a19
import layer_618b86a04df69c5d77896a1b as layer_618b86a04df69c5d77896a1b
import layer_618b86a04df69c5d77896a1f as layer_618b86a04df69c5d77896a1f
import layer_618b86a04df69c5d77896a23 as layer_618b86a04df69c5d77896a23
import layer_618b86a04df69c5d778969f9 as layer_618b86a04df69c5d778969f9
import layer_618b86a04df69c5d77896a01 as layer_618b86a04df69c5d77896a01
import layer_618b86a04df69c5d77896a07 as layer_618b86a04df69c5d77896a07
import layer_618b86a04df69c5d77896a0b as layer_618b86a04df69c5d77896a0b
import layer_618b86a04df69c5d77896a17 as layer_618b86a04df69c5d77896a17
import layer_618b86a04df69c5d77896a21 as layer_618b86a04df69c5d77896a21
import layer_618b86a04df69c5d77896a2e as layer_618b86a04df69c5d77896a2e
import layer_618b86a04df69c5d77896a32 as layer_618b86a04df69c5d77896a32
import layer_618b86a04df69c5d77896a09 as layer_618b86a04df69c5d77896a09
import layer_618b86a04df69c5d77896a0d as layer_618b86a04df69c5d77896a0d
import layer_618b86a04df69c5d77896a0f as layer_618b86a04df69c5d77896a0f
import layer_618b86a04df69c5d77896a11 as layer_618b86a04df69c5d77896a11
import layer_618b86a04df69c5d77896a30 as layer_618b86a04df69c5d77896a30
import layer_618b86a04df69c5d77896a34 as layer_618b86a04df69c5d77896a34
import layer_618b86a04df69c5d77896a36 as layer_618b86a04df69c5d77896a36
import layer_618b86a04df69c5d77896a38 as layer_618b86a04df69c5d77896a38
import layer_618b86a04df69c5d77896a3c as layer_618b86a04df69c5d77896a3c
import layer_618b86a04df69c5d77896a40 as layer_618b86a04df69c5d77896a40
import layer_618b86a04df69c5d77896a3e as layer_618b86a04df69c5d77896a3e
import layer_618b86a04df69c5d77896a42 as layer_618b86a04df69c5d77896a42
import layer_618b86a04df69c5d77896a44 as layer_618b86a04df69c5d77896a44
import layer_618b86a04df69c5d77896a46 as layer_618b86a04df69c5d77896a46
import layer_618b86a04df69c5d77896a2a as layer_618b86a04df69c5d77896a2a
import layer_618b86a04df69c5d77896a7a as layer_618b86a04df69c5d77896a7a
import layer_618b86a04df69c5d77896a4c as layer_618b86a04df69c5d77896a4c
import layer_618b86a04df69c5d77896a50 as layer_618b86a04df69c5d77896a50
import layer_618b86a04df69c5d77896a54 as layer_618b86a04df69c5d77896a54
import layer_618b86a04df69c5d77896a58 as layer_618b86a04df69c5d77896a58
import layer_618b86a04df69c5d77896a6a as layer_618b86a04df69c5d77896a6a
import layer_618b86a04df69c5d77896a6e as layer_618b86a04df69c5d77896a6e
import layer_618b86a04df69c5d77896a70 as layer_618b86a04df69c5d77896a70
import layer_618b86a04df69c5d77896a74 as layer_618b86a04df69c5d77896a74
import layer_618b86a04df69c5d77896a78 as layer_618b86a04df69c5d77896a78
import layer_618b86a04df69c5d77896a4e as layer_618b86a04df69c5d77896a4e
import layer_618b86a04df69c5d77896a56 as layer_618b86a04df69c5d77896a56
import layer_618b86a04df69c5d77896a5c as layer_618b86a04df69c5d77896a5c
import layer_618b86a04df69c5d77896a60 as layer_618b86a04df69c5d77896a60
import layer_618b86a04df69c5d77896a6c as layer_618b86a04df69c5d77896a6c
import layer_618b86a04df69c5d77896a76 as layer_618b86a04df69c5d77896a76
import layer_618b86a04df69c5d77896a83 as layer_618b86a04df69c5d77896a83
import layer_618b86a04df69c5d77896a87 as layer_618b86a04df69c5d77896a87
import layer_618b86a04df69c5d77896a5e as layer_618b86a04df69c5d77896a5e
import layer_618b86a04df69c5d77896a62 as layer_618b86a04df69c5d77896a62
import layer_618b86a04df69c5d77896a64 as layer_618b86a04df69c5d77896a64
import layer_618b86a04df69c5d77896a66 as layer_618b86a04df69c5d77896a66
import layer_618b86a04df69c5d77896a85 as layer_618b86a04df69c5d77896a85
import layer_618b86a04df69c5d77896a89 as layer_618b86a04df69c5d77896a89
import layer_618b86a04df69c5d77896a8b as layer_618b86a04df69c5d77896a8b
import layer_618b86a04df69c5d77896a8d as layer_618b86a04df69c5d77896a8d
import layer_618b86a04df69c5d77896a91 as layer_618b86a04df69c5d77896a91
import layer_618b86a04df69c5d77896a95 as layer_618b86a04df69c5d77896a95
import layer_618b86a04df69c5d77896a93 as layer_618b86a04df69c5d77896a93
import layer_618b86a04df69c5d77896a97 as layer_618b86a04df69c5d77896a97
import layer_618b86a04df69c5d77896a99 as layer_618b86a04df69c5d77896a99
import layer_618b86a04df69c5d77896a9b as layer_618b86a04df69c5d77896a9b
import layer_618b86a04df69c5d77896a7f as layer_618b86a04df69c5d77896a7f
import layer_618b86a04df69c5d77896b24 as layer_618b86a04df69c5d77896b24
import layer_618b86a04df69c5d77896af6 as layer_618b86a04df69c5d77896af6
import layer_618b86a04df69c5d77896afa as layer_618b86a04df69c5d77896afa
import layer_618b86a04df69c5d77896afe as layer_618b86a04df69c5d77896afe
import layer_618b86a04df69c5d77896b02 as layer_618b86a04df69c5d77896b02
import layer_618b86a04df69c5d77896b14 as layer_618b86a04df69c5d77896b14
import layer_618b86a04df69c5d77896b18 as layer_618b86a04df69c5d77896b18
import layer_618b86a04df69c5d77896b1a as layer_618b86a04df69c5d77896b1a
import layer_618b86a04df69c5d77896b1e as layer_618b86a04df69c5d77896b1e
import layer_618b86a04df69c5d77896b22 as layer_618b86a04df69c5d77896b22
import layer_618b86a04df69c5d77896af8 as layer_618b86a04df69c5d77896af8
import layer_618b86a04df69c5d77896b00 as layer_618b86a04df69c5d77896b00
import layer_618b86a04df69c5d77896b06 as layer_618b86a04df69c5d77896b06
import layer_618b86a04df69c5d77896b0a as layer_618b86a04df69c5d77896b0a
import layer_618b86a04df69c5d77896b16 as layer_618b86a04df69c5d77896b16
import layer_618b86a04df69c5d77896b20 as layer_618b86a04df69c5d77896b20
import layer_618b86a04df69c5d77896b2d as layer_618b86a04df69c5d77896b2d
import layer_618b86a04df69c5d77896b31 as layer_618b86a04df69c5d77896b31
import layer_618b86a04df69c5d77896b08 as layer_618b86a04df69c5d77896b08
import layer_618b86a04df69c5d77896b0c as layer_618b86a04df69c5d77896b0c
import layer_618b86a04df69c5d77896b0e as layer_618b86a04df69c5d77896b0e
import layer_618b86a04df69c5d77896b10 as layer_618b86a04df69c5d77896b10
import layer_618b86a04df69c5d77896b2f as layer_618b86a04df69c5d77896b2f
import layer_618b86a04df69c5d77896b33 as layer_618b86a04df69c5d77896b33
import layer_618b86a04df69c5d77896b35 as layer_618b86a04df69c5d77896b35
import layer_618b86a04df69c5d77896b37 as layer_618b86a04df69c5d77896b37
import layer_618b86a04df69c5d77896b3b as layer_618b86a04df69c5d77896b3b
import layer_618b86a04df69c5d77896b3f as layer_618b86a04df69c5d77896b3f
import layer_618b86a04df69c5d77896b3d as layer_618b86a04df69c5d77896b3d
import layer_618b86a04df69c5d77896b41 as layer_618b86a04df69c5d77896b41
import layer_618b86a04df69c5d77896b43 as layer_618b86a04df69c5d77896b43
import layer_618b86a04df69c5d77896b45 as layer_618b86a04df69c5d77896b45
import layer_618b86a04df69c5d77896b29 as layer_618b86a04df69c5d77896b29
import layer_618b86a04df69c5d77896acf as layer_618b86a04df69c5d77896acf
import layer_618b86a04df69c5d77896aa1 as layer_618b86a04df69c5d77896aa1
import layer_618b86a04df69c5d77896aa5 as layer_618b86a04df69c5d77896aa5
import layer_618b86a04df69c5d77896aa9 as layer_618b86a04df69c5d77896aa9
import layer_618b86a04df69c5d77896aad as layer_618b86a04df69c5d77896aad
import layer_618b86a04df69c5d77896abf as layer_618b86a04df69c5d77896abf
import layer_618b86a04df69c5d77896ac3 as layer_618b86a04df69c5d77896ac3
import layer_618b86a04df69c5d77896ac5 as layer_618b86a04df69c5d77896ac5
import layer_618b86a04df69c5d77896ac9 as layer_618b86a04df69c5d77896ac9
import layer_618b86a04df69c5d77896acd as layer_618b86a04df69c5d77896acd
import layer_618b86a04df69c5d77896aa3 as layer_618b86a04df69c5d77896aa3
import layer_618b86a04df69c5d77896aab as layer_618b86a04df69c5d77896aab
import layer_618b86a04df69c5d77896ab1 as layer_618b86a04df69c5d77896ab1
import layer_618b86a04df69c5d77896ab5 as layer_618b86a04df69c5d77896ab5
import layer_618b86a04df69c5d77896ac1 as layer_618b86a04df69c5d77896ac1
import layer_618b86a04df69c5d77896acb as layer_618b86a04df69c5d77896acb
import layer_618b86a04df69c5d77896ad8 as layer_618b86a04df69c5d77896ad8
import layer_618b86a04df69c5d77896adc as layer_618b86a04df69c5d77896adc
import layer_618b86a04df69c5d77896ab3 as layer_618b86a04df69c5d77896ab3
import layer_618b86a04df69c5d77896ab7 as layer_618b86a04df69c5d77896ab7
import layer_618b86a04df69c5d77896ab9 as layer_618b86a04df69c5d77896ab9
import layer_618b86a04df69c5d77896abb as layer_618b86a04df69c5d77896abb
import layer_618b86a04df69c5d77896ada as layer_618b86a04df69c5d77896ada
import layer_618b86a04df69c5d77896ade as layer_618b86a04df69c5d77896ade
import layer_618b86a04df69c5d77896ae0 as layer_618b86a04df69c5d77896ae0
import layer_618b86a04df69c5d77896ae2 as layer_618b86a04df69c5d77896ae2
import layer_618b86a04df69c5d77896ae6 as layer_618b86a04df69c5d77896ae6
import layer_618b86a04df69c5d77896aea as layer_618b86a04df69c5d77896aea
import layer_618b86a04df69c5d77896ae8 as layer_618b86a04df69c5d77896ae8
import layer_618b86a04df69c5d77896aec as layer_618b86a04df69c5d77896aec
import layer_618b86a04df69c5d77896aee as layer_618b86a04df69c5d77896aee
import layer_618b86a04df69c5d77896af0 as layer_618b86a04df69c5d77896af0
import layer_618b86a04df69c5d77896ad4 as layer_618b86a04df69c5d77896ad4
import layer_618b86a04df69c5d77896b51 as layer_618b86a04df69c5d77896b51
import layer_618b86a04df69c5d77896b55 as layer_618b86a04df69c5d77896b55
import layer_618b86a04df69c5d77896b57 as layer_618b86a04df69c5d77896b57
import layer_618b86a04df69c5d77896b59 as layer_618b86a04df69c5d77896b59
import layer_618b86a04df69c5d77896b5d as layer_618b86a04df69c5d77896b5d
import layer_618b86a04df69c5d77896b5f as layer_618b86a04df69c5d77896b5f
import layer_618b86a04df69c5d77896b61 as layer_618b86a04df69c5d77896b61
import layer_618b86a04df69c5d77896b63 as layer_618b86a04df69c5d77896b63
import layer_618b86a04df69c5d77896b65 as layer_618b86a04df69c5d77896b65
import layer_618b86a04df69c5d77896b67 as layer_618b86a04df69c5d77896b67
import layer_618b86a04df69c5d77896b6b as layer_618b86a04df69c5d77896b6b
import layer_618b86a04df69c5d77896b6d as layer_618b86a04df69c5d77896b6d
import layer_618b86a04df69c5d77896b6f as layer_618b86a04df69c5d77896b6f
import layer_618b86a04df69c5d77896b71 as layer_618b86a04df69c5d77896b71
import layer_618b86a04df69c5d77896b4b as layer_618b86a04df69c5d77896b4b
import layer_618b86a04df69c5d77896b4d as layer_618b86a04df69c5d77896b4d
import layer_618b86a04df69c5d77896b4f as layer_618b86a04df69c5d77896b4f
import layer_618b86a04df69c5d77896b79 as layer_618b86a04df69c5d77896b79
import layer_618b86a04df69c5d77896b7b as layer_618b86a04df69c5d77896b7b
import layer_618b86a04df69c5d77896b7d as layer_618b86a04df69c5d77896b7d
import layer_618b86a04df69c5d77896b75 as layer_618b86a04df69c5d77896b75
import layer_618b86a04df69c5d77896b89 as layer_618b86a04df69c5d77896b89
import layer_618b86a04df69c5d77896b8d as layer_618b86a04df69c5d77896b8d
import layer_618b86a04df69c5d77896b8f as layer_618b86a04df69c5d77896b8f
import layer_618b86a04df69c5d77896b91 as layer_618b86a04df69c5d77896b91
import layer_618b86a04df69c5d77896b95 as layer_618b86a04df69c5d77896b95
import layer_618b86a04df69c5d77896b97 as layer_618b86a04df69c5d77896b97
import layer_618b86a04df69c5d77896b99 as layer_618b86a04df69c5d77896b99
import layer_618b86a04df69c5d77896b9d as layer_618b86a04df69c5d77896b9d
import layer_618b86a04df69c5d77896b9f as layer_618b86a04df69c5d77896b9f
import layer_618b86a04df69c5d77896ba1 as layer_618b86a04df69c5d77896ba1
import layer_618b86a04df69c5d77896ba4 as layer_618b86a04df69c5d77896ba4
import layer_618b86a04df69c5d77896ba8 as layer_618b86a04df69c5d77896ba8
import layer_618b86a04df69c5d77896baa as layer_618b86a04df69c5d77896baa
import layer_618b86a04df69c5d77896bac as layer_618b86a04df69c5d77896bac
import layer_618b86a04df69c5d77896bb0 as layer_618b86a04df69c5d77896bb0
import layer_618b86a04df69c5d77896bb2 as layer_618b86a04df69c5d77896bb2
import layer_618b86a04df69c5d77896bb4 as layer_618b86a04df69c5d77896bb4
import layer_618b86a04df69c5d77896bb8 as layer_618b86a04df69c5d77896bb8
import layer_618b86a04df69c5d77896bba as layer_618b86a04df69c5d77896bba
import layer_618b86a04df69c5d77896bbc as layer_618b86a04df69c5d77896bbc
import layer_618b86a04df69c5d77896bc0 as layer_618b86a04df69c5d77896bc0
import layer_618b86a04df69c5d77896bc2 as layer_618b86a04df69c5d77896bc2
import layer_618b86a04df69c5d77896bc4 as layer_618b86a04df69c5d77896bc4
import layer_618b86a04df69c5d77896bc7 as layer_618b86a04df69c5d77896bc7
import layer_618b86a04df69c5d77896bc9 as layer_618b86a04df69c5d77896bc9
import layer_618b86a04df69c5d77896bcd as layer_618b86a04df69c5d77896bcd
import layer_618b86a04df69c5d77896bcf as layer_618b86a04df69c5d77896bcf
import layer_618b86a04df69c5d77896bd1 as layer_618b86a04df69c5d77896bd1
import layer_618b86a04df69c5d77896b83 as layer_618b86a04df69c5d77896b83
import layer_618b86a04df69c5d77896b85 as layer_618b86a04df69c5d77896b85
import layer_618b86a04df69c5d77896b87 as layer_618b86a04df69c5d77896b87
import layer_618b86a04df69c5d77896bd6 as layer_618b86a04df69c5d77896bd6
import layer_618b86a04df69c5d77896be2 as layer_618b86a04df69c5d77896be2
import layer_618b86a04df69c5d77896be6 as layer_618b86a04df69c5d77896be6
import layer_618b86a04df69c5d77896be8 as layer_618b86a04df69c5d77896be8
import layer_618b86a04df69c5d77896bea as layer_618b86a04df69c5d77896bea
import layer_618b86a04df69c5d77896bee as layer_618b86a04df69c5d77896bee
import layer_618b86a04df69c5d77896bf0 as layer_618b86a04df69c5d77896bf0
import layer_618b86a04df69c5d77896bf2 as layer_618b86a04df69c5d77896bf2
import layer_618b86a04df69c5d77896bf6 as layer_618b86a04df69c5d77896bf6
import layer_618b86a04df69c5d77896bf8 as layer_618b86a04df69c5d77896bf8
import layer_618b86a04df69c5d77896bfa as layer_618b86a04df69c5d77896bfa
import layer_618b86a04df69c5d77896bfd as layer_618b86a04df69c5d77896bfd
import layer_618b86a04df69c5d77896c01 as layer_618b86a04df69c5d77896c01
import layer_618b86a04df69c5d77896c03 as layer_618b86a04df69c5d77896c03
import layer_618b86a04df69c5d77896c05 as layer_618b86a04df69c5d77896c05
import layer_618b86a04df69c5d77896c09 as layer_618b86a04df69c5d77896c09
import layer_618b86a04df69c5d77896c0b as layer_618b86a04df69c5d77896c0b
import layer_618b86a04df69c5d77896c0d as layer_618b86a04df69c5d77896c0d
import layer_618b86a04df69c5d77896c11 as layer_618b86a04df69c5d77896c11
import layer_618b86a04df69c5d77896c13 as layer_618b86a04df69c5d77896c13
import layer_618b86a04df69c5d77896c15 as layer_618b86a04df69c5d77896c15
import layer_618b86a04df69c5d77896c19 as layer_618b86a04df69c5d77896c19
import layer_618b86a04df69c5d77896c1b as layer_618b86a04df69c5d77896c1b
import layer_618b86a04df69c5d77896c1d as layer_618b86a04df69c5d77896c1d
import layer_618b86a04df69c5d77896c20 as layer_618b86a04df69c5d77896c20
import layer_618b86a04df69c5d77896c22 as layer_618b86a04df69c5d77896c22
import layer_618b86a04df69c5d77896c26 as layer_618b86a04df69c5d77896c26
import layer_618b86a04df69c5d77896c28 as layer_618b86a04df69c5d77896c28
import layer_618b86a04df69c5d77896c2a as layer_618b86a04df69c5d77896c2a
import layer_618b86a04df69c5d77896bdc as layer_618b86a04df69c5d77896bdc
import layer_618b86a04df69c5d77896bde as layer_618b86a04df69c5d77896bde
import layer_618b86a04df69c5d77896be0 as layer_618b86a04df69c5d77896be0
import layer_618b86a04df69c5d77896c2f as layer_618b86a04df69c5d77896c2f
import layer_618b86a04df69c5d77896c31 as layer_618b86a04df69c5d77896c31
import layer_618b86a04df69c5d77896c35 as layer_618b86a04df69c5d77896c35
import layer_618b86a04df69c5d77896c33 as layer_618b86a04df69c5d77896c33


def get_layer_object(module):
    for member in getmembers(module):
        if member[1].__module__ == module.__name__:
            return member[1]

def get_loss_sum_fn(list_loss):
    def LossSum(y_true, y_pred):
        loss = 0
        for loss_fn in list_loss:
            loss += loss_fn(y_true, y_pred)
        return loss

    return LossSum

class Model(BaseModel):
    def __init__(self, *args, **kwargs):
        super(Model, self).__init__(*args, **kwargs)
        self.path_weight = file_path + "/weight.hdf5"
        inputs, outputs, losses, labels = self.build_source()
        self.compile(inputs, outputs, losses, labels)

    def build_source(self):
        config_loss = dict()
        volume = 64
        height = 64
        width = 64
        channels = 3
        num_class = 7
        output_channels = 1
        batch_size = 1

        n1_Image = layer_618b86a04df69c5d778968e8.Image(shape=[64, 64, 3])
        n2_Backbone_n1_Conv2D = layer_618b86a04df69c5d778968ec.Conv2D(filters=32, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n1_Image)
        n2_Backbone_n3_BatchNormalization = layer_618b86a04df69c5d778968f0.BatchNormalization()(n2_Backbone_n1_Conv2D)
        n2_Backbone_n2_Activation = layer_618b86a04df69c5d778968ee.Activation(activation='relu')(n2_Backbone_n3_BatchNormalization)
        n2_Backbone_n4_Conv2D = layer_618b86a04df69c5d778968f2.Conv2D(filters=32, kernel_size=[3, 3], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n2_Activation)
        n2_Backbone_n5_BatchNormalization = layer_618b86a04df69c5d778968f4.BatchNormalization()(n2_Backbone_n4_Conv2D)
        n2_Backbone_n6_Activation = layer_618b86a04df69c5d778968f6.Activation(activation='relu')(n2_Backbone_n5_BatchNormalization)
        n2_Backbone_n7_Conv2D = layer_618b86a04df69c5d778968f8.Conv2D(filters=64, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n6_Activation)
        n2_Backbone_n8_BatchNormalization = layer_618b86a04df69c5d778968fa.BatchNormalization()(n2_Backbone_n7_Conv2D)
        n2_Backbone_n9_Activation = layer_618b86a04df69c5d778968fc.Activation(activation='relu')(n2_Backbone_n8_BatchNormalization)
        n2_Backbone_n10_MaxPooling2D = layer_618b86a04df69c5d778968fe.MaxPooling2D(pool_size=[2, 2], strides=[2, 2], padding='valid')(n2_Backbone_n9_Activation)
        n2_Backbone_n11_mixed_0_n9_Activation = layer_618b86a04df69c5d7789693c.Activation(activation='linear')(n2_Backbone_n10_MaxPooling2D)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896904.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896908.BatchNormalization()(n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d7789690c.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896910.BatchNormalization()(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d7789691c.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896920.BatchNormalization()(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n7_AveragePooling2D = layer_618b86a04df69c5d77896932.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896936.Conv2D(filters=32, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d7789693a.BatchNormalization()(n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896906.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d7789690e.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896914.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896918.BatchNormalization()(n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d7789691e.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896924.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896928.BatchNormalization()(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896938.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896916.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896926.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d7789692c.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896930.BatchNormalization()(n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d7789692e.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896941.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n11_mixed_0_n10_Concatenate = layer_618b86a04df69c5d77896941.Concatenate(axis=-1)([n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n11_mixed_0_n10_Concatenate = layer_618b86a04df69c5d77896941.Concatenate(axis=-1)(*[n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n12_mixed_0_n9_Activation = layer_618b86a04df69c5d7789697f.Activation(activation='linear')(n2_Backbone_n11_mixed_0_n10_Concatenate)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896947.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d7789694b.BatchNormalization()(n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d7789694f.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896953.BatchNormalization()(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d7789695f.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896963.BatchNormalization()(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n7_AveragePooling2D = layer_618b86a04df69c5d77896975.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896979.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d7789697d.BatchNormalization()(n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896949.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896951.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896957.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d7789695b.BatchNormalization()(n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896961.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896967.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d7789696b.BatchNormalization()(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d7789697b.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896959.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896969.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d7789696f.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896973.BatchNormalization()(n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896971.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896984.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n12_mixed_0_n10_Concatenate = layer_618b86a04df69c5d77896984.Concatenate(axis=-1)([n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n12_mixed_0_n10_Concatenate = layer_618b86a04df69c5d77896984.Concatenate(axis=-1)(*[n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n13_mixed_0_n9_Activation = layer_618b86a04df69c5d778969c2.Activation(activation='linear')(n2_Backbone_n12_mixed_0_n10_Concatenate)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d7789698a.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d7789698e.BatchNormalization()(n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896992.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896996.BatchNormalization()(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969a2.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d778969a6.BatchNormalization()(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n7_AveragePooling2D = layer_618b86a04df69c5d778969b8.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969bc.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d778969c0.BatchNormalization()(n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d7789698c.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896994.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d7789699a.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d7789699e.BatchNormalization()(n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d778969a4.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969aa.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d778969ae.BatchNormalization()(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d778969be.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d7789699c.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d778969ac.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969b2.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d778969b6.BatchNormalization()(n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d778969b4.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d778969c7.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n13_mixed_0_n10_Concatenate = layer_618b86a04df69c5d778969c7.Concatenate(axis=-1)([n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n13_mixed_0_n10_Concatenate = layer_618b86a04df69c5d778969c7.Concatenate(axis=-1)(*[n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n14_mixed_3_n2_Activation = layer_618b86a04df69c5d778969d3.Activation(activation='linear')(n2_Backbone_n13_mixed_0_n10_Concatenate)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969d7.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d778969d9.BatchNormalization()(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d778969db.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969df.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d778969e1.BatchNormalization()(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d778969e3.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969e7.Conv2D(filters=96, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n3_Activation)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d778969e9.BatchNormalization()(n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d778969eb.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n6_MaxPooling2D = layer_618b86a04df69c5d778969ed.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='valid')(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969cd.Conv2D(filters=384, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d778969cf.BatchNormalization()(n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d778969d1.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d778969f1.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n14_mixed_3_n7_Concatenate = layer_618b86a04df69c5d778969f1.Concatenate(axis=-1)([n2_Backbone_n14_mixed_3_n6_MaxPooling2D, n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation, n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n14_mixed_3_n7_Concatenate = layer_618b86a04df69c5d778969f1.Concatenate(axis=-1)(*[n2_Backbone_n14_mixed_3_n6_MaxPooling2D, n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation, n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n15_mixed_0_n7_Activation = layer_618b86a04df69c5d77896a25.Activation(activation='linear')(n2_Backbone_n14_mixed_3_n7_Concatenate)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969f7.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d778969fb.BatchNormalization()(n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d778969ff.Conv2D(filters=128, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a03.BatchNormalization()(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a15.Conv2D(filters=128, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a19.BatchNormalization()(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n5_AveragePooling2D = layer_618b86a04df69c5d77896a1b.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a1f.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a23.BatchNormalization()(n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d778969f9.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a01.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a07.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a0b.BatchNormalization()(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a17.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a21.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a2e.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a32.BatchNormalization()(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a09.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896a0d.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896a0f.BatchNormalization()(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896a11.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a30.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896a34.Conv2D(filters=128, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896a36.BatchNormalization()(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896a38.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a3c.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a40.BatchNormalization()(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a3e.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896a42.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896a44.BatchNormalization()(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896a46.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896a2a.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n15_mixed_0_n8_Concatenate = layer_618b86a04df69c5d77896a2a.Concatenate(axis=-1)([n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n15_mixed_0_n8_Concatenate = layer_618b86a04df69c5d77896a2a.Concatenate(axis=-1)(*[n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n16_mixed_0_n7_Activation = layer_618b86a04df69c5d77896a7a.Activation(activation='linear')(n2_Backbone_n15_mixed_0_n8_Concatenate)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a4c.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a50.BatchNormalization()(n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a54.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a58.BatchNormalization()(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a6a.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a6e.BatchNormalization()(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n5_AveragePooling2D = layer_618b86a04df69c5d77896a70.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a74.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a78.BatchNormalization()(n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a4e.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a56.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a5c.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a60.BatchNormalization()(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a6c.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a76.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a83.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a87.BatchNormalization()(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a5e.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896a62.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896a64.BatchNormalization()(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896a66.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a85.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896a89.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896a8b.BatchNormalization()(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896a8d.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896a91.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896a95.BatchNormalization()(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896a93.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896a97.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896a99.BatchNormalization()(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896a9b.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896a7f.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n16_mixed_0_n8_Concatenate = layer_618b86a04df69c5d77896a7f.Concatenate(axis=-1)([n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n16_mixed_0_n8_Concatenate = layer_618b86a04df69c5d77896a7f.Concatenate(axis=-1)(*[n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n18_mixed_0_n7_Activation = layer_618b86a04df69c5d77896b24.Activation(activation='linear')(n2_Backbone_n16_mixed_0_n8_Concatenate)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896af6.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896afa.BatchNormalization()(n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896afe.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896b02.BatchNormalization()(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b14.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896b18.BatchNormalization()(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n5_AveragePooling2D = layer_618b86a04df69c5d77896b1a.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b1e.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896b22.BatchNormalization()(n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896af8.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896b00.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b06.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896b0a.BatchNormalization()(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896b16.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896b20.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b2d.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896b31.BatchNormalization()(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896b08.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896b0c.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896b0e.BatchNormalization()(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896b10.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896b2f.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896b33.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896b35.BatchNormalization()(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896b37.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b3b.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896b3f.BatchNormalization()(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896b3d.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896b41.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896b43.BatchNormalization()(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896b45.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896b29.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n18_mixed_0_n8_Concatenate = layer_618b86a04df69c5d77896b29.Concatenate(axis=-1)([n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n18_mixed_0_n8_Concatenate = layer_618b86a04df69c5d77896b29.Concatenate(axis=-1)(*[n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n17_mixed_0_n7_Activation = layer_618b86a04df69c5d77896acf.Activation(activation='linear')(n2_Backbone_n18_mixed_0_n8_Concatenate)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896aa1.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896aa5.BatchNormalization()(n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896aa9.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896aad.BatchNormalization()(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896abf.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896ac3.BatchNormalization()(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n5_AveragePooling2D = layer_618b86a04df69c5d77896ac5.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896ac9.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896acd.BatchNormalization()(n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896aa3.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896aab.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896ab1.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896ab5.BatchNormalization()(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896ac1.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896acb.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896ad8.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896adc.BatchNormalization()(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896ab3.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896ab7.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896ab9.BatchNormalization()(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896abb.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896ada.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896ade.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896ae0.BatchNormalization()(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896ae2.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896ae6.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618b86a04df69c5d77896aea.BatchNormalization()(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618b86a04df69c5d77896ae8.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896aec.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896aee.BatchNormalization()(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896af0.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896ad4.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n17_mixed_0_n8_Concatenate = layer_618b86a04df69c5d77896ad4.Concatenate(axis=-1)([n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n17_mixed_0_n8_Concatenate = layer_618b86a04df69c5d77896ad4.Concatenate(axis=-1)(*[n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n19_mixed_3_n2_Activation = layer_618b86a04df69c5d77896b51.Activation(activation='linear')(n2_Backbone_n17_mixed_0_n8_Concatenate)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b55.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b57.BatchNormalization()(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896b59.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b5d.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b5f.BatchNormalization()(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896b61.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n4_Conv2D = layer_618b86a04df69c5d77896b63.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n5_BatchNormalization = layer_618b86a04df69c5d77896b65.BatchNormalization()(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n6_Activation = layer_618b86a04df69c5d77896b67.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b6b.Conv2D(filters=192, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n6_Activation)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b6d.BatchNormalization()(n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896b6f.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n6_MaxPooling2D = layer_618b86a04df69c5d77896b71.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='valid')(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b4b.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b4d.BatchNormalization()(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896b4f.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b79.Conv2D(filters=320, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b7b.BatchNormalization()(n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896b7d.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896b75.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n19_mixed_3_n7_Concatenate = layer_618b86a04df69c5d77896b75.Concatenate(axis=-1)([n2_Backbone_n19_mixed_3_n6_MaxPooling2D, n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation, n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n19_mixed_3_n7_Concatenate = layer_618b86a04df69c5d77896b75.Concatenate(axis=-1)(*[n2_Backbone_n19_mixed_3_n6_MaxPooling2D, n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation, n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n2_Activation = layer_618b86a04df69c5d77896b89.Activation(activation='linear')(n2_Backbone_n19_mixed_3_n7_Concatenate)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b8d.Conv2D(filters=384, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b8f.BatchNormalization()(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896b91.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b95.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b97.BatchNormalization()(n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896b99.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b9d.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b9f.BatchNormalization()(n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896ba1.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896ba4.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n6_Concatenate = layer_618b86a04df69c5d77896ba4.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n6_Concatenate = layer_618b86a04df69c5d77896ba4.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896ba8.Conv2D(filters=448, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896baa.BatchNormalization()(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896bac.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896bb0.Conv2D(filters=384, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896bb2.BatchNormalization()(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896bb4.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896bb8.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896bba.BatchNormalization()(n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896bbc.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896bc0.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896bc2.BatchNormalization()(n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896bc4.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896bc7.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n11_Concatenate = layer_618b86a04df69c5d77896bc7.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n11_Concatenate = layer_618b86a04df69c5d77896bc7.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n12_AveragePooling2D = layer_618b86a04df69c5d77896bc9.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896bcd.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n12_AveragePooling2D)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896bcf.BatchNormalization()(n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896bd1.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896b83.Conv2D(filters=320, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896b85.BatchNormalization()(n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896b87.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896bd6.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n14_Concatenate = layer_618b86a04df69c5d77896bd6.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n6_Concatenate, n2_Backbone_n20_mixed_9_n11_Concatenate, n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n14_Concatenate = layer_618b86a04df69c5d77896bd6.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n6_Concatenate, n2_Backbone_n20_mixed_9_n11_Concatenate, n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n2_Activation = layer_618b86a04df69c5d77896be2.Activation(activation='linear')(n2_Backbone_n20_mixed_9_n14_Concatenate)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896be6.Conv2D(filters=384, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896be8.BatchNormalization()(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896bea.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896bee.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896bf0.BatchNormalization()(n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896bf2.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896bf6.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896bf8.BatchNormalization()(n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896bfa.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896bfd.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n6_Concatenate = layer_618b86a04df69c5d77896bfd.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n6_Concatenate = layer_618b86a04df69c5d77896bfd.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896c01.Conv2D(filters=448, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896c03.BatchNormalization()(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896c05.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896c09.Conv2D(filters=384, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896c0b.BatchNormalization()(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896c0d.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896c11.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896c13.BatchNormalization()(n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896c15.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896c19.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896c1b.BatchNormalization()(n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896c1d.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896c20.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n11_Concatenate = layer_618b86a04df69c5d77896c20.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n11_Concatenate = layer_618b86a04df69c5d77896c20.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n12_AveragePooling2D = layer_618b86a04df69c5d77896c22.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896c26.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n12_AveragePooling2D)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896c28.BatchNormalization()(n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896c2a.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n1_Conv2D = layer_618b86a04df69c5d77896bdc.Conv2D(filters=320, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n2_BatchNormalization = layer_618b86a04df69c5d77896bde.BatchNormalization()(n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation = layer_618b86a04df69c5d77896be0.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618b86a04df69c5d77896c2f.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n14_Concatenate = layer_618b86a04df69c5d77896c2f.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n6_Concatenate, n2_Backbone_n21_mixed_9_n11_Concatenate, n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n14_Concatenate = layer_618b86a04df69c5d77896c2f.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n6_Concatenate, n2_Backbone_n21_mixed_9_n11_Concatenate, n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation])
        n3_GlobalAveragePooling2D = layer_618b86a04df69c5d77896c31.GlobalAveragePooling2D()(n2_Backbone_n21_mixed_9_n14_Concatenate)
        n9_Dropout = layer_618b86a04df69c5d77896c35.Dropout(rate=0.5)(n3_GlobalAveragePooling2D)
        n4_Dense = layer_618b86a04df69c5d77896c33.Dense(units=7, activation='softmax', use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n9_Dropout)
        label = keras.layers.Input(shape=[7])
        loss = keras.losses.CategoricalCrossentropy()(label, n4_Dense)
        



        for key in list(config_loss.keys()):
            if len(config_loss[key]) == 1:
                config_loss[key] = config_loss[key][0]
            elif len(config_loss[key]) > 1:
                config_loss[key] = get_loss_sum_fn(config_loss[key])
            else:
                del config_loss[key]
        inputs = [n1_Image]
        outputs = [n4_Dense]
        losses = [loss]
        labels = [label]

        return inputs, outputs, losses, labels

