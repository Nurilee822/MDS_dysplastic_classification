#   상기 프로그램에 대한 저작권을 포함한 지적재산권은 Deepnoid에 있으며,
#   Deepnoid가 명시적으로 허용하지 않은 사용, 복사, 변경, 제3자에의 공개,
#   배포는 엄격히 금지되며, Deepnoid의 지적재산권 침해에 해당됩니다.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------
#   You are strictly prohibited to copy, disclose, distribute, modify,
#   or use this program in part or as a whole without the prior written
#   consent of Deepnoid Co., Ltd. Deepnoid Co., Ltd., owns the
#   intellectual property rights in and to this program.
#   (Copyright ⓒ 2020 Deepnoid Co., Ltd. All Rights Reserved|Confidential)
#  -----------------------------------------------------------------------------


import numpy as np
import cv2
import matplotlib.cm as cm
import tensorflow as tf
import tensorflow.keras as keras
import SimpleITK as sitk


def resize_3d(img_array, shape):
    sitk_image = sitk.GetImageFromArray(img_array, isVector=True)  # input label image
    original_spacing = sitk_image.GetSpacing()
    original_size = sitk_image.GetSize()

    new_size = shape
    new_spacing = [(ospc * osz / nsz) for osz, ospc, nsz in
                   zip(original_size, original_spacing, new_size)]
    # main image processing
    sitk_image = sitk.Resample(sitk_image, new_size, sitk.Transform(),
                               sitk.sitkNearestNeighbor,
                               sitk_image.GetOrigin(),
                               new_spacing, sitk_image.GetDirection(),
                               0, sitk_image.GetPixelID())

    return sitk.GetArrayFromImage(sitk_image)


def find_last_layer(model):
    for i in range(len(model.layers)):
        idx_last = len(model.layers) - i - 1

        if type(model.layers[idx_last]).__name__ in ('Conv2D', 'Activation', 'ReLU'):
            last_conv_layer = model.layers[idx_last]
            break

    return last_conv_layer


def change_layer(model, layer_changed):
    list_backward = list()
    model_classifier_input = list()
    model_last_conv_output = list()

    changed_layers = dict()

    for i in range(len(model.layers)):
        idx_last = len(model.layers) - i - 1
        if model.layers[idx_last].output.name == layer_changed.output.name:
            break
        list_backward.append(model.layers[idx_last])

    for layer in list_backward[::-1]:
        inputs = layer.input
        if not isinstance(inputs, list):
            inputs = [inputs]
        inputs_new = list()

        for ip in inputs:
            if ip.name not in changed_layers.keys():
                output = keras.Input(shape=ip.shape[1:])
                changed_layers[ip.name] = output

                inputs_new.append(output)
                model_classifier_input.append(output)
                model_last_conv_output.append(ip)

                if ip.name == layer_changed.output.name:
                    idx_last_conv_layer = len(model_classifier_input) - 1

            else:
                inputs_new.append(changed_layers[ip.name])

        if len(inputs_new) == 1:
            inputs_new = inputs_new[0]
        changed_layers[layer.output.name] = layer(inputs_new)

    model_last_conv_layer = keras.Model(model.inputs, model_last_conv_output)
    model_classifier = keras.Model(model_classifier_input, changed_layers[layer.output.name])

    return idx_last_conv_layer, model_last_conv_layer, model_classifier

def make_gradcam_heatmap(
        model, img_array):
    # First, we create a model that maps the input image to the activations
    # of the last conv layer

    # get activation layer
    layer = find_last_layer(model)
    idx_last_conv_layer, model_last_conv_layer, model_classifier = change_layer(model, layer)

    # Then, we compute the gradient of the top predicted class for our input image
    # with respect to the activations of the last conv layer
    with tf.GradientTape() as tape:
        # Compute activations of the last conv layer and make the tape watch it
        outputs = model_last_conv_layer(img_array)
        if len(outputs) != 1:
            last_conv_layer_output = outputs[idx_last_conv_layer]
        else:
            last_conv_layer_output = outputs
        tape.watch(last_conv_layer_output)
        # Compute class predictions
        preds = model_classifier(outputs)
        top_pred_index = tf.argmax(preds[0])
        top_class_channel = preds[:, top_pred_index]

    # This is the gradient of the top predicted class with regard to
    # the output feature map of the last conv layer
    grads = tape.gradient(top_class_channel, last_conv_layer_output)

    # This is a vector where each entry is the mean intensity of the gradient
    # over a specific feature map channel
    if len(img_array.shape) == 5:
        axis = (0, 1, 2, 3)
    else:
        axis = (0, 1, 2)
    pooled_grads = tf.reduce_mean(grads, axis=axis)

    # We multiply each channel in the feature map array
    # by "how important this channel is" with regard to the top predicted class
    last_conv_layer_output = last_conv_layer_output.numpy()[0]
    pooled_grads = pooled_grads.numpy()
    for i in range(pooled_grads.shape[-1]):
        if len(img_array.shape) == 5:
            last_conv_layer_output[:, :, :, i] *= pooled_grads[i]
        else:
            last_conv_layer_output[:, :, i] *= pooled_grads[i]

    # The channel-wise mean of the resulting feature map
    # is our heatmap of class activation
    heatmap = np.mean(last_conv_layer_output, axis=-1)

    # For visualization purpose, we will also normalize the heatmap between 0 & 1
    heatmap = np.maximum(heatmap, 0) / np.max(heatmap)

    heatmap = np.uint8(heatmap * 255)
    # We use jet colormap to colorize heatmap
    jet = cm.get_cmap("jet")

    # We use RGB values of the colormap
    jet_colors = jet(np.arange(256))[:, :3]
    jet_heatmap = jet_colors[heatmap]

    if len(img_array.shape) == 5:
        jet_heatmap = resize_3d(jet_heatmap, tuple(list(img_array[0].shape)[:-1][::-1]))
    else:
        jet_heatmap = cv2.resize(jet_heatmap, tuple(list(img_array[0].shape)[:-1][::-1]))

    return jet_heatmap
