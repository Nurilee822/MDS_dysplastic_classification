import os
import sys
PATH_SCRIPT = os.path.dirname(os.path.abspath(__file__))

import source_code

model = source_code.Model()
model.build_open_vino_model(path=f"{PATH_SCRIPT}/saved_model")
