import os
import sys
file_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(f"{file_path}/utils")

import base_model
from openvino.runtime import Core
import numpy as np


class Model(base_model.BaseModel):
    def __init__(self, *args, **kwargs):
        super(Model, self).__init__(*args, **kwargs)
        self.filename_xml = None
        self.filename_weights = None

        self.model = None
        self.input_key = None
        self.output_key = None

        self.initialization()

    def initialization(self):
        self.set_filename_xml(f"{file_path}/saved_model/saved_model.xml")
        self.set_filename_weights(f"{file_path}/saved_model/saved_model.bin")
        self.compile_openvino()

    def set_filename_xml(self, filename_xml):
        self.filename_xml = filename_xml

    def set_filename_weights(self, filename_weights):
        self.filename_weights = filename_weights

    def compile_openvino(self):
        self.ie = Core()
        model = self.ie.read_model(model=self.filename_xml, weights=self.filename_weights)
        self.model = self.ie.compile_model(model=model, device_name="CPU")

    def __call__(self, data):
        prediction = self.call_openvino(data)
        data = self.save_pred_result(data, prediction)
        return data

    def call_openvino(self, data):
        img = data['image']['array']
        if not data['image']['header']['IsVector']:
            img = np.expand_dims(img, axis=-1)
        img = np.expand_dims(img, axis=0)
        output_key = next(iter(self.model.outputs))
        result = self.model([img])[output_key][0]
        print(result.shape)
        return result
