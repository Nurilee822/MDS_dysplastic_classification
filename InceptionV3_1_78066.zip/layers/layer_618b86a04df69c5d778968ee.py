from tensorflow.keras.layers import *


class Activation(Activation):
    pass