import sys
from tensorflow import keras
import tensorflow.keras.backend as K
import inspect
import os

file_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(f"{file_path}/layers")
sys.path.append(f"{file_path}/utils")


from base_model import BaseModel
from inspect import getmembers, isfunction

import tensorflow as tf
import layer_618a6b37d8225b6588c104e8 as layer_618a6b37d8225b6588c104e8
import layer_618a6b37d8225b6588c104ec as layer_618a6b37d8225b6588c104ec
import layer_618a6b37d8225b6588c104f0 as layer_618a6b37d8225b6588c104f0
import layer_618a6b37d8225b6588c104ee as layer_618a6b37d8225b6588c104ee
import layer_618a6b37d8225b6588c104f2 as layer_618a6b37d8225b6588c104f2
import layer_618a6b37d8225b6588c104f4 as layer_618a6b37d8225b6588c104f4
import layer_618a6b37d8225b6588c104f6 as layer_618a6b37d8225b6588c104f6
import layer_618a6b37d8225b6588c104f8 as layer_618a6b37d8225b6588c104f8
import layer_618a6b37d8225b6588c104fa as layer_618a6b37d8225b6588c104fa
import layer_618a6b37d8225b6588c104fc as layer_618a6b37d8225b6588c104fc
import layer_618a6b37d8225b6588c104fe as layer_618a6b37d8225b6588c104fe
import layer_618a6b37d8225b6588c1053c as layer_618a6b37d8225b6588c1053c
import layer_618a6b37d8225b6588c10504 as layer_618a6b37d8225b6588c10504
import layer_618a6b37d8225b6588c10508 as layer_618a6b37d8225b6588c10508
import layer_618a6b37d8225b6588c1050c as layer_618a6b37d8225b6588c1050c
import layer_618a6b37d8225b6588c10510 as layer_618a6b37d8225b6588c10510
import layer_618a6b37d8225b6588c1051c as layer_618a6b37d8225b6588c1051c
import layer_618a6b37d8225b6588c10520 as layer_618a6b37d8225b6588c10520
import layer_618a6b37d8225b6588c10532 as layer_618a6b37d8225b6588c10532
import layer_618a6b37d8225b6588c10536 as layer_618a6b37d8225b6588c10536
import layer_618a6b37d8225b6588c1053a as layer_618a6b37d8225b6588c1053a
import layer_618a6b37d8225b6588c10506 as layer_618a6b37d8225b6588c10506
import layer_618a6b37d8225b6588c1050e as layer_618a6b37d8225b6588c1050e
import layer_618a6b37d8225b6588c10514 as layer_618a6b37d8225b6588c10514
import layer_618a6b37d8225b6588c10518 as layer_618a6b37d8225b6588c10518
import layer_618a6b37d8225b6588c1051e as layer_618a6b37d8225b6588c1051e
import layer_618a6b37d8225b6588c10524 as layer_618a6b37d8225b6588c10524
import layer_618a6b37d8225b6588c10528 as layer_618a6b37d8225b6588c10528
import layer_618a6b37d8225b6588c10538 as layer_618a6b37d8225b6588c10538
import layer_618a6b37d8225b6588c10516 as layer_618a6b37d8225b6588c10516
import layer_618a6b37d8225b6588c10526 as layer_618a6b37d8225b6588c10526
import layer_618a6b37d8225b6588c1052c as layer_618a6b37d8225b6588c1052c
import layer_618a6b37d8225b6588c10530 as layer_618a6b37d8225b6588c10530
import layer_618a6b37d8225b6588c1052e as layer_618a6b37d8225b6588c1052e
import layer_618a6b37d8225b6588c10541 as layer_618a6b37d8225b6588c10541
import layer_618a6b37d8225b6588c1057f as layer_618a6b37d8225b6588c1057f
import layer_618a6b37d8225b6588c10547 as layer_618a6b37d8225b6588c10547
import layer_618a6b37d8225b6588c1054b as layer_618a6b37d8225b6588c1054b
import layer_618a6b37d8225b6588c1054f as layer_618a6b37d8225b6588c1054f
import layer_618a6b37d8225b6588c10553 as layer_618a6b37d8225b6588c10553
import layer_618a6b37d8225b6588c1055f as layer_618a6b37d8225b6588c1055f
import layer_618a6b37d8225b6588c10563 as layer_618a6b37d8225b6588c10563
import layer_618a6b37d8225b6588c10575 as layer_618a6b37d8225b6588c10575
import layer_618a6b37d8225b6588c10579 as layer_618a6b37d8225b6588c10579
import layer_618a6b37d8225b6588c1057d as layer_618a6b37d8225b6588c1057d
import layer_618a6b37d8225b6588c10549 as layer_618a6b37d8225b6588c10549
import layer_618a6b37d8225b6588c10551 as layer_618a6b37d8225b6588c10551
import layer_618a6b37d8225b6588c10557 as layer_618a6b37d8225b6588c10557
import layer_618a6b37d8225b6588c1055b as layer_618a6b37d8225b6588c1055b
import layer_618a6b37d8225b6588c10561 as layer_618a6b37d8225b6588c10561
import layer_618a6b37d8225b6588c10567 as layer_618a6b37d8225b6588c10567
import layer_618a6b37d8225b6588c1056b as layer_618a6b37d8225b6588c1056b
import layer_618a6b37d8225b6588c1057b as layer_618a6b37d8225b6588c1057b
import layer_618a6b37d8225b6588c10559 as layer_618a6b37d8225b6588c10559
import layer_618a6b37d8225b6588c10569 as layer_618a6b37d8225b6588c10569
import layer_618a6b37d8225b6588c1056f as layer_618a6b37d8225b6588c1056f
import layer_618a6b37d8225b6588c10573 as layer_618a6b37d8225b6588c10573
import layer_618a6b37d8225b6588c10571 as layer_618a6b37d8225b6588c10571
import layer_618a6b37d8225b6588c10584 as layer_618a6b37d8225b6588c10584
import layer_618a6b37d8225b6588c105c2 as layer_618a6b37d8225b6588c105c2
import layer_618a6b37d8225b6588c1058a as layer_618a6b37d8225b6588c1058a
import layer_618a6b37d8225b6588c1058e as layer_618a6b37d8225b6588c1058e
import layer_618a6b37d8225b6588c10592 as layer_618a6b37d8225b6588c10592
import layer_618a6b37d8225b6588c10596 as layer_618a6b37d8225b6588c10596
import layer_618a6b37d8225b6588c105a2 as layer_618a6b37d8225b6588c105a2
import layer_618a6b37d8225b6588c105a6 as layer_618a6b37d8225b6588c105a6
import layer_618a6b37d8225b6588c105b8 as layer_618a6b37d8225b6588c105b8
import layer_618a6b37d8225b6588c105bc as layer_618a6b37d8225b6588c105bc
import layer_618a6b37d8225b6588c105c0 as layer_618a6b37d8225b6588c105c0
import layer_618a6b37d8225b6588c1058c as layer_618a6b37d8225b6588c1058c
import layer_618a6b37d8225b6588c10594 as layer_618a6b37d8225b6588c10594
import layer_618a6b37d8225b6588c1059a as layer_618a6b37d8225b6588c1059a
import layer_618a6b37d8225b6588c1059e as layer_618a6b37d8225b6588c1059e
import layer_618a6b37d8225b6588c105a4 as layer_618a6b37d8225b6588c105a4
import layer_618a6b37d8225b6588c105aa as layer_618a6b37d8225b6588c105aa
import layer_618a6b37d8225b6588c105ae as layer_618a6b37d8225b6588c105ae
import layer_618a6b37d8225b6588c105be as layer_618a6b37d8225b6588c105be
import layer_618a6b37d8225b6588c1059c as layer_618a6b37d8225b6588c1059c
import layer_618a6b37d8225b6588c105ac as layer_618a6b37d8225b6588c105ac
import layer_618a6b37d8225b6588c105b2 as layer_618a6b37d8225b6588c105b2
import layer_618a6b37d8225b6588c105b6 as layer_618a6b37d8225b6588c105b6
import layer_618a6b37d8225b6588c105b4 as layer_618a6b37d8225b6588c105b4
import layer_618a6b37d8225b6588c105c7 as layer_618a6b37d8225b6588c105c7
import layer_618a6b37d8225b6588c105d3 as layer_618a6b37d8225b6588c105d3
import layer_618a6b37d8225b6588c105d7 as layer_618a6b37d8225b6588c105d7
import layer_618a6b37d8225b6588c105d9 as layer_618a6b37d8225b6588c105d9
import layer_618a6b37d8225b6588c105db as layer_618a6b37d8225b6588c105db
import layer_618a6b37d8225b6588c105df as layer_618a6b37d8225b6588c105df
import layer_618a6b37d8225b6588c105e1 as layer_618a6b37d8225b6588c105e1
import layer_618a6b37d8225b6588c105e3 as layer_618a6b37d8225b6588c105e3
import layer_618a6b37d8225b6588c105e7 as layer_618a6b37d8225b6588c105e7
import layer_618a6b37d8225b6588c105e9 as layer_618a6b37d8225b6588c105e9
import layer_618a6b37d8225b6588c105eb as layer_618a6b37d8225b6588c105eb
import layer_618a6b37d8225b6588c105ed as layer_618a6b37d8225b6588c105ed
import layer_618a6b37d8225b6588c105cd as layer_618a6b37d8225b6588c105cd
import layer_618a6b37d8225b6588c105cf as layer_618a6b37d8225b6588c105cf
import layer_618a6b37d8225b6588c105d1 as layer_618a6b37d8225b6588c105d1
import layer_618a6b37d8225b6588c105f1 as layer_618a6b37d8225b6588c105f1
import layer_618a6b37d8225b6588c10625 as layer_618a6b37d8225b6588c10625
import layer_618a6b37d8225b6588c105f7 as layer_618a6b37d8225b6588c105f7
import layer_618a6b37d8225b6588c105fb as layer_618a6b37d8225b6588c105fb
import layer_618a6b37d8225b6588c105ff as layer_618a6b37d8225b6588c105ff
import layer_618a6b37d8225b6588c10603 as layer_618a6b37d8225b6588c10603
import layer_618a6b37d8225b6588c10615 as layer_618a6b37d8225b6588c10615
import layer_618a6b37d8225b6588c10619 as layer_618a6b37d8225b6588c10619
import layer_618a6b37d8225b6588c1061b as layer_618a6b37d8225b6588c1061b
import layer_618a6b37d8225b6588c1061f as layer_618a6b37d8225b6588c1061f
import layer_618a6b37d8225b6588c10623 as layer_618a6b37d8225b6588c10623
import layer_618a6b37d8225b6588c105f9 as layer_618a6b37d8225b6588c105f9
import layer_618a6b37d8225b6588c10601 as layer_618a6b37d8225b6588c10601
import layer_618a6b37d8225b6588c10607 as layer_618a6b37d8225b6588c10607
import layer_618a6b37d8225b6588c1060b as layer_618a6b37d8225b6588c1060b
import layer_618a6b37d8225b6588c10617 as layer_618a6b37d8225b6588c10617
import layer_618a6b37d8225b6588c10621 as layer_618a6b37d8225b6588c10621
import layer_618a6b37d8225b6588c1062e as layer_618a6b37d8225b6588c1062e
import layer_618a6b37d8225b6588c10632 as layer_618a6b37d8225b6588c10632
import layer_618a6b37d8225b6588c10609 as layer_618a6b37d8225b6588c10609
import layer_618a6b37d8225b6588c1060d as layer_618a6b37d8225b6588c1060d
import layer_618a6b37d8225b6588c1060f as layer_618a6b37d8225b6588c1060f
import layer_618a6b37d8225b6588c10611 as layer_618a6b37d8225b6588c10611
import layer_618a6b37d8225b6588c10630 as layer_618a6b37d8225b6588c10630
import layer_618a6b37d8225b6588c10634 as layer_618a6b37d8225b6588c10634
import layer_618a6b37d8225b6588c10636 as layer_618a6b37d8225b6588c10636
import layer_618a6b37d8225b6588c10638 as layer_618a6b37d8225b6588c10638
import layer_618a6b37d8225b6588c1063c as layer_618a6b37d8225b6588c1063c
import layer_618a6b37d8225b6588c10640 as layer_618a6b37d8225b6588c10640
import layer_618a6b37d8225b6588c1063e as layer_618a6b37d8225b6588c1063e
import layer_618a6b37d8225b6588c10642 as layer_618a6b37d8225b6588c10642
import layer_618a6b37d8225b6588c10644 as layer_618a6b37d8225b6588c10644
import layer_618a6b37d8225b6588c10646 as layer_618a6b37d8225b6588c10646
import layer_618a6b37d8225b6588c1062a as layer_618a6b37d8225b6588c1062a
import layer_618a6b37d8225b6588c1067a as layer_618a6b37d8225b6588c1067a
import layer_618a6b37d8225b6588c1064c as layer_618a6b37d8225b6588c1064c
import layer_618a6b37d8225b6588c10650 as layer_618a6b37d8225b6588c10650
import layer_618a6b37d8225b6588c10654 as layer_618a6b37d8225b6588c10654
import layer_618a6b37d8225b6588c10658 as layer_618a6b37d8225b6588c10658
import layer_618a6b37d8225b6588c1066a as layer_618a6b37d8225b6588c1066a
import layer_618a6b37d8225b6588c1066e as layer_618a6b37d8225b6588c1066e
import layer_618a6b37d8225b6588c10670 as layer_618a6b37d8225b6588c10670
import layer_618a6b37d8225b6588c10674 as layer_618a6b37d8225b6588c10674
import layer_618a6b37d8225b6588c10678 as layer_618a6b37d8225b6588c10678
import layer_618a6b37d8225b6588c1064e as layer_618a6b37d8225b6588c1064e
import layer_618a6b37d8225b6588c10656 as layer_618a6b37d8225b6588c10656
import layer_618a6b37d8225b6588c1065c as layer_618a6b37d8225b6588c1065c
import layer_618a6b37d8225b6588c10660 as layer_618a6b37d8225b6588c10660
import layer_618a6b37d8225b6588c1066c as layer_618a6b37d8225b6588c1066c
import layer_618a6b37d8225b6588c10676 as layer_618a6b37d8225b6588c10676
import layer_618a6b37d8225b6588c10683 as layer_618a6b37d8225b6588c10683
import layer_618a6b37d8225b6588c10687 as layer_618a6b37d8225b6588c10687
import layer_618a6b37d8225b6588c1065e as layer_618a6b37d8225b6588c1065e
import layer_618a6b37d8225b6588c10662 as layer_618a6b37d8225b6588c10662
import layer_618a6b37d8225b6588c10664 as layer_618a6b37d8225b6588c10664
import layer_618a6b37d8225b6588c10666 as layer_618a6b37d8225b6588c10666
import layer_618a6b37d8225b6588c10685 as layer_618a6b37d8225b6588c10685
import layer_618a6b37d8225b6588c10689 as layer_618a6b37d8225b6588c10689
import layer_618a6b37d8225b6588c1068b as layer_618a6b37d8225b6588c1068b
import layer_618a6b37d8225b6588c1068d as layer_618a6b37d8225b6588c1068d
import layer_618a6b37d8225b6588c10691 as layer_618a6b37d8225b6588c10691
import layer_618a6b37d8225b6588c10695 as layer_618a6b37d8225b6588c10695
import layer_618a6b37d8225b6588c10693 as layer_618a6b37d8225b6588c10693
import layer_618a6b37d8225b6588c10697 as layer_618a6b37d8225b6588c10697
import layer_618a6b37d8225b6588c10699 as layer_618a6b37d8225b6588c10699
import layer_618a6b37d8225b6588c1069b as layer_618a6b37d8225b6588c1069b
import layer_618a6b37d8225b6588c1067f as layer_618a6b37d8225b6588c1067f
import layer_618a6b37d8225b6588c10724 as layer_618a6b37d8225b6588c10724
import layer_618a6b37d8225b6588c106f6 as layer_618a6b37d8225b6588c106f6
import layer_618a6b37d8225b6588c106fa as layer_618a6b37d8225b6588c106fa
import layer_618a6b37d8225b6588c106fe as layer_618a6b37d8225b6588c106fe
import layer_618a6b37d8225b6588c10702 as layer_618a6b37d8225b6588c10702
import layer_618a6b37d8225b6588c10714 as layer_618a6b37d8225b6588c10714
import layer_618a6b37d8225b6588c10718 as layer_618a6b37d8225b6588c10718
import layer_618a6b37d8225b6588c1071a as layer_618a6b37d8225b6588c1071a
import layer_618a6b37d8225b6588c1071e as layer_618a6b37d8225b6588c1071e
import layer_618a6b37d8225b6588c10722 as layer_618a6b37d8225b6588c10722
import layer_618a6b37d8225b6588c106f8 as layer_618a6b37d8225b6588c106f8
import layer_618a6b37d8225b6588c10700 as layer_618a6b37d8225b6588c10700
import layer_618a6b37d8225b6588c10706 as layer_618a6b37d8225b6588c10706
import layer_618a6b37d8225b6588c1070a as layer_618a6b37d8225b6588c1070a
import layer_618a6b37d8225b6588c10716 as layer_618a6b37d8225b6588c10716
import layer_618a6b37d8225b6588c10720 as layer_618a6b37d8225b6588c10720
import layer_618a6b37d8225b6588c1072d as layer_618a6b37d8225b6588c1072d
import layer_618a6b37d8225b6588c10731 as layer_618a6b37d8225b6588c10731
import layer_618a6b37d8225b6588c10708 as layer_618a6b37d8225b6588c10708
import layer_618a6b37d8225b6588c1070c as layer_618a6b37d8225b6588c1070c
import layer_618a6b37d8225b6588c1070e as layer_618a6b37d8225b6588c1070e
import layer_618a6b37d8225b6588c10710 as layer_618a6b37d8225b6588c10710
import layer_618a6b37d8225b6588c1072f as layer_618a6b37d8225b6588c1072f
import layer_618a6b37d8225b6588c10733 as layer_618a6b37d8225b6588c10733
import layer_618a6b37d8225b6588c10735 as layer_618a6b37d8225b6588c10735
import layer_618a6b37d8225b6588c10737 as layer_618a6b37d8225b6588c10737
import layer_618a6b37d8225b6588c1073b as layer_618a6b37d8225b6588c1073b
import layer_618a6b37d8225b6588c1073f as layer_618a6b37d8225b6588c1073f
import layer_618a6b37d8225b6588c1073d as layer_618a6b37d8225b6588c1073d
import layer_618a6b37d8225b6588c10741 as layer_618a6b37d8225b6588c10741
import layer_618a6b37d8225b6588c10743 as layer_618a6b37d8225b6588c10743
import layer_618a6b37d8225b6588c10745 as layer_618a6b37d8225b6588c10745
import layer_618a6b37d8225b6588c10729 as layer_618a6b37d8225b6588c10729
import layer_618a6b37d8225b6588c106cf as layer_618a6b37d8225b6588c106cf
import layer_618a6b37d8225b6588c106a1 as layer_618a6b37d8225b6588c106a1
import layer_618a6b37d8225b6588c106a5 as layer_618a6b37d8225b6588c106a5
import layer_618a6b37d8225b6588c106a9 as layer_618a6b37d8225b6588c106a9
import layer_618a6b37d8225b6588c106ad as layer_618a6b37d8225b6588c106ad
import layer_618a6b37d8225b6588c106bf as layer_618a6b37d8225b6588c106bf
import layer_618a6b37d8225b6588c106c3 as layer_618a6b37d8225b6588c106c3
import layer_618a6b37d8225b6588c106c5 as layer_618a6b37d8225b6588c106c5
import layer_618a6b37d8225b6588c106c9 as layer_618a6b37d8225b6588c106c9
import layer_618a6b37d8225b6588c106cd as layer_618a6b37d8225b6588c106cd
import layer_618a6b37d8225b6588c106a3 as layer_618a6b37d8225b6588c106a3
import layer_618a6b37d8225b6588c106ab as layer_618a6b37d8225b6588c106ab
import layer_618a6b37d8225b6588c106b1 as layer_618a6b37d8225b6588c106b1
import layer_618a6b37d8225b6588c106b5 as layer_618a6b37d8225b6588c106b5
import layer_618a6b37d8225b6588c106c1 as layer_618a6b37d8225b6588c106c1
import layer_618a6b37d8225b6588c106cb as layer_618a6b37d8225b6588c106cb
import layer_618a6b37d8225b6588c106d8 as layer_618a6b37d8225b6588c106d8
import layer_618a6b37d8225b6588c106dc as layer_618a6b37d8225b6588c106dc
import layer_618a6b37d8225b6588c106b3 as layer_618a6b37d8225b6588c106b3
import layer_618a6b37d8225b6588c106b7 as layer_618a6b37d8225b6588c106b7
import layer_618a6b37d8225b6588c106b9 as layer_618a6b37d8225b6588c106b9
import layer_618a6b37d8225b6588c106bb as layer_618a6b37d8225b6588c106bb
import layer_618a6b37d8225b6588c106da as layer_618a6b37d8225b6588c106da
import layer_618a6b37d8225b6588c106de as layer_618a6b37d8225b6588c106de
import layer_618a6b37d8225b6588c106e0 as layer_618a6b37d8225b6588c106e0
import layer_618a6b37d8225b6588c106e2 as layer_618a6b37d8225b6588c106e2
import layer_618a6b37d8225b6588c106e6 as layer_618a6b37d8225b6588c106e6
import layer_618a6b37d8225b6588c106ea as layer_618a6b37d8225b6588c106ea
import layer_618a6b37d8225b6588c106e8 as layer_618a6b37d8225b6588c106e8
import layer_618a6b37d8225b6588c106ec as layer_618a6b37d8225b6588c106ec
import layer_618a6b37d8225b6588c106ee as layer_618a6b37d8225b6588c106ee
import layer_618a6b37d8225b6588c106f0 as layer_618a6b37d8225b6588c106f0
import layer_618a6b37d8225b6588c106d4 as layer_618a6b37d8225b6588c106d4
import layer_618a6b37d8225b6588c10751 as layer_618a6b37d8225b6588c10751
import layer_618a6b37d8225b6588c10755 as layer_618a6b37d8225b6588c10755
import layer_618a6b37d8225b6588c10757 as layer_618a6b37d8225b6588c10757
import layer_618a6b37d8225b6588c10759 as layer_618a6b37d8225b6588c10759
import layer_618a6b37d8225b6588c1075d as layer_618a6b37d8225b6588c1075d
import layer_618a6b37d8225b6588c1075f as layer_618a6b37d8225b6588c1075f
import layer_618a6b37d8225b6588c10761 as layer_618a6b37d8225b6588c10761
import layer_618a6b37d8225b6588c10763 as layer_618a6b37d8225b6588c10763
import layer_618a6b37d8225b6588c10765 as layer_618a6b37d8225b6588c10765
import layer_618a6b37d8225b6588c10767 as layer_618a6b37d8225b6588c10767
import layer_618a6b37d8225b6588c1076b as layer_618a6b37d8225b6588c1076b
import layer_618a6b37d8225b6588c1076d as layer_618a6b37d8225b6588c1076d
import layer_618a6b37d8225b6588c1076f as layer_618a6b37d8225b6588c1076f
import layer_618a6b37d8225b6588c10771 as layer_618a6b37d8225b6588c10771
import layer_618a6b37d8225b6588c1074b as layer_618a6b37d8225b6588c1074b
import layer_618a6b37d8225b6588c1074d as layer_618a6b37d8225b6588c1074d
import layer_618a6b37d8225b6588c1074f as layer_618a6b37d8225b6588c1074f
import layer_618a6b37d8225b6588c10779 as layer_618a6b37d8225b6588c10779
import layer_618a6b37d8225b6588c1077b as layer_618a6b37d8225b6588c1077b
import layer_618a6b37d8225b6588c1077d as layer_618a6b37d8225b6588c1077d
import layer_618a6b37d8225b6588c10775 as layer_618a6b37d8225b6588c10775
import layer_618a6b37d8225b6588c10789 as layer_618a6b37d8225b6588c10789
import layer_618a6b37d8225b6588c1078d as layer_618a6b37d8225b6588c1078d
import layer_618a6b37d8225b6588c1078f as layer_618a6b37d8225b6588c1078f
import layer_618a6b37d8225b6588c10791 as layer_618a6b37d8225b6588c10791
import layer_618a6b37d8225b6588c10795 as layer_618a6b37d8225b6588c10795
import layer_618a6b37d8225b6588c10797 as layer_618a6b37d8225b6588c10797
import layer_618a6b37d8225b6588c10799 as layer_618a6b37d8225b6588c10799
import layer_618a6b37d8225b6588c1079d as layer_618a6b37d8225b6588c1079d
import layer_618a6b37d8225b6588c1079f as layer_618a6b37d8225b6588c1079f
import layer_618a6b37d8225b6588c107a1 as layer_618a6b37d8225b6588c107a1
import layer_618a6b37d8225b6588c107a4 as layer_618a6b37d8225b6588c107a4
import layer_618a6b37d8225b6588c107a8 as layer_618a6b37d8225b6588c107a8
import layer_618a6b37d8225b6588c107aa as layer_618a6b37d8225b6588c107aa
import layer_618a6b37d8225b6588c107ac as layer_618a6b37d8225b6588c107ac
import layer_618a6b37d8225b6588c107b0 as layer_618a6b37d8225b6588c107b0
import layer_618a6b37d8225b6588c107b2 as layer_618a6b37d8225b6588c107b2
import layer_618a6b37d8225b6588c107b4 as layer_618a6b37d8225b6588c107b4
import layer_618a6b37d8225b6588c107b8 as layer_618a6b37d8225b6588c107b8
import layer_618a6b37d8225b6588c107ba as layer_618a6b37d8225b6588c107ba
import layer_618a6b37d8225b6588c107bc as layer_618a6b37d8225b6588c107bc
import layer_618a6b37d8225b6588c107c0 as layer_618a6b37d8225b6588c107c0
import layer_618a6b37d8225b6588c107c2 as layer_618a6b37d8225b6588c107c2
import layer_618a6b37d8225b6588c107c4 as layer_618a6b37d8225b6588c107c4
import layer_618a6b37d8225b6588c107c7 as layer_618a6b37d8225b6588c107c7
import layer_618a6b37d8225b6588c107c9 as layer_618a6b37d8225b6588c107c9
import layer_618a6b37d8225b6588c107cd as layer_618a6b37d8225b6588c107cd
import layer_618a6b37d8225b6588c107cf as layer_618a6b37d8225b6588c107cf
import layer_618a6b37d8225b6588c107d1 as layer_618a6b37d8225b6588c107d1
import layer_618a6b37d8225b6588c10783 as layer_618a6b37d8225b6588c10783
import layer_618a6b37d8225b6588c10785 as layer_618a6b37d8225b6588c10785
import layer_618a6b37d8225b6588c10787 as layer_618a6b37d8225b6588c10787
import layer_618a6b37d8225b6588c107d6 as layer_618a6b37d8225b6588c107d6
import layer_618a6b37d8225b6588c107e2 as layer_618a6b37d8225b6588c107e2
import layer_618a6b37d8225b6588c107e6 as layer_618a6b37d8225b6588c107e6
import layer_618a6b37d8225b6588c107e8 as layer_618a6b37d8225b6588c107e8
import layer_618a6b37d8225b6588c107ea as layer_618a6b37d8225b6588c107ea
import layer_618a6b37d8225b6588c107ee as layer_618a6b37d8225b6588c107ee
import layer_618a6b37d8225b6588c107f0 as layer_618a6b37d8225b6588c107f0
import layer_618a6b37d8225b6588c107f2 as layer_618a6b37d8225b6588c107f2
import layer_618a6b37d8225b6588c107f6 as layer_618a6b37d8225b6588c107f6
import layer_618a6b37d8225b6588c107f8 as layer_618a6b37d8225b6588c107f8
import layer_618a6b37d8225b6588c107fa as layer_618a6b37d8225b6588c107fa
import layer_618a6b37d8225b6588c107fd as layer_618a6b37d8225b6588c107fd
import layer_618a6b37d8225b6588c10801 as layer_618a6b37d8225b6588c10801
import layer_618a6b37d8225b6588c10803 as layer_618a6b37d8225b6588c10803
import layer_618a6b37d8225b6588c10805 as layer_618a6b37d8225b6588c10805
import layer_618a6b37d8225b6588c10809 as layer_618a6b37d8225b6588c10809
import layer_618a6b37d8225b6588c1080b as layer_618a6b37d8225b6588c1080b
import layer_618a6b37d8225b6588c1080d as layer_618a6b37d8225b6588c1080d
import layer_618a6b37d8225b6588c10811 as layer_618a6b37d8225b6588c10811
import layer_618a6b37d8225b6588c10813 as layer_618a6b37d8225b6588c10813
import layer_618a6b37d8225b6588c10815 as layer_618a6b37d8225b6588c10815
import layer_618a6b37d8225b6588c10819 as layer_618a6b37d8225b6588c10819
import layer_618a6b37d8225b6588c1081b as layer_618a6b37d8225b6588c1081b
import layer_618a6b37d8225b6588c1081d as layer_618a6b37d8225b6588c1081d
import layer_618a6b37d8225b6588c10820 as layer_618a6b37d8225b6588c10820
import layer_618a6b37d8225b6588c10822 as layer_618a6b37d8225b6588c10822
import layer_618a6b37d8225b6588c10826 as layer_618a6b37d8225b6588c10826
import layer_618a6b37d8225b6588c10828 as layer_618a6b37d8225b6588c10828
import layer_618a6b37d8225b6588c1082a as layer_618a6b37d8225b6588c1082a
import layer_618a6b37d8225b6588c107dc as layer_618a6b37d8225b6588c107dc
import layer_618a6b37d8225b6588c107de as layer_618a6b37d8225b6588c107de
import layer_618a6b37d8225b6588c107e0 as layer_618a6b37d8225b6588c107e0
import layer_618a6b37d8225b6588c1082f as layer_618a6b37d8225b6588c1082f
import layer_618a6b37d8225b6588c10831 as layer_618a6b37d8225b6588c10831
import layer_618a6b37d8225b6588c10835 as layer_618a6b37d8225b6588c10835
import layer_618a6b37d8225b6588c10833 as layer_618a6b37d8225b6588c10833


def get_layer_object(module):
    for member in getmembers(module):
        if member[1].__module__ == module.__name__:
            return member[1]

def get_loss_sum_fn(list_loss):
    def LossSum(y_true, y_pred):
        loss = 0
        for loss_fn in list_loss:
            loss += loss_fn(y_true, y_pred)
        return loss

    return LossSum

class Model(BaseModel):
    def __init__(self, *args, **kwargs):
        super(Model, self).__init__(*args, **kwargs)
        self.path_weight = file_path + "/weight.hdf5"
        inputs, outputs, losses, labels = self.build_source()
        self.compile(inputs, outputs, losses, labels)

    def build_source(self):
        config_loss = dict()
        volume = 64
        height = 64
        width = 64
        channels = 3
        num_class = 7
        output_channels = 1
        batch_size = 1

        n1_Image = layer_618a6b37d8225b6588c104e8.Image(shape=[64, 64, 3])
        n2_Backbone_n1_Conv2D = layer_618a6b37d8225b6588c104ec.Conv2D(filters=32, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n1_Image)
        n2_Backbone_n3_BatchNormalization = layer_618a6b37d8225b6588c104f0.BatchNormalization()(n2_Backbone_n1_Conv2D)
        n2_Backbone_n2_Activation = layer_618a6b37d8225b6588c104ee.Activation(activation='relu')(n2_Backbone_n3_BatchNormalization)
        n2_Backbone_n4_Conv2D = layer_618a6b37d8225b6588c104f2.Conv2D(filters=32, kernel_size=[3, 3], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n2_Activation)
        n2_Backbone_n5_BatchNormalization = layer_618a6b37d8225b6588c104f4.BatchNormalization()(n2_Backbone_n4_Conv2D)
        n2_Backbone_n6_Activation = layer_618a6b37d8225b6588c104f6.Activation(activation='relu')(n2_Backbone_n5_BatchNormalization)
        n2_Backbone_n7_Conv2D = layer_618a6b37d8225b6588c104f8.Conv2D(filters=64, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n6_Activation)
        n2_Backbone_n8_BatchNormalization = layer_618a6b37d8225b6588c104fa.BatchNormalization()(n2_Backbone_n7_Conv2D)
        n2_Backbone_n9_Activation = layer_618a6b37d8225b6588c104fc.Activation(activation='relu')(n2_Backbone_n8_BatchNormalization)
        n2_Backbone_n10_MaxPooling2D = layer_618a6b37d8225b6588c104fe.MaxPooling2D(pool_size=[2, 2], strides=[2, 2], padding='valid')(n2_Backbone_n9_Activation)
        n2_Backbone_n11_mixed_0_n9_Activation = layer_618a6b37d8225b6588c1053c.Activation(activation='linear')(n2_Backbone_n10_MaxPooling2D)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10504.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10508.BatchNormalization()(n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1050c.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10510.BatchNormalization()(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1051c.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10520.BatchNormalization()(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n7_AveragePooling2D = layer_618a6b37d8225b6588c10532.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10536.Conv2D(filters=32, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1053a.BatchNormalization()(n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10506.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1050e.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10514.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10518.BatchNormalization()(n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1051e.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10524.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10528.BatchNormalization()(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10538.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10516.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10526.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1052c.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10530.BatchNormalization()(n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1052e.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c10541.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n11_mixed_0_n10_Concatenate = layer_618a6b37d8225b6588c10541.Concatenate(axis=-1)([n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n11_mixed_0_n10_Concatenate = layer_618a6b37d8225b6588c10541.Concatenate(axis=-1)(*[n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n12_mixed_0_n9_Activation = layer_618a6b37d8225b6588c1057f.Activation(activation='linear')(n2_Backbone_n11_mixed_0_n10_Concatenate)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10547.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1054b.BatchNormalization()(n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1054f.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10553.BatchNormalization()(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1055f.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10563.BatchNormalization()(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n7_AveragePooling2D = layer_618a6b37d8225b6588c10575.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10579.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1057d.BatchNormalization()(n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10549.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10551.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10557.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1055b.BatchNormalization()(n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10561.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10567.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1056b.BatchNormalization()(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1057b.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10559.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10569.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1056f.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10573.BatchNormalization()(n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10571.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c10584.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n12_mixed_0_n10_Concatenate = layer_618a6b37d8225b6588c10584.Concatenate(axis=-1)([n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n12_mixed_0_n10_Concatenate = layer_618a6b37d8225b6588c10584.Concatenate(axis=-1)(*[n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n13_mixed_0_n9_Activation = layer_618a6b37d8225b6588c105c2.Activation(activation='linear')(n2_Backbone_n12_mixed_0_n10_Concatenate)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1058a.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1058e.BatchNormalization()(n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10592.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10596.BatchNormalization()(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105a2.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c105a6.BatchNormalization()(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n7_AveragePooling2D = layer_618a6b37d8225b6588c105b8.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105bc.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c105c0.BatchNormalization()(n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1058c.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10594.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1059a.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1059e.BatchNormalization()(n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c105a4.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105aa.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c105ae.BatchNormalization()(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c105be.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1059c.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c105ac.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105b2.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c105b6.BatchNormalization()(n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c105b4.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c105c7.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n13_mixed_0_n10_Concatenate = layer_618a6b37d8225b6588c105c7.Concatenate(axis=-1)([n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n13_mixed_0_n10_Concatenate = layer_618a6b37d8225b6588c105c7.Concatenate(axis=-1)(*[n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n14_mixed_3_n2_Activation = layer_618a6b37d8225b6588c105d3.Activation(activation='linear')(n2_Backbone_n13_mixed_0_n10_Concatenate)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105d7.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c105d9.BatchNormalization()(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c105db.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105df.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c105e1.BatchNormalization()(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c105e3.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105e7.Conv2D(filters=96, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n3_Activation)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c105e9.BatchNormalization()(n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c105eb.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n6_MaxPooling2D = layer_618a6b37d8225b6588c105ed.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='valid')(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105cd.Conv2D(filters=384, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c105cf.BatchNormalization()(n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c105d1.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c105f1.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n14_mixed_3_n7_Concatenate = layer_618a6b37d8225b6588c105f1.Concatenate(axis=-1)([n2_Backbone_n14_mixed_3_n6_MaxPooling2D, n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation, n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n14_mixed_3_n7_Concatenate = layer_618a6b37d8225b6588c105f1.Concatenate(axis=-1)(*[n2_Backbone_n14_mixed_3_n6_MaxPooling2D, n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation, n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n15_mixed_0_n7_Activation = layer_618a6b37d8225b6588c10625.Activation(activation='linear')(n2_Backbone_n14_mixed_3_n7_Concatenate)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105f7.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c105fb.BatchNormalization()(n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c105ff.Conv2D(filters=128, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10603.BatchNormalization()(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10615.Conv2D(filters=128, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10619.BatchNormalization()(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n5_AveragePooling2D = layer_618a6b37d8225b6588c1061b.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1061f.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10623.BatchNormalization()(n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c105f9.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10601.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10607.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1060b.BatchNormalization()(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10617.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10621.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1062e.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10632.BatchNormalization()(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10609.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c1060d.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c1060f.BatchNormalization()(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c10611.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10630.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c10634.Conv2D(filters=128, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c10636.BatchNormalization()(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c10638.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1063c.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10640.BatchNormalization()(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1063e.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c10642.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c10644.BatchNormalization()(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c10646.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c1062a.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n15_mixed_0_n8_Concatenate = layer_618a6b37d8225b6588c1062a.Concatenate(axis=-1)([n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n15_mixed_0_n8_Concatenate = layer_618a6b37d8225b6588c1062a.Concatenate(axis=-1)(*[n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n16_mixed_0_n7_Activation = layer_618a6b37d8225b6588c1067a.Activation(activation='linear')(n2_Backbone_n15_mixed_0_n8_Concatenate)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1064c.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10650.BatchNormalization()(n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10654.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10658.BatchNormalization()(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1066a.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1066e.BatchNormalization()(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n5_AveragePooling2D = layer_618a6b37d8225b6588c10670.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10674.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10678.BatchNormalization()(n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1064e.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10656.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1065c.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10660.BatchNormalization()(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1066c.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10676.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10683.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10687.BatchNormalization()(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1065e.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c10662.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c10664.BatchNormalization()(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c10666.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10685.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c10689.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c1068b.BatchNormalization()(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c1068d.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10691.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10695.BatchNormalization()(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10693.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c10697.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c10699.BatchNormalization()(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c1069b.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c1067f.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n16_mixed_0_n8_Concatenate = layer_618a6b37d8225b6588c1067f.Concatenate(axis=-1)([n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n16_mixed_0_n8_Concatenate = layer_618a6b37d8225b6588c1067f.Concatenate(axis=-1)(*[n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n18_mixed_0_n7_Activation = layer_618a6b37d8225b6588c10724.Activation(activation='linear')(n2_Backbone_n16_mixed_0_n8_Concatenate)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106f6.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c106fa.BatchNormalization()(n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106fe.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10702.BatchNormalization()(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10714.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10718.BatchNormalization()(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n5_AveragePooling2D = layer_618a6b37d8225b6588c1071a.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1071e.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10722.BatchNormalization()(n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c106f8.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10700.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10706.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1070a.BatchNormalization()(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10716.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10720.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1072d.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c10731.BatchNormalization()(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c10708.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c1070c.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c1070e.BatchNormalization()(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c10710.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1072f.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c10733.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c10735.BatchNormalization()(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c10737.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1073b.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c1073f.BatchNormalization()(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c1073d.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c10741.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c10743.BatchNormalization()(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c10745.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c10729.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n18_mixed_0_n8_Concatenate = layer_618a6b37d8225b6588c10729.Concatenate(axis=-1)([n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n18_mixed_0_n8_Concatenate = layer_618a6b37d8225b6588c10729.Concatenate(axis=-1)(*[n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n17_mixed_0_n7_Activation = layer_618a6b37d8225b6588c106cf.Activation(activation='linear')(n2_Backbone_n18_mixed_0_n8_Concatenate)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106a1.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c106a5.BatchNormalization()(n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106a9.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c106ad.BatchNormalization()(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106bf.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c106c3.BatchNormalization()(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n5_AveragePooling2D = layer_618a6b37d8225b6588c106c5.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106c9.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c106cd.BatchNormalization()(n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c106a3.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c106ab.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106b1.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c106b5.BatchNormalization()(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c106c1.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c106cb.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106d8.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c106dc.BatchNormalization()(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c106b3.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c106b7.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c106b9.BatchNormalization()(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c106bb.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c106da.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c106de.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c106e0.BatchNormalization()(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c106e2.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c106e6.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618a6b37d8225b6588c106ea.BatchNormalization()(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618a6b37d8225b6588c106e8.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c106ec.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c106ee.BatchNormalization()(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c106f0.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c106d4.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n17_mixed_0_n8_Concatenate = layer_618a6b37d8225b6588c106d4.Concatenate(axis=-1)([n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n17_mixed_0_n8_Concatenate = layer_618a6b37d8225b6588c106d4.Concatenate(axis=-1)(*[n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n19_mixed_3_n2_Activation = layer_618a6b37d8225b6588c10751.Activation(activation='linear')(n2_Backbone_n17_mixed_0_n8_Concatenate)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10755.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c10757.BatchNormalization()(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c10759.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1075d.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c1075f.BatchNormalization()(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c10761.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n4_Conv2D = layer_618a6b37d8225b6588c10763.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n5_BatchNormalization = layer_618a6b37d8225b6588c10765.BatchNormalization()(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n6_Activation = layer_618a6b37d8225b6588c10767.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1076b.Conv2D(filters=192, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n6_Activation)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c1076d.BatchNormalization()(n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c1076f.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n6_MaxPooling2D = layer_618a6b37d8225b6588c10771.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='valid')(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1074b.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c1074d.BatchNormalization()(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c1074f.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10779.Conv2D(filters=320, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c1077b.BatchNormalization()(n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c1077d.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c10775.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n19_mixed_3_n7_Concatenate = layer_618a6b37d8225b6588c10775.Concatenate(axis=-1)([n2_Backbone_n19_mixed_3_n6_MaxPooling2D, n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation, n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n19_mixed_3_n7_Concatenate = layer_618a6b37d8225b6588c10775.Concatenate(axis=-1)(*[n2_Backbone_n19_mixed_3_n6_MaxPooling2D, n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation, n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n2_Activation = layer_618a6b37d8225b6588c10789.Activation(activation='linear')(n2_Backbone_n19_mixed_3_n7_Concatenate)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1078d.Conv2D(filters=384, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c1078f.BatchNormalization()(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c10791.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10795.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c10797.BatchNormalization()(n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c10799.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c1079d.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c1079f.BatchNormalization()(n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107a1.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c107a4.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n6_Concatenate = layer_618a6b37d8225b6588c107a4.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n6_Concatenate = layer_618a6b37d8225b6588c107a4.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107a8.Conv2D(filters=448, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107aa.BatchNormalization()(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107ac.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107b0.Conv2D(filters=384, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107b2.BatchNormalization()(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107b4.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107b8.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107ba.BatchNormalization()(n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107bc.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107c0.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107c2.BatchNormalization()(n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107c4.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c107c7.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n11_Concatenate = layer_618a6b37d8225b6588c107c7.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n11_Concatenate = layer_618a6b37d8225b6588c107c7.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n12_AveragePooling2D = layer_618a6b37d8225b6588c107c9.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107cd.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n12_AveragePooling2D)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107cf.BatchNormalization()(n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107d1.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10783.Conv2D(filters=320, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c10785.BatchNormalization()(n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c10787.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c107d6.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n14_Concatenate = layer_618a6b37d8225b6588c107d6.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n6_Concatenate, n2_Backbone_n20_mixed_9_n11_Concatenate, n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n14_Concatenate = layer_618a6b37d8225b6588c107d6.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n6_Concatenate, n2_Backbone_n20_mixed_9_n11_Concatenate, n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n2_Activation = layer_618a6b37d8225b6588c107e2.Activation(activation='linear')(n2_Backbone_n20_mixed_9_n14_Concatenate)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107e6.Conv2D(filters=384, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107e8.BatchNormalization()(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107ea.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107ee.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107f0.BatchNormalization()(n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107f2.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107f6.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107f8.BatchNormalization()(n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107fa.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c107fd.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n6_Concatenate = layer_618a6b37d8225b6588c107fd.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n6_Concatenate = layer_618a6b37d8225b6588c107fd.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10801.Conv2D(filters=448, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c10803.BatchNormalization()(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c10805.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10809.Conv2D(filters=384, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c1080b.BatchNormalization()(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c1080d.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10811.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c10813.BatchNormalization()(n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c10815.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10819.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c1081b.BatchNormalization()(n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c1081d.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c10820.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n11_Concatenate = layer_618a6b37d8225b6588c10820.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n11_Concatenate = layer_618a6b37d8225b6588c10820.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n12_AveragePooling2D = layer_618a6b37d8225b6588c10822.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c10826.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n12_AveragePooling2D)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c10828.BatchNormalization()(n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c1082a.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n1_Conv2D = layer_618a6b37d8225b6588c107dc.Conv2D(filters=320, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n2_BatchNormalization = layer_618a6b37d8225b6588c107de.BatchNormalization()(n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation = layer_618a6b37d8225b6588c107e0.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a6b37d8225b6588c1082f.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n14_Concatenate = layer_618a6b37d8225b6588c1082f.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n6_Concatenate, n2_Backbone_n21_mixed_9_n11_Concatenate, n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n14_Concatenate = layer_618a6b37d8225b6588c1082f.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n6_Concatenate, n2_Backbone_n21_mixed_9_n11_Concatenate, n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation])
        n3_GlobalAveragePooling2D = layer_618a6b37d8225b6588c10831.GlobalAveragePooling2D()(n2_Backbone_n21_mixed_9_n14_Concatenate)
        n9_Dropout = layer_618a6b37d8225b6588c10835.Dropout(rate=0.5)(n3_GlobalAveragePooling2D)
        n4_Dense = layer_618a6b37d8225b6588c10833.Dense(units=7, activation='softmax', use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n9_Dropout)
        label = keras.layers.Input(shape=[7])
        loss = keras.losses.CategoricalCrossentropy()(label, n4_Dense)
        



        for key in list(config_loss.keys()):
            if len(config_loss[key]) == 1:
                config_loss[key] = config_loss[key][0]
            elif len(config_loss[key]) > 1:
                config_loss[key] = get_loss_sum_fn(config_loss[key])
            else:
                del config_loss[key]
        inputs = [n1_Image]
        outputs = [n4_Dense]
        losses = [loss]
        labels = [label]

        return inputs, outputs, losses, labels

