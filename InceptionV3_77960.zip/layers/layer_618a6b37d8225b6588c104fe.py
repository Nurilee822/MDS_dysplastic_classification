from tensorflow.keras.layers import *


class MaxPooling2D(MaxPooling2D):
    pass