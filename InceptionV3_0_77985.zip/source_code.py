import sys
from tensorflow import keras
import tensorflow.keras.backend as K
import inspect
import os

file_path = os.path.dirname(os.path.realpath(__file__))
sys.path.append(f"{file_path}/layers")
sys.path.append(f"{file_path}/utils")


from base_model import BaseModel
from inspect import getmembers, isfunction

import tensorflow as tf
import layer_618a8756d8225b6588c1405e as layer_618a8756d8225b6588c1405e
import layer_618a8756d8225b6588c14062 as layer_618a8756d8225b6588c14062
import layer_618a8756d8225b6588c14066 as layer_618a8756d8225b6588c14066
import layer_618a8756d8225b6588c14064 as layer_618a8756d8225b6588c14064
import layer_618a8756d8225b6588c14068 as layer_618a8756d8225b6588c14068
import layer_618a8756d8225b6588c1406a as layer_618a8756d8225b6588c1406a
import layer_618a8756d8225b6588c1406c as layer_618a8756d8225b6588c1406c
import layer_618a8756d8225b6588c1406e as layer_618a8756d8225b6588c1406e
import layer_618a8756d8225b6588c14070 as layer_618a8756d8225b6588c14070
import layer_618a8756d8225b6588c14072 as layer_618a8756d8225b6588c14072
import layer_618a8756d8225b6588c14074 as layer_618a8756d8225b6588c14074
import layer_618a8756d8225b6588c140b2 as layer_618a8756d8225b6588c140b2
import layer_618a8756d8225b6588c1407a as layer_618a8756d8225b6588c1407a
import layer_618a8756d8225b6588c1407e as layer_618a8756d8225b6588c1407e
import layer_618a8756d8225b6588c14082 as layer_618a8756d8225b6588c14082
import layer_618a8756d8225b6588c14086 as layer_618a8756d8225b6588c14086
import layer_618a8756d8225b6588c14092 as layer_618a8756d8225b6588c14092
import layer_618a8756d8225b6588c14096 as layer_618a8756d8225b6588c14096
import layer_618a8756d8225b6588c140a8 as layer_618a8756d8225b6588c140a8
import layer_618a8756d8225b6588c140ac as layer_618a8756d8225b6588c140ac
import layer_618a8756d8225b6588c140b0 as layer_618a8756d8225b6588c140b0
import layer_618a8756d8225b6588c1407c as layer_618a8756d8225b6588c1407c
import layer_618a8756d8225b6588c14084 as layer_618a8756d8225b6588c14084
import layer_618a8756d8225b6588c1408a as layer_618a8756d8225b6588c1408a
import layer_618a8756d8225b6588c1408e as layer_618a8756d8225b6588c1408e
import layer_618a8756d8225b6588c14094 as layer_618a8756d8225b6588c14094
import layer_618a8756d8225b6588c1409a as layer_618a8756d8225b6588c1409a
import layer_618a8756d8225b6588c1409e as layer_618a8756d8225b6588c1409e
import layer_618a8756d8225b6588c140ae as layer_618a8756d8225b6588c140ae
import layer_618a8756d8225b6588c1408c as layer_618a8756d8225b6588c1408c
import layer_618a8756d8225b6588c1409c as layer_618a8756d8225b6588c1409c
import layer_618a8756d8225b6588c140a2 as layer_618a8756d8225b6588c140a2
import layer_618a8756d8225b6588c140a6 as layer_618a8756d8225b6588c140a6
import layer_618a8756d8225b6588c140a4 as layer_618a8756d8225b6588c140a4
import layer_618a8756d8225b6588c140b7 as layer_618a8756d8225b6588c140b7
import layer_618a8756d8225b6588c140f5 as layer_618a8756d8225b6588c140f5
import layer_618a8756d8225b6588c140bd as layer_618a8756d8225b6588c140bd
import layer_618a8756d8225b6588c140c1 as layer_618a8756d8225b6588c140c1
import layer_618a8756d8225b6588c140c5 as layer_618a8756d8225b6588c140c5
import layer_618a8756d8225b6588c140c9 as layer_618a8756d8225b6588c140c9
import layer_618a8756d8225b6588c140d5 as layer_618a8756d8225b6588c140d5
import layer_618a8756d8225b6588c140d9 as layer_618a8756d8225b6588c140d9
import layer_618a8756d8225b6588c140eb as layer_618a8756d8225b6588c140eb
import layer_618a8756d8225b6588c140ef as layer_618a8756d8225b6588c140ef
import layer_618a8756d8225b6588c140f3 as layer_618a8756d8225b6588c140f3
import layer_618a8756d8225b6588c140bf as layer_618a8756d8225b6588c140bf
import layer_618a8756d8225b6588c140c7 as layer_618a8756d8225b6588c140c7
import layer_618a8756d8225b6588c140cd as layer_618a8756d8225b6588c140cd
import layer_618a8756d8225b6588c140d1 as layer_618a8756d8225b6588c140d1
import layer_618a8756d8225b6588c140d7 as layer_618a8756d8225b6588c140d7
import layer_618a8756d8225b6588c140dd as layer_618a8756d8225b6588c140dd
import layer_618a8756d8225b6588c140e1 as layer_618a8756d8225b6588c140e1
import layer_618a8756d8225b6588c140f1 as layer_618a8756d8225b6588c140f1
import layer_618a8756d8225b6588c140cf as layer_618a8756d8225b6588c140cf
import layer_618a8756d8225b6588c140df as layer_618a8756d8225b6588c140df
import layer_618a8756d8225b6588c140e5 as layer_618a8756d8225b6588c140e5
import layer_618a8756d8225b6588c140e9 as layer_618a8756d8225b6588c140e9
import layer_618a8756d8225b6588c140e7 as layer_618a8756d8225b6588c140e7
import layer_618a8756d8225b6588c140fa as layer_618a8756d8225b6588c140fa
import layer_618a8756d8225b6588c14138 as layer_618a8756d8225b6588c14138
import layer_618a8756d8225b6588c14100 as layer_618a8756d8225b6588c14100
import layer_618a8756d8225b6588c14104 as layer_618a8756d8225b6588c14104
import layer_618a8756d8225b6588c14108 as layer_618a8756d8225b6588c14108
import layer_618a8756d8225b6588c1410c as layer_618a8756d8225b6588c1410c
import layer_618a8756d8225b6588c14118 as layer_618a8756d8225b6588c14118
import layer_618a8756d8225b6588c1411c as layer_618a8756d8225b6588c1411c
import layer_618a8756d8225b6588c1412e as layer_618a8756d8225b6588c1412e
import layer_618a8756d8225b6588c14132 as layer_618a8756d8225b6588c14132
import layer_618a8756d8225b6588c14136 as layer_618a8756d8225b6588c14136
import layer_618a8756d8225b6588c14102 as layer_618a8756d8225b6588c14102
import layer_618a8756d8225b6588c1410a as layer_618a8756d8225b6588c1410a
import layer_618a8756d8225b6588c14110 as layer_618a8756d8225b6588c14110
import layer_618a8756d8225b6588c14114 as layer_618a8756d8225b6588c14114
import layer_618a8756d8225b6588c1411a as layer_618a8756d8225b6588c1411a
import layer_618a8756d8225b6588c14120 as layer_618a8756d8225b6588c14120
import layer_618a8756d8225b6588c14124 as layer_618a8756d8225b6588c14124
import layer_618a8756d8225b6588c14134 as layer_618a8756d8225b6588c14134
import layer_618a8756d8225b6588c14112 as layer_618a8756d8225b6588c14112
import layer_618a8756d8225b6588c14122 as layer_618a8756d8225b6588c14122
import layer_618a8756d8225b6588c14128 as layer_618a8756d8225b6588c14128
import layer_618a8756d8225b6588c1412c as layer_618a8756d8225b6588c1412c
import layer_618a8756d8225b6588c1412a as layer_618a8756d8225b6588c1412a
import layer_618a8756d8225b6588c1413d as layer_618a8756d8225b6588c1413d
import layer_618a8756d8225b6588c14149 as layer_618a8756d8225b6588c14149
import layer_618a8756d8225b6588c1414d as layer_618a8756d8225b6588c1414d
import layer_618a8756d8225b6588c1414f as layer_618a8756d8225b6588c1414f
import layer_618a8756d8225b6588c14151 as layer_618a8756d8225b6588c14151
import layer_618a8756d8225b6588c14155 as layer_618a8756d8225b6588c14155
import layer_618a8756d8225b6588c14157 as layer_618a8756d8225b6588c14157
import layer_618a8756d8225b6588c14159 as layer_618a8756d8225b6588c14159
import layer_618a8756d8225b6588c1415d as layer_618a8756d8225b6588c1415d
import layer_618a8756d8225b6588c1415f as layer_618a8756d8225b6588c1415f
import layer_618a8756d8225b6588c14161 as layer_618a8756d8225b6588c14161
import layer_618a8756d8225b6588c14163 as layer_618a8756d8225b6588c14163
import layer_618a8756d8225b6588c14143 as layer_618a8756d8225b6588c14143
import layer_618a8756d8225b6588c14145 as layer_618a8756d8225b6588c14145
import layer_618a8756d8225b6588c14147 as layer_618a8756d8225b6588c14147
import layer_618a8756d8225b6588c14167 as layer_618a8756d8225b6588c14167
import layer_618a8756d8225b6588c1419b as layer_618a8756d8225b6588c1419b
import layer_618a8756d8225b6588c1416d as layer_618a8756d8225b6588c1416d
import layer_618a8756d8225b6588c14171 as layer_618a8756d8225b6588c14171
import layer_618a8756d8225b6588c14175 as layer_618a8756d8225b6588c14175
import layer_618a8756d8225b6588c14179 as layer_618a8756d8225b6588c14179
import layer_618a8756d8225b6588c1418b as layer_618a8756d8225b6588c1418b
import layer_618a8756d8225b6588c1418f as layer_618a8756d8225b6588c1418f
import layer_618a8756d8225b6588c14191 as layer_618a8756d8225b6588c14191
import layer_618a8756d8225b6588c14195 as layer_618a8756d8225b6588c14195
import layer_618a8756d8225b6588c14199 as layer_618a8756d8225b6588c14199
import layer_618a8756d8225b6588c1416f as layer_618a8756d8225b6588c1416f
import layer_618a8756d8225b6588c14177 as layer_618a8756d8225b6588c14177
import layer_618a8756d8225b6588c1417d as layer_618a8756d8225b6588c1417d
import layer_618a8756d8225b6588c14181 as layer_618a8756d8225b6588c14181
import layer_618a8756d8225b6588c1418d as layer_618a8756d8225b6588c1418d
import layer_618a8756d8225b6588c14197 as layer_618a8756d8225b6588c14197
import layer_618a8756d8225b6588c141a4 as layer_618a8756d8225b6588c141a4
import layer_618a8756d8225b6588c141a8 as layer_618a8756d8225b6588c141a8
import layer_618a8756d8225b6588c1417f as layer_618a8756d8225b6588c1417f
import layer_618a8756d8225b6588c14183 as layer_618a8756d8225b6588c14183
import layer_618a8756d8225b6588c14185 as layer_618a8756d8225b6588c14185
import layer_618a8756d8225b6588c14187 as layer_618a8756d8225b6588c14187
import layer_618a8756d8225b6588c141a6 as layer_618a8756d8225b6588c141a6
import layer_618a8756d8225b6588c141aa as layer_618a8756d8225b6588c141aa
import layer_618a8756d8225b6588c141ac as layer_618a8756d8225b6588c141ac
import layer_618a8756d8225b6588c141ae as layer_618a8756d8225b6588c141ae
import layer_618a8756d8225b6588c141b2 as layer_618a8756d8225b6588c141b2
import layer_618a8756d8225b6588c141b6 as layer_618a8756d8225b6588c141b6
import layer_618a8756d8225b6588c141b4 as layer_618a8756d8225b6588c141b4
import layer_618a8756d8225b6588c141b8 as layer_618a8756d8225b6588c141b8
import layer_618a8756d8225b6588c141ba as layer_618a8756d8225b6588c141ba
import layer_618a8756d8225b6588c141bc as layer_618a8756d8225b6588c141bc
import layer_618a8756d8225b6588c141a0 as layer_618a8756d8225b6588c141a0
import layer_618a8756d8225b6588c141f0 as layer_618a8756d8225b6588c141f0
import layer_618a8756d8225b6588c141c2 as layer_618a8756d8225b6588c141c2
import layer_618a8756d8225b6588c141c6 as layer_618a8756d8225b6588c141c6
import layer_618a8756d8225b6588c141ca as layer_618a8756d8225b6588c141ca
import layer_618a8756d8225b6588c141ce as layer_618a8756d8225b6588c141ce
import layer_618a8756d8225b6588c141e0 as layer_618a8756d8225b6588c141e0
import layer_618a8756d8225b6588c141e4 as layer_618a8756d8225b6588c141e4
import layer_618a8756d8225b6588c141e6 as layer_618a8756d8225b6588c141e6
import layer_618a8756d8225b6588c141ea as layer_618a8756d8225b6588c141ea
import layer_618a8756d8225b6588c141ee as layer_618a8756d8225b6588c141ee
import layer_618a8756d8225b6588c141c4 as layer_618a8756d8225b6588c141c4
import layer_618a8756d8225b6588c141cc as layer_618a8756d8225b6588c141cc
import layer_618a8756d8225b6588c141d2 as layer_618a8756d8225b6588c141d2
import layer_618a8756d8225b6588c141d6 as layer_618a8756d8225b6588c141d6
import layer_618a8756d8225b6588c141e2 as layer_618a8756d8225b6588c141e2
import layer_618a8756d8225b6588c141ec as layer_618a8756d8225b6588c141ec
import layer_618a8756d8225b6588c141f9 as layer_618a8756d8225b6588c141f9
import layer_618a8756d8225b6588c141fd as layer_618a8756d8225b6588c141fd
import layer_618a8756d8225b6588c141d4 as layer_618a8756d8225b6588c141d4
import layer_618a8756d8225b6588c141d8 as layer_618a8756d8225b6588c141d8
import layer_618a8756d8225b6588c141da as layer_618a8756d8225b6588c141da
import layer_618a8756d8225b6588c141dc as layer_618a8756d8225b6588c141dc
import layer_618a8756d8225b6588c141fb as layer_618a8756d8225b6588c141fb
import layer_618a8756d8225b6588c141ff as layer_618a8756d8225b6588c141ff
import layer_618a8756d8225b6588c14201 as layer_618a8756d8225b6588c14201
import layer_618a8756d8225b6588c14203 as layer_618a8756d8225b6588c14203
import layer_618a8756d8225b6588c14207 as layer_618a8756d8225b6588c14207
import layer_618a8756d8225b6588c1420b as layer_618a8756d8225b6588c1420b
import layer_618a8756d8225b6588c14209 as layer_618a8756d8225b6588c14209
import layer_618a8756d8225b6588c1420d as layer_618a8756d8225b6588c1420d
import layer_618a8756d8225b6588c1420f as layer_618a8756d8225b6588c1420f
import layer_618a8756d8225b6588c14211 as layer_618a8756d8225b6588c14211
import layer_618a8756d8225b6588c141f5 as layer_618a8756d8225b6588c141f5
import layer_618a8756d8225b6588c1429a as layer_618a8756d8225b6588c1429a
import layer_618a8756d8225b6588c1426c as layer_618a8756d8225b6588c1426c
import layer_618a8756d8225b6588c14270 as layer_618a8756d8225b6588c14270
import layer_618a8756d8225b6588c14274 as layer_618a8756d8225b6588c14274
import layer_618a8756d8225b6588c14278 as layer_618a8756d8225b6588c14278
import layer_618a8756d8225b6588c1428a as layer_618a8756d8225b6588c1428a
import layer_618a8756d8225b6588c1428e as layer_618a8756d8225b6588c1428e
import layer_618a8756d8225b6588c14290 as layer_618a8756d8225b6588c14290
import layer_618a8756d8225b6588c14294 as layer_618a8756d8225b6588c14294
import layer_618a8756d8225b6588c14298 as layer_618a8756d8225b6588c14298
import layer_618a8756d8225b6588c1426e as layer_618a8756d8225b6588c1426e
import layer_618a8756d8225b6588c14276 as layer_618a8756d8225b6588c14276
import layer_618a8756d8225b6588c1427c as layer_618a8756d8225b6588c1427c
import layer_618a8756d8225b6588c14280 as layer_618a8756d8225b6588c14280
import layer_618a8756d8225b6588c1428c as layer_618a8756d8225b6588c1428c
import layer_618a8756d8225b6588c14296 as layer_618a8756d8225b6588c14296
import layer_618a8756d8225b6588c142a3 as layer_618a8756d8225b6588c142a3
import layer_618a8756d8225b6588c142a7 as layer_618a8756d8225b6588c142a7
import layer_618a8756d8225b6588c1427e as layer_618a8756d8225b6588c1427e
import layer_618a8756d8225b6588c14282 as layer_618a8756d8225b6588c14282
import layer_618a8756d8225b6588c14284 as layer_618a8756d8225b6588c14284
import layer_618a8756d8225b6588c14286 as layer_618a8756d8225b6588c14286
import layer_618a8756d8225b6588c142a5 as layer_618a8756d8225b6588c142a5
import layer_618a8756d8225b6588c142a9 as layer_618a8756d8225b6588c142a9
import layer_618a8756d8225b6588c142ab as layer_618a8756d8225b6588c142ab
import layer_618a8756d8225b6588c142ad as layer_618a8756d8225b6588c142ad
import layer_618a8756d8225b6588c142b1 as layer_618a8756d8225b6588c142b1
import layer_618a8756d8225b6588c142b5 as layer_618a8756d8225b6588c142b5
import layer_618a8756d8225b6588c142b3 as layer_618a8756d8225b6588c142b3
import layer_618a8756d8225b6588c142b7 as layer_618a8756d8225b6588c142b7
import layer_618a8756d8225b6588c142b9 as layer_618a8756d8225b6588c142b9
import layer_618a8756d8225b6588c142bb as layer_618a8756d8225b6588c142bb
import layer_618a8756d8225b6588c1429f as layer_618a8756d8225b6588c1429f
import layer_618a8756d8225b6588c14245 as layer_618a8756d8225b6588c14245
import layer_618a8756d8225b6588c14217 as layer_618a8756d8225b6588c14217
import layer_618a8756d8225b6588c1421b as layer_618a8756d8225b6588c1421b
import layer_618a8756d8225b6588c1421f as layer_618a8756d8225b6588c1421f
import layer_618a8756d8225b6588c14223 as layer_618a8756d8225b6588c14223
import layer_618a8756d8225b6588c14235 as layer_618a8756d8225b6588c14235
import layer_618a8756d8225b6588c14239 as layer_618a8756d8225b6588c14239
import layer_618a8756d8225b6588c1423b as layer_618a8756d8225b6588c1423b
import layer_618a8756d8225b6588c1423f as layer_618a8756d8225b6588c1423f
import layer_618a8756d8225b6588c14243 as layer_618a8756d8225b6588c14243
import layer_618a8756d8225b6588c14219 as layer_618a8756d8225b6588c14219
import layer_618a8756d8225b6588c14221 as layer_618a8756d8225b6588c14221
import layer_618a8756d8225b6588c14227 as layer_618a8756d8225b6588c14227
import layer_618a8756d8225b6588c1422b as layer_618a8756d8225b6588c1422b
import layer_618a8756d8225b6588c14237 as layer_618a8756d8225b6588c14237
import layer_618a8756d8225b6588c14241 as layer_618a8756d8225b6588c14241
import layer_618a8756d8225b6588c1424e as layer_618a8756d8225b6588c1424e
import layer_618a8756d8225b6588c14252 as layer_618a8756d8225b6588c14252
import layer_618a8756d8225b6588c14229 as layer_618a8756d8225b6588c14229
import layer_618a8756d8225b6588c1422d as layer_618a8756d8225b6588c1422d
import layer_618a8756d8225b6588c1422f as layer_618a8756d8225b6588c1422f
import layer_618a8756d8225b6588c14231 as layer_618a8756d8225b6588c14231
import layer_618a8756d8225b6588c14250 as layer_618a8756d8225b6588c14250
import layer_618a8756d8225b6588c14254 as layer_618a8756d8225b6588c14254
import layer_618a8756d8225b6588c14256 as layer_618a8756d8225b6588c14256
import layer_618a8756d8225b6588c14258 as layer_618a8756d8225b6588c14258
import layer_618a8756d8225b6588c1425c as layer_618a8756d8225b6588c1425c
import layer_618a8756d8225b6588c14260 as layer_618a8756d8225b6588c14260
import layer_618a8756d8225b6588c1425e as layer_618a8756d8225b6588c1425e
import layer_618a8756d8225b6588c14262 as layer_618a8756d8225b6588c14262
import layer_618a8756d8225b6588c14264 as layer_618a8756d8225b6588c14264
import layer_618a8756d8225b6588c14266 as layer_618a8756d8225b6588c14266
import layer_618a8756d8225b6588c1424a as layer_618a8756d8225b6588c1424a
import layer_618a8756d8225b6588c142c7 as layer_618a8756d8225b6588c142c7
import layer_618a8756d8225b6588c142cb as layer_618a8756d8225b6588c142cb
import layer_618a8756d8225b6588c142cd as layer_618a8756d8225b6588c142cd
import layer_618a8756d8225b6588c142cf as layer_618a8756d8225b6588c142cf
import layer_618a8756d8225b6588c142d3 as layer_618a8756d8225b6588c142d3
import layer_618a8756d8225b6588c142d5 as layer_618a8756d8225b6588c142d5
import layer_618a8756d8225b6588c142d7 as layer_618a8756d8225b6588c142d7
import layer_618a8756d8225b6588c142d9 as layer_618a8756d8225b6588c142d9
import layer_618a8756d8225b6588c142db as layer_618a8756d8225b6588c142db
import layer_618a8756d8225b6588c142dd as layer_618a8756d8225b6588c142dd
import layer_618a8756d8225b6588c142e1 as layer_618a8756d8225b6588c142e1
import layer_618a8756d8225b6588c142e3 as layer_618a8756d8225b6588c142e3
import layer_618a8756d8225b6588c142e5 as layer_618a8756d8225b6588c142e5
import layer_618a8756d8225b6588c142e7 as layer_618a8756d8225b6588c142e7
import layer_618a8756d8225b6588c142c1 as layer_618a8756d8225b6588c142c1
import layer_618a8756d8225b6588c142c3 as layer_618a8756d8225b6588c142c3
import layer_618a8756d8225b6588c142c5 as layer_618a8756d8225b6588c142c5
import layer_618a8756d8225b6588c142ef as layer_618a8756d8225b6588c142ef
import layer_618a8756d8225b6588c142f1 as layer_618a8756d8225b6588c142f1
import layer_618a8756d8225b6588c142f3 as layer_618a8756d8225b6588c142f3
import layer_618a8756d8225b6588c142eb as layer_618a8756d8225b6588c142eb
import layer_618a8756d8225b6588c142ff as layer_618a8756d8225b6588c142ff
import layer_618a8756d8225b6588c14303 as layer_618a8756d8225b6588c14303
import layer_618a8756d8225b6588c14305 as layer_618a8756d8225b6588c14305
import layer_618a8756d8225b6588c14307 as layer_618a8756d8225b6588c14307
import layer_618a8756d8225b6588c1430b as layer_618a8756d8225b6588c1430b
import layer_618a8756d8225b6588c1430d as layer_618a8756d8225b6588c1430d
import layer_618a8756d8225b6588c1430f as layer_618a8756d8225b6588c1430f
import layer_618a8756d8225b6588c14313 as layer_618a8756d8225b6588c14313
import layer_618a8756d8225b6588c14315 as layer_618a8756d8225b6588c14315
import layer_618a8756d8225b6588c14317 as layer_618a8756d8225b6588c14317
import layer_618a8756d8225b6588c1431a as layer_618a8756d8225b6588c1431a
import layer_618a8756d8225b6588c1431e as layer_618a8756d8225b6588c1431e
import layer_618a8756d8225b6588c14320 as layer_618a8756d8225b6588c14320
import layer_618a8756d8225b6588c14322 as layer_618a8756d8225b6588c14322
import layer_618a8756d8225b6588c14326 as layer_618a8756d8225b6588c14326
import layer_618a8756d8225b6588c14328 as layer_618a8756d8225b6588c14328
import layer_618a8756d8225b6588c1432a as layer_618a8756d8225b6588c1432a
import layer_618a8756d8225b6588c1432e as layer_618a8756d8225b6588c1432e
import layer_618a8756d8225b6588c14330 as layer_618a8756d8225b6588c14330
import layer_618a8756d8225b6588c14332 as layer_618a8756d8225b6588c14332
import layer_618a8756d8225b6588c14336 as layer_618a8756d8225b6588c14336
import layer_618a8756d8225b6588c14338 as layer_618a8756d8225b6588c14338
import layer_618a8756d8225b6588c1433a as layer_618a8756d8225b6588c1433a
import layer_618a8756d8225b6588c1433d as layer_618a8756d8225b6588c1433d
import layer_618a8756d8225b6588c1433f as layer_618a8756d8225b6588c1433f
import layer_618a8756d8225b6588c14343 as layer_618a8756d8225b6588c14343
import layer_618a8756d8225b6588c14345 as layer_618a8756d8225b6588c14345
import layer_618a8756d8225b6588c14347 as layer_618a8756d8225b6588c14347
import layer_618a8756d8225b6588c142f9 as layer_618a8756d8225b6588c142f9
import layer_618a8756d8225b6588c142fb as layer_618a8756d8225b6588c142fb
import layer_618a8756d8225b6588c142fd as layer_618a8756d8225b6588c142fd
import layer_618a8756d8225b6588c1434c as layer_618a8756d8225b6588c1434c
import layer_618a8756d8225b6588c14358 as layer_618a8756d8225b6588c14358
import layer_618a8756d8225b6588c1435c as layer_618a8756d8225b6588c1435c
import layer_618a8756d8225b6588c1435e as layer_618a8756d8225b6588c1435e
import layer_618a8756d8225b6588c14360 as layer_618a8756d8225b6588c14360
import layer_618a8756d8225b6588c14364 as layer_618a8756d8225b6588c14364
import layer_618a8756d8225b6588c14366 as layer_618a8756d8225b6588c14366
import layer_618a8756d8225b6588c14368 as layer_618a8756d8225b6588c14368
import layer_618a8756d8225b6588c1436c as layer_618a8756d8225b6588c1436c
import layer_618a8756d8225b6588c1436e as layer_618a8756d8225b6588c1436e
import layer_618a8756d8225b6588c14370 as layer_618a8756d8225b6588c14370
import layer_618a8756d8225b6588c14373 as layer_618a8756d8225b6588c14373
import layer_618a8756d8225b6588c14377 as layer_618a8756d8225b6588c14377
import layer_618a8756d8225b6588c14379 as layer_618a8756d8225b6588c14379
import layer_618a8756d8225b6588c1437b as layer_618a8756d8225b6588c1437b
import layer_618a8756d8225b6588c1437f as layer_618a8756d8225b6588c1437f
import layer_618a8756d8225b6588c14381 as layer_618a8756d8225b6588c14381
import layer_618a8756d8225b6588c14383 as layer_618a8756d8225b6588c14383
import layer_618a8756d8225b6588c14387 as layer_618a8756d8225b6588c14387
import layer_618a8756d8225b6588c14389 as layer_618a8756d8225b6588c14389
import layer_618a8756d8225b6588c1438b as layer_618a8756d8225b6588c1438b
import layer_618a8756d8225b6588c1438f as layer_618a8756d8225b6588c1438f
import layer_618a8756d8225b6588c14391 as layer_618a8756d8225b6588c14391
import layer_618a8756d8225b6588c14393 as layer_618a8756d8225b6588c14393
import layer_618a8756d8225b6588c14396 as layer_618a8756d8225b6588c14396
import layer_618a8756d8225b6588c14398 as layer_618a8756d8225b6588c14398
import layer_618a8756d8225b6588c1439c as layer_618a8756d8225b6588c1439c
import layer_618a8756d8225b6588c1439e as layer_618a8756d8225b6588c1439e
import layer_618a8756d8225b6588c143a0 as layer_618a8756d8225b6588c143a0
import layer_618a8756d8225b6588c14352 as layer_618a8756d8225b6588c14352
import layer_618a8756d8225b6588c14354 as layer_618a8756d8225b6588c14354
import layer_618a8756d8225b6588c14356 as layer_618a8756d8225b6588c14356
import layer_618a8756d8225b6588c143a5 as layer_618a8756d8225b6588c143a5
import layer_618a8756d8225b6588c143a7 as layer_618a8756d8225b6588c143a7
import layer_618a8756d8225b6588c143ab as layer_618a8756d8225b6588c143ab
import layer_618a8756d8225b6588c143a9 as layer_618a8756d8225b6588c143a9


def get_layer_object(module):
    for member in getmembers(module):
        if member[1].__module__ == module.__name__:
            return member[1]

def get_loss_sum_fn(list_loss):
    def LossSum(y_true, y_pred):
        loss = 0
        for loss_fn in list_loss:
            loss += loss_fn(y_true, y_pred)
        return loss

    return LossSum

class Model(BaseModel):
    def __init__(self, *args, **kwargs):
        super(Model, self).__init__(*args, **kwargs)
        self.path_weight = file_path + "/weight.hdf5"
        inputs, outputs, losses, labels = self.build_source()
        self.compile(inputs, outputs, losses, labels)

    def build_source(self):
        config_loss = dict()
        volume = 64
        height = 64
        width = 64
        channels = 3
        num_class = 7
        output_channels = 1
        batch_size = 1

        n1_Image = layer_618a8756d8225b6588c1405e.Image(shape=[64, 64, 3])
        n2_Backbone_n1_Conv2D = layer_618a8756d8225b6588c14062.Conv2D(filters=32, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n1_Image)
        n2_Backbone_n3_BatchNormalization = layer_618a8756d8225b6588c14066.BatchNormalization()(n2_Backbone_n1_Conv2D)
        n2_Backbone_n2_Activation = layer_618a8756d8225b6588c14064.Activation(activation='relu')(n2_Backbone_n3_BatchNormalization)
        n2_Backbone_n4_Conv2D = layer_618a8756d8225b6588c14068.Conv2D(filters=32, kernel_size=[3, 3], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n2_Activation)
        n2_Backbone_n5_BatchNormalization = layer_618a8756d8225b6588c1406a.BatchNormalization()(n2_Backbone_n4_Conv2D)
        n2_Backbone_n6_Activation = layer_618a8756d8225b6588c1406c.Activation(activation='relu')(n2_Backbone_n5_BatchNormalization)
        n2_Backbone_n7_Conv2D = layer_618a8756d8225b6588c1406e.Conv2D(filters=64, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n6_Activation)
        n2_Backbone_n8_BatchNormalization = layer_618a8756d8225b6588c14070.BatchNormalization()(n2_Backbone_n7_Conv2D)
        n2_Backbone_n9_Activation = layer_618a8756d8225b6588c14072.Activation(activation='relu')(n2_Backbone_n8_BatchNormalization)
        n2_Backbone_n10_MaxPooling2D = layer_618a8756d8225b6588c14074.MaxPooling2D(pool_size=[2, 2], strides=[2, 2], padding='valid')(n2_Backbone_n9_Activation)
        n2_Backbone_n11_mixed_0_n9_Activation = layer_618a8756d8225b6588c140b2.Activation(activation='linear')(n2_Backbone_n10_MaxPooling2D)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1407a.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1407e.BatchNormalization()(n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14082.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14086.BatchNormalization()(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14092.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14096.BatchNormalization()(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n7_AveragePooling2D = layer_618a8756d8225b6588c140a8.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n11_mixed_0_n9_Activation)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140ac.Conv2D(filters=32, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140b0.BatchNormalization()(n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1407c.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14084.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1408a.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1408e.BatchNormalization()(n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14094.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1409a.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1409e.BatchNormalization()(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140ae.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1408c.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1409c.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140a2.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n11_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140a6.BatchNormalization()(n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140a4.Activation(activation='relu')(n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c140b7.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n11_mixed_0_n10_Concatenate = layer_618a8756d8225b6588c140b7.Concatenate(axis=-1)([n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n11_mixed_0_n10_Concatenate = layer_618a8756d8225b6588c140b7.Concatenate(axis=-1)(*[n2_Backbone_n11_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n11_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n12_mixed_0_n9_Activation = layer_618a8756d8225b6588c140f5.Activation(activation='linear')(n2_Backbone_n11_mixed_0_n10_Concatenate)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140bd.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140c1.BatchNormalization()(n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140c5.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140c9.BatchNormalization()(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140d5.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140d9.BatchNormalization()(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n7_AveragePooling2D = layer_618a8756d8225b6588c140eb.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n12_mixed_0_n9_Activation)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140ef.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140f3.BatchNormalization()(n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140bf.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140c7.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140cd.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140d1.BatchNormalization()(n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140d7.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140dd.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140e1.BatchNormalization()(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140f1.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140cf.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140df.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c140e5.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n12_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c140e9.BatchNormalization()(n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c140e7.Activation(activation='relu')(n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c140fa.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n12_mixed_0_n10_Concatenate = layer_618a8756d8225b6588c140fa.Concatenate(axis=-1)([n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n12_mixed_0_n10_Concatenate = layer_618a8756d8225b6588c140fa.Concatenate(axis=-1)(*[n2_Backbone_n12_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n12_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n13_mixed_0_n9_Activation = layer_618a8756d8225b6588c14138.Activation(activation='linear')(n2_Backbone_n12_mixed_0_n10_Concatenate)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14100.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14104.BatchNormalization()(n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14108.Conv2D(filters=48, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1410c.BatchNormalization()(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14118.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1411c.BatchNormalization()(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n7_AveragePooling2D = layer_618a8756d8225b6588c1412e.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n13_mixed_0_n9_Activation)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14132.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n7_AveragePooling2D)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14136.BatchNormalization()(n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14102.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1410a.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14110.Conv2D(filters=64, kernel_size=[5, 5], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14114.BatchNormalization()(n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1411a.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14120.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14124.BatchNormalization()(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14134.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14112.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14122.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14128.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n13_mixed_0_n5_Conv2D_BN_n2_Activation)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1412c.BatchNormalization()(n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1412a.Activation(activation='relu')(n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c1413d.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n13_mixed_0_n10_Concatenate = layer_618a8756d8225b6588c1413d.Concatenate(axis=-1)([n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation])
        else:
            n2_Backbone_n13_mixed_0_n10_Concatenate = layer_618a8756d8225b6588c1413d.Concatenate(axis=-1)(*[n2_Backbone_n13_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n3_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n13_mixed_0_n8_Conv2D_BN_n2_Activation])
        n2_Backbone_n14_mixed_3_n2_Activation = layer_618a8756d8225b6588c14149.Activation(activation='linear')(n2_Backbone_n13_mixed_0_n10_Concatenate)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1414d.Conv2D(filters=64, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c1414f.BatchNormalization()(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14151.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14155.Conv2D(filters=96, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14157.BatchNormalization()(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14159.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1415d.Conv2D(filters=96, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n4_Conv2D_BN_n3_Activation)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c1415f.BatchNormalization()(n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14161.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n14_mixed_3_n6_MaxPooling2D = layer_618a8756d8225b6588c14163.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='valid')(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14143.Conv2D(filters=384, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n14_mixed_3_n2_Activation)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14145.BatchNormalization()(n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14147.Activation(activation='relu')(n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c14167.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n14_mixed_3_n7_Concatenate = layer_618a8756d8225b6588c14167.Concatenate(axis=-1)([n2_Backbone_n14_mixed_3_n6_MaxPooling2D, n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation, n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n14_mixed_3_n7_Concatenate = layer_618a8756d8225b6588c14167.Concatenate(axis=-1)(*[n2_Backbone_n14_mixed_3_n6_MaxPooling2D, n2_Backbone_n14_mixed_3_n1_Conv2D_BN_n3_Activation, n2_Backbone_n14_mixed_3_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n15_mixed_0_n7_Activation = layer_618a8756d8225b6588c1419b.Activation(activation='linear')(n2_Backbone_n14_mixed_3_n7_Concatenate)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1416d.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14171.BatchNormalization()(n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14175.Conv2D(filters=128, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14179.BatchNormalization()(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1418b.Conv2D(filters=128, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1418f.BatchNormalization()(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n5_AveragePooling2D = layer_618a8756d8225b6588c14191.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n15_mixed_0_n7_Activation)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14195.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14199.BatchNormalization()(n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1416f.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14177.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1417d.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14181.BatchNormalization()(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1418d.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14197.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c141a4.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c141a8.BatchNormalization()(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1417f.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c14183.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c14185.BatchNormalization()(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c14187.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c141a6.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c141aa.Conv2D(filters=128, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c141ac.BatchNormalization()(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c141ae.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c141b2.Conv2D(filters=128, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c141b6.BatchNormalization()(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c141b4.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c141b8.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c141ba.BatchNormalization()(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c141bc.Activation(activation='relu')(n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c141a0.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n15_mixed_0_n8_Concatenate = layer_618a8756d8225b6588c141a0.Concatenate(axis=-1)([n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n15_mixed_0_n8_Concatenate = layer_618a8756d8225b6588c141a0.Concatenate(axis=-1)(*[n2_Backbone_n15_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n15_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n15_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n16_mixed_0_n7_Activation = layer_618a8756d8225b6588c141f0.Activation(activation='linear')(n2_Backbone_n15_mixed_0_n8_Concatenate)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c141c2.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c141c6.BatchNormalization()(n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c141ca.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c141ce.BatchNormalization()(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c141e0.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c141e4.BatchNormalization()(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n5_AveragePooling2D = layer_618a8756d8225b6588c141e6.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n16_mixed_0_n7_Activation)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c141ea.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c141ee.BatchNormalization()(n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c141c4.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c141cc.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c141d2.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c141d6.BatchNormalization()(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c141e2.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c141ec.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c141f9.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c141fd.BatchNormalization()(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c141d4.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c141d8.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c141da.BatchNormalization()(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c141dc.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c141fb.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c141ff.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c14201.BatchNormalization()(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c14203.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14207.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1420b.BatchNormalization()(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14209.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c1420d.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c1420f.BatchNormalization()(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c14211.Activation(activation='relu')(n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c141f5.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n16_mixed_0_n8_Concatenate = layer_618a8756d8225b6588c141f5.Concatenate(axis=-1)([n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n16_mixed_0_n8_Concatenate = layer_618a8756d8225b6588c141f5.Concatenate(axis=-1)(*[n2_Backbone_n16_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n16_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n16_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n18_mixed_0_n7_Activation = layer_618a8756d8225b6588c1429a.Activation(activation='linear')(n2_Backbone_n16_mixed_0_n8_Concatenate)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1426c.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14270.BatchNormalization()(n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14274.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14278.BatchNormalization()(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1428a.Conv2D(filters=160, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1428e.BatchNormalization()(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n5_AveragePooling2D = layer_618a8756d8225b6588c14290.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n18_mixed_0_n7_Activation)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14294.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14298.BatchNormalization()(n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1426e.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14276.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1427c.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14280.BatchNormalization()(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1428c.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14296.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c142a3.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c142a7.BatchNormalization()(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1427e.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c14282.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c14284.BatchNormalization()(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c14286.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c142a5.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c142a9.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c142ab.BatchNormalization()(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c142ad.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c142b1.Conv2D(filters=160, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c142b5.BatchNormalization()(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c142b3.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c142b7.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c142b9.BatchNormalization()(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c142bb.Activation(activation='relu')(n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c1429f.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n18_mixed_0_n8_Concatenate = layer_618a8756d8225b6588c1429f.Concatenate(axis=-1)([n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n18_mixed_0_n8_Concatenate = layer_618a8756d8225b6588c1429f.Concatenate(axis=-1)(*[n2_Backbone_n18_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n18_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n18_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n17_mixed_0_n7_Activation = layer_618a8756d8225b6588c14245.Activation(activation='linear')(n2_Backbone_n18_mixed_0_n8_Concatenate)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14217.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1421b.BatchNormalization()(n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1421f.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14223.BatchNormalization()(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14235.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14239.BatchNormalization()(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n5_AveragePooling2D = layer_618a8756d8225b6588c1423b.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n17_mixed_0_n7_Activation)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1423f.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n5_AveragePooling2D)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14243.BatchNormalization()(n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14219.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14221.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14227.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n2_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c1422b.BatchNormalization()(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14237.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14241.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1424e.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n4_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14252.BatchNormalization()(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14229.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c1422d.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c1422f.BatchNormalization()(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c14231.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c14250.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c14254.Conv2D(filters=160, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c14256.BatchNormalization()(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c14258.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1425c.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n9_Conv2D_BN_n6_Activation)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n3_BatchNormalization = layer_618a8756d8225b6588c14260.BatchNormalization()(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n2_Activation = layer_618a8756d8225b6588c1425e.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n3_BatchNormalization)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c14262.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n2_Activation)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c14264.BatchNormalization()(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c14266.Activation(activation='relu')(n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n5_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c1424a.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n17_mixed_0_n8_Concatenate = layer_618a8756d8225b6588c1424a.Concatenate(axis=-1)([n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation])
        else:
            n2_Backbone_n17_mixed_0_n8_Concatenate = layer_618a8756d8225b6588c1424a.Concatenate(axis=-1)(*[n2_Backbone_n17_mixed_0_n1_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n6_Conv2D_BN_n2_Activation, n2_Backbone_n17_mixed_0_n3_Conv2D_BN_n6_Activation, n2_Backbone_n17_mixed_0_n10_Conv2D_BN_n6_Activation])
        n2_Backbone_n19_mixed_3_n2_Activation = layer_618a8756d8225b6588c142c7.Activation(activation='linear')(n2_Backbone_n17_mixed_0_n8_Concatenate)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c142cb.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c142cd.BatchNormalization()(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c142cf.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c142d3.Conv2D(filters=192, kernel_size=[1, 7], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c142d5.BatchNormalization()(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c142d7.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n4_Conv2D = layer_618a8756d8225b6588c142d9.Conv2D(filters=192, kernel_size=[7, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n5_BatchNormalization = layer_618a8756d8225b6588c142db.BatchNormalization()(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n4_Conv2D)
        n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n6_Activation = layer_618a8756d8225b6588c142dd.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n5_BatchNormalization)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c142e1.Conv2D(filters=192, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n4_Conv2D_BN_n6_Activation)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c142e3.BatchNormalization()(n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c142e5.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n6_MaxPooling2D = layer_618a8756d8225b6588c142e7.MaxPooling2D(pool_size=[3, 3], strides=[2, 2], padding='valid')(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c142c1.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n2_Activation)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c142c3.BatchNormalization()(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c142c5.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c142ef.Conv2D(filters=320, kernel_size=[3, 3], strides=[2, 2], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n19_mixed_3_n1_Conv2D_BN_n3_Activation)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c142f1.BatchNormalization()(n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c142f3.Activation(activation='relu')(n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c142eb.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n19_mixed_3_n7_Concatenate = layer_618a8756d8225b6588c142eb.Concatenate(axis=-1)([n2_Backbone_n19_mixed_3_n6_MaxPooling2D, n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation, n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n19_mixed_3_n7_Concatenate = layer_618a8756d8225b6588c142eb.Concatenate(axis=-1)(*[n2_Backbone_n19_mixed_3_n6_MaxPooling2D, n2_Backbone_n19_mixed_3_n5_Conv2D_BN_n3_Activation, n2_Backbone_n19_mixed_3_n8_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n2_Activation = layer_618a8756d8225b6588c142ff.Activation(activation='linear')(n2_Backbone_n19_mixed_3_n7_Concatenate)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14303.Conv2D(filters=384, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14305.BatchNormalization()(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14307.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1430b.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c1430d.BatchNormalization()(n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c1430f.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14313.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14315.BatchNormalization()(n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14317.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c1431a.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n6_Concatenate = layer_618a8756d8225b6588c1431a.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n6_Concatenate = layer_618a8756d8225b6588c1431a.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1431e.Conv2D(filters=448, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14320.BatchNormalization()(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14322.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14326.Conv2D(filters=384, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n7_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14328.BatchNormalization()(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c1432a.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1432e.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14330.BatchNormalization()(n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14332.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14336.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14338.BatchNormalization()(n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c1433a.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c1433d.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n11_Concatenate = layer_618a8756d8225b6588c1433d.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n11_Concatenate = layer_618a8756d8225b6588c1433d.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n9_Conv2D_BN_n3_Activation])
        n2_Backbone_n20_mixed_9_n12_AveragePooling2D = layer_618a8756d8225b6588c1433f.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14343.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n12_AveragePooling2D)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14345.BatchNormalization()(n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14347.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c142f9.Conv2D(filters=320, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n20_mixed_9_n2_Activation)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c142fb.BatchNormalization()(n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c142fd.Activation(activation='relu')(n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c1434c.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n20_mixed_9_n14_Concatenate = layer_618a8756d8225b6588c1434c.Concatenate(axis=-1)([n2_Backbone_n20_mixed_9_n6_Concatenate, n2_Backbone_n20_mixed_9_n11_Concatenate, n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n20_mixed_9_n14_Concatenate = layer_618a8756d8225b6588c1434c.Concatenate(axis=-1)(*[n2_Backbone_n20_mixed_9_n6_Concatenate, n2_Backbone_n20_mixed_9_n11_Concatenate, n2_Backbone_n20_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n20_mixed_9_n13_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n2_Activation = layer_618a8756d8225b6588c14358.Activation(activation='linear')(n2_Backbone_n20_mixed_9_n14_Concatenate)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1435c.Conv2D(filters=384, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c1435e.BatchNormalization()(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14360.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14364.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14366.BatchNormalization()(n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14368.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1436c.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n3_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c1436e.BatchNormalization()(n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14370.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c14373.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n6_Concatenate = layer_618a8756d8225b6588c14373.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n6_Concatenate = layer_618a8756d8225b6588c14373.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n4_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n5_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14377.Conv2D(filters=448, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14379.BatchNormalization()(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c1437b.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1437f.Conv2D(filters=384, kernel_size=[3, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n7_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14381.BatchNormalization()(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14383.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14387.Conv2D(filters=384, kernel_size=[3, 1], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14389.BatchNormalization()(n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c1438b.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1438f.Conv2D(filters=384, kernel_size=[1, 3], strides=[1, 1], padding='same', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n8_Conv2D_BN_n3_Activation)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14391.BatchNormalization()(n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14393.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c14396.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n11_Concatenate = layer_618a8756d8225b6588c14396.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n11_Concatenate = layer_618a8756d8225b6588c14396.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n10_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n9_Conv2D_BN_n3_Activation])
        n2_Backbone_n21_mixed_9_n12_AveragePooling2D = layer_618a8756d8225b6588c14398.AveragePooling2D(pool_size=[3, 3], strides=[1, 1], padding='same')(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c1439c.Conv2D(filters=192, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n12_AveragePooling2D)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c1439e.BatchNormalization()(n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c143a0.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n2_BatchNormalization)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n1_Conv2D = layer_618a8756d8225b6588c14352.Conv2D(filters=320, kernel_size=[1, 1], strides=[1, 1], padding='valid', dilation_rate=[1, 1], activation=None, use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n2_Backbone_n21_mixed_9_n2_Activation)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n2_BatchNormalization = layer_618a8756d8225b6588c14354.BatchNormalization()(n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n1_Conv2D)
        n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation = layer_618a8756d8225b6588c14356.Activation(activation='relu')(n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n2_BatchNormalization)
        num_args = len(inspect.getfullargspec(layer_618a8756d8225b6588c143a5.Concatenate(axis=-1).call).args)
        if num_args == 2:
            n2_Backbone_n21_mixed_9_n14_Concatenate = layer_618a8756d8225b6588c143a5.Concatenate(axis=-1)([n2_Backbone_n21_mixed_9_n6_Concatenate, n2_Backbone_n21_mixed_9_n11_Concatenate, n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation])
        else:
            n2_Backbone_n21_mixed_9_n14_Concatenate = layer_618a8756d8225b6588c143a5.Concatenate(axis=-1)(*[n2_Backbone_n21_mixed_9_n6_Concatenate, n2_Backbone_n21_mixed_9_n11_Concatenate, n2_Backbone_n21_mixed_9_n1_Conv2D_BN_n3_Activation, n2_Backbone_n21_mixed_9_n13_Conv2D_BN_n3_Activation])
        n3_GlobalAveragePooling2D = layer_618a8756d8225b6588c143a7.GlobalAveragePooling2D()(n2_Backbone_n21_mixed_9_n14_Concatenate)
        n9_Dropout = layer_618a8756d8225b6588c143ab.Dropout(rate=0.5)(n3_GlobalAveragePooling2D)
        n4_Dense = layer_618a8756d8225b6588c143a9.Dense(units=7, activation='softmax', use_bias=False, kernel_initializer='glorot_uniform', bias_initializer='Zeros', kernel_regularizer=None, bias_regularizer=None, activity_regularizer=None, kernel_constraint=None, bias_constraint=None)(n9_Dropout)
        label = keras.layers.Input(shape=[7])
        loss = keras.losses.CategoricalCrossentropy()(label, n4_Dense)
        



        for key in list(config_loss.keys()):
            if len(config_loss[key]) == 1:
                config_loss[key] = config_loss[key][0]
            elif len(config_loss[key]) > 1:
                config_loss[key] = get_loss_sum_fn(config_loss[key])
            else:
                del config_loss[key]
        inputs = [n1_Image]
        outputs = [n4_Dense]
        losses = [loss]
        labels = [label]

        return inputs, outputs, losses, labels

